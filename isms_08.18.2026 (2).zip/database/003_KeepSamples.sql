-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 003: Keep Sample Boxes, Items, Requests, and Returns
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- 1. Keep Sample Physical Storage Boxes
IF OBJECT_ID(N'[qms].[KeepSampleBoxes]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[KeepSampleBoxes] (
        [BoxId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [BoxNumber] NVARCHAR(50) NOT NULL UNIQUE, -- e.g. 26-08-001-1F
        [Factory] NVARCHAR(20) NOT NULL, -- '1F' or '2F'
        [Department] NVARCHAR(50) NOT NULL DEFAULT 'QM',
        [Section] NVARCHAR(50) NOT NULL,
        [ItemDescription] NVARCHAR(255) NOT NULL,
        [Quantity] INT NOT NULL DEFAULT 0,
        [DateReceived] DATE NOT NULL,
        [ExpirationDate] DATE NOT NULL,
        [RetentionPeriodYears] INT NOT NULL DEFAULT 3,
        [Status] NVARCHAR(30) NOT NULL DEFAULT 'ACTIVE', -- ACTIVE, FOR CHECKING, EXPIRED, DISPOSED
        [ArchiveType] NVARCHAR(30) NOT NULL DEFAULT '3-Year Standard',
        [RackLocation] NVARCHAR(50) NOT NULL,
        [RequestedBy] NVARCHAR(100) NOT NULL,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [CreatedByUserId] NVARCHAR(64) NULL,
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [RowVersion] ROWVERSION NOT NULL
    );
END
GO

-- 2. Keep Sample Items Inside Box
IF OBJECT_ID(N'[qms].[KeepSampleBoxItems]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[KeepSampleBoxItems] (
        [ItemId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [BoxId] NVARCHAR(64) NOT NULL FOREIGN KEY REFERENCES [qms].[KeepSampleBoxes]([BoxId]) ON DELETE CASCADE,
        [DrawingNumber] NVARCHAR(100) NOT NULL,
        [ItemName] NVARCHAR(200) NOT NULL,
        [LotNumber] NVARCHAR(100) NOT NULL,
        [TerminalPartNumber] NVARCHAR(100) NULL,
        [Quantity] INT NOT NULL DEFAULT 1,
        [Remarks] NVARCHAR(500) NULL,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()
    );
END
GO

-- 3. Keep Sample Borrow Requests (BKS Workflow)
IF OBJECT_ID(N'[qms].[KeepSampleRequests]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[KeepSampleRequests] (
        [RequestId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [ControlNo] NVARCHAR(50) NOT NULL UNIQUE, -- e.g. BKS-2608-0001
        [BoxId] NVARCHAR(64) NULL FOREIGN KEY REFERENCES [qms].[KeepSampleBoxes]([BoxId]),
        [BoxNumber] NVARCHAR(50) NOT NULL,
        [Factory] NVARCHAR(20) NOT NULL,
        [Department] NVARCHAR(50) NOT NULL,
        [RequestorId] NVARCHAR(64) NULL,
        [RequestorName] NVARCHAR(100) NOT NULL,
        [RequestorEmail] NVARCHAR(150) NOT NULL,
        [DateNeeded] DATE NOT NULL,
        [ReturnedDueDate] DATE NOT NULL,
        [ActualReturnedDate] DATE NULL,
        [Status] NVARCHAR(50) NOT NULL DEFAULT 'Unreturned', -- Unreturned, Returned To Original Box, For Filing the UKS
        [ReasonForBorrowing] NVARCHAR(500) NOT NULL,
        [QMApprovedBy] NVARCHAR(100) NULL,
        [QMApprovalDate] DATETIMEOFFSET NULL,
        [QCHoldReleasedBy] NVARCHAR(100) NULL,
        [QCHoldReleaseDate] DATETIMEOFFSET NULL,
        [QAInvestigatedBy] NVARCHAR(100) NULL,
        [QADispositionResult] NVARCHAR(500) NULL,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [RowVersion] ROWVERSION NOT NULL
    );
END
GO

-- 4. Items in Borrow Request
IF OBJECT_ID(N'[qms].[KeepSampleRequestItems]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[KeepSampleRequestItems] (
        [RequestItemId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [RequestId] NVARCHAR(64) NOT NULL FOREIGN KEY REFERENCES [qms].[KeepSampleRequests]([RequestId]) ON DELETE CASCADE,
        [DrawingNumber] NVARCHAR(100) NOT NULL,
        [ItemName] NVARCHAR(200) NOT NULL,
        [LotNumber] NVARCHAR(100) NOT NULL,
        [Quantity] INT NOT NULL DEFAULT 1,
        [ReturnStatus] NVARCHAR(50) NOT NULL DEFAULT 'BORROWED'
    );
END
GO

PRINT 'Script 003 executed: Keep Sample schema created successfully.';
