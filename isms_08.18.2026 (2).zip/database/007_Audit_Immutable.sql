-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 007: Immutable Cryptographic Audit Trail, SHA-256 Hash Chain & Sequence Engine
-- Compliance: IATF 16949 §7.5.3.2.1 (Record Retention & Tamper Resistance)
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- 1. Concurrency-Safe Atomic Control Number Sequence Engine
IF OBJECT_ID(N'[qms].[DocumentSequences]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[DocumentSequences] (
        [SequencePrefix] NVARCHAR(20) NOT NULL, -- 'BKS', 'RISR', 'BOX-1F', 'BOX-2F'
        [YearMonth] NVARCHAR(6) NOT NULL, -- e.g. '2608'
        [CurrentValue] INT NOT NULL DEFAULT 0,
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        CONSTRAINT PK_DocumentSequences PRIMARY KEY ([SequencePrefix], [YearMonth])
    );
END
GO

-- Stored Procedure to atomically generate consecutive sequence numbers without gaps or collisions
IF OBJECT_ID(N'[qms].[usp_GetNextControlNumber]', N'P') IS NOT NULL
    DROP PROCEDURE [qms].[usp_GetNextControlNumber];
GO

CREATE PROCEDURE [qms].[usp_GetNextControlNumber]
    @Prefix NVARCHAR(20),
    @YearMonth NVARCHAR(6),
    @GeneratedControlNo NVARCHAR(50) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @NextNum INT;

    MERGE [qms].[DocumentSequences] WITH (ROWLOCK, HOLDLOCK) AS Target
    USING (SELECT @Prefix AS SequencePrefix, @YearMonth AS YearMonth) AS Source
    ON (Target.SequencePrefix = Source.SequencePrefix AND Target.YearMonth = Source.YearMonth)
    WHEN MATCHED THEN
        UPDATE SET Target.CurrentValue = Target.CurrentValue + 1, Target.UpdatedAt = SYSDATETIMEOFFSET()
    WHEN NOT MATCHED THEN
        INSERT (SequencePrefix, YearMonth, CurrentValue, UpdatedAt)
        VALUES (Source.SequencePrefix, Source.YearMonth, 1, SYSDATETIMEOFFSET());

    SELECT @NextNum = CurrentValue 
    FROM [qms].[DocumentSequences] 
    WHERE SequencePrefix = @Prefix AND YearMonth = @YearMonth;

    IF @Prefix = 'BKS'
        SET @GeneratedControlNo = 'BKS-' + @YearMonth + '-' + RIGHT('0000' + CAST(@NextNum AS VARCHAR(10)), 4);
    ELSE IF @Prefix = 'RISR'
        SET @GeneratedControlNo = 'RISR-' + @YearMonth + '-' + RIGHT('0000' + CAST(@NextNum AS VARCHAR(10)), 4);
    ELSE
        SET @GeneratedControlNo = @Prefix + '-' + @YearMonth + '-' + RIGHT('000' + CAST(@NextNum AS VARCHAR(10)), 3);
END
GO

-- 2. Server-Side Immutable Audit Trail with Cryptographic Verification
IF OBJECT_ID(N'[audit].[AuditLogs]', N'U') IS NULL
BEGIN
    CREATE TABLE [audit].[AuditLogs] (
        [AuditId] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [CorrelationId] NVARCHAR(64) NOT NULL, -- Group related operations in single HTTP request
        [Timestamp] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [ActorUserId] NVARCHAR(64) NULL,
        [ActorEmployeeId] NVARCHAR(50) NOT NULL,
        [ActorName] NVARCHAR(100) NOT NULL,
        [ActorRole] NVARCHAR(50) NOT NULL,
        [Module] NVARCHAR(100) NOT NULL,
        [Action] NVARCHAR(100) NOT NULL,
        [RecordId] NVARCHAR(100) NOT NULL,
        [Details] NVARCHAR(MAX) NOT NULL,
        [PreviousValues] NVARCHAR(MAX) NULL, -- JSON snapshot of pre-state
        [NewValues] NVARCHAR(MAX) NULL,      -- JSON snapshot of post-state
        [IpAddress] NVARCHAR(45) NOT NULL,
        [UserAgent] NVARCHAR(255) NULL,
        [PreviousBlockHash] NVARCHAR(64) NULL, -- Cryptographic hash chain
        [CurrentBlockHash] NVARCHAR(64) NOT NULL
    );
END
GO

-- Stored Procedure to insert audit entry with SHA-256 hash calculation
IF OBJECT_ID(N'[audit].[usp_InsertAuditLog]', N'P') IS NOT NULL
    DROP PROCEDURE [audit].[usp_InsertAuditLog];
GO

CREATE PROCEDURE [audit].[usp_InsertAuditLog]
    @CorrelationId NVARCHAR(64),
    @ActorUserId NVARCHAR(64),
    @ActorEmployeeId NVARCHAR(50),
    @ActorName NVARCHAR(100),
    @ActorRole NVARCHAR(50),
    @Module NVARCHAR(100),
    @Action NVARCHAR(100),
    @RecordId NVARCHAR(100),
    @Details NVARCHAR(MAX),
    @PreviousValues NVARCHAR(MAX),
    @NewValues NVARCHAR(MAX),
    @IpAddress NVARCHAR(45),
    @UserAgent NVARCHAR(255)
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @PrevHash NVARCHAR(64);
    DECLARE @Payload NVARCHAR(MAX);
    DECLARE @CurrentHash NVARCHAR(64);

    -- Fetch the hash of the latest audit record
    SELECT TOP 1 @PrevHash = CurrentBlockHash 
    FROM [audit].[AuditLogs] 
    ORDER BY AuditId DESC;

    SET @PrevHash = ISNULL(@PrevHash, 'GENESIS_BLOCK_JAE_ISMS_2026');
    
    SET @Payload = @PrevHash + '|' + @ActorEmployeeId + '|' + @Module + '|' + @Action + '|' + @RecordId + '|' + CAST(SYSDATETIMEOFFSET() AS VARCHAR(50)) + '|' + @Details;
    SET @CurrentHash = CONVERT(NVARCHAR(64), HASHBYTES('SHA2_256', @Payload), 2);

    INSERT INTO [audit].[AuditLogs] (
        CorrelationId, ActorUserId, ActorEmployeeId, ActorName, ActorRole,
        Module, Action, RecordId, Details, PreviousValues, NewValues,
        IpAddress, UserAgent, PreviousBlockHash, CurrentBlockHash
    ) VALUES (
        @CorrelationId, @ActorUserId, @ActorEmployeeId, @ActorName, @ActorRole,
        @Module, @Action, @RecordId, @Details, @PreviousValues, @NewValues,
        @IpAddress, @UserAgent, @PrevHash, @CurrentHash
    );
END
GO

-- 3. Trigger enforcing strict append-only immutability (Disallow UPDATE or DELETE)
IF OBJECT_ID(N'[audit].[trg_AuditLogs_PreventModification]', N'TR') IS NOT NULL
    DROP TRIGGER [audit].[trg_AuditLogs_PreventModification];
GO

CREATE TRIGGER [audit].[trg_AuditLogs_PreventModification]
ON [audit].[AuditLogs]
INSTEAD OF UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    RAISERROR('IATF 16949 / ISO 9001 Compliance Violation: Audit trail records are cryptographically sealed and immutable. UPDATE and DELETE operations are strictly prohibited.', 16, 1);
    ROLLBACK TRANSACTION;
END
GO

PRINT 'Script 007 executed: Immutable audit trail with SHA-256 and Sequence engine created.';
