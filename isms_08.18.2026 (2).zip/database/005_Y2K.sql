-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 005: Y2K Physical Location, Rack Inventory & Archival Retentions
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- 1. Y2K Physical Location Racks
IF OBJECT_ID(N'[qms].[Y2KRacks]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[Y2KRacks] (
        [RackId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [RackCode] NVARCHAR(50) NOT NULL UNIQUE, -- e.g. RACK-A1-1F
        [Factory] NVARCHAR(20) NOT NULL, -- '1F' or '2F'
        [Building] NVARCHAR(50) NOT NULL,
        [FloorLevel] NVARCHAR(20) NOT NULL,
        [TotalCapacityBoxes] INT NOT NULL DEFAULT 50,
        [CurrentStoredBoxes] INT NOT NULL DEFAULT 0,
        [IsActive] BIT NOT NULL DEFAULT 1
    );
END
GO

-- 2. Y2K Box Masterlist
IF OBJECT_ID(N'[qms].[Y2KBoxes]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[Y2KBoxes] (
        [BoxId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [BoxNumber] NVARCHAR(50) NOT NULL UNIQUE,
        [RackId] NVARCHAR(64) NULL FOREIGN KEY REFERENCES [qms].[Y2KRacks]([RackId]),
        [RackLocation] NVARCHAR(50) NOT NULL,
        [Factory] NVARCHAR(20) NOT NULL,
        [Department] NVARCHAR(50) NOT NULL,
        [Section] NVARCHAR(50) NOT NULL,
        [ItemDescription] NVARCHAR(255) NOT NULL,
        [Quantity] INT NOT NULL DEFAULT 1,
        [RetentionYears] INT NOT NULL DEFAULT 3,
        [DateReceived] DATE NOT NULL,
        [ExpirationDate] DATE NOT NULL,
        [Status] NVARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [RowVersion] ROWVERSION NOT NULL
    );
END
GO

PRINT 'Script 005 executed: Y2K Location schema created successfully.';
