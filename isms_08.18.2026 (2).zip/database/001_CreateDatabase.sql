-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 001: Database Creation & High-Performance Configuration
-- Target Database: Microsoft SQL Server 2019 / 2022 / SQL Express
-- IATF 16949 / ISO 9001 Compliance Tier
-- ==============================================================================

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'ISMS_QM_DB')
BEGIN
    CREATE DATABASE [ISMS_QM_DB]
    COLLATE Latin1_General_100_CI_AS_SC_UTF8;
    PRINT 'Database [ISMS_QM_DB] created successfully with UTF-8 collation.';
END
ELSE
BEGIN
    PRINT 'Database [ISMS_QM_DB] already exists.';
END
GO

USE [ISMS_QM_DB];
GO

-- Enable Snapshot Isolation for high-concurrency multi-user transactions without lock contention
ALTER DATABASE [ISMS_QM_DB] SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;
ALTER DATABASE [ISMS_QM_DB] SET ALLOW_SNAPSHOT_ISOLATION ON;
ALTER DATABASE [ISMS_QM_DB] SET AUTO_UPDATE_STATISTICS ON;
ALTER DATABASE [ISMS_QM_DB] SET RECOVERY FULL;
GO

-- Create Dedicated Schema for QMS
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'qms')
    EXEC('CREATE SCHEMA [qms] AUTHORIZATION [dbo]');
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'audit')
    EXEC('CREATE SCHEMA [audit] AUTHORIZATION [dbo]');
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'sec')
    EXEC('CREATE SCHEMA [sec] AUTHORIZATION [dbo]');
GO

PRINT 'Script 001 executed: Database, Schemas, and Snapshot Isolation configured.';
