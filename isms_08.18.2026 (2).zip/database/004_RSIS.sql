-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 004: RS/IS Defect Sample Masterlist & Multi-Stage Approval Workflow
-- Stages: Requestor -> QC Hold -> QM Review -> QA Disposition
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- 1. RS/IS Defect Sample Master Record
IF OBJECT_ID(N'[qms].[RSISRecords]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[RSISRecords] (
        [RecordId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [ControlNo] NVARCHAR(50) NOT NULL UNIQUE, -- e.g. RISR-2608-0001
        [Factory] NVARCHAR(20) NOT NULL, -- '1F' or '2F'
        [Department] NVARCHAR(50) NOT NULL,
        [Section] NVARCHAR(50) NOT NULL,
        
        -- Part Details
        [DrawingNumber] NVARCHAR(100) NOT NULL,
        [ItemName] NVARCHAR(200) NOT NULL,
        [LotNumber] NVARCHAR(100) NOT NULL,
        [Quantity] INT NOT NULL DEFAULT 1,
        [DefectDescription] NVARCHAR(1000) NOT NULL,
        [DefectType] NVARCHAR(100) NOT NULL,
        
        -- Stage 1: Requestor Entry
        [IssuedByUserId] NVARCHAR(64) NULL,
        [IssuedByName] NVARCHAR(100) NOT NULL,
        [DateForwarded] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [DateNeeded] DATE NULL,
        [ReturnedDueDate] DATE NULL,
        
        -- Stage 2: QC Hold Area Custody
        [QCHoldStatus] NVARCHAR(50) NOT NULL DEFAULT 'No Received Sample', -- No Received Sample, For Disposition, Received, Cleared
        [QCHoldReceivedBy] NVARCHAR(100) NULL,
        [QCHoldReceivedAt] DATETIMEOFFSET NULL,
        [QCHoldRackLocation] NVARCHAR(50) NULL,
        
        -- Stage 3: QM Review & Routing
        [QMStatus] NVARCHAR(50) NOT NULL DEFAULT 'Not Yet Approved', -- Not Yet Approved, Approved, Rejected
        [QMReviewedBy] NVARCHAR(100) NULL,
        [QMReviewedAt] DATETIMEOFFSET NULL,
        [QMEndorsedToQAEngineer] NVARCHAR(100) NULL,
        [QMRoutingRemarks] NVARCHAR(500) NULL,
        
        -- Stage 4: QA Investigation & Root Cause Disposition
        [QAStatus] NVARCHAR(50) NOT NULL DEFAULT 'Open', -- Open, Under Investigation, Closed
        [QAInvestigatedBy] NVARCHAR(100) NULL,
        [QAClosedAt] DATETIMEOFFSET NULL,
        [QARootCause] NVARCHAR(1000) NULL,
        [QAFinalDisposition] NVARCHAR(500) NULL,
        
        -- Concurrency & Audit Metadata
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [RowVersion] ROWVERSION NOT NULL
    );
END
GO

-- 2. RS/IS State Transition History / Workflow Steps
IF OBJECT_ID(N'[qms].[RSISWorkflowTransitions]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[RSISWorkflowTransitions] (
        [TransitionId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [RecordId] NVARCHAR(64) NOT NULL FOREIGN KEY REFERENCES [qms].[RSISRecords]([RecordId]) ON DELETE CASCADE,
        [FromStage] NVARCHAR(50) NOT NULL,
        [ToStage] NVARCHAR(50) NOT NULL,
        [ActionTaken] NVARCHAR(100) NOT NULL,
        [PerformedByUserId] NVARCHAR(64) NULL,
        [PerformedByName] NVARCHAR(100) NOT NULL,
        [PerformedByRole] NVARCHAR(50) NOT NULL,
        [Remarks] NVARCHAR(1000) NULL,
        [Timestamp] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [IpAddress] NVARCHAR(45) NULL
    );
END
GO

PRINT 'Script 004 executed: RS/IS schema created successfully.';
