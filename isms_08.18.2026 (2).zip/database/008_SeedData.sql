-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 008: Master Seed Data (Roles, Permissions, Master Accounts, Factory Sections)
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- 1. Populate Roles
IF NOT EXISTS (SELECT * FROM [sec].[Roles] WHERE RoleId = 'SYSADMIN')
BEGIN
    INSERT INTO [sec].[Roles] (RoleId, RoleName, Description, HierarchyLevel) VALUES
    ('SYSADMIN', 'System Administrator', 'Full unconstrained system, database and security access', 10),
    ('ADMIN', 'Quality Management Lead / Admin', 'Administrative quality approval and registry supervisor', 8),
    ('QM', 'Quality Management Supervisor', 'Evaluates defect samples, approves requests and routes investigations', 6),
    ('QA', 'Quality Assurance Engineer', 'Conducts root-cause failure analysis and issues disposition approvals', 5),
    ('QC_HOLD', 'QC Hold Area Custodian', 'Manages physical sample intake, staging cages and returns', 4),
    ('REQUESTOR', 'Production / Section Requestor', 'Submits borrow requisitions and reports defect samples', 2),
    ('USER', 'General Read-Only Operator', 'Read-only viewer for line telemetry and sample statuses', 1);
END
GO

-- 2. Populate Granular Permissions
IF NOT EXISTS (SELECT * FROM [sec].[Permissions] WHERE PermissionId = 'Users.Manage')
BEGIN
    INSERT INTO [sec].[Permissions] (PermissionId, Category, Description) VALUES
    ('Users.View', 'User Security', 'View user accounts and roles'),
    ('Users.Manage', 'User Security', 'Create, update, lock user accounts'),
    ('Samples.View', 'Keep Sample', 'View keep sample boxes and inventory'),
    ('Samples.Create', 'Keep Sample', 'Create new keep sample box records'),
    ('Samples.Edit', 'Keep Sample', 'Update keep sample box metadata'),
    ('Samples.Approve', 'Keep Sample', 'Approve keep sample borrow and scrap requests'),
    ('Requests.View', 'Requisitions', 'View keep sample borrow requisitions'),
    ('Requests.Create', 'Requisitions', 'Submit borrow requests for keep samples or RS/IS'),
    ('Requests.Edit', 'Requisitions', 'Modify requisition details before approval'),
    ('Requests.Approve', 'Requisitions', 'Approve borrow requests as QM supervisor'),
    ('Requests.Release', 'Requisitions', 'Release physical parts from QC Hold cages'),
    ('Requests.Return', 'Requisitions', 'Process physical return and verification to box'),
    ('RSIS.View', 'RS/IS Defect', 'View RS/IS defect sample masterlist and records'),
    ('RSIS.Create', 'RS/IS Defect', 'Submit new RS/IS defect sample notice'),
    ('RSIS.QCIntake', 'RS/IS Defect', 'Acknowledge custody receipt at QC Hold'),
    ('RSIS.QMEndorse', 'RS/IS Defect', 'Review defect and route to QA engineer'),
    ('RSIS.QADisposition', 'RS/IS Defect', 'Close RS/IS with root cause & disposition'),
    ('Y2K.View', 'Location Management', 'View Y2K racks and physical locations'),
    ('Y2K.Manage', 'Location Management', 'Modify Y2K rack definitions and capacity'),
    ('Production.View', 'Production Schedule', 'View production lots and schedule timeline'),
    ('Production.Manage', 'Production Schedule', 'Manage line scheduling and quality holds'),
    ('AuditLogs.View', 'Audit', 'View immutable audit trail'),
    ('AuditLogs.Export', 'Audit', 'Export audit logs for ISO / IATF auditor review'),
    ('AuditLogs.VerifyIntegrity', 'Audit', 'Perform cryptographic hash chain verification'),
    ('System.Backup', 'System Administration', 'Execute SQL Server physical database backup'),
    ('System.Restore', 'System Administration', 'Database recovery verification procedure'),
    ('System.Configuration', 'System Administration', 'Configure system parameters and API bindings');
END
GO

-- 3. Map All Permissions to SYSADMIN and ADMIN
INSERT INTO [sec].[RolePermissions] (RoleId, PermissionId)
SELECT 'SYSADMIN', PermissionId FROM [sec].[Permissions]
WHERE NOT EXISTS (SELECT 1 FROM [sec].[RolePermissions] WHERE RoleId = 'SYSADMIN' AND PermissionId = [sec].[Permissions].PermissionId);

INSERT INTO [sec].[RolePermissions] (RoleId, PermissionId)
SELECT 'ADMIN', PermissionId FROM [sec].[Permissions]
WHERE PermissionId NOT IN ('System.Backup', 'System.Restore')
AND NOT EXISTS (SELECT 1 FROM [sec].[RolePermissions] WHERE RoleId = 'ADMIN' AND PermissionId = [sec].[Permissions].PermissionId);

-- QM Role Permissions
INSERT INTO [sec].[RolePermissions] (RoleId, PermissionId)
SELECT 'QM', PermissionId FROM [sec].[Permissions]
WHERE PermissionId IN ('Samples.View', 'Samples.Create', 'Samples.Edit', 'Samples.Approve', 'Requests.View', 'Requests.Create', 'Requests.Approve', 'RSIS.View', 'RSIS.Create', 'RSIS.QMEndorse', 'Y2K.View', 'Production.View', 'AuditLogs.View')
AND NOT EXISTS (SELECT 1 FROM [sec].[RolePermissions] WHERE RoleId = 'QM' AND PermissionId = [sec].[Permissions].PermissionId);

-- QA Role Permissions
INSERT INTO [sec].[RolePermissions] (RoleId, PermissionId)
SELECT 'QA', PermissionId FROM [sec].[Permissions]
WHERE PermissionId IN ('Samples.View', 'Requests.View', 'Requests.Create', 'RSIS.View', 'RSIS.Create', 'RSIS.QADisposition', 'Y2K.View', 'Production.View', 'AuditLogs.View')
AND NOT EXISTS (SELECT 1 FROM [sec].[RolePermissions] WHERE RoleId = 'QA' AND PermissionId = [sec].[Permissions].PermissionId);

-- QC_HOLD Role Permissions
INSERT INTO [sec].[RolePermissions] (RoleId, PermissionId)
SELECT 'QC_HOLD', PermissionId FROM [sec].[Permissions]
WHERE PermissionId IN ('Samples.View', 'Requests.View', 'Requests.Release', 'Requests.Return', 'RSIS.View', 'RSIS.QCIntake', 'Y2K.View', 'Production.View')
AND NOT EXISTS (SELECT 1 FROM [sec].[RolePermissions] WHERE RoleId = 'QC_HOLD' AND PermissionId = [sec].[Permissions].PermissionId);

-- REQUESTOR / USER Role Permissions
INSERT INTO [sec].[RolePermissions] (RoleId, PermissionId)
SELECT 'REQUESTOR', PermissionId FROM [sec].[Permissions]
WHERE PermissionId IN ('Samples.View', 'Requests.View', 'Requests.Create', 'RSIS.View', 'RSIS.Create', 'Y2K.View', 'Production.View')
AND NOT EXISTS (SELECT 1 FROM [sec].[RolePermissions] WHERE RoleId = 'REQUESTOR' AND PermissionId = [sec].[Permissions].PermissionId);

INSERT INTO [sec].[RolePermissions] (RoleId, PermissionId)
SELECT 'USER', PermissionId FROM [sec].[Permissions]
WHERE PermissionId IN ('Samples.View', 'Requests.View', 'RSIS.View', 'Y2K.View', 'Production.View')
AND NOT EXISTS (SELECT 1 FROM [sec].[RolePermissions] WHERE RoleId = 'USER' AND PermissionId = [sec].[Permissions].PermissionId);
GO

-- 4. Initial System Administrator Bootstrap
-- Standard BCrypt Hash for Initial Setup (Requires immediate password change on first login)
-- BCrypt work factor: 11
IF NOT EXISTS (SELECT * FROM [sec].[Users] WHERE Username = 'sysadmin')
BEGIN
    INSERT INTO [sec].[Users] (
        UserId, EmployeeId, Username, PasswordHash,
        FirstName, LastName, Email, Department, Section, Factory, Shift, RoleId, MustChangePassword, IsActive
    ) VALUES
    ('usr-sysadmin-01', 'JAE-00001', 'sysadmin', 
     '$2a$11$e8mZ4o9191dZ1t0.g4zDq.sWlQcIqmPZ6jM7q8bUjM9yHqZ8j4w0.', -- Provisioning Hash (Change immediately)
     'System', 'Administrator', 'sysadmin@jae.com.ph', 'MIS', 'IT Infrastructure', '1F', 'Shift A', 'SYSADMIN', 1, 1),
    ('usr-admin-01', 'JAE-88421', 'admin_qm', 
     '$2a$11$e8mZ4o9191dZ1t0.g4zDq.sWlQcIqmPZ6jM7q8bUjM9yHqZ8j4w0.', 
     'Clarissa', 'Alcantara', 'c.alcantara@jae.com.ph', 'QM', 'Quality Management', '1F', 'Shift A', 'ADMIN', 1, 1);
END
GO

-- 5. Stored Procedure for First-Time Setup and Forced Password Change
IF OBJECT_ID(N'[sec].[usp_FirstTimeSetup]', N'P') IS NOT NULL
    DROP PROCEDURE [sec].[usp_FirstTimeSetup];
GO

CREATE PROCEDURE [sec].[usp_FirstTimeSetup]
    @EmployeeId NVARCHAR(50),
    @NewPasswordHash NVARCHAR(255),
    @UpdatedBy NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE [sec].[Users]
    SET [PasswordHash] = @NewPasswordHash,
        [FailedLoginAttempts] = 0,
        [LockoutEnd] = NULL,
        [UpdatedAt] = SYSDATETIMEOFFSET()
    WHERE [EmployeeId] = @EmployeeId;

    EXEC [audit].[usp_InsertAuditLog]
        @CorrelationId = 'SETUP-INITIAL',
        @ActorUserId = 'SYSTEM',
        @ActorEmployeeId = @UpdatedBy,
        @ActorName = 'Setup Administrator',
        @ActorRole = 'SYSADMIN',
        @Module = 'Security',
        @Action = 'ADMIN_FIRST_TIME_SETUP',
        @RecordId = @EmployeeId,
        @Details = 'Initial administrator credentials established and password rotation enforced.',
        @PreviousValues = NULL,
        @NewValues = '{"Status":"PasswordRotated"}',
        @IpAddress = '127.0.0.1',
        @UserAgent = 'SQL Server Initialization Job';
END
GO

PRINT 'Script 008 executed: Seed data & first-time setup procedure inserted successfully.';
