-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 006: Production Schedules, Quality Gates & Batch Maintenance
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- 1. Production Batch Schedules
IF OBJECT_ID(N'[qms].[ProductionSchedules]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[ProductionSchedules] (
        [ScheduleId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [JobOrderNo] NVARCHAR(50) NOT NULL UNIQUE,
        [Factory] NVARCHAR(20) NOT NULL,
        [Department] NVARCHAR(50) NOT NULL,
        [LineName] NVARCHAR(50) NOT NULL,
        [ProductCode] NVARCHAR(100) NOT NULL,
        [PartNumber] NVARCHAR(100) NOT NULL,
        [LotNumber] NVARCHAR(100) NOT NULL,
        [Customer] NVARCHAR(100) NOT NULL,
        [Stage] NVARCHAR(50) NOT NULL, -- Stamping, Molding, Assembly, Quality Inspection
        [TargetQuantity] INT NOT NULL,
        [CompletedQuantity] INT NOT NULL DEFAULT 0,
        [Status] NVARCHAR(50) NOT NULL DEFAULT 'Scheduled', -- Scheduled, In Progress, Completed, Quality Gate Hold
        [ScheduledDate] DATE NOT NULL,
        [QualityGateHoldReason] NVARCHAR(500) NULL,
        [AssociatedRSISControlNo] NVARCHAR(50) NULL,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET()
    );
END
GO

-- 2. Quality Gate Hold Incidents
IF OBJECT_ID(N'[qms].[QualityGateHolds]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[QualityGateHolds] (
        [HoldId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [ScheduleId] NVARCHAR(64) NOT NULL FOREIGN KEY REFERENCES [qms].[ProductionSchedules]([ScheduleId]),
        [HoldTriggerReason] NVARCHAR(100) NOT NULL,
        [TriggeredBy] NVARCHAR(100) NOT NULL,
        [TriggerTimestamp] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [ReleaseAuthorizedBy] NVARCHAR(100) NULL,
        [ReleaseTimestamp] DATETIMEOFFSET NULL,
        [ReleaseRemarks] NVARCHAR(1000) NULL,
        [Status] NVARCHAR(30) NOT NULL DEFAULT 'ACTIVE_HOLD'
    );
END
GO

PRINT 'Script 006 executed: Production schedules schema created successfully.';
