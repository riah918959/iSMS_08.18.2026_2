-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 002: Security, Users, Roles & Granular Permission Matrix (RBAC)
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- 1. Roles Master Table
IF OBJECT_ID(N'[sec].[Roles]', N'U') IS NULL
BEGIN
    CREATE TABLE [sec].[Roles] (
        [RoleId] NVARCHAR(50) NOT NULL PRIMARY KEY,
        [RoleName] NVARCHAR(100) NOT NULL,
        [Description] NVARCHAR(255) NULL,
        [HierarchyLevel] INT NOT NULL DEFAULT 1,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [IsActive] BIT NOT NULL DEFAULT 1
    );
END
GO

-- 2. Granular Permissions Master
IF OBJECT_ID(N'[sec].[Permissions]', N'U') IS NULL
BEGIN
    CREATE TABLE [sec].[Permissions] (
        [PermissionId] NVARCHAR(100) NOT NULL PRIMARY KEY,
        [Category] NVARCHAR(50) NOT NULL,
        [Description] NVARCHAR(255) NOT NULL
    );
END
GO

-- 3. Role-Permission Mapping
IF OBJECT_ID(N'[sec].[RolePermissions]', N'U') IS NULL
BEGIN
    CREATE TABLE [sec].[RolePermissions] (
        [RoleId] NVARCHAR(50) NOT NULL FOREIGN KEY REFERENCES [sec].[Roles]([RoleId]) ON DELETE CASCADE,
        [PermissionId] NVARCHAR(100) NOT NULL FOREIGN KEY REFERENCES [sec].[Permissions]([PermissionId]) ON DELETE CASCADE,
        [AssignedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        CONSTRAINT PK_RolePermissions PRIMARY KEY ([RoleId], [PermissionId])
    );
END
GO

-- 4. Users Table (No plaintext passwords; standardized BCrypt password hash)
IF OBJECT_ID(N'[sec].[Users]', N'U') IS NULL
BEGIN
    CREATE TABLE [sec].[Users] (
        [UserId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [EmployeeId] NVARCHAR(50) NOT NULL UNIQUE,
        [Username] NVARCHAR(50) NOT NULL UNIQUE,
        [PasswordHash] NVARCHAR(255) NOT NULL, -- Standard BCrypt hash ($2a$ / $2b$)
        [FirstName] NVARCHAR(100) NOT NULL,
        [LastName] NVARCHAR(100) NOT NULL,
        [Email] NVARCHAR(150) NOT NULL,
        [Department] NVARCHAR(50) NOT NULL,
        [Section] NVARCHAR(50) NOT NULL,
        [Factory] NVARCHAR(20) NOT NULL, -- '1F' or '2F'
        [Shift] NVARCHAR(20) NOT NULL DEFAULT 'Shift A',
        [RoleId] NVARCHAR(50) NOT NULL FOREIGN KEY REFERENCES [sec].[Roles]([RoleId]),
        [MustChangePassword] BIT NOT NULL DEFAULT 1,
        [IsActive] BIT NOT NULL DEFAULT 1,
        [FailedLoginAttempts] INT NOT NULL DEFAULT 0,
        [LockoutEnd] DATETIMEOFFSET NULL,
        [LastLoginAt] DATETIMEOFFSET NULL,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [RowVersion] ROWVERSION NOT NULL
    );
END
GO

-- 5. Active User Sessions & Refresh Tokens
IF OBJECT_ID(N'[sec].[UserSessions]', N'U') IS NULL
BEGIN
    CREATE TABLE [sec].[UserSessions] (
        [SessionId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [UserId] NVARCHAR(64) NOT NULL FOREIGN KEY REFERENCES [sec].[Users]([UserId]) ON DELETE CASCADE,
        [RefreshTokenHash] NVARCHAR(255) NOT NULL UNIQUE,
        [IpAddress] NVARCHAR(45) NOT NULL,
        [UserAgent] NVARCHAR(255) NULL,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [ExpiresAt] DATETIMEOFFSET NOT NULL,
        [RevokedAt] DATETIMEOFFSET NULL
    );
END
GO

PRINT 'Script 002 executed: Security RBAC schema created successfully.';
