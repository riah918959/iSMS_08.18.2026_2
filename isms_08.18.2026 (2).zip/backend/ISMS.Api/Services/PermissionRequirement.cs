using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;

namespace ISMS.Api.Services
{
    public class PermissionRequirement : IAuthorizationRequirement
    {
        public string Permission { get; }

        public PermissionRequirement(string permission)
        {
            Permission = permission;
        }
    }

    public class PermissionAuthorizationHandler : AuthorizationHandler<PermissionRequirement>
    {
        private readonly ISMSDbContext _db;

        public PermissionAuthorizationHandler(ISMSDbContext db)
        {
            _db = db;
        }

        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
        {
            if (!context.User.Identity?.IsAuthenticated ?? true)
            {
                return;
            }

            // 1. Check if the permission is present as a JWT Claim
            if (context.User.HasClaim(c => c.Type == "Permission" && c.Value == requirement.Permission))
            {
                context.Succeed(requirement);
                return;
            }

            // 2. Sysadmin always has all permissions
            var roleClaim = context.User.FindFirst(ClaimTypes.Role)?.Value;
            if (string.Equals(roleClaim, "SYSADMIN", System.StringComparison.OrdinalIgnoreCase) ||
                string.Equals(roleClaim, "Sysadmin", System.StringComparison.OrdinalIgnoreCase))
            {
                context.Succeed(requirement);
                return;
            }

            // 3. Fallback to SQL database lookup
            if (!string.IsNullOrEmpty(roleClaim))
            {
                var hasPermission = await _db.RolePermissions
                    .AnyAsync(rp => rp.RoleId == roleClaim && rp.PermissionId == requirement.Permission);

                if (hasPermission)
                {
                    context.Succeed(requirement);
                }
            }
        }
    }
}
