using System;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;
using ISMS.Api.Models;

namespace ISMS.Api.Services
{
    public interface IAuditLogService
    {
        Task LogAsync(string correlationId, string? userId, string employeeId, string name, string role,
            string module, string action, string recordId, string details, string? prevValues, string? newValues,
            string ipAddress, string? userAgent);
    }

    public class AuditLogService : IAuditLogService
    {
        private readonly ISMSDbContext _db;

        public AuditLogService(ISMSDbContext db)
        {
            _db = db;
        }

        public async Task LogAsync(string correlationId, string? userId, string employeeId, string name, string role,
            string module, string action, string recordId, string details, string? prevValues, string? newValues,
            string ipAddress, string? userAgent)
        {
            var corrId = string.IsNullOrWhiteSpace(correlationId) ? Guid.NewGuid().ToString() : correlationId;
            var safeIp = string.IsNullOrWhiteSpace(ipAddress) ? "127.0.0.1" : ipAddress;

            try
            {
                // Attempt atomic insertion via stored procedure
                await _db.Database.ExecuteSqlRawAsync(
                    "EXEC [audit].[usp_InsertAuditLog] @CorrelationId, @ActorUserId, @ActorEmployeeId, @ActorName, @ActorRole, @Module, @Action, @RecordId, @Details, @PreviousValues, @NewValues, @IpAddress, @UserAgent",
                    new Microsoft.Data.SqlClient.SqlParameter("@CorrelationId", corrId),
                    new Microsoft.Data.SqlClient.SqlParameter("@ActorUserId", (object?)userId ?? DBNull.Value),
                    new Microsoft.Data.SqlClient.SqlParameter("@ActorEmployeeId", employeeId),
                    new Microsoft.Data.SqlClient.SqlParameter("@ActorName", name),
                    new Microsoft.Data.SqlClient.SqlParameter("@ActorRole", role),
                    new Microsoft.Data.SqlClient.SqlParameter("@Module", module),
                    new Microsoft.Data.SqlClient.SqlParameter("@Action", action),
                    new Microsoft.Data.SqlClient.SqlParameter("@RecordId", recordId),
                    new Microsoft.Data.SqlClient.SqlParameter("@Details", details),
                    new Microsoft.Data.SqlClient.SqlParameter("@PreviousValues", (object?)prevValues ?? DBNull.Value),
                    new Microsoft.Data.SqlClient.SqlParameter("@NewValues", (object?)newValues ?? DBNull.Value),
                    new Microsoft.Data.SqlClient.SqlParameter("@IpAddress", safeIp),
                    new Microsoft.Data.SqlClient.SqlParameter("@UserAgent", (object?)userAgent ?? DBNull.Value)
                );
            }
            catch
            {
                // Fallback to EF Core with serialized isolation level to prevent concurrency split-brain hash chains
                using var transaction = await _db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
                var lastLog = await _db.AuditLogs.OrderByDescending(a => a.AuditId).FirstOrDefaultAsync();
                string prevHash = lastLog?.CurrentBlockHash ?? "GENESIS_BLOCK_JAE_ISMS_2026";

                var now = DateTimeOffset.UtcNow;
                string payload = $"{prevHash}|{employeeId}|{module}|{action}|{recordId}|{now.ToUnixTimeSeconds()}|{details}";
                
                using var sha256 = SHA256.Create();
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(payload));
                string currentHash = Convert.ToHexString(hashBytes);

                var logEntry = new AuditLog
                {
                    CorrelationId = corrId,
                    Timestamp = now,
                    ActorUserId = userId,
                    ActorEmployeeId = employeeId,
                    ActorName = name,
                    ActorRole = role,
                    Module = module,
                    Action = action,
                    RecordId = recordId,
                    Details = details,
                    PreviousValues = prevValues,
                    NewValues = newValues,
                    IpAddress = safeIp,
                    UserAgent = userAgent,
                    PreviousBlockHash = prevHash,
                    CurrentBlockHash = currentHash
                };

                _db.AuditLogs.Add(logEntry);
                await _db.SaveChangesAsync();
                await transaction.CommitAsync();
            }
        }
    }
}
