using System;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;

namespace ISMS.Api.Services
{
    public interface IDocumentSequenceService
    {
        Task<string> GenerateControlNumberAsync(string prefix);
    }

    public class DocumentSequenceService : IDocumentSequenceService
    {
        private readonly ISMSDbContext _db;

        public DocumentSequenceService(ISMSDbContext db)
        {
            _db = db;
        }

        public async Task<string> GenerateControlNumberAsync(string prefix)
        {
            string yearMonth = DateTime.UtcNow.ToString("yyMM");
            var prefixParam = new SqlParameter("@Prefix", prefix);
            var yearMonthParam = new SqlParameter("@YearMonth", yearMonth);
            var outputParam = new SqlParameter
            {
                ParameterName = "@GeneratedControlNo",
                SqlDbType = System.Data.SqlDbType.NVarChar,
                Size = 50,
                Direction = System.Data.ParameterDirection.Output
            };

            try
            {
                await _db.Database.ExecuteSqlRawAsync(
                    "EXEC [qms].[usp_GetNextControlNumber] @Prefix, @YearMonth, @GeneratedControlNo OUTPUT",
                    prefixParam, yearMonthParam, outputParam
                );

                var generated = outputParam.Value?.ToString();
                if (!string.IsNullOrWhiteSpace(generated))
                {
                    return generated;
                }
            }
            catch (Exception ex)
            {
                // If stored procedure fails, attempt atomic EF transaction on DocumentSequences table without random numbers
                try
                {
                    using var transaction = await _db.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);
                    var seq = await _db.DocumentSequences
                        .FirstOrDefaultAsync(s => s.SequencePrefix == prefix && s.YearMonth == yearMonth);

                    if (seq == null)
                    {
                        seq = new Models.DocumentSequence
                        {
                            SequencePrefix = prefix,
                            YearMonth = yearMonth,
                            CurrentValue = 1,
                            UpdatedAt = DateTimeOffset.UtcNow
                        };
                        _db.DocumentSequences.Add(seq);
                    }
                    else
                    {
                        seq.CurrentValue++;
                        seq.UpdatedAt = DateTimeOffset.UtcNow;
                    }

                    await _db.SaveChangesAsync();
                    await transaction.CommitAsync();

                    if (prefix == "BKS" || prefix == "RISR")
                        return $"{prefix}-{yearMonth}-{seq.CurrentValue:D4}";
                    return $"{prefix}-{yearMonth}-{seq.CurrentValue:D3}";
                }
                catch
                {
                    throw new InvalidOperationException($"CRITICAL QMS SEQUENCE FAILURE: Authoritative SQL Server sequence generation failed for prefix '{prefix}' ({ex.Message}). Random fallback is strictly prohibited under IATF 16949 / ISO 9001.");
                }
            }

            throw new InvalidOperationException($"CRITICAL QMS SEQUENCE FAILURE: Failed to generate authoritative control number for prefix '{prefix}'.");
        }
    }
}
