using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;

namespace ISMS.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HealthController : ControllerBase
    {
        private readonly ISMSDbContext _db;

        public HealthController(ISMSDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<IActionResult> Check()
        {
            var sw = Stopwatch.StartNew();
            bool dbConnected = false;
            string dbError = string.Empty;

            try
            {
                dbConnected = await _db.Database.CanConnectAsync();
            }
            catch (Exception ex)
            {
                dbError = ex.Message;
            }
            sw.Stop();

            return Ok(new
            {
                status = dbConnected ? "HEALTHY" : "DEGRADED",
                timestamp = DateTimeOffset.UtcNow,
                system = "JAE iSMS ASP.NET Core 8 Web API",
                version = "1.0.0-GA",
                environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production",
                database = new
                {
                    provider = "Microsoft SQL Server",
                    connected = dbConnected,
                    latencyMs = sw.ElapsedMilliseconds,
                    error = string.IsNullOrEmpty(dbError) ? null : dbError
                }
            });
        }
    }
}
