using System;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;
using ISMS.Api.Models;
using ISMS.Api.Services;

namespace ISMS.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly ISMSDbContext _db;
        private readonly IAuditLogService _audit;

        public UsersController(ISMSDbContext db, IAuditLogService audit)
        {
            _db = db;
            _audit = audit;
        }

        private (string UserId, string EmployeeId, string Name, string Role) GetCurrentActor()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "SYSTEM";
            var employeeId = User.FindFirst("EmployeeId")?.Value ?? "SYSTEM";
            var name = User.FindFirst(ClaimTypes.Name)?.Value ?? User.Identity?.Name ?? "Administrator";
            var role = User.FindFirst(ClaimTypes.Role)?.Value ?? "USER";
            return (userId, employeeId, name, role);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var actor = GetCurrentActor();
            // Allow all authenticated users to read personnel directory for workflow routing
            var users = await _db.Users
                .Include(u => u.Role)
                .Select(u => new
                {
                    u.UserId,
                    u.EmployeeId,
                    u.Username,
                    u.FirstName,
                    u.LastName,
                    u.Email,
                    u.Department,
                    u.Section,
                    u.Factory,
                    u.Shift,
                    u.RoleId,
                    RoleName = u.Role != null ? u.Role.RoleName : u.RoleId,
                    u.MustChangePassword,
                    u.IsActive,
                    u.LastLoginAt,
                    u.CreatedAt,
                    u.UpdatedAt
                })
                .OrderBy(u => u.LastName)
                .ToListAsync();

            return Ok(users);
        }

        public record CreateUserRequest(
            string EmployeeId,
            string Username,
            string InitialPassword,
            string FirstName,
            string LastName,
            string Email,
            string Department,
            string Section,
            string Factory,
            string Shift,
            string RoleId
        );

        [HttpPost]
        [Authorize(Roles = "SYSADMIN,ADMIN,Sysadmin,Admin")]
        public async Task<IActionResult> Create([FromBody] CreateUserRequest req)
        {
            var actor = GetCurrentActor();

            if (string.IsNullOrWhiteSpace(req.EmployeeId) || string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.InitialPassword))
            {
                return BadRequest(new { message = "EmployeeId, Username, and InitialPassword are required." });
            }

            // Only SYSADMIN can create SYSADMIN accounts
            if (string.Equals(req.RoleId, "SYSADMIN", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(actor.Role, "SYSADMIN", StringComparison.OrdinalIgnoreCase))
            {
                return Forbid();
            }

            var cleanUsername = req.Username.Trim().ToLower();
            var cleanEmployeeId = req.EmployeeId.Trim().ToUpper();

            if (await _db.Users.AnyAsync(u => u.Username.ToLower() == cleanUsername))
            {
                return BadRequest(new { message = $"Username '{req.Username}' is already taken." });
            }

            if (await _db.Users.AnyAsync(u => u.EmployeeId.ToUpper() == cleanEmployeeId))
            {
                return BadRequest(new { message = $"Employee ID '{req.EmployeeId}' is already registered." });
            }

            var newUser = new User
            {
                UserId = Guid.NewGuid().ToString(),
                EmployeeId = cleanEmployeeId,
                Username = cleanUsername,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.InitialPassword, workFactor: 11),
                FirstName = req.FirstName.Trim(),
                LastName = req.LastName.Trim(),
                Email = string.IsNullOrWhiteSpace(req.Email) ? $"{cleanUsername}@jae.com.ph" : req.Email.Trim(),
                Department = req.Department,
                Section = req.Section,
                Factory = req.Factory,
                Shift = req.Shift,
                RoleId = req.RoleId,
                MustChangePassword = true,
                IsActive = true,
                CreatedAt = DateTimeOffset.UtcNow,
                UpdatedAt = DateTimeOffset.UtcNow
            };

            _db.Users.Add(newUser);
            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "Security",
                "USER_REGISTERED",
                newUser.EmployeeId,
                $"Admin {actor.Name} registered user {newUser.EmployeeId} ({newUser.FirstName} {newUser.LastName}, Role: {newUser.RoleId})",
                null,
                System.Text.Json.JsonSerializer.Serialize(new { newUser.UserId, newUser.EmployeeId, newUser.Username, newUser.RoleId }),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(new { success = true, user = newUser });
        }

        public record ResetPasswordRequest(string NewPassword);

        [HttpPost("{id}/reset-password")]
        [Authorize(Roles = "SYSADMIN,ADMIN,Sysadmin,Admin")]
        public async Task<IActionResult> ResetPassword(string id, [FromBody] ResetPasswordRequest req)
        {
            var actor = GetCurrentActor();

            var user = await _db.Users.FirstOrDefaultAsync(u => u.UserId == id || u.EmployeeId == id);
            if (user == null) return NotFound(new { message = "User not found." });

            if (string.Equals(user.RoleId, "SYSADMIN", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(actor.Role, "SYSADMIN", StringComparison.OrdinalIgnoreCase))
            {
                return Forbid();
            }

            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.NewPassword, workFactor: 11);
            user.MustChangePassword = true;
            user.FailedLoginAttempts = 0;
            user.LockoutEnd = null;
            user.UpdatedAt = DateTimeOffset.UtcNow;

            // Revoke all sessions for this user
            var sessions = await _db.UserSessions.Where(s => s.UserId == user.UserId && s.RevokedAt == null).ToListAsync();
            foreach (var s in sessions)
            {
                s.RevokedAt = DateTimeOffset.UtcNow;
            }

            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "Security",
                "USER_PASSWORD_RESET",
                user.EmployeeId,
                $"Admin {actor.Name} administratively reset password for {user.EmployeeId}. Forced password rotation on next login.",
                null,
                "{\"Status\":\"PasswordResetByAdmin\"}",
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(new { success = true, message = $"Password reset successfully for {user.FirstName} {user.LastName}." });
        }

        [HttpPost("{id}/toggle-active")]
        [Authorize(Roles = "SYSADMIN,ADMIN,Sysadmin,Admin")]
        public async Task<IActionResult> ToggleActive(string id)
        {
            var actor = GetCurrentActor();

            var user = await _db.Users.FirstOrDefaultAsync(u => u.UserId == id || u.EmployeeId == id);
            if (user == null) return NotFound(new { message = "User not found." });

            if (string.Equals(user.RoleId, "SYSADMIN", StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(actor.Role, "SYSADMIN", StringComparison.OrdinalIgnoreCase))
            {
                return Forbid();
            }

            user.IsActive = !user.IsActive;
            user.UpdatedAt = DateTimeOffset.UtcNow;

            if (!user.IsActive)
            {
                // Revoke sessions immediately
                var sessions = await _db.UserSessions.Where(s => s.UserId == user.UserId && s.RevokedAt == null).ToListAsync();
                foreach (var s in sessions)
                {
                    s.RevokedAt = DateTimeOffset.UtcNow;
                }
            }

            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "Security",
                user.IsActive ? "USER_ACTIVATED" : "USER_DEACTIVATED",
                user.EmployeeId,
                $"Admin {actor.Name} changed active status of {user.EmployeeId} to {user.IsActive}",
                null,
                System.Text.Json.JsonSerializer.Serialize(new { user.UserId, user.IsActive }),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(new { success = true, isActive = user.IsActive });
        }
    }
}
