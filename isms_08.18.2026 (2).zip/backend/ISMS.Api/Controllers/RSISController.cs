using System;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;
using ISMS.Api.Models;
using ISMS.Api.Services;

namespace ISMS.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class RSISController : ControllerBase
    {
        private readonly ISMSDbContext _db;
        private readonly IDocumentSequenceService _sequences;
        private readonly IAuditLogService _audit;

        public RSISController(ISMSDbContext db, IDocumentSequenceService sequences, IAuditLogService audit)
        {
            _db = db;
            _sequences = sequences;
            _audit = audit;
        }

        private (string UserId, string EmployeeId, string Name, string Role) GetCurrentActor()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "SYSTEM";
            var employeeId = User.FindFirst("EmployeeId")?.Value ?? "SYSTEM";
            var name = User.FindFirst(ClaimTypes.Name)?.Value ?? User.Identity?.Name ?? "Operator";
            var role = User.FindFirst(ClaimTypes.Role)?.Value ?? "USER";
            return (userId, employeeId, name, role);
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var records = await _db.RSISRecords
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
            return Ok(records);
        }

        [HttpPost]
        [Authorize(Roles = "SYSADMIN,ADMIN,QM,QA,QC_HOLD,REQUESTOR,Sysadmin,Admin,QM,QA,QC Hold,Requestor")]
        public async Task<IActionResult> Create([FromBody] RSISRecord record)
        {
            var actor = GetCurrentActor();

            // Server strictly generates sequential control number
            record.ControlNo = await _sequences.GenerateControlNumberAsync("RISR");
            record.IssuedByName = $"{actor.Name} ({actor.EmployeeId})";
            record.DateForwarded = DateTimeOffset.UtcNow;
            record.QCHoldStatus = "For Disposition";
            record.QMStatus = "Not Yet Approved";
            record.QAStatus = "Open";
            record.CreatedAt = DateTimeOffset.UtcNow;
            record.UpdatedAt = DateTimeOffset.UtcNow;

            _db.RSISRecords.Add(record);
            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "RSISRecord",
                "FORWARD_DEFECT_SAMPLE",
                record.ControlNo,
                $"Forwarded defect sample {record.ControlNo} ({record.DrawingNumber}, Lot {record.LotNumber}) - Defect: {record.DefectDescription}",
                null,
                System.Text.Json.JsonSerializer.Serialize(record),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(record);
        }

        [HttpPut("{id}/qc-intake")]
        [Authorize(Roles = "SYSADMIN,ADMIN,QC_HOLD,Sysadmin,Admin,QC Hold")]
        public async Task<IActionResult> QcHoldIntake(string id)
        {
            var record = await _db.RSISRecords.FirstOrDefaultAsync(r => r.RecordId == id || r.ControlNo == id);
            if (record == null) return NotFound(new { message = "RS/IS record not found." });

            var actor = GetCurrentActor();
            record.QCHoldStatus = "Forwarded";
            record.QCHoldReceivedBy = actor.Name;
            record.QCHoldReceivedAt = DateTimeOffset.UtcNow;
            record.UpdatedAt = DateTimeOffset.UtcNow;

            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "RSISRecord",
                "QC_HOLD_INTAKE",
                record.ControlNo,
                $"QC Hold Custodian {actor.Name} received physical defect sample {record.ControlNo} and forwarded to QM",
                null,
                System.Text.Json.JsonSerializer.Serialize(record),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(record);
        }

        [HttpPut("{id}/qm-endorse")]
        [Authorize(Roles = "SYSADMIN,ADMIN,QM,Sysadmin,Admin,QM")]
        public async Task<IActionResult> QmEndorse(string id, [FromBody] QmEndorseRequest req)
        {
            var record = await _db.RSISRecords.FirstOrDefaultAsync(r => r.RecordId == id || r.ControlNo == id);
            if (record == null) return NotFound(new { message = "RS/IS record not found." });

            var actor = GetCurrentActor();
            record.QMStatus = "Approved";
            record.QMReviewedBy = actor.Name;
            record.QMReviewedAt = DateTimeOffset.UtcNow;
            record.QMEndorsedToQAEngineer = req.EndorsedQAEngineer;
            record.UpdatedAt = DateTimeOffset.UtcNow;

            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "RSISRecord",
                "QM_ENDORSE_DEFECT",
                record.ControlNo,
                $"QM Supervisor {actor.Name} endorsed defect {record.ControlNo} to QA engineer {req.EndorsedQAEngineer}",
                null,
                System.Text.Json.JsonSerializer.Serialize(record),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(record);
        }

        public record QmEndorseRequest(string EndorsedQAEngineer);
        public record QaDispositionRequest(string RootCause, string FinalDisposition, string Status);

        [HttpPut("{id}/qa-disposition")]
        [Authorize(Roles = "SYSADMIN,ADMIN,QA,Sysadmin,Admin,QA")]
        public async Task<IActionResult> QaDisposition(string id, [FromBody] QaDispositionRequest req)
        {
            var record = await _db.RSISRecords.FirstOrDefaultAsync(r => r.RecordId == id || r.ControlNo == id);
            if (record == null) return NotFound(new { message = "RS/IS record not found." });

            var actor = GetCurrentActor();
            record.QAStatus = req.Status ?? "Closed";
            record.QAInvestigatedBy = actor.Name;
            record.QARootCause = req.RootCause;
            record.QAFinalDisposition = req.FinalDisposition;
            record.QAClosedAt = DateTimeOffset.UtcNow;
            record.UpdatedAt = DateTimeOffset.UtcNow;

            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "RSISRecord",
                "QA_ROOT_CAUSE_DISPOSITION",
                record.ControlNo,
                $"QA Engineer {actor.Name} closed defect {record.ControlNo}. Root Cause: {req.RootCause}; Disposition: {req.FinalDisposition}",
                null,
                System.Text.Json.JsonSerializer.Serialize(record),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(record);
        }
    }
}
