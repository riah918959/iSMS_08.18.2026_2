using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;
using ISMS.Api.Models;
using ISMS.Api.Services;

namespace ISMS.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class KeepSampleController : ControllerBase
    {
        private readonly ISMSDbContext _db;
        private readonly IDocumentSequenceService _sequences;
        private readonly IAuditLogService _audit;

        public KeepSampleController(ISMSDbContext db, IDocumentSequenceService sequences, IAuditLogService audit)
        {
            _db = db;
            _sequences = sequences;
            _audit = audit;
        }

        private (string UserId, string EmployeeId, string Name, string Role) GetCurrentActor()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "SYSTEM";
            var employeeId = User.FindFirst("EmployeeId")?.Value ?? "SYSTEM";
            var name = User.FindFirst(ClaimTypes.Name)?.Value ?? User.Identity?.Name ?? "Operator";
            var role = User.FindFirst(ClaimTypes.Role)?.Value ?? "USER";
            return (userId, employeeId, name, role);
        }

        [HttpGet("boxes")]
        public async Task<IActionResult> GetBoxes()
        {
            var boxes = await _db.KeepSampleBoxes
                .Include(b => b.Items)
                .OrderByDescending(b => b.CreatedAt)
                .ToListAsync();
            return Ok(boxes);
        }

        [HttpPost("boxes")]
        [Authorize(Roles = "SYSADMIN,ADMIN,QM,QA,QC_HOLD,Sysadmin,Admin,QM,QA,QC Hold")]
        public async Task<IActionResult> CreateBox([FromBody] KeepSampleBox box)
        {
            var actor = GetCurrentActor();

            // Server strictly owns control number generation
            string prefix = box.Factory == "2F" || box.Factory == "Second Factory" ? "BOX-2F" : "BOX-1F";
            box.BoxNumber = await _sequences.GenerateControlNumberAsync(prefix);
            box.RequestedBy = $"{actor.Name} ({actor.EmployeeId})";
            box.CreatedAt = DateTimeOffset.UtcNow;
            box.UpdatedAt = DateTimeOffset.UtcNow;

            _db.KeepSampleBoxes.Add(box);
            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "KeepSampleBox",
                "CREATE_BOX",
                box.BoxNumber,
                $"Created Keep Sample Box {box.BoxNumber} in {box.StorageArea} ({box.Section})",
                null,
                System.Text.Json.JsonSerializer.Serialize(box),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return CreatedAtAction(nameof(GetBoxes), new { id = box.BoxId }, box);
        }

        [HttpGet("requests")]
        public async Task<IActionResult> GetRequests()
        {
            var requests = await _db.KeepSampleRequests
                .OrderByDescending(r => r.CreatedAt)
                .ToListAsync();
            return Ok(requests);
        }

        [HttpPost("requests")]
        [Authorize(Roles = "SYSADMIN,ADMIN,QM,QA,QC_HOLD,REQUESTOR,Sysadmin,Admin,QM,QA,QC Hold,Requestor")]
        public async Task<IActionResult> CreateRequest([FromBody] KeepSampleRequest req)
        {
            var actor = GetCurrentActor();

            // Server strictly generates sequential control number
            req.ControlNo = await _sequences.GenerateControlNumberAsync("BKS");
            req.RequestorName = actor.Name;
            req.Status = "Unreturned";
            req.CreatedAt = DateTimeOffset.UtcNow;
            req.UpdatedAt = DateTimeOffset.UtcNow;

            _db.KeepSampleRequests.Add(req);
            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "KeepSampleRequest",
                "SUBMIT_REQUISITION",
                req.ControlNo,
                $"Submitted borrow request {req.ControlNo} for box {req.BoxNumber}, reason: {req.ReasonForBorrowing}",
                null,
                System.Text.Json.JsonSerializer.Serialize(req),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(req);
        }

        [HttpPut("requests/{id}/approve")]
        [Authorize(Roles = "SYSADMIN,ADMIN,QM,Sysadmin,Admin,QM")]
        public async Task<IActionResult> ApproveRequest(string id)
        {
            var req = await _db.KeepSampleRequests.FirstOrDefaultAsync(r => r.RequestId == id || r.ControlNo == id);
            if (req == null) return NotFound(new { message = "Request not found." });

            var actor = GetCurrentActor();
            req.QMApprovedBy = actor.Name;
            req.QMApprovalDate = DateTimeOffset.UtcNow;
            req.UpdatedAt = DateTimeOffset.UtcNow;

            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                actor.UserId,
                actor.EmployeeId,
                actor.Name,
                actor.Role,
                "KeepSampleRequest",
                "QM_APPROVE_REQUISITION",
                req.ControlNo,
                $"QM Supervisor {actor.Name} approved borrow requisition {req.ControlNo}",
                null,
                System.Text.Json.JsonSerializer.Serialize(req),
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(req);
        }
    }
}
