using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using ISMS.Api.Data;
using ISMS.Api.Models;
using ISMS.Api.Services;

namespace ISMS.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ISMSDbContext _db;
        private readonly IConfiguration _config;
        private readonly IAuditLogService _audit;

        public AuthController(ISMSDbContext db, IConfiguration config, IAuditLogService audit)
        {
            _db = db;
            _config = config;
            _audit = audit;
        }

        public record LoginRequest(string Identifier, string Password);
        public record RefreshRequest(string RefreshToken);
        public record ChangePasswordRequest(string CurrentPassword, string NewPassword);
        public record LoginResponse(
            bool Success, 
            string Message, 
            string? Token, 
            string? RefreshToken, 
            bool MustChangePassword, 
            object? User,
            List<string>? Permissions
        );

        private string GetJwtSecret()
        {
            string? secretKey = _config["JwtSettings:SecretKey"] 
                ?? Environment.GetEnvironmentVariable("JwtSettings__SecretKey")
                ?? Environment.GetEnvironmentVariable("JWT_SECRET_KEY");

            if (string.IsNullOrWhiteSpace(secretKey) || secretKey.Length < 32)
            {
                throw new InvalidOperationException("CRITICAL SECURITY ERROR: JwtSettings:SecretKey is missing or too short. Configure a secret key of at least 32 characters.");
            }
            return secretKey;
        }

        private static string HashToken(string token)
        {
            using var sha256 = SHA256.Create();
            byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(token));
            return Convert.ToHexString(hash);
        }

        private async Task<(string AccessToken, string RefreshToken)> GenerateTokensAsync(User user, List<string> permissions)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(GetJwtSecret());

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId),
                new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
                new Claim("EmployeeId", user.EmployeeId),
                new Claim(ClaimTypes.Role, user.RoleId),
                new Claim("Department", user.Department),
                new Claim("Section", user.Section),
                new Claim("Factory", user.Factory),
                new Claim("Shift", user.Shift)
            };

            foreach (var perm in permissions)
            {
                claims.Add(new Claim("Permission", perm));
            }

            int expMinutes = int.TryParse(_config["JwtSettings:ExpirationMinutes"], out int mins) ? mins : 30;
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddMinutes(expMinutes),
                Issuer = _config["JwtSettings:Issuer"] ?? "https://isms-api.corp.jae.com.ph",
                Audience = _config["JwtSettings:Audience"] ?? "https://isms.corp.jae.com.ph",
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            string accessToken = tokenHandler.WriteToken(token);

            // Generate cryptographic refresh token
            byte[] randomBytes = new byte[64];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(randomBytes);
            string rawRefreshToken = Convert.ToBase64String(randomBytes);
            string refreshTokenHash = HashToken(rawRefreshToken);

            // Persist session to sec.UserSessions
            var session = new UserSession
            {
                SessionId = Guid.NewGuid().ToString(),
                UserId = user.UserId,
                RefreshTokenHash = refreshTokenHash,
                IpAddress = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                UserAgent = Request.Headers.UserAgent.ToString(),
                CreatedAt = DateTimeOffset.UtcNow,
                ExpiresAt = DateTimeOffset.UtcNow.AddDays(7)
            };

            _db.UserSessions.Add(session);
            await _db.SaveChangesAsync();

            return (accessToken, rawRefreshToken);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.Identifier) || string.IsNullOrWhiteSpace(req.Password))
                return BadRequest(new LoginResponse(false, "Identifier and Password are required.", null, null, false, null, null));

            string term = req.Identifier.Trim().ToLower();
            var user = await _db.Users
                .Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.Username.ToLower() == term || u.EmployeeId.ToLower() == term || u.Email.ToLower() == term);

            if (user == null || !user.IsActive)
            {
                return Unauthorized(new LoginResponse(false, "Invalid credentials or deactivated account.", null, null, false, null, null));
            }

            // Check Account Lockout Policy
            if (user.LockoutEnd.HasValue && user.LockoutEnd > DateTimeOffset.UtcNow)
            {
                var remaining = user.LockoutEnd.Value - DateTimeOffset.UtcNow;
                return Unauthorized(new LoginResponse(false, $"Account is temporarily locked due to excessive failed attempts. Please retry in {Math.Ceiling(remaining.TotalMinutes)} minutes.", null, null, false, null, null));
            }

            // Strict BCrypt verification (No hardcoded bypasses)
            bool isPasswordValid = false;
            try
            {
                isPasswordValid = BCrypt.Net.BCrypt.Verify(req.Password, user.PasswordHash);
            }
            catch
            {
                isPasswordValid = false;
            }

            if (!isPasswordValid)
            {
                user.FailedLoginAttempts++;
                if (user.FailedLoginAttempts >= 5)
                {
                    user.LockoutEnd = DateTimeOffset.UtcNow.AddMinutes(15);
                }
                user.UpdatedAt = DateTimeOffset.UtcNow;
                await _db.SaveChangesAsync();

                await _audit.LogAsync(
                    Guid.NewGuid().ToString(),
                    user.UserId,
                    user.EmployeeId,
                    $"{user.FirstName} {user.LastName}",
                    user.RoleId,
                    "Authentication",
                    "LOGIN_FAILED",
                    user.UserId,
                    $"Failed login attempt ({user.FailedLoginAttempts}/5) from {HttpContext.Connection.RemoteIpAddress}",
                    null,
                    null,
                    HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                    Request.Headers.UserAgent.ToString()
                );

                return Unauthorized(new LoginResponse(false, "Invalid username or password.", null, null, false, null, null));
            }

            // Reset failed login counter upon successful authentication
            user.FailedLoginAttempts = 0;
            user.LockoutEnd = null;
            user.LastLoginAt = DateTimeOffset.UtcNow;
            user.UpdatedAt = DateTimeOffset.UtcNow;
            await _db.SaveChangesAsync();

            // Load all granular permissions assigned to user's role
            var permissions = await _db.RolePermissions
                .Where(rp => rp.RoleId == user.RoleId)
                .Select(rp => rp.PermissionId)
                .ToListAsync();

            var (accessToken, refreshToken) = await GenerateTokensAsync(user, permissions);

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                user.UserId,
                user.EmployeeId,
                $"{user.FirstName} {user.LastName}",
                user.RoleId,
                "Authentication",
                "LOGIN_SUCCESS",
                user.UserId,
                $"Operator {user.EmployeeId} ({user.FirstName} {user.LastName}) logged in successfully.",
                null,
                null,
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(new LoginResponse(true, "Authentication successful", accessToken, refreshToken, user.MustChangePassword, new
            {
                user.UserId,
                user.EmployeeId,
                user.Username,
                user.FirstName,
                user.LastName,
                user.Email,
                user.Department,
                user.Section,
                user.Factory,
                user.Shift,
                user.RoleId,
                user.MustChangePassword
            }, permissions));
        }

        [HttpPost("refresh")]
        public async Task<IActionResult> Refresh([FromBody] RefreshRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.RefreshToken))
                return BadRequest(new { message = "RefreshToken is required." });

            string tokenHash = HashToken(req.RefreshToken);
            var session = await _db.UserSessions
                .Include(s => s.User)
                .FirstOrDefaultAsync(s => s.RefreshTokenHash == tokenHash);

            if (session == null || session.RevokedAt != null || session.ExpiresAt <= DateTimeOffset.UtcNow || session.User == null || !session.User.IsActive)
            {
                return Unauthorized(new { message = "Invalid or expired session. Please log in again." });
            }

            // Revoke current session (Token rotation)
            session.RevokedAt = DateTimeOffset.UtcNow;

            var permissions = await _db.RolePermissions
                .Where(rp => rp.RoleId == session.User.RoleId)
                .Select(rp => rp.PermissionId)
                .ToListAsync();

            var (newAccessToken, newRefreshToken) = await GenerateTokensAsync(session.User, permissions);

            return Ok(new
            {
                token = newAccessToken,
                refreshToken = newRefreshToken
            });
        }

        [HttpPost("logout")]
        [Authorize]
        public async Task<IActionResult> Logout([FromBody] RefreshRequest? req)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (!string.IsNullOrEmpty(req?.RefreshToken))
            {
                string tokenHash = HashToken(req.RefreshToken);
                var session = await _db.UserSessions.FirstOrDefaultAsync(s => s.RefreshTokenHash == tokenHash);
                if (session != null)
                {
                    session.RevokedAt = DateTimeOffset.UtcNow;
                    await _db.SaveChangesAsync();
                }
            }
            else if (!string.IsNullOrEmpty(userId))
            {
                // Revoke all active sessions for this user
                var sessions = await _db.UserSessions
                    .Where(s => s.UserId == userId && s.RevokedAt == null)
                    .ToListAsync();
                foreach (var s in sessions)
                {
                    s.RevokedAt = DateTimeOffset.UtcNow;
                }
                await _db.SaveChangesAsync();
            }

            return Ok(new { message = "Logged out successfully." });
        }

        [HttpPost("change-password")]
        [Authorize]
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest req)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            if (string.IsNullOrWhiteSpace(req.NewPassword) || req.NewPassword.Length < 6)
            {
                return BadRequest(new { message = "New password must be at least 6 characters long." });
            }

            var user = await _db.Users.FirstOrDefaultAsync(u => u.UserId == userId);
            if (user == null || !user.IsActive)
                return NotFound(new { message = "User not found." });

            if (!BCrypt.Net.BCrypt.Verify(req.CurrentPassword, user.PasswordHash))
            {
                return BadRequest(new { message = "Current password is incorrect." });
            }

            // Standard BCrypt hashing with work factor 11
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(req.NewPassword, workFactor: 11);
            user.MustChangePassword = false;
            user.UpdatedAt = DateTimeOffset.UtcNow;

            // Revoke other active sessions for security
            var otherSessions = await _db.UserSessions
                .Where(s => s.UserId == user.UserId && s.RevokedAt == null)
                .ToListAsync();
            foreach (var s in otherSessions)
            {
                s.RevokedAt = DateTimeOffset.UtcNow;
            }

            await _db.SaveChangesAsync();

            await _audit.LogAsync(
                Guid.NewGuid().ToString(),
                user.UserId,
                user.EmployeeId,
                $"{user.FirstName} {user.LastName}",
                user.RoleId,
                "Authentication",
                "PASSWORD_ROTATED",
                user.UserId,
                $"Operator {user.EmployeeId} updated their password successfully.",
                null,
                "{\"Status\":\"PasswordChanged\"}",
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Request.Headers.UserAgent.ToString()
            );

            return Ok(new { success = true, message = "Password updated successfully. Please use your new credentials on future logins." });
        }
    }
}

