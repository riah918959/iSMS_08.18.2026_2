using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ISMS.Api.Data;

namespace ISMS.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AuditController : ControllerBase
    {
        private readonly ISMSDbContext _db;

        public AuditController(ISMSDbContext db)
        {
            _db = db;
        }

        [HttpGet]
        [Authorize(Roles = "SYSADMIN,ADMIN,QM,QA,Sysadmin,Admin,QM,QA")]
        public async Task<IActionResult> GetAuditLogs([FromQuery] int limit = 100)
        {
            var logs = await _db.AuditLogs
                .OrderByDescending(a => a.Timestamp)
                .Take(limit)
                .ToListAsync();

            return Ok(logs);
        }

        [HttpGet("verify-integrity")]
        [Authorize(Roles = "SYSADMIN,ADMIN,QM,QA,Sysadmin,Admin,QM,QA")]
        public async Task<IActionResult> VerifyIntegrity()
        {
            var logs = await _db.AuditLogs
                .OrderBy(a => a.AuditId)
                .ToListAsync();

            // Chain verification
            bool isValid = true;
            string lastHash = "GENESIS_BLOCK_JAE_ISMS_2026";
            int invalidIndex = -1;

            for (int i = 0; i < logs.Count; i++)
            {
                if (logs[i].PreviousBlockHash != lastHash)
                {
                    isValid = false;
                    invalidIndex = i;
                    break;
                }
                lastHash = logs[i].CurrentBlockHash;
            }

            return Ok(new
            {
                totalRecords = logs.Count,
                chainValid = isValid,
                tamperedRecordIndex = invalidIndex,
                genesisHash = "GENESIS_BLOCK_JAE_ISMS_2026",
                latestBlockHash = lastHash
            });
        }
    }
}
