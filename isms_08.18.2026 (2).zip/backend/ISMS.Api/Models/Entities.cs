using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ISMS.Api.Models
{
    // ==========================================
    // SECURITY & RBAC ENTITIES
    // ==========================================
    [Table("Roles", Schema = "sec")]
    public class Role
    {
        [Key]
        [MaxLength(50)]
        public string RoleId { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string RoleName { get; set; } = string.Empty;

        [MaxLength(255)]
        public string? Description { get; set; }

        public int HierarchyLevel { get; set; } = 1;
        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
        public bool IsActive { get; set; } = true;

        public virtual ICollection<User> Users { get; set; } = new List<User>();
        public virtual ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
    }

    [Table("Permissions", Schema = "sec")]
    public class Permission
    {
        [Key]
        [MaxLength(100)]
        public string PermissionId { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Category { get; set; } = string.Empty;

        [Required]
        [MaxLength(255)]
        public string Description { get; set; } = string.Empty;

        public virtual ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
    }

    [Table("RolePermissions", Schema = "sec")]
    public class RolePermission
    {
        [MaxLength(50)]
        public string RoleId { get; set; } = string.Empty;
        public virtual Role? Role { get; set; }

        [MaxLength(100)]
        public string PermissionId { get; set; } = string.Empty;
        public virtual Permission? Permission { get; set; }

        public DateTimeOffset AssignedAt { get; set; } = DateTimeOffset.UtcNow;
    }

    [Table("Users", Schema = "sec")]
    public class User
    {
        [Key]
        [MaxLength(64)]
        public string UserId { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [MaxLength(50)]
        public string EmployeeId { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Username { get; set; } = string.Empty;

        [Required]
        [MaxLength(255)]
        public string PasswordHash { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [MaxLength(150)]
        public string Email { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Department { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Section { get; set; } = string.Empty;

        [Required]
        [MaxLength(20)]
        public string Factory { get; set; } = "1F";

        [Required]
        [MaxLength(20)]
        public string Shift { get; set; } = "Shift A";

        [Required]
        [MaxLength(50)]
        public string RoleId { get; set; } = string.Empty;
        public virtual Role? Role { get; set; }

        public bool MustChangePassword { get; set; } = true;
        public bool IsActive { get; set; } = true;
        public int FailedLoginAttempts { get; set; } = 0;
        public DateTimeOffset? LockoutEnd { get; set; }
        public DateTimeOffset? LastLoginAt { get; set; }
        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public virtual ICollection<UserSession> Sessions { get; set; } = new List<UserSession>();
    }

    [Table("UserSessions", Schema = "sec")]
    public class UserSession
    {
        [Key]
        [MaxLength(64)]
        public string SessionId { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [MaxLength(64)]
        public string UserId { get; set; } = string.Empty;
        public virtual User? User { get; set; }

        [Required]
        [MaxLength(255)]
        public string RefreshTokenHash { get; set; } = string.Empty;

        [Required]
        [MaxLength(45)]
        public string IpAddress { get; set; } = "127.0.0.1";

        [MaxLength(255)]
        public string? UserAgent { get; set; }

        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset ExpiresAt { get; set; } = DateTimeOffset.UtcNow.AddDays(7);
        public DateTimeOffset? RevokedAt { get; set; }
    }

    [Table("DocumentSequences", Schema = "qms")]
    public class DocumentSequence
    {
        [MaxLength(20)]
        public string SequencePrefix { get; set; } = string.Empty;

        [MaxLength(6)]
        public string YearMonth { get; set; } = string.Empty;

        public int CurrentValue { get; set; } = 0;
        public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;
    }

    // ==========================================
    // KEEP SAMPLES ENTITIES
    // ==========================================
    [Table("KeepSampleBoxes", Schema = "qms")]
    public class KeepSampleBox
    {
        [Key]
        [MaxLength(64)]
        public string BoxId { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [MaxLength(50)]
        public string BoxNumber { get; set; } = string.Empty;

        [Required]
        [MaxLength(20)]
        public string Factory { get; set; } = "1F";

        [Required]
        [MaxLength(50)]
        public string Department { get; set; } = "QM";

        [Required]
        [MaxLength(50)]
        public string Section { get; set; } = string.Empty;

        [Required]
        [MaxLength(255)]
        public string ItemDescription { get; set; } = string.Empty;

        public int Quantity { get; set; } = 0;
        public DateOnly DateReceived { get; set; }
        public DateOnly ExpirationDate { get; set; }
        public int RetentionPeriodYears { get; set; } = 3;

        [Required]
        [MaxLength(30)]
        public string Status { get; set; } = "ACTIVE"; // ACTIVE, FOR CHECKING, EXPIRED, DISPOSED

        [Required]
        [MaxLength(30)]
        public string ArchiveType { get; set; } = "3-Year Standard";

        [Required]
        [MaxLength(50)]
        public string RackLocation { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string RequestedBy { get; set; } = string.Empty;

        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;

        [Timestamp]
        public byte[]? RowVersion { get; set; }

        public virtual ICollection<KeepSampleBoxItem> Items { get; set; } = new List<KeepSampleBoxItem>();
    }

    [Table("KeepSampleBoxItems", Schema = "qms")]
    public class KeepSampleBoxItem
    {
        [Key]
        [MaxLength(64)]
        public string ItemId { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [MaxLength(64)]
        public string BoxId { get; set; } = string.Empty;
        public virtual KeepSampleBox? Box { get; set; }

        [Required]
        [MaxLength(100)]
        public string DrawingNumber { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string ItemName { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string LotNumber { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? TerminalPartNumber { get; set; }

        public int Quantity { get; set; } = 1;

        [MaxLength(500)]
        public string? Remarks { get; set; }
    }

    [Table("KeepSampleRequests", Schema = "qms")]
    public class KeepSampleRequest
    {
        [Key]
        [MaxLength(64)]
        public string RequestId { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [MaxLength(50)]
        public string ControlNo { get; set; } = string.Empty;

        [MaxLength(64)]
        public string? BoxId { get; set; }

        [Required]
        [MaxLength(50)]
        public string BoxNumber { get; set; } = string.Empty;

        [Required]
        [MaxLength(20)]
        public string Factory { get; set; } = "1F";

        [Required]
        [MaxLength(50)]
        public string Department { get; set; } = "QM";

        [Required]
        [MaxLength(100)]
        public string RequestorName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [MaxLength(150)]
        public string RequestorEmail { get; set; } = string.Empty;

        public DateOnly DateNeeded { get; set; }
        public DateOnly ReturnedDueDate { get; set; }
        public DateOnly? ActualReturnedDate { get; set; }

        [Required]
        [MaxLength(50)]
        public string Status { get; set; } = "Unreturned"; // Unreturned, Returned To Original Box, For Filing the UKS

        [Required]
        [MaxLength(500)]
        public string ReasonForBorrowing { get; set; } = string.Empty;

        [MaxLength(100)]
        public string? QMApprovedBy { get; set; }
        public DateTimeOffset? QMApprovalDate { get; set; }

        [MaxLength(100)]
        public string? QCHoldReleasedBy { get; set; }
        public DateTimeOffset? QCHoldReleaseDate { get; set; }

        [MaxLength(100)]
        public string? QAInvestigatedBy { get; set; }

        [MaxLength(500)]
        public string? QADispositionResult { get; set; }

        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;

        [Timestamp]
        public byte[]? RowVersion { get; set; }
    }

    // ==========================================
    // RS/IS DEFECT SAMPLE ENTITIES
    // ==========================================
    [Table("RSISRecords", Schema = "qms")]
    public class RSISRecord
    {
        [Key]
        [MaxLength(64)]
        public string RecordId { get; set; } = Guid.NewGuid().ToString();

        [Required]
        [MaxLength(50)]
        public string ControlNo { get; set; } = string.Empty;

        [Required]
        [MaxLength(20)]
        public string Factory { get; set; } = "1F";

        [Required]
        [MaxLength(50)]
        public string Department { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Section { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string DrawingNumber { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string ItemName { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string LotNumber { get; set; } = string.Empty;

        public int Quantity { get; set; } = 1;

        [Required]
        [MaxLength(1000)]
        public string DefectDescription { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string DefectType { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string IssuedByName { get; set; } = string.Empty;

        public DateTimeOffset DateForwarded { get; set; } = DateTimeOffset.UtcNow;
        public DateOnly? DateNeeded { get; set; }
        public DateOnly? ReturnedDueDate { get; set; }

        // QC Hold Area
        [Required]
        [MaxLength(50)]
        public string QCHoldStatus { get; set; } = "No Received Sample";

        [MaxLength(100)]
        public string? QCHoldReceivedBy { get; set; }
        public DateTimeOffset? QCHoldReceivedAt { get; set; }

        // QM Review
        [Required]
        [MaxLength(50)]
        public string QMStatus { get; set; } = "Not Yet Approved";

        [MaxLength(100)]
        public string? QMReviewedBy { get; set; }
        public DateTimeOffset? QMReviewedAt { get; set; }

        [MaxLength(100)]
        public string? QMEndorsedToQAEngineer { get; set; }

        // QA Investigation
        [Required]
        [MaxLength(50)]
        public string QAStatus { get; set; } = "Open";

        [MaxLength(100)]
        public string? QAInvestigatedBy { get; set; }
        public DateTimeOffset? QAClosedAt { get; set; }

        [MaxLength(1000)]
        public string? QARootCause { get; set; }

        [MaxLength(500)]
        public string? QAFinalDisposition { get; set; }

        public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
        public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;

        [Timestamp]
        public byte[]? RowVersion { get; set; }
    }

    // ==========================================
    // IMMUTABLE AUDIT LOG ENTITY
    // ==========================================
    [Table("AuditLogs", Schema = "audit")]
    public class AuditLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long AuditId { get; set; }

        [Required]
        [MaxLength(64)]
        public string CorrelationId { get; set; } = Guid.NewGuid().ToString();

        public DateTimeOffset Timestamp { get; set; } = DateTimeOffset.UtcNow;

        [MaxLength(64)]
        public string? ActorUserId { get; set; }

        [Required]
        [MaxLength(50)]
        public string ActorEmployeeId { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string ActorName { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string ActorRole { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string Module { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string Action { get; set; } = string.Empty;

        [Required]
        [MaxLength(100)]
        public string RecordId { get; set; } = string.Empty;

        [Required]
        public string Details { get; set; } = string.Empty;

        public string? PreviousValues { get; set; }
        public string? NewValues { get; set; }

        [Required]
        [MaxLength(45)]
        public string IpAddress { get; set; } = "127.0.0.1";

        [MaxLength(255)]
        public string? UserAgent { get; set; }

        [MaxLength(64)]
        public string? PreviousBlockHash { get; set; }

        [Required]
        [MaxLength(64)]
        public string CurrentBlockHash { get; set; } = string.Empty;
    }
}
