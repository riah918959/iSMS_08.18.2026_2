using Microsoft.EntityFrameworkCore;
using ISMS.Api.Models;

namespace ISMS.Api.Data
{
    public class ISMSDbContext : DbContext
    {
        public ISMSDbContext(DbContextOptions<ISMSDbContext> options) : base(options)
        {
        }

        public DbSet<Role> Roles => Set<Role>();
        public DbSet<Permission> Permissions => Set<Permission>();
        public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
        public DbSet<User> Users => Set<User>();
        public DbSet<UserSession> UserSessions => Set<UserSession>();
        public DbSet<DocumentSequence> DocumentSequences => Set<DocumentSequence>();
        public DbSet<KeepSampleBox> KeepSampleBoxes => Set<KeepSampleBox>();
        public DbSet<KeepSampleBoxItem> KeepSampleBoxItems => Set<KeepSampleBoxItem>();
        public DbSet<KeepSampleRequest> KeepSampleRequests => Set<KeepSampleRequest>();
        public DbSet<RSISRecord> RSISRecords => Set<RSISRecord>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Composite Key for RolePermission
            modelBuilder.Entity<RolePermission>()
                .HasKey(rp => new { rp.RoleId, rp.PermissionId });

            modelBuilder.Entity<RolePermission>()
                .HasOne(rp => rp.Role)
                .WithMany(r => r.RolePermissions)
                .HasForeignKey(rp => rp.RoleId);

            modelBuilder.Entity<RolePermission>()
                .HasOne(rp => rp.Permission)
                .WithMany(p => p.RolePermissions)
                .HasForeignKey(rp => rp.PermissionId);

            // Composite Key for DocumentSequence
            modelBuilder.Entity<DocumentSequence>()
                .HasKey(ds => new { ds.SequencePrefix, ds.YearMonth });

            // UserSession configuration
            modelBuilder.Entity<UserSession>()
                .HasOne(us => us.User)
                .WithMany(u => u.Sessions)
                .HasForeignKey(us => us.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<UserSession>()
                .HasIndex(us => us.RefreshTokenHash)
                .IsUnique();

            // Indexes for fast querying
            modelBuilder.Entity<User>()
                .HasIndex(u => u.EmployeeId)
                .IsUnique();

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Username)
                .IsUnique();

            modelBuilder.Entity<KeepSampleBox>()
                .HasIndex(b => b.BoxNumber)
                .IsUnique();

            modelBuilder.Entity<KeepSampleRequest>()
                .HasIndex(r => r.ControlNo)
                .IsUnique();

            modelBuilder.Entity<RSISRecord>()
                .HasIndex(r => r.ControlNo)
                .IsUnique();

            modelBuilder.Entity<AuditLog>()
                .HasIndex(a => a.CorrelationId);

            modelBuilder.Entity<AuditLog>()
                .HasIndex(a => a.Timestamp);
        }
    }
}
