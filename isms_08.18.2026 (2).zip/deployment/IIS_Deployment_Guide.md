# JAE Philippines, Inc. - iSMS On-Premise Production Deployment Guide
**Target Environment:** Windows Server 2019/2022 + IIS 10 + Microsoft SQL Server 2019/2022

---

## 1. Architecture Overview
```
[Client Web Browser (Edge / Chrome)]
              │ (HTTPS :443)
              ▼
[Windows Server 2022 - IIS 10 Reverse Proxy & SPA Host]
   ├── SPA Static Files: C:\inetpub\wwwroot\isms-frontend
   └── ASP.NET Core 8 Web API: C:\inetpub\wwwroot\isms-api (Kestrel Process :5000)
              │
              │ (TCP 1433 with Encrypted TDS)
              ▼
[Microsoft SQL Server 2022 (ISMS_QM_DB)]
   ├── Schema [qms]: Sample Boxes, Requisitions, RS/IS Masterlist
   ├── Schema [sec]: User Accounts, Roles, Permissions (PBKDF2/BCrypt)
   └── Schema [audit]: SHA-256 Cryptographic Hash Chained Audit Trail
```

---

## 2. Server Prerequisites
1. **Windows Server 2019 or 2022** (Standard or Datacenter edition)
2. **.NET 8.0 Hosting Bundle**: Install ASP.NET Core Runtime 8.x + IIS AspNetCoreModuleV2
3. **IIS 10 Features**: Web Server (IIS), URL Rewrite Module 2.1, Application Request Routing (ARR) 3.0
4. **Microsoft SQL Server 2019 or 2022 Standard/Enterprise** or **SQL Server 2022 Express**

---

## 3. Database Deployment Steps
1. Open **SQL Server Management Studio (SSMS)** as Administrator.
2. Connect to target instance (e.g. `JAE-ISMS-SQL01\SQLEXPRESS`).
3. Execute SQL scripts sequentially:
   - `001_CreateDatabase.sql`
   - `002_Security_RBAC.sql`
   - `003_KeepSamples.sql`
   - `004_RSIS.sql`
   - `005_Y2K.sql`
   - `006_Production.sql`
   - `007_Audit_Immutable.sql`
   - `008_SeedData.sql`

---

## 4. ASP.NET Core 8 API Publication & IIS Site Setup
1. In development terminal:
   ```bash
   cd backend/ISMS.Api
   dotnet publish -c Release -o C:\publish\isms-api
   ```
2. Copy files to production directory: `C:\inetpub\wwwroot\isms-api`.
3. In IIS Manager:
   - Create Application Pool: `ISMS_Api_AppPool` (No Managed Code, Integrated pipeline).
   - Set Identity: ApplicationPoolIdentity or domain service account `corp\svc_isms`.
   - Add Website: `iSMS_API` bound to port `5000` or HTTPS port `443/api`.

---

## 5. React Frontend Deployment
1. Build frontend:
   ```bash
   npm run build
   ```
2. Copy contents of `dist/` to `C:\inetpub\wwwroot\isms-frontend`.
3. Place standard SPA `web.config` inside `C:\inetpub\wwwroot\isms-frontend`:
   ```xml
   <?xml version="1.0" encoding="UTF-8"?>
   <configuration>
     <system.webServer>
       <rewrite>
         <rules>
           <rule name="React SPA Fallback" stopProcessing="true">
             <match url=".*" />
             <conditions logicalGrouping="MatchAll">
               <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
               <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
             </conditions>
             <action type="Rewrite" url="/" />
           </rule>
         </rules>
       </rewrite>
     </system.webServer>
   </configuration>
   ```

---

## 6. Verification
- Test API Health: `https://isms-api.corp.jae.com.ph/api/health`
- Test Frontend: `https://isms.corp.jae.com.ph`
