# JAE Philippines, Inc. - iSMS Backup & Disaster Recovery Runbook
**Compliance:** IATF 16949 §7.5.3 (Control of documented information) / ISO 9001:2015

---

## 1. Physical SQL Server Backup Strategy
SQL Server requires native binary `.bak` backup files with checksum verification and transaction log management.

### Recommended Production Schedule:
- **Full Database Backup (.BAK)**: Daily at 01:00 AM (Retained for 30 days on NAS)
- **Differential Backup**: Every 4 hours
- **Transaction Log Backup**: Every 15 minutes (Enables Point-In-Time recovery with RPO < 15 min)

---

## 2. Automated T-SQL Backup Maintenance Script
```sql
USE master;
GO

-- 1. Full Database Backup with Compression & Checksum
DECLARE @BackupFile NVARCHAR(500);
SET @BackupFile = N'D:\SQL_Backups\ISMS_QM_DB_FULL_' + REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), ':', '-') + N'.bak';

BACKUP DATABASE [ISMS_QM_DB]
TO DISK = @BackupFile
WITH FORMAT,
     MEDIANAME = N'ISMS_DB_Backups',
     NAME = N'Full Backup of ISMS_QM_DB',
     COMPRESSION,
     CHECKSUM,
     STATS = 10;
GO

-- 2. Verify Backup Integrity
RESTORE VERIFYONLY FROM DISK = N'D:\SQL_Backups\ISMS_QM_DB_FULL_Latest.bak';
GO
```

---

## 3. Disaster Recovery Restoration Procedure
1. If the database server experiences hardware failure:
   ```sql
   USE master;
   GO
   RESTORE DATABASE [ISMS_QM_DB]
   FROM DISK = N'D:\SQL_Backups\ISMS_QM_DB_FULL_2026-08-15.bak'
   WITH REPLACE, RECOVERY, STATS = 5;
   GO
   ```
2. Re-verify SHA-256 Audit Chain via API endpoint:
   `GET /api/audit/verify-integrity`
