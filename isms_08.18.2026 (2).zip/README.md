# iSMS - Integrated Sample Management System (JAE Philippines)

Integrated Sample Management System for JAE Philippines Quality Management Department. Handles automotive connector and wire harness manufacturing sample tracking, Keep Sample Entry & Requests, RS/IS Sample Management, Inspection schedules, and Production/Audit verification workflows.

## Features & Modules

- **Summary & Notifications**: Real-time KPI Dashboard, P.I.C Alert Matrix & Action Items.
- **Sample Entry**:
  - Y2K Masterlist (Complete Automotive Sample Inventory & Storage Management).
  - Keep Sample Entry (1F/2F multi-location box & rack filing).
  - RS / IS Sample Entry (Multi-role endorsement: Requestor, QC Hold, QM Routing & QA Disposition).
- **Request Sample**:
  - Keep Sample Borrow Requisition & Return Tracking.
  - RS / IS Multi-role Borrow & Auto-Notification Workflows.
- **Administration & System**:
  - Batch Schedule & Production Schedule calendars.
  - Quality Analytics (Defect pareto, hold distribution, trend charts).
  - User Registry with RBAC (Sysadmin, QM, QC, QA, Engineering, Production, Requestor).
  - SQL Hub (ISMS_QM_DB Connection & Table Browser).
  - Audit Trail & Activity Logs.

## UI Design & Standards
- Standardized colorful module headers with emerald-green and magenta-pink theme.
- High-contrast enterprise tables with dark-green borders (`.isms-table`) and pink hover/active states.
- Double-click row interaction to open detailed record workspaces.
- Standardized corporate identity header anchored directly above the sidebar navigation.

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Run local development server:
   ```bash
   npm run dev
   ```

3. Build production bundle:
   ```bash
   npm run build
   ```
