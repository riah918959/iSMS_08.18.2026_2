import React, { useState } from 'react';
import {
  Search,
  Download,
  Shield,
  Clock,
  User,
  Eye,
  CheckCircle2,
  Terminal,
  Activity,
  Calendar,
  Filter,
  RotateCcw,
  SlidersHorizontal
} from 'lucide-react';
import { AuditLogEntry, UserProfile } from '../types';
import { storageService } from '../services/storageService';

interface AuditLogsViewProps {
  currentUser: UserProfile;
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ currentUser }) => {
  const [logs, setLogs] = useState<AuditLogEntry[]>(storageService.getAuditLogs());
  const [searchQuery, setSearchQuery] = useState('');
  const [moduleFilter, setModuleFilter] = useState<string>('All');
  const [actionFilter, setActionFilter] = useState<string>('All');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [shiftFilter, setShiftFilter] = useState<string>('ALL');
  const [selectedLog, setSelectedLog] = useState<AuditLogEntry | null>(null);

  const getActorName = (l: AuditLogEntry) => l.actorName || l.staffName || 'System Engine';
  const getActorId = (l: AuditLogEntry) => l.actorEmployeeId || l.staffId || 'SYS-AUTO';
  const getActorRole = (l: AuditLogEntry) => l.actorRole || l.role || 'Sysadmin';
  const getTargetId = (l: AuditLogEntry) => l.targetId || l.recordId || 'N/A';

  const applyPreset = (preset: string) => {
    const today = new Date();
    const formatDate = (d: Date) => d.toISOString().split('T')[0];

    if (preset === 'TODAY') {
      setStartDate(formatDate(today));
      setEndDate(formatDate(today));
      setShiftFilter('ALL');
    } else if (preset === 'YESTERDAY') {
      const yesterday = new Date(today);
      yesterday.setDate(today.getDate() - 1);
      setStartDate(formatDate(yesterday));
      setEndDate(formatDate(yesterday));
      setShiftFilter('ALL');
    } else if (preset === 'PAST_7_DAYS') {
      const past7 = new Date(today);
      past7.setDate(today.getDate() - 7);
      setStartDate(formatDate(past7));
      setEndDate(formatDate(today));
      setShiftFilter('ALL');
    } else if (preset === 'THIS_MONTH') {
      const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
      setStartDate(formatDate(firstDay));
      setEndDate(formatDate(today));
      setShiftFilter('ALL');
    } else if (preset === 'RESET') {
      setStartDate('');
      setEndDate('');
      setShiftFilter('ALL');
      setModuleFilter('All');
      setActionFilter('All');
      setSearchQuery('');
    }
  };

  const handleExportCSV = () => {
    const csvContent = [
      ['Timestamp', 'Actor Employee ID', 'Actor Name', 'Role', 'Module', 'Action', 'Target ID / Control No', 'Where / Station', 'Details'],
      ...filteredLogs.map(l => [
        l.timestamp,
        getActorId(l),
        `"${getActorName(l)}"`,
        getActorRole(l),
        l.module,
        l.action,
        `"${getTargetId(l)}"`,
        `"${l.ipAddress || 'Internal'}"`,
        `"${l.details.replace(/"/g, '""')}"`
      ])
    ].map(e => e.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `iSMS_Compliance_Audit_Log_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredLogs = logs.filter((l) => {
    const actorName = getActorName(l);
    const actorId = getActorId(l);
    const target = getTargetId(l);
    const q = searchQuery.toLowerCase();

    const matchesSearch =
      actorName.toLowerCase().includes(q) ||
      actorId.toLowerCase().includes(q) ||
      target.toLowerCase().includes(q) ||
      l.details.toLowerCase().includes(q) ||
      (l.ipAddress || '').toLowerCase().includes(q);

    const matchesModule = moduleFilter === 'All' || l.module === moduleFilter;
    const matchesAction = actionFilter === 'All' || l.action === actionFilter;

    // Date range filter
    let matchesDate = true;
    if (startDate || endDate) {
      const logDateStr = l.timestamp.split(' ')[0] || l.timestamp.split('T')[0];
      if (startDate && logDateStr < startDate) {
        matchesDate = false;
      }
      if (endDate && logDateStr > endDate) {
        matchesDate = false;
      }
    }

    // Shift filter based on timestamp hour
    let matchesShift = true;
    if (shiftFilter !== 'ALL') {
      const timePart = l.timestamp.split(' ')[1] || (l.timestamp.includes('T') ? l.timestamp.split('T')[1] : '');
      const hour = parseInt(timePart.split(':')[0], 10);
      if (!isNaN(hour)) {
        if (shiftFilter === 'DAY') {
          // Day shift: 06:00 to 18:00
          matchesShift = hour >= 6 && hour < 18;
        } else if (shiftFilter === 'NIGHT') {
          // Night shift: 18:00 to 06:00
          matchesShift = hour >= 18 || hour < 6;
        }
      }
    }

    return matchesSearch && matchesModule && matchesAction && matchesDate && matchesShift;
  });

  return (
    <div id="audit-logs-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette, compact 3/4 layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <Shield className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                Audit Trail & Operational Telemetry
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                IATF 16949 COMPLIANCE
              </span>
            </div>
            <p className="text-xs text-emerald-200/90 font-medium">
              Production Traceability Ledger • Recording Who did What, When, Where, to Which Record, and What Changed
            </p>
          </div>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-md flex items-center space-x-1.5 transition-all transform active:scale-98"
        >
          <Download className="w-4 h-4" />
          <span>Export Audit Trail (CSV)</span>
        </button>
      </div>

      {/* Quick Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Recorded Events</span>
            <div className="text-2xl font-bold font-mono text-white mt-0.5">{logs.length}</div>
          </div>
          <div className="p-3 bg-pink-950/60 text-pink-400 rounded-xl border border-pink-700/50">
            <Activity className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Security Level</span>
            <div className="text-2xl font-bold font-mono text-emerald-400 mt-0.5">IATF 16949</div>
          </div>
          <div className="p-3 bg-emerald-950/60 text-emerald-400 rounded-xl border border-emerald-700/50">
            <Shield className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Operational Mode</span>
            <div className="text-2xl font-bold font-mono text-slate-200 mt-0.5">Zero AI Ops</div>
          </div>
          <div className="p-3 bg-slate-800 text-slate-300 rounded-xl border border-slate-700">
            <Terminal className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Audit Integrity</span>
            <div className="text-2xl font-bold font-mono text-sky-400 mt-0.5">Verified 100%</div>
          </div>
          <div className="p-3 bg-sky-950/60 text-sky-400 rounded-xl border border-sky-700/50">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH TOOLBAR (With Date-Range & Shift Filters - Request #6) */}
      <div className="bg-[#1A1A1A] p-4 rounded-xl shadow-xs border border-emerald-800/40 space-y-3 text-xs">
        
        {/* Row 1: Search and Category Dropdowns */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search by Actor Name, Employee ID, Control No, Workstation, or Change Details..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#141414] border border-slate-700 text-white rounded-lg pl-9 pr-3 py-2 text-xs focus:outline-none focus:border-pink-500 placeholder-slate-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={moduleFilter}
              onChange={(e) => setModuleFilter(e.target.value)}
              className="bg-[#141414] border border-slate-700 text-slate-200 rounded-lg px-3 py-2 text-xs font-semibold focus:outline-none focus:border-pink-500"
            >
              <option value="All">All System Modules</option>
              <option value="KEEP_SAMPLE_BOX">Keep Sample Boxes</option>
              <option value="KEEP_SAMPLE_ENTRY">Keep Sample Entry</option>
              <option value="KEEP_SAMPLE_REQUEST">Keep Sample Requests</option>
              <option value="RSIS_ENTRY">RS/IS Sample Records</option>
              <option value="RSIS_SAMPLE_RECORD">RS/IS Records</option>
              <option value="Y2K_MASTERLIST">Y2K Masterlist</option>
              <option value="Y2K_LOCATION">Y2K Locations</option>
              <option value="PRODUCTION_SCHEDULE">Production Schedules</option>
              <option value="USER_REGISTRY">User Registry</option>
              <option value="SYSTEM_SYNC">System Sync & Config</option>
            </select>

            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="bg-[#141414] border border-slate-700 text-slate-200 rounded-lg px-3 py-2 text-xs font-semibold focus:outline-none focus:border-pink-500"
            >
              <option value="All">All Actions</option>
              <option value="CREATE">CREATE (New Record)</option>
              <option value="UPDATE">UPDATE (Edit Data)</option>
              <option value="STATUS_CHANGE">STATUS_CHANGE (Workflow)</option>
              <option value="RECEIVE">RECEIVE (QC Intake)</option>
              <option value="RETURN">RETURN (Re-filing)</option>
              <option value="APPROVE">APPROVE (QM Sign-off)</option>
              <option value="DELETE">DELETE (Record Removal)</option>
              <option value="RUN_BATCH">RUN_BATCH (Automated Sweep)</option>
              <option value="SYNC">SYNC (SQL Server)</option>
            </select>
          </div>
        </div>

        {/* Row 2: Date Range Picker & Shift Presets */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 pt-2 border-t border-gray-800/80">
          
          {/* Date Picker Inputs */}
          <div className="flex flex-wrap items-center gap-2 text-gray-300">
            <div className="flex items-center gap-1.5 bg-[#141414] border border-slate-700 rounded-lg px-2.5 py-1.5">
              <Calendar className="w-3.5 h-3.5 text-pink-400" />
              <span className="text-[11px] font-bold text-gray-400">FROM:</span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="bg-transparent text-white text-xs font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 bg-[#141414] border border-slate-700 rounded-lg px-2.5 py-1.5">
              <Calendar className="w-3.5 h-3.5 text-pink-400" />
              <span className="text-[11px] font-bold text-gray-400">TO:</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="bg-transparent text-white text-xs font-mono focus:outline-none"
              />
            </div>

            {/* Shift Filter Dropdown */}
            <div className="flex items-center gap-1.5 bg-[#141414] border border-slate-700 rounded-lg px-2.5 py-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-[11px] font-bold text-gray-400">SHIFT:</span>
              <select
                value={shiftFilter}
                onChange={(e) => setShiftFilter(e.target.value)}
                className="bg-transparent text-white text-xs font-semibold focus:outline-none cursor-pointer"
              >
                <option value="ALL" className="bg-[#1a1a1a]">All Shifts (24H)</option>
                <option value="DAY" className="bg-[#1a1a1a]">Day Shift (06:00 - 18:00)</option>
                <option value="NIGHT" className="bg-[#1a1a1a]">Night Shift (18:00 - 06:00)</option>
              </select>
            </div>
          </div>

          {/* Quick Presets & Reset */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[10px] text-gray-500 font-bold uppercase mr-1">Quick Ranges:</span>
            <button
              onClick={() => applyPreset('TODAY')}
              className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded border border-gray-700 text-[10px] font-bold uppercase transition-colors"
            >
              Today
            </button>
            <button
              onClick={() => applyPreset('YESTERDAY')}
              className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded border border-gray-700 text-[10px] font-bold uppercase transition-colors"
            >
              Yesterday
            </button>
            <button
              onClick={() => applyPreset('PAST_7_DAYS')}
              className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded border border-gray-700 text-[10px] font-bold uppercase transition-colors"
            >
              Past 7 Days
            </button>
            <button
              onClick={() => applyPreset('THIS_MONTH')}
              className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white rounded border border-gray-700 text-[10px] font-bold uppercase transition-colors"
            >
              This Month
            </button>
            {(startDate || endDate || shiftFilter !== 'ALL' || moduleFilter !== 'All' || actionFilter !== 'All' || searchQuery) && (
              <button
                onClick={() => applyPreset('RESET')}
                className="px-2.5 py-1 bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 rounded border border-rose-700/60 text-[10px] font-bold uppercase flex items-center gap-1 transition-colors"
              >
                <RotateCcw className="w-3 h-3 text-rose-400" />
                <span>Clear Filters</span>
              </button>
            )}
          </div>

        </div>

      </div>


      {/* AUDIT LOG TABLE (High-Contrast isms-table) */}
      <div className="bg-[#141414] rounded-2xl shadow-xl border-2 border-emerald-800/80 overflow-hidden">
        <div className="p-4 md:p-5 border-b border-emerald-800/60 flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-[#18231c] via-[#141a16] to-[#121212]">
          <div className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-pink-400" />
            <div>
              <h2 className="text-base font-bold text-white font-['Chakra_Petch'] uppercase tracking-wide">
                OPERATIONAL & SECURITY TRANSACTION LEDGER
              </h2>
              <span className="text-xs text-emerald-300/80 font-mono">({filteredLogs.length} Verified Records) • IATF 16949 Compliant</span>
            </div>
          </div>
          <span className="text-xs text-emerald-400 font-mono bg-emerald-950/70 border border-emerald-700/50 px-3 py-1 rounded-lg">
            Zero AI Metadata • Pure Operational State
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse isms-table">
            <thead>
              <tr className="bg-[#0b1912] text-white border-b border-emerald-800/80 font-bold uppercase text-[11px] tracking-wider">
                <th className="p-3 border-r border-emerald-800/60">WHEN (TIMESTAMP)</th>
                <th className="p-3 border-r border-emerald-800/60">WHO (ACTOR & ID)</th>
                <th className="p-3 border-r border-emerald-800/60">ROLE</th>
                <th className="p-3 border-r border-emerald-800/60">WHERE (MODULE / STATION)</th>
                <th className="p-3 border-r border-emerald-800/60">WHAT (ACTION)</th>
                <th className="p-3 border-r border-emerald-800/60">TO WHICH RECORD</th>
                <th className="p-3 border-r border-emerald-800/60">WHAT CHANGED (DETAILS)</th>
                <th className="p-3 text-center">INSPECT</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-emerald-900/40 bg-[#161616] text-slate-200 font-mono">
              {filteredLogs.map((log) => {
                const actorName = getActorName(log);
                const actorId = getActorId(log);
                const actorRole = getActorRole(log);
                const target = getTargetId(log);

                return (
                  <tr
                    key={log.id}
                    onDoubleClick={() => setSelectedLog(log)}
                    className="hover:bg-pink-950/30 transition-colors cursor-pointer border-b border-emerald-900/40"
                  >
                    <td className="p-3 border-r border-emerald-900/40 text-slate-400 whitespace-nowrap text-[11px]">
                      {log.timestamp}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 whitespace-nowrap">
                      <div className="font-bold text-white">{actorName}</div>
                      <div className="text-[10px] text-pink-400 font-mono">{actorId}</div>
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        actorRole === 'Sysadmin' || actorRole === 'Admin'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/50'
                          : actorRole === 'QC Hold'
                          ? 'bg-pink-950 text-pink-300 border border-pink-700/50'
                          : actorRole === 'QM'
                          ? 'bg-purple-950 text-purple-300 border border-purple-700/50'
                          : actorRole === 'QA'
                          ? 'bg-blue-950 text-blue-300 border border-blue-700/50'
                          : 'bg-slate-800 text-slate-300 border border-slate-700/50'
                      }`}>
                        {actorRole}
                      </span>
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 text-slate-300 whitespace-nowrap">
                      <div className="font-semibold text-emerald-300">{log.module}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[140px]">{log.ipAddress || 'Internal Workstation'}</div>
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                        log.action === 'CREATE'
                          ? 'bg-emerald-900/60 text-emerald-300 border border-emerald-600/50'
                          : log.action === 'STATUS_CHANGE' || log.action === 'APPROVE'
                          ? 'bg-purple-900/60 text-purple-300 border border-purple-600/50'
                          : log.action === 'RECEIVE' || log.action === 'RETURN'
                          ? 'bg-blue-900/60 text-blue-300 border border-blue-600/50'
                          : log.action === 'DELETE'
                          ? 'bg-rose-900/60 text-rose-300 border border-rose-600/50'
                          : 'bg-amber-900/60 text-amber-300 border border-amber-600/50'
                      }`}>
                        {log.action}
                      </span>
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 font-mono font-bold text-pink-400 whitespace-nowrap">
                      {target}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 max-w-md truncate text-slate-300 font-sans text-xs" title={log.details}>
                      {log.details}
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedLog(log);
                        }}
                        className="p-1.5 text-pink-400 hover:text-white bg-pink-950/40 hover:bg-pink-900/60 border border-pink-700/40 rounded-lg transition-colors"
                        title="View Full Audit Snapshot"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    No operational audit records match the current filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* INSPECT LOG MODAL */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="bg-[#181818] rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden border-2 border-emerald-700/80 text-white">
            <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 font-bold text-sm flex items-center justify-between font-['Chakra_Petch'] border-b border-emerald-600">
              <span className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-pink-400" />
                <span>Audit Snapshot Record ({selectedLog.id})</span>
              </span>
              <button
                onClick={() => setSelectedLog(null)}
                className="text-white hover:text-pink-300 text-lg font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4 bg-[#121212] p-4 rounded-xl border border-emerald-800/60">
                <div>
                  <span className="text-slate-400 font-medium">When (Timestamp):</span>
                  <div className="font-mono font-bold text-emerald-400 mt-0.5">{selectedLog.timestamp}</div>
                </div>
                <div>
                  <span className="text-slate-400 font-medium">What (Action):</span>
                  <div className="font-mono font-bold text-pink-400 mt-0.5">{selectedLog.action} on {selectedLog.module}</div>
                </div>
                <div>
                  <span className="text-slate-400 font-medium">Who (Staff Member):</span>
                  <div className="font-semibold text-white mt-0.5">{getActorName(selectedLog)} ({getActorId(selectedLog)})</div>
                  <div className="text-[10px] text-pink-300 font-mono">Role: {getActorRole(selectedLog)}</div>
                </div>
                <div>
                  <span className="text-slate-400 font-medium">Where (Workstation / Node):</span>
                  <div className="font-mono text-slate-300 mt-0.5">{selectedLog.ipAddress || 'Local Secured Station'}</div>
                </div>
                <div className="col-span-2 border-t border-emerald-900/60 pt-2">
                  <span className="text-slate-400 font-medium">To Which Record:</span>
                  <div className="font-mono font-bold text-pink-400 text-sm mt-0.5">{getTargetId(selectedLog)}</div>
                </div>
              </div>

              <div>
                <span className="font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                  What Changed (Operational Detail):
                </span>
                <p className="p-4 bg-[#121212] border border-slate-700 rounded-xl text-slate-200 font-mono text-xs leading-relaxed">
                  {selectedLog.details}
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setSelectedLog(null)}
                  className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs transition-colors"
                >
                  Close Snapshot
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

