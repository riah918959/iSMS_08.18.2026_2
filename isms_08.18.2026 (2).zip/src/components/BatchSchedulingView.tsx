import React, { useState, useEffect } from 'react';
import {
  Clock,
  Play,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Server,
  Calendar,
  Activity,
  History,
  ShieldCheck,
  Bell,
  Database,
  Sliders,
  Check,
  AlertCircle,
  Printer
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { BatchJobDefinition, BatchJobRunLog, UserProfile } from '../types';
import { BatchPrintScheduleModal } from './BatchPrintScheduleModal';

interface BatchSchedulingViewProps {
  currentUser: UserProfile;
}

export const BatchSchedulingView: React.FC<BatchSchedulingViewProps> = ({ currentUser }) => {
  const [batchJobs, setBatchJobs] = useState<BatchJobDefinition[]>([]);
  const [logs, setLogs] = useState<BatchJobRunLog[]>([]);
  const [runningJobId, setRunningJobId] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [successToast, setSuccessToast] = useState<string | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);

  const refreshData = () => {
    setBatchJobs(storageService.getBatchJobs());
    setLogs(storageService.getBatchLogs());
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleRunJob = (job: BatchJobDefinition) => {
    setRunningJobId(job.id);
    setTimeout(() => {
      try {
        const log = storageService.runBatchJob(job.id, `${currentUser.firstName} ${currentUser.lastName} (${currentUser.role})`);
        refreshData();
        setSuccessToast(`Successfully executed batch job: "${job.name}". ${log.details}`);
        setTimeout(() => setSuccessToast(null), 5000);
      } catch (err: any) {
        alert(`Failed running batch: ${err.message}`);
      } finally {
        setRunningJobId(null);
      }
    }, 600);
  };

  const handleToggleAutoRun = (job: BatchJobDefinition) => {
    const updated: BatchJobDefinition = {
      ...job,
      autoEnabled: !job.autoEnabled
    };
    storageService.saveBatchJob(updated);
    refreshData();
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'RETENTION_SWEEP':
        return <Calendar className="w-4 h-4 text-amber-500" />;
      case 'QC_ESCALATION':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'OVERDUE_ALERT':
        return <Bell className="w-4 h-4 text-indigo-500" />;
      case 'SQL_SYNC':
        return <Database className="w-4 h-4 text-pink-500" />;
      default:
        return <ShieldCheck className="w-4 h-4 text-emerald-500" />;
    }
  };

  const filteredJobs = filterCategory === 'ALL'
    ? batchJobs
    : batchJobs.filter((j) => j.category === filterCategory);

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans'] pb-12 w-full animate-in fade-in duration-300">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette, compact 3/4 layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <Activity className="w-5 h-5 md:w-5 md:h-5 text-pink-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                Batch Scheduling & Maintenance
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                CRON ENGINE
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsPrintModalOpen(true)}
            className="bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white font-bold text-xs px-3.5 py-1.5 rounded-lg border border-pink-500/50 flex items-center space-x-2 transition-all shadow-md active:scale-95 cursor-pointer font-['Chakra_Petch']"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Batch Print Schedule</span>
          </button>
          <button
            onClick={refreshData}
            className="bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs px-3.5 py-1.5 rounded-lg border border-slate-700 flex items-center space-x-2 transition-all shadow-sm cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
            <span>Refresh Status</span>
          </button>
        </div>
      </div>

      {/* Status Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
        <div className="bg-[#1A1A1A] p-3.5 rounded-xl border border-emerald-800/40 shadow-sm">
          <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Active Batch Jobs</span>
          <span className="text-lg font-bold font-mono text-emerald-400">{batchJobs.filter(j => j.autoEnabled).length} / {batchJobs.length}</span>
        </div>
        <div className="bg-[#1A1A1A] p-3.5 rounded-xl border border-emerald-800/40 shadow-sm">
          <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Cron Engine Status</span>
          <span className="text-lg font-bold font-mono text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            ONLINE
          </span>
        </div>
        <div className="bg-[#1A1A1A] p-3.5 rounded-xl border border-emerald-800/40 shadow-sm">
          <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">SQL Express Sync</span>
          <span className="text-lg font-bold font-mono text-pink-400">ISMS_QM_DB</span>
        </div>
        <div className="bg-[#1A1A1A] p-3.5 rounded-xl border border-emerald-800/40 shadow-sm">
          <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider">Total Run Logs</span>
          <span className="text-lg font-bold font-mono text-amber-400">{logs.length} Executions</span>
        </div>
      </div>

      {/* Success Notification Banner */}
      {successToast && (
        <div className="bg-emerald-950/80 border border-emerald-600 text-emerald-200 p-3.5 rounded-xl shadow-sm flex items-start space-x-3 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <span className="font-bold">Batch Run Successful: </span>
            <span>{successToast}</span>
          </div>
          <button onClick={() => setSuccessToast(null)} className="text-emerald-400 hover:text-emerald-200 font-bold text-xs">
            Dismiss
          </button>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 border-b border-emerald-900/40 pb-2 text-xs overflow-x-auto">
        <span className="font-bold text-emerald-400 uppercase tracking-wider text-[11px] mr-2 shrink-0 font-['Chakra_Petch']">Filter Jobs:</span>
        {['ALL', 'RETENTION_SWEEP', 'QC_ESCALATION', 'OVERDUE_ALERT', 'SQL_SYNC', 'AUDIT_CHECKSUM'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all shrink-0 ${
              filterCategory === cat
                ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-sm'
                : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700'
            }`}
          >
            {cat.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Batch Job Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredJobs.map((job) => {
          const isRunning = runningJobId === job.id;
          return (
            <div
              key={job.id}
              className="bg-[#1A1A1A] rounded-xl p-4 shadow-sm border border-emerald-800/40 hover:border-pink-500/60 transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center space-x-2.5">
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-700 text-emerald-400">
                      {getCategoryIcon(job.category)}
                    </div>
                    <div>
                      <span className="text-[10px] font-mono font-bold text-pink-400 block">
                        {job.code}
                      </span>
                      <h3 className="font-bold text-white text-xs leading-tight">
                        {job.name}
                      </h3>
                    </div>
                  </div>
                  
                  {/* Status pill */}
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-md font-bold border ${
                      job.status === 'SUCCESS'
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-700/60'
                        : job.status === 'RUNNING'
                        ? 'bg-amber-950 text-amber-300 border-amber-700/60 animate-pulse'
                        : 'bg-rose-950 text-rose-300 border-rose-700/60'
                    }`}
                  >
                    {job.status}
                  </span>
                </div>

                {/* Description */}
                <p className="text-slate-300 text-xs leading-relaxed">
                  {job.description}
                </p>

                {/* Schedule Info Table */}
                <div className="bg-[#141414] rounded-lg p-3 border border-slate-800 space-y-1.5 text-[11px]">
                  <div className="flex justify-between">
                    <span className="text-slate-400 flex items-center gap-1 font-semibold">
                      <Clock className="w-3 h-3 text-slate-500" /> Frequency:
                    </span>
                    <span className="font-bold text-slate-200">{job.frequency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 flex items-center gap-1 font-semibold">
                      <Calendar className="w-3 h-3 text-slate-500" /> Cron Spec:
                    </span>
                    <span className="font-mono text-pink-300 font-bold bg-pink-950/60 px-1.5 py-0.2 rounded border border-pink-700/50">
                      {job.cronExpression}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-semibold">Last Execution:</span>
                    <span className="font-mono text-slate-300 font-bold">{job.lastRunTimestamp || 'Never'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-semibold">Next Scheduled:</span>
                    <span className="font-mono text-emerald-400 font-bold">{job.nextScheduledRun || 'Pending'}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleToggleAutoRun(job)}
                  className={`flex items-center space-x-1.5 text-[11px] font-bold px-3 py-1.5 rounded-lg border transition-colors ${
                    job.autoEnabled
                      ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60 hover:bg-emerald-900'
                      : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-800'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${job.autoEnabled ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                  <span>{job.autoEnabled ? 'Auto-Active' : 'Paused'}</span>
                </button>

                <button
                  disabled={isRunning}
                  onClick={() => handleRunJob(job)}
                  className={`flex items-center space-x-1.5 text-xs font-bold px-3.5 py-1.5 rounded-lg text-white shadow-sm transition-all ${
                    isRunning
                      ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 active:scale-95'
                  }`}
                >
                  {isRunning ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Executing...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" />
                      <span>Run Now</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          );
        })}
      </div>

      {/* Execution Logs Section */}
      <div className="bg-[#1A1A1A] rounded-xl p-4 md:p-5 shadow-sm border border-emerald-800/40 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <History className="w-4 h-4 text-pink-400" />
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-['Chakra_Petch']">
              Audit & Execution Run History
            </h2>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            Showing latest {logs.length} execution events
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-800 rounded-lg">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#141414] text-emerald-400 border-b border-slate-800 font-bold uppercase text-[10px] tracking-wider font-mono">
              <tr>
                <th className="p-3">Status</th>
                <th className="p-3">Batch Name / Code</th>
                <th className="p-3">Timestamp</th>
                <th className="p-3">Trigger Mode</th>
                <th className="p-3">Duration</th>
                <th className="p-3">Records</th>
                <th className="p-3">Executed By</th>
                <th className="p-3">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 bg-[#161616]">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-white/5 transition-colors">
                  <td className="p-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold font-mono border ${
                        log.status === 'SUCCESS'
                          ? 'bg-emerald-950 text-emerald-300 border-emerald-700/60'
                          : 'bg-amber-950 text-amber-300 border-amber-700/60'
                      }`}
                    >
                      {log.status === 'SUCCESS' ? (
                        <CheckCircle2 className="w-3 h-3 mr-1 text-emerald-400" />
                      ) : (
                        <AlertCircle className="w-3 h-3 mr-1 text-amber-400" />
                      )}
                      {log.status}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-white">
                    {log.batchName}
                  </td>
                  <td className="p-3 font-mono text-slate-400 text-[11px]">
                    {log.timestamp}
                  </td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                        log.triggerType === 'CRON_AUTOMATED'
                          ? 'bg-indigo-950 text-indigo-300 border border-indigo-700/50'
                          : 'bg-pink-950 text-pink-300 border border-pink-700/50'
                      }`}
                    >
                      {log.triggerType}
                    </span>
                  </td>
                  <td className="p-3 font-mono text-slate-400 text-[11px]">
                    {log.durationMs} ms
                  </td>
                  <td className="p-3 font-mono font-bold text-emerald-400">
                    {log.recordsProcessed}
                  </td>
                  <td className="p-3 font-semibold text-slate-300">
                    {log.executedBy}
                  </td>
                  <td className="p-3 text-slate-400 max-w-xs truncate" title={log.details}>
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Batch Print Schedule PDF Modal */}
      <BatchPrintScheduleModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        currentUser={currentUser}
      />

    </div>
  );
};
