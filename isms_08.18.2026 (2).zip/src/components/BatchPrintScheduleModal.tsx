import React, { useState } from 'react';
import {
  Printer,
  X,
  FileText,
  Filter,
  CheckCircle2,
  Calendar,
  Building,
  User,
  ShieldCheck,
  AlertTriangle,
  Info,
  Clock,
  Layers,
  Sparkles,
  Download
} from 'lucide-react';
import { ProductionScheduleItem, UserProfile } from '../types';
import { storageService } from '../services/storageService';
import { JAELogo } from './BrandingLogos';

interface BatchPrintScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
}

export const BatchPrintScheduleModal: React.FC<BatchPrintScheduleModalProps> = ({
  isOpen,
  onClose,
  currentUser
}) => {
  const [schedules] = useState<ProductionScheduleItem[]>(storageService.getProductionSchedules());
  const [selectedFactory, setSelectedFactory] = useState<string>('ALL');
  const [selectedShift, setSelectedShift] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [printDate] = useState<string>(new Date().toISOString().split('T')[0]);

  if (!isOpen) return null;

  const filteredSchedules = schedules.filter((item) => {
    const matchFactory = selectedFactory === 'ALL' || item.factory === selectedFactory;
    const matchShift = selectedShift === 'ALL' || item.shift === selectedShift;
    const matchStatus = selectedStatus === 'ALL' || (
      selectedStatus === 'ACTIVE'
        ? item.status === 'In Progress' || item.status === 'Scheduled' || item.status === 'On Hold'
        : item.status === selectedStatus
    );
    return matchFactory && matchShift && matchStatus;
  });

  const totalTargetQty = filteredSchedules.reduce((acc, curr) => acc + (curr.targetQuantity || 0), 0);
  const totalCompletedQty = filteredSchedules.reduce((acc, curr) => acc + (curr.completedQuantity || 0), 0);
  const totalDefects = filteredSchedules.reduce((acc, curr) => acc + (curr.defectQuantity || 0), 0);
  const inProgressCount = filteredSchedules.filter((s) => s.status === 'In Progress').length;
  const onHoldCount = filteredSchedules.filter((s) => s.status === 'On Hold').length;

  const handleTriggerPrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      {/* Print CSS Rules */}
      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #printable-production-schedule,
          #printable-production-schedule * {
            visibility: visible;
          }
          #printable-production-schedule {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 12px;
            background: #ffffff !important;
            color: #000000 !important;
          }
          .no-print {
            display: none !important;
          }
          @page {
            size: landscape;
            margin: 8mm;
          }
        }
      `}</style>

      <div className="bg-[#141414] text-white w-full max-w-6xl rounded-2xl border border-emerald-700/60 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Toolbar (Screen Only) */}
        <div className="no-print p-4 bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border-b border-emerald-700/60 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40">
              <Printer className="w-5 h-5 text-pink-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                  Batch Print Production Schedule
                </h2>
                <span className="text-[10px] font-mono font-bold bg-pink-950 text-pink-300 px-2 py-0.5 rounded border border-pink-700/60">
                  HIGH-CONTRAST FLOOR SPEC
                </span>
              </div>
              <p className="text-xs text-emerald-200/80">
                Generate high-contrast, simplified physical batch schedule sheets for line leaders and floor operators.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleTriggerPrint}
              className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold font-['Chakra_Petch'] rounded-xl flex items-center space-x-2 shadow-lg hover:shadow-emerald-900/40 transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Schedule (PDF)</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-xl transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Controls Bar (Screen Only) */}
        <div className="no-print p-3 bg-[#1A1A1A] border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="text-slate-300 font-bold flex items-center gap-1 font-['Chakra_Petch'] uppercase text-[11px]">
              <Filter className="w-3.5 h-3.5 text-pink-400" />
              Floor Filter:
            </span>

            {/* Factory Filter */}
            <select
              value={selectedFactory}
              onChange={(e) => setSelectedFactory(e.target.value)}
              className="bg-[#141414] border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 font-semibold focus:border-pink-500 focus:outline-none"
            >
              <option value="ALL">All Factories (1F & 2F)</option>
              <option value="First Factory">First Factory (1F)</option>
              <option value="Second Factory">Second Factory (2F)</option>
            </select>

            {/* Shift Filter */}
            <select
              value={selectedShift}
              onChange={(e) => setSelectedShift(e.target.value)}
              className="bg-[#141414] border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 font-semibold focus:border-pink-500 focus:outline-none"
            >
              <option value="ALL">All Shifts (Day & Night)</option>
              <option value="Day Shift (A)">Day Shift (A)</option>
              <option value="Night Shift (B)">Night Shift (B)</option>
            </select>

            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-[#141414] border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 font-semibold focus:border-pink-500 focus:outline-none"
            >
              <option value="ALL">All Schedule Statuses</option>
              <option value="ACTIVE">Active & Scheduled (Exclude Done)</option>
              <option value="In Progress">In Progress Only</option>
              <option value="On Hold">On Hold (QC Interlock)</option>
              <option value="Completed">Completed Only</option>
            </select>
          </div>

          <div className="text-[11px] text-slate-400 font-mono">
            Matching: <strong className="text-emerald-400">{filteredSchedules.length}</strong> job orders | Target: <strong className="text-white">{totalTargetQty.toLocaleString()} pcs</strong>
          </div>
        </div>

        {/* Scrollable Printable Container Preview */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-900/60">
          
          {/* THE HIGH-CONTRAST PRINT DOCUMENT */}
          <div
            id="printable-production-schedule"
            className="bg-white text-black p-6 sm:p-8 rounded-lg shadow-xl border-2 border-black max-w-5xl mx-auto space-y-5 font-sans"
            style={{ fontFamily: "'Plus Jakarta Sans', Arial, sans-serif" }}
          >
            {/* High-Contrast Document Header */}
            <div className="border-b-4 border-black pb-4 space-y-2">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-xs font-black tracking-widest text-black uppercase font-mono">
                    JAE PHILIPPINES, INC. • QUALITY MANAGEMENT SYSTEM
                  </div>
                  <h1 className="text-xl sm:text-2xl font-black text-black tracking-tight uppercase mt-0.5">
                    DAILY PRODUCTION FLOOR SCHEDULE & QUALITY DISPOSITION
                  </h1>
                  <div className="text-xs font-bold text-black uppercase">
                    Integrated Sample Management System (iSMS) — Floor Operator Working Sheet
                  </div>
                </div>

                <div className="text-right border-2 border-black p-2 bg-neutral-100 rounded text-xs font-mono">
                  <div className="font-black text-black text-sm">DOC NO: JAE-PRD-SCH-01</div>
                  <div className="text-[11px] text-neutral-800 font-bold">REV: 04 • CONFIDENTIAL</div>
                  <div className="text-[10px] text-neutral-600">JAE Special Economic Zone</div>
                </div>
              </div>

              {/* Metadata strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t-2 border-black text-xs font-mono">
                <div>
                  <span className="font-bold text-neutral-700 block text-[10px] uppercase">DATE OF RUN:</span>
                  <strong className="text-black text-sm">{printDate}</strong>
                </div>
                <div>
                  <span className="font-bold text-neutral-700 block text-[10px] uppercase">FACILITY / PLANT:</span>
                  <strong className="text-black text-sm">{selectedFactory === 'ALL' ? 'First & Second Factory' : selectedFactory}</strong>
                </div>
                <div>
                  <span className="font-bold text-neutral-700 block text-[10px] uppercase">SHIFT ASSIGNMENT:</span>
                  <strong className="text-black text-sm">{selectedShift === 'ALL' ? 'Day Shift (A) & Night Shift (B)' : selectedShift}</strong>
                </div>
                <div>
                  <span className="font-bold text-neutral-700 block text-[10px] uppercase">SCHEDULED BY:</span>
                  <strong className="text-black text-sm">{currentUser.firstName} {currentUser.lastName}</strong>
                </div>
              </div>
            </div>

            {/* High-Contrast KPI Summary Strip for Floor Supervisors */}
            <div className="grid grid-cols-4 gap-3 text-center">
              <div className="border-2 border-black p-2 bg-neutral-100">
                <div className="text-[10px] font-black uppercase text-neutral-700">Total Planned Lots</div>
                <div className="text-xl font-black text-black font-mono">{filteredSchedules.length}</div>
              </div>
              <div className="border-2 border-black p-2 bg-neutral-100">
                <div className="text-[10px] font-black uppercase text-neutral-700">Target Output Qty</div>
                <div className="text-xl font-black text-black font-mono">{totalTargetQty.toLocaleString()} <span className="text-xs">pcs</span></div>
              </div>
              <div className="border-2 border-black p-2 bg-neutral-100">
                <div className="text-[10px] font-black uppercase text-neutral-700">Completed Output</div>
                <div className="text-xl font-black text-black font-mono">{totalCompletedQty.toLocaleString()} <span className="text-xs">pcs</span></div>
              </div>
              <div className="border-2 border-black p-2 bg-neutral-100">
                <div className="text-[10px] font-black uppercase text-neutral-700">Open QC Holds / Defects</div>
                <div className="text-xl font-black text-black font-mono">{onHoldCount} <span className="text-xs font-normal">({totalDefects} defects)</span></div>
              </div>
            </div>

            {/* High-Contrast Production Schedule Table */}
            <div className="overflow-x-auto border-2 border-black">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-black text-white font-black uppercase text-[11px] font-mono border-b-2 border-black">
                  <tr>
                    <th className="p-2 border-r border-neutral-700 w-8 text-center">#</th>
                    <th className="p-2 border-r border-neutral-700">Job Order / Lot No</th>
                    <th className="p-2 border-r border-neutral-700">Part No & Specifications</th>
                    <th className="p-2 border-r border-neutral-700">Line & Stage</th>
                    <th className="p-2 border-r border-neutral-700 text-center">Target / Output</th>
                    <th className="p-2 border-r border-neutral-700">Status & P.I.C.</th>
                    <th className="p-2 w-36 text-center">Operator & QC Sign-off</th>
                  </tr>
                </thead>
                <tbody className="divide-y-2 divide-black text-black">
                  {filteredSchedules.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-sm font-bold text-neutral-600">
                        No production schedules matching current filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredSchedules.map((item, idx) => {
                      const isOnHold = item.status === 'On Hold';
                      const isDone = item.status === 'Completed';

                      return (
                        <tr
                          key={item.id}
                          className={`hover:bg-neutral-50 ${isOnHold ? 'bg-neutral-200/90' : ''}`}
                          style={{ pageBreakInside: 'avoid' }}
                        >
                          {/* Index */}
                          <td className="p-2 text-center font-black font-mono border-r-2 border-black text-sm">
                            {idx + 1}
                          </td>

                          {/* Job Order & Lot Number */}
                          <td className="p-2 border-r-2 border-black font-mono whitespace-nowrap">
                            <div className="font-black text-sm text-black">{item.jobOrderNo || item.lotNumber}</div>
                            <div className="text-[11px] font-bold text-neutral-700">Lot: {item.lotNumber}</div>
                            <div className="text-[10px] text-neutral-600">{item.customer}</div>
                          </td>

                          {/* Part Description & Specs */}
                          <td className="p-2 border-r-2 border-black">
                            <div className="font-black text-xs text-black">{item.partNumber || item.productCode}</div>
                            <div className="text-[11px] font-bold text-neutral-800 leading-tight mt-0.5">
                              {item.partDescription || item.productName}
                            </div>
                            <div className="mt-1 flex flex-wrap gap-1 text-[10px] font-mono font-bold bg-neutral-100 p-1 border border-neutral-300 rounded">
                              <span>Crimp: <strong>{item.crimpHeightSpecMm || '1.24 ± 0.03 mm'}</strong></span>
                              <span>•</span>
                              <span>Pull Force: <strong>{item.pullForceSpecN || '≥ 85.0 N'}</strong></span>
                            </div>
                          </td>

                          {/* Line, Factory & Stage */}
                          <td className="p-2 border-r-2 border-black whitespace-nowrap">
                            <div className="font-black text-xs text-black">{item.lineName || item.line}</div>
                            <div className="text-[11px] font-bold text-neutral-700">{item.factory}</div>
                            <div className="text-[10px] font-black uppercase text-neutral-900 mt-0.5 bg-neutral-200 px-1 py-0.5 rounded inline-block">
                              {item.stage} • {item.shift}
                            </div>
                          </td>

                          {/* Target / Completed Quantity */}
                          <td className="p-2 border-r-2 border-black text-center font-mono whitespace-nowrap">
                            <div className="text-xs font-black text-black">
                              {(item.targetQuantity || 0).toLocaleString()} <span className="text-[10px]">TGT</span>
                            </div>
                            <div className="text-xs font-bold text-neutral-800">
                              {(item.completedQuantity || 0).toLocaleString()} <span className="text-[10px]">ACT</span>
                            </div>
                            {item.defectQuantity > 0 && (
                              <div className="text-[10px] font-black text-red-700">
                                {item.defectQuantity} Defect(s)
                              </div>
                            )}
                          </td>

                          {/* Status & P.I.C. */}
                          <td className="p-2 border-r-2 border-black whitespace-nowrap">
                            <div className={`text-[11px] font-black uppercase px-1.5 py-0.5 rounded inline-block border ${
                              isOnHold
                                ? 'bg-black text-white border-black'
                                : isDone
                                ? 'bg-neutral-200 text-black border-black'
                                : 'bg-neutral-100 text-black border-black'
                            }`}>
                              {item.status}
                            </div>
                            <div className="font-bold text-xs text-black mt-1">
                              PIC: {item.picName || item.picStaff || 'Line Leader'}
                            </div>
                            <div className="text-[10px] text-neutral-600 font-mono">
                              Status: {item.picNotificationStatus || 'Notified'}
                            </div>
                          </td>

                          {/* Operator Sign-off Blank Box */}
                          <td className="p-2 text-left font-mono text-[10px] bg-neutral-50">
                            <div className="border border-black p-1.5 h-full space-y-1">
                              <div className="text-[9px] font-bold text-neutral-600">OPR: _________________</div>
                              <div className="text-[9px] font-bold text-neutral-600">TIME: ________________</div>
                              <div className="text-[9px] font-bold text-neutral-600">QC:  _________________</div>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Shop Floor Quality Mandates & Operational Reminders */}
            <div className="border-2 border-black p-3 bg-neutral-100 space-y-1.5 text-xs text-black">
              <div className="font-black text-sm uppercase flex items-center gap-1.5">
                <span>⚠️ STANDARD SHOP FLOOR QUALITY OPERATING GUIDELINES</span>
              </div>
              <ul className="list-decimal list-inside space-y-0.5 text-[11px] font-medium leading-tight text-neutral-900">
                <li>
                  <strong>Golden Sample Verification:</strong> Compare first 5 pieces from start of lot against the verified Golden Sample in the registered Keep Sample Box.
                </li>
                <li>
                  <strong>Mandatory Dimension & Crimp Inspection:</strong> Record crimp height and terminal tensile pull force every 2 hours or after any reel change.
                </li>
                <li>
                  <strong>Immediate QC Hold Escalation:</strong> If any parameter violates CPK 1.33 or drawing tolerance, immediately halt line and inform QC Hold station via iSMS.
                </li>
                <li>
                  <strong>Physical Keep Sample Surrender:</strong> Line leaders must surrender tagged retention samples to QC Hold prior to closing job order.
                </li>
              </ul>
            </div>

            {/* Verification Signatures / Handover Block */}
            <div className="grid grid-cols-3 gap-4 pt-3 border-t-2 border-black text-xs font-mono">
              <div className="space-y-6">
                <span className="font-bold text-neutral-700 block text-[10px] uppercase">PREPARED BY (SCHEDULER):</span>
                <div className="border-b-2 border-black pb-1 font-bold text-black text-xs">
                  {currentUser.firstName} {currentUser.lastName}
                </div>
                <div className="text-[10px] text-neutral-600">Date: {printDate}</div>
              </div>

              <div className="space-y-6">
                <span className="font-bold text-neutral-700 block text-[10px] uppercase">VERIFIED BY (LINE LEADER):</span>
                <div className="border-b-2 border-black pb-1 font-bold text-black text-xs">
                  ___________________________
                </div>
                <div className="text-[10px] text-neutral-600">Shift / Line Sign-off</div>
              </div>

              <div className="space-y-6">
                <span className="font-bold text-neutral-700 block text-[10px] uppercase">QC HOLD / QM ENDORSEMENT:</span>
                <div className="border-b-2 border-black pb-1 font-bold text-black text-xs">
                  ___________________________
                </div>
                <div className="text-[10px] text-neutral-600">Quality Assurance Release</div>
              </div>
            </div>

            {/* Confidentiality Footer */}
            <div className="text-center pt-2 text-[9px] text-neutral-500 font-mono border-t border-neutral-400">
              JAE PHILIPPINES, INC. — PROPRIETARY & CONFIDENTIAL • PRODUCED BY ISMS AUTOMATION SYSTEM • SQL GATEWAY: DESKTOP-RLHCI2C\SQLEXPRESS
            </div>

          </div>

        </div>

        {/* Modal Footer Controls */}
        <div className="no-print p-4 bg-[#161616] border-t border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            Formatted for physical clipboard mounting on plant floors (A4/Letter Landscape).
          </span>
          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition-all"
            >
              Close
            </button>
            <button
              onClick={handleTriggerPrint}
              className="px-5 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold font-['Chakra_Petch'] rounded-xl flex items-center space-x-2 shadow-lg transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Schedule / Save PDF</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
