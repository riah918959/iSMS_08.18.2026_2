import React, { useState, useEffect } from 'react';
import {
  Box,
  Plus,
  Save,
  Printer,
  QrCode,
  Search,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Edit2,
  Calendar,
  Filter,
  FileSpreadsheet,
  UploadCloud,
  Trash2,
  Lock,
  Unlock,
  Sparkles,
  Info,
  ShieldCheck,
  Layers,
  ArrowLeft,
  Scan,
  Barcode,
  Package,
  Clock,
  History,
  FileText,
  UserCheck,
  CheckSquare,
  AlertCircle,
  Camera,
  Zap,
  ScanLine,
  Tag,
  Hash,
  XCircle,
  CheckCircle2
} from 'lucide-react';
import {
  KeepSampleBox,
  FactoryType,
  StorageAreaType,
  SectionType,
  ArchiveType,
  KeepSampleBoxStatus,
  UserProfile,
  SampleItemRow
} from '../types';
import { storageService, calculateExpirationDate, evaluateKeepSampleStatus } from '../services/storageService';
import { JAELogo } from './BrandingLogos';
import { DataImportModal } from './DataImportModal';

interface KeepSampleEntryViewProps {
  currentUser: UserProfile;
  onOpenPrintLabel?: (box: KeepSampleBox) => void;
  onOpenScanner?: (onScanned: (val: string) => void) => void;
  onRefreshData: () => void;
}

export type KeepSampleTab = 
  | 'BOX_NUMBER_REQUEST'
  | 'KEEP_SAMPLES_LIST'
  | 'QC_HOLD_VERIFICATION'
  | 'AUDIT_TRAIL';

export const KeepSampleEntryView: React.FC<KeepSampleEntryViewProps> = ({
  currentUser,
  onOpenPrintLabel,
  onOpenScanner,
  onRefreshData
}) => {
  const [boxes, setBoxes] = useState<KeepSampleBox[]>(storageService.getKeepSampleBoxes());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFactory, setFilterFactory] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info' | 'warning'; text: string } | null>(null);
  const [printingBox, setPrintingBox] = useState<KeepSampleBox | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);

  // Multitab and Selection
  const [isMultitabOpen, setIsMultitabOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<KeepSampleTab>('BOX_NUMBER_REQUEST');
  const [selectedBoxId, setSelectedBoxId] = useState<string | null>(null);

  // Box Form State (Page 1)
  const [factory, setFactory] = useState<FactoryType>('First Factory');
  const [boxNumber, setBoxNumber] = useState<string>(storageService.generateNextBoxNumber('First Factory'));
  const [requestedBy, setRequestedBy] = useState<string>(`${currentUser.firstName} ${currentUser.lastName}`);
  const [storageArea, setStorageArea] = useState<StorageAreaType>('1F MEZZANINE');
  const [section, setSection] = useState<SectionType>('MX CONNECTOR');
  const [productFamily, setProductFamily] = useState<string>('');
  const [item, setItem] = useState<string>('');
  const [archiveType, setArchiveType] = useState<ArchiveType>('KS');
  const [dateGenerated, setDateGenerated] = useState<string>(new Date().toISOString().split('T')[0]);
  const [dateExpiration, setDateExpiration] = useState<string>(calculateExpirationDate(new Date().toISOString().split('T')[0], 'KS'));
  const [remarks, setRemarks] = useState<string>('');
  const [rackLocation, setRackLocation] = useState<string>('On-going');
  const [maxCapacity, setMaxCapacity] = useState<number>(12);
  const [boxState, setBoxState] = useState<'open' | 'closed'>('open');
  const [samples, setSamples] = useState<SampleItemRow[]>([]);

  // Page 2: Continuous QR Batch Scanning State
  const [isScanSectionOpen, setIsScanSectionOpen] = useState<boolean>(true);
  const [page2ScanInput, setPage2ScanInput] = useState<string>('');
  const [lastScannedFeedback, setLastScannedFeedback] = useState<{ status: 'success' | 'error' | 'duplicate'; msg: string } | null>(null);

  // Manual Add Item Modal (fallback/optional)
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState<boolean>(false);
  const [newItemName, setNewItemName] = useState<string>('');
  const [newDrawingNumber, setNewDrawingNumber] = useState<string>('');
  const [newPoNumber, setNewPoNumber] = useState<string>('');
  const [newLotNumber, setNewLotNumber] = useState<string>('');
  const [newQuantity, setNewQuantity] = useState<number>(1);
  const [newDefectType, setNewDefectType] = useState<string>('');
  const [newUnitQty, setNewUnitQty] = useState<string>('');
  const [newCavity, setNewCavity] = useState<string>('');
  const [newCavityNo, setNewCavityNo] = useState<string>('');
  const [newTime, setNewTime] = useState<string>('');
  const [newItemRemarks, setNewItemRemarks] = useState<string>('');

  // RBAC Permission Checks
  const isSysadmin = currentUser.role === 'Sysadmin' || currentUser.role === 'Admin';
  const isQMAdmin = currentUser.role === 'QM Admin' || isSysadmin;
  const isQMHold = currentUser.role === 'QM Hold' || currentUser.role === 'QM';
  const isQCHold = currentUser.role === 'QC Hold';
  const isQCInspector = currentUser.role === 'QC Inspector';

  // QC Inspector is restricted to Page 2 (Sample in Box) only
  const canAccessPage1 = !isQCInspector;
  const canAccessPage3 = (isQCHold || isQMHold || isQMAdmin || isSysadmin) && boxState === 'closed';
  const canManageBoxes = isSysadmin || isQMAdmin || isQMHold || isQCHold;
  const canEditWhenClosed = isSysadmin || isQMAdmin || isQMHold;
  const isBoxLocked = boxState === 'closed' && !canEditWhenClosed;

  const sectionsList: SectionType[] = [
    'MX CONNECTOR',
    'MX HARNESS',
    'MX PRE ASSY',
    'MX57 MANUAL',
    'MX57 AUTO',
    'VARIOUS',
    'MX HONDA',
    'QM/IQC',
    'OQC',
    'QA/QC',
    'STAMPING',
    'MOLDING',
    'WAREHOUSE'
  ];

  // Calculated Status
  const currentCalculatedStatus: KeepSampleBoxStatus = evaluateKeepSampleStatus(
    Boolean((item && item.trim()) || samples.length > 0),
    dateExpiration
  );

  // If QC Inspector, auto-lock to Page 2
  useEffect(() => {
    if (isQCInspector && isMultitabOpen && activeTab !== 'KEEP_SAMPLES_LIST') {
      setActiveTab('KEEP_SAMPLES_LIST');
    }
  }, [isQCInspector, isMultitabOpen, activeTab]);

  const handleStorageAreaChange = (newArea: StorageAreaType) => {
    setStorageArea(newArea);
    if (newArea === '1F MEZZANINE' || newArea === 'F2B STORAGE') {
      setRackLocation('On-going');
    }
  };

  const handleFactoryChange = (newFactory: FactoryType) => {
    setFactory(newFactory);
    if (!selectedBoxId) {
      const nextNum = storageService.generateNextBoxNumber(newFactory);
      setBoxNumber(nextNum);
      const newArea = newFactory === 'First Factory' ? '1F MEZZANINE' : 'F2B STORAGE';
      setStorageArea(newArea);
      setRackLocation('On-going');
    }
  };

  const handleArchiveTypeChange = (newType: ArchiveType) => {
    setArchiveType(newType);
    setDateExpiration(calculateExpirationDate(dateGenerated, newType));
  };

  const handleDateGenChange = (newDate: string) => {
    setDateGenerated(newDate);
    setDateExpiration(calculateExpirationDate(newDate, archiveType));
  };

  // Open Multitab for New Box Registration (QC Hold, QM Admin, QM Hold)
  const handleOpenNewBoxRegistration = () => {
    if (isQCInspector) {
      setFeedbackMsg({
        type: 'warning',
        text: 'QC Inspectors are restricted to Page 2 (Sample in Box). Please select an existing box from the masterlist to scan samples.'
      });
      return;
    }
    setSelectedBoxId(null);
    const nextNum = storageService.generateNextBoxNumber(factory);
    setBoxNumber(nextNum);
    setRequestedBy(`${currentUser.firstName} ${currentUser.lastName}`);
    const initArea: StorageAreaType = factory === 'First Factory' ? '1F MEZZANINE' : 'F2B STORAGE';
    setStorageArea(initArea);
    setSection(currentUser.section || 'MX CONNECTOR');
    setProductFamily('');
    setItem('');
    setArchiveType('KS');
    const today = new Date().toISOString().split('T')[0];
    setDateGenerated(today);
    setDateExpiration(calculateExpirationDate(today, 'KS'));
    setRemarks('');
    setRackLocation('On-going');
    setMaxCapacity(12);
    setBoxState('open');
    setSamples([]);
    setActiveTab('BOX_NUMBER_REQUEST');
    setIsMultitabOpen(true);
    setLastScannedFeedback(null);
    setFeedbackMsg({
      type: 'info',
      text: `Opened New Box Registration: ${nextNum}. Fill box details and proceed to Page 2 for batch sample scanning.`
    });
  };

  // Open Multitab when a Masterlist Box is selected
  const handleSelectBoxFromMasterlist = (box: KeepSampleBox) => {
    setSelectedBoxId(box.id);
    setFactory(box.factory);
    setBoxNumber(box.boxNumber);
    setRequestedBy(box.requestedBy);
    setStorageArea(box.storageArea);
    setSection(box.section);
    setProductFamily(box.productFamily || '');
    setItem(box.item || '');
    setArchiveType(box.archiveType);
    setDateGenerated(box.dateGenerated);
    setDateExpiration(box.dateExpiration || box.expirationDate || calculateExpirationDate(box.dateGenerated, box.archiveType));
    setRemarks(box.remarks || '');
    setRackLocation(box.rackLocation || 'RACK-1F-M01');
    setMaxCapacity(box.maxCapacity || 12);
    setBoxState(box.boxState || 'open');
    setSamples(box.samples || []);
    setLastScannedFeedback(null);
    
    // If QC Inspector, immediately open Page 2
    if (isQCInspector) {
      setActiveTab('KEEP_SAMPLES_LIST');
    } else {
      setActiveTab('BOX_NUMBER_REQUEST');
    }
    setIsMultitabOpen(true);
  };

  // Save Box from Page 1
  const handleSaveBoxRegistration = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!canManageBoxes) {
      setFeedbackMsg({
        type: 'error',
        text: `Permission Denied: User role "${currentUser.role}" cannot register or edit boxes.`
      });
      return;
    }

    try {
      const saved = storageService.saveKeepSampleBox({
        id: selectedBoxId || undefined,
        boxNumber,
        factory,
        requestedBy,
        storageArea,
        section,
        productFamily,
        item: item || productFamily || (samples[0]?.itemName ?? ''),
        archiveType,
        dateGenerated,
        dateExpiration,
        status: currentCalculatedStatus,
        boxState: boxState || 'open',
        remarks,
        rackLocation,
        maxCapacity,
        occupiedSlots: samples.length,
        samples
      });

      const updated = storageService.getKeepSampleBoxes();
      setBoxes(updated);
      onRefreshData();
      setSelectedBoxId(saved.id);

      setFeedbackMsg({
        type: 'success',
        text: `Box ${saved.boxNumber} registered and saved as draft! Proceeding to Page 2 to scan samples.`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed to save box: ${err.message}`
      });
    }
  };

  // =========================================================================
  // PAGE 2: CONTINUOUS BATCH QR CODE SCANNER & AUTO-ADD LOGIC
  // =========================================================================
  const handleProcessBatchQRScan = (rawScanned: string) => {
    if (!rawScanned || !rawScanned.trim()) return;
    const trimmed = rawScanned.trim();

    if (isBoxLocked) {
      setLastScannedFeedback({
        status: 'error',
        msg: `Box ${boxNumber} is CLOSED & LOCKED. Only QM Hold / QM Admin can unlock or modify items.`
      });
      setFeedbackMsg({
        type: 'error',
        text: `Cannot scan into closed box ${boxNumber}. Please contact QM Hold to unlock if needed.`
      });
      setPage2ScanInput('');
      return;
    }

    // Expected QR Format:
    // Item|PO|Qty|Lot|Defect/Process|UnitQty|BoxNo|Cavity|CavityNo|Time|DWG
    let pItem = '';
    let pPoNo = '';
    let pQty = 1;
    let pLotNo = '';
    let pDefectProcess = 'Master Golden Sample';
    let pUnitQty = '1 EA/CAVITY';
    let pBoxNo = '';
    let pCavity = '';
    let pCavityNo = '';
    let pTime = '';
    let pDrawingNo = '';

    if (trimmed.includes('|')) {
      const parts = trimmed.split('|').map((p) => p.trim());
      pItem = parts[0] || '';
      pPoNo = parts[1] || '';
      const pQtyRaw = parts[2] ? parts[2].replace(/[^\d]/g, '') : '';
      pQty = pQtyRaw ? parseInt(pQtyRaw, 10) : 1;
      pLotNo = parts[3] || '';
      pDefectProcess = parts[4] || 'Master Golden Sample';
      pUnitQty = parts[5] || '1 EA/CAVITY';
      pBoxNo = parts[6] || '';
      pCavity = parts[7] || '';
      pCavityNo = parts[8] || '';
      pTime = parts[9] || '';
      pDrawingNo = parts[10] || '';
    } else {
      // Fallback for simple payload
      pItem = trimmed;
      pLotNo = `LOT-${Date.now().toString().slice(-6)}`;
      pDrawingNo = 'DWG-SCAN-AUTO';
    }

    // 1. VALIDATION: Incorrect Box Number Alert
    if (pBoxNo && boxNumber && pBoxNo.trim().toLowerCase() !== boxNumber.trim().toLowerCase()) {
      const errorMsg = `❌ MISMATCHED BOX NUMBER! Scanned QR specifies Box "${pBoxNo}", but current active box is "${boxNumber}". Item was NOT added.`;
      setLastScannedFeedback({
        status: 'error',
        msg: errorMsg
      });
      setFeedbackMsg({
        type: 'error',
        text: errorMsg
      });
      setPage2ScanInput('');
      return;
    }

    // 2. VALIDATION: Duplicate Scan Check
    // A sample is duplicate if the same Lot Number + Drawing Number (or Lot Number + Item Name) exists in the box
    const isDuplicate = samples.some((s) => {
      if (pLotNo && s.lotNumber && s.lotNumber.trim().toLowerCase() === pLotNo.trim().toLowerCase()) {
        if (pDrawingNo && s.drawingNumber && s.drawingNumber.trim().toLowerCase() === pDrawingNo.trim().toLowerCase()) {
          return true;
        }
        if (pItem && s.itemName && s.itemName.trim().toLowerCase() === pItem.trim().toLowerCase()) {
          return true;
        }
      }
      return false;
    });

    if (isDuplicate) {
      const dupMsg = `⚠️ DUPLICATE KEEP SAMPLE DETECTED! Lot Number "${pLotNo}" (${pItem || pDrawingNo}) has ALREADY been scanned and added to Box ${boxNumber}. Duplicate skipped.`;
      setLastScannedFeedback({
        status: 'duplicate',
        msg: dupMsg
      });
      setFeedbackMsg({
        type: 'warning',
        text: dupMsg
      });
      setPage2ScanInput('');
      return;
    }

    // 3. AUTOMATIC BATCH ADDITION
    const newSampleItem: SampleItemRow = {
      id: `smp-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      itemName: pItem || `Keep Sample Part ${samples.length + 1}`,
      drawingNumber: pDrawingNo,
      poNumber: pPoNo,
      lotNumber: pLotNo || `LOT-${Date.now().toString().slice(-4)}`,
      quantity: pQty,
      defectType: pDefectProcess,
      unitQty: pUnitQty,
      boxNo: boxNumber,
      cavity: pCavity,
      cavityNo: pCavityNo,
      time: pTime,
      process: pDefectProcess,
      remarks: `Scanned: Cavity ${pCavity} (#${pCavityNo}) | Time: ${pTime} | Unit: ${pUnitQty}`
    };

    const updatedSamples = [newSampleItem, ...samples];
    setSamples(updatedSamples);
    if (!item && pItem) {
      setItem(pItem);
    }
    if (!productFamily && pItem) {
      setProductFamily(pItem.split(' ')[0] || '');
    }

    // If box already exists in storage, update directly
    if (selectedBoxId) {
      try {
        storageService.addSampleToBox(selectedBoxId, newSampleItem);
        setBoxes(storageService.getKeepSampleBoxes());
        onRefreshData();
      } catch (err) {
        console.error('Auto-save error on batch scan:', err);
      }
    }

    const successMsg = `✅ AUTO-ADDED SAMPLE: "${newSampleItem.itemName}" | Lot: ${newSampleItem.lotNumber} | DWG: ${newSampleItem.drawingNumber || 'N/A'} | Qty: ${newSampleItem.quantity}. Box Total: ${updatedSamples.length}/${maxCapacity}`;
    setLastScannedFeedback({
      status: 'success',
      msg: successMsg
    });
    setFeedbackMsg({
      type: 'success',
      text: successMsg
    });
    setPage2ScanInput('');
  };

  // =========================================================================
  // PAGE 2: SAVE AS DRAFT vs SAVE AS CLOSED
  // =========================================================================
  const handleSaveAsDraft = () => {
    try {
      const saved = storageService.saveKeepSampleBox({
        id: selectedBoxId || undefined,
        boxNumber,
        factory,
        requestedBy,
        storageArea,
        section,
        productFamily,
        item: item || productFamily || (samples[0]?.itemName ?? ''),
        archiveType,
        dateGenerated,
        dateExpiration,
        status: currentCalculatedStatus,
        boxState: 'open',
        remarks,
        rackLocation,
        maxCapacity,
        occupiedSlots: samples.length,
        samples
      });

      setBoxState('open');
      setSelectedBoxId(saved.id);
      setBoxes(storageService.getKeepSampleBoxes());
      onRefreshData();

      setFeedbackMsg({
        type: 'success',
        text: `💾 Box ${boxNumber} saved as DRAFT (Status: Open). QC Inspectors can continue scanning samples anytime.`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed to save draft: ${err.message}`
      });
    }
  };

  const handleSaveAsClosed = () => {
    if (samples.length === 0) {
      const confirmClose = window.confirm(`Box ${boxNumber} has 0 samples registered. Are you sure you want to close this box?`);
      if (!confirmClose) return;
    }

    try {
      const saved = storageService.saveKeepSampleBox({
        id: selectedBoxId || undefined,
        boxNumber,
        factory,
        requestedBy,
        storageArea,
        section,
        productFamily,
        item: item || productFamily || (samples[0]?.itemName ?? ''),
        archiveType,
        dateGenerated,
        dateExpiration,
        status: currentCalculatedStatus,
        boxState: 'closed',
        remarks,
        rackLocation,
        maxCapacity,
        occupiedSlots: samples.length,
        samples
      });

      setBoxState('closed');
      setSelectedBoxId(saved.id);
      setBoxes(storageService.getKeepSampleBoxes());
      onRefreshData();

      setFeedbackMsg({
        type: 'success',
        text: `🔒 Box ${boxNumber} successfully SAVED AS CLOSED & LOCKED! It is now finalized. Proceeding to QC Hold Verification & A6 Label Printing.`
      });

      // Switch to Page 3 if allowed
      if (isQCHold || isQMHold || isQMAdmin || isSysadmin) {
        setActiveTab('QC_HOLD_VERIFICATION');
      }
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed to close box: ${err.message}`
      });
    }
  };

  // QM Hold / QM Admin Unlock Box
  const handleUnlockBox = () => {
    if (!canEditWhenClosed) {
      setFeedbackMsg({
        type: 'error',
        text: 'Access Denied: Only QM Hold, QM Admin, or Sysadmin can unlock closed boxes.'
      });
      return;
    }
    if (window.confirm(`Unlock Box ${boxNumber} to reopen editing for QC Inspectors?`)) {
      setBoxState('open');
      if (selectedBoxId) {
        storageService.updateKeepSampleBox(selectedBoxId, { boxState: 'open' });
        setBoxes(storageService.getKeepSampleBoxes());
        onRefreshData();
      }
      setFeedbackMsg({
        type: 'info',
        text: `Box ${boxNumber} unlocked by QM Authority. Status set back to Open (Draft).`
      });
    }
  };

  // Manual Add Item Modal Form
  const handleManualAddSampleItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) {
      alert('Please enter Item Name or Component Part Number');
      return;
    }

    const manualItem: SampleItemRow = {
      id: `smp-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      itemName: newItemName.trim(),
      drawingNumber: newDrawingNumber.trim(),
      poNumber: newPoNumber.trim(),
      lotNumber: newLotNumber.trim() || `LOT-${Date.now().toString().slice(-4)}`,
      quantity: Number(newQuantity) || 1,
      defectType: newDefectType,
      boxNo: boxNumber,
      cavity: newCavity.trim(),
      cavityNo: newCavityNo.trim(),
      time: newTime.trim(),
      unitQty: newUnitQty.trim(),
      process: newDefectType,
      remarks: newItemRemarks.trim()
    };

    const updated = [manualItem, ...samples];
    setSamples(updated);
    if (!item) setItem(manualItem.itemName);

    if (selectedBoxId) {
      try {
        storageService.addSampleToBox(selectedBoxId, manualItem);
        setBoxes(storageService.getKeepSampleBoxes());
        onRefreshData();
      } catch (err) {
        console.error('Manual add error:', err);
      }
    }

    // Reset Modal Form
    setNewItemName('');
    setNewDrawingNumber('');
    setNewPoNumber('');
    setNewLotNumber('');
    setNewQuantity(1);
    setNewUnitQty('1 EA/CAVITY');
    setNewCavity('');
    setNewCavityNo('');
    setNewTime('');
    setNewItemRemarks('');
    setIsAddItemModalOpen(false);

    setFeedbackMsg({
      type: 'success',
      text: `Added sample "${manualItem.itemName}" to Box ${boxNumber}.`
    });
  };

  const handleDeleteSampleItem = (sampleId: string) => {
    if (isBoxLocked) {
      alert('Cannot remove items: Box is Closed and Locked. Only QM Hold / QM Admin can modify.');
      return;
    }
    if (window.confirm('Remove this sample item from the box?')) {
      const filtered = samples.filter((s) => s.id !== sampleId);
      setSamples(filtered);
      if (selectedBoxId) {
        try {
          storageService.deleteSampleFromBox(selectedBoxId, sampleId);
          setBoxes(storageService.getKeepSampleBoxes());
          onRefreshData();
        } catch (err) {
          console.error('Delete item sync error:', err);
        }
      }
    }
  };

  const handleDeleteBox = (box: KeepSampleBox) => {
    if (!isSysadmin && !isQMAdmin) {
      alert('Access Denied: Only Admin, Sysadmin, or QM Admin can delete Keep Sample boxes.');
      return;
    }
    if (window.confirm(`Are you sure you want to delete box "${box.boxNumber}" and all associated samples?`)) {
      storageService.deleteKeepSampleBox(box.id);
      setBoxes(storageService.getKeepSampleBoxes());
      onRefreshData();
      setFeedbackMsg({
        type: 'info',
        text: `Box ${box.boxNumber} deleted from masterlist.`
      });
      if (selectedBoxId === box.id) {
        setIsMultitabOpen(false);
        setSelectedBoxId(null);
      }
    }
  };

  const handlePrintA6Label = (boxOverride?: KeepSampleBox) => {
    const currentBoxObj: KeepSampleBox = boxOverride || {
      id: selectedBoxId || 'preview',
      boxNumber,
      factory,
      requestedBy,
      storageArea,
      section,
      productFamily,
      item: item || productFamily,
      archiveType,
      dateGenerated,
      dateExpiration,
      status: currentCalculatedStatus,
      boxState,
      remarks,
      rackLocation,
      maxCapacity,
      occupiedSlots: samples.length,
      samples
    };
    setPrintingBox(currentBoxObj);
  };

  // Filtered Boxes for Masterlist
  const filteredBoxes = boxes.filter((box) => {
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (box.boxNumber || '').toLowerCase().includes(q) ||
      (box.section || '').toLowerCase().includes(q) ||
      (box.productFamily && box.productFamily.toLowerCase().includes(q)) ||
      (box.item && box.item.toLowerCase().includes(q)) ||
      (box.rackLocation && box.rackLocation.toLowerCase().includes(q)) ||
      (box.requestedBy && box.requestedBy.toLowerCase().includes(q)) ||
      (box.samples && box.samples.some((s) => 
        (s.itemName || '').toLowerCase().includes(q) ||
        (s.drawingNumber || '').toLowerCase().includes(q) ||
        (s.lotNumber || '').toLowerCase().includes(q) ||
        (s.poNumber || '').toLowerCase().includes(q)
      ));

    const matchesFactory = filterFactory === 'All' || box.factory === filterFactory;
    const matchesStatus = filterStatus === 'All' || box.status === filterStatus;

    return matchesSearch && matchesFactory && matchesStatus;
  });

  const getStatusBadge = (status: KeepSampleBoxStatus) => {
    switch (status) {
      case 'NOT YET EXPIRED':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-950/80 text-emerald-300 border border-emerald-600/70 inline-flex items-center gap-1 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            NOT YET EXPIRED
          </span>
        );
      case 'EXPIRED':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-rose-950/80 text-rose-300 border border-rose-600/70 inline-flex items-center gap-1 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
            EXPIRED
          </span>
        );
      case 'FOR CHECKING':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-amber-950/80 text-amber-300 border border-amber-600/70 inline-flex items-center gap-1 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
            FOR CHECKING
          </span>
        );
      case 'AVAILABLE SPACE':
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-blue-950/80 text-blue-300 border border-blue-600/70 inline-flex items-center gap-1 shadow-xs">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
            AVAILABLE SPACE
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans']">
      
      {/* Header & Role Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-emerald-800/60">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white tracking-tight font-['Chakra_Petch'] uppercase flex items-center gap-2">
            <Box className="w-6 h-6 text-pink-400" />
            <span>KEEP SAMPLE MASTERLIST & BOX ENTRY</span>
          </h1>
        </div>

        <div className="flex items-center space-x-2">
          {canManageBoxes && (
            <>
              <button
                type="button"
                onClick={() => setIsImportModalOpen(true)}
                className="px-3 py-1.5 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-700/60 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-all shadow-xs"
                title="Import Keep Sample records via Excel/CSV"
              >
                <UploadCloud className="w-3.5 h-3.5" />
                <span>Import Masterlist</span>
              </button>

              {!isQCInspector && (
                <button
                  type="button"
                  onClick={handleOpenNewBoxRegistration}
                  className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-all shadow-md active:scale-98"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ New Box Registration</span>
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-xs ${
          feedbackMsg.type === 'success'
            ? 'bg-emerald-950/90 border-emerald-500 text-emerald-200'
            : feedbackMsg.type === 'error'
            ? 'bg-rose-950/90 border-rose-500 text-rose-200'
            : feedbackMsg.type === 'warning'
            ? 'bg-amber-950/90 border-amber-500 text-amber-200'
            : 'bg-blue-950/90 border-blue-500 text-blue-200'
        }`}>
          <div className="flex items-center space-x-2.5">
            {feedbackMsg.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
            {feedbackMsg.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />}
            {feedbackMsg.type === 'warning' && <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />}
            {feedbackMsg.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-[11px] underline ml-2 opacity-80 hover:opacity-100 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. MASTERLIST VIEW (Shown when Multitab workspace is closed) */}
      {/* ========================================================================= */}
      {!isMultitabOpen ? (
        <div className="space-y-4 animate-in fade-in duration-200">
          
          {/* Top Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#121815] rounded-xl border border-emerald-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-emerald-700 to-green-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">TOTAL BOXES</span>
                <Box className="w-3.5 h-3.5 text-emerald-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-emerald-100">{boxes.length}</div>
                <div className="p-2 bg-emerald-950 text-emerald-400 rounded-lg border border-emerald-700/50">
                  <Box className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div className="bg-[#121815] rounded-xl border border-teal-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-teal-700 to-emerald-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">NOT YET EXPIRED</span>
                <CheckCircle className="w-3.5 h-3.5 text-teal-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-teal-200">
                  {boxes.filter(b => b.status === 'NOT YET EXPIRED').length}
                </div>
                <div className="p-2 bg-teal-950 text-teal-400 rounded-lg border border-teal-700/50">
                  <CheckCircle className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div className="bg-[#121815] rounded-xl border border-rose-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-rose-700 to-red-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">EXPIRED RETENTION</span>
                <AlertTriangle className="w-3.5 h-3.5 text-rose-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-rose-200">
                  {boxes.filter(b => b.status === 'EXPIRED').length}
                </div>
                <div className="p-2 bg-rose-950 text-rose-400 rounded-lg border border-rose-700/50">
                  <AlertTriangle className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div className="bg-[#121815] rounded-xl border border-blue-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-blue-700 to-indigo-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">AVAILABLE SPACE</span>
                <Package className="w-3.5 h-3.5 text-blue-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-blue-200">
                  {boxes.filter(b => b.status === 'AVAILABLE SPACE' || b.status === 'FOR CHECKING').length}
                </div>
                <div className="p-2 bg-blue-950 text-blue-400 rounded-lg border border-blue-700/50">
                  <Package className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

          {/* Masterlist Container */}
          <div className="bg-[#121815] rounded-xl shadow-lg border border-emerald-700/60 overflow-hidden">
            
            <div className="px-4 py-2.5 border-b border-emerald-700/60 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-gradient-to-r from-[#064e3b] via-[#095742] to-[#043d2e]">
              <div>
                <h2 className="text-sm md:text-base font-bold text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                  <Box className="w-4 h-4 text-pink-300" />
                  <span>REGISTERED KEEP SAMPLE BOXES</span>
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-[200px]">
                  <Search className="w-3.5 h-3.5 text-emerald-300 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search box, part, lot, rack..."
                    className="w-full bg-[#0a2820] border border-emerald-500/70 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-emerald-300/60 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <select
                  value={filterFactory}
                  onChange={(e) => setFilterFactory(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Factories</option>
                  <option value="First Factory">1F Only</option>
                  <option value="Second Factory">2F Only</option>
                </select>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Statuses</option>
                  <option value="NOT YET EXPIRED">Not Yet Expired</option>
                  <option value="EXPIRED">Expired</option>
                  <option value="FOR CHECKING">For Checking</option>
                  <option value="AVAILABLE SPACE">Available Space</option>
                </select>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="isms-table w-full text-xs">
                <thead>
                  <tr className="bg-[#062c21] text-emerald-200 uppercase text-[10px] tracking-wider border-b border-emerald-700/60 font-mono">
                    <th className="p-2.5 font-bold text-emerald-100">Box Number</th>
                    <th className="p-2.5 font-bold text-emerald-100">Factory & Area</th>
                    <th className="p-2.5 font-bold text-emerald-100">Rack Location</th>
                    <th className="p-2.5 font-bold text-emerald-100">Section</th>
                    <th className="p-2.5 font-bold text-emerald-100">Product Family / Item</th>
                    <th className="p-2.5 font-bold text-emerald-100">State</th>
                    <th className="p-2.5 font-bold text-emerald-100">Retention Expiration</th>
                    <th className="p-2.5 font-bold text-emerald-100 min-w-[160px]">Box Capacity & Fill Rate</th>
                    <th className="p-2.5 font-bold text-emerald-100">Status</th>
                    <th className="p-2.5 text-right font-bold text-emerald-100">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-900/40">
                  {filteredBoxes.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="p-8 text-center text-emerald-300/70">
                        No Keep Sample boxes found matching your search.
                      </td>
                    </tr>
                  ) : (
                    filteredBoxes.map((box) => {
                      const isSelected = selectedBoxId === box.id;
                      const isClosed = box.boxState === 'closed';
                      return (
                        <tr
                          key={box.id}
                          onClick={() => setSelectedBoxId(box.id)}
                          onDoubleClick={() => handleSelectBoxFromMasterlist(box)}
                          className={`cursor-pointer transition-colors duration-150 group hover:bg-[#18392d]/80 ${
                            isSelected ? 'bg-pink-950/50' : 'bg-[#101e18]'
                          }`}
                          title="Double-click to open box workspace"
                        >
                          <td className="p-2.5 font-mono font-bold text-pink-300 group-hover:text-pink-200 whitespace-nowrap">
                            {box.boxNumber}
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            <span className="font-semibold text-white block">
                              {box.factory === 'First Factory' ? '1st Factory' : '2nd Factory'}
                            </span>
                            <span className="text-[10px] text-emerald-300 font-mono">
                              {box.storageArea}
                            </span>
                          </td>
                          <td className="p-2.5 font-mono text-emerald-300 font-bold whitespace-nowrap">
                            {box.rackLocation || 'RACK-PENDING'}
                          </td>
                          <td className="p-2.5 font-semibold text-emerald-100 whitespace-nowrap">
                            {box.section}
                          </td>
                          <td className="p-2.5 text-slate-100 max-w-xs truncate" title={box.item}>
                            <div className="font-bold text-white">{box.productFamily || box.item || 'Keep Sample Box'}</div>
                            {box.item && box.productFamily && (
                              <div className="text-[10px] text-emerald-400 truncate">{box.item}</div>
                            )}
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            {isClosed ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-rose-950/80 text-rose-300 border border-rose-600/60 inline-flex items-center gap-1 font-mono">
                                <Lock className="w-3 h-3 text-rose-400" /> CLOSED
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-950/80 text-emerald-300 border border-emerald-600/60 inline-flex items-center gap-1 font-mono">
                                <Unlock className="w-3 h-3 text-emerald-400" /> OPEN (DRAFT)
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 font-mono text-slate-200 whitespace-nowrap">
                            {box.dateExpiration || '-'}
                          </td>
                          <td className="p-2.5 whitespace-nowrap min-w-[160px]">
                            {(() => {
                              const actualCount = box.samples?.length ?? box.occupiedSlots ?? 0;
                              const maxCap = box.maxCapacity && box.maxCapacity > 0 ? box.maxCapacity : 12;
                              const pct = Math.round((actualCount / maxCap) * 100);
                              const isFull = actualCount >= maxCap;
                              const isNearFull = pct >= 75 && !isFull;
                              const barColor = isFull
                                ? 'bg-gradient-to-r from-rose-500 to-red-600'
                                : isNearFull
                                ? 'bg-gradient-to-r from-amber-400 to-orange-500'
                                : 'bg-gradient-to-r from-emerald-400 to-teal-500';

                              return (
                                <div className="space-y-1.5 py-0.5">
                                  <div className="flex items-center justify-between text-[11px] font-mono font-bold">
                                    <span className="text-white flex items-center gap-1">
                                      <span className={isFull ? 'text-rose-300' : isNearFull ? 'text-amber-300' : 'text-emerald-300'}>
                                        {actualCount}
                                      </span>
                                      <span className="text-slate-500">/</span>
                                      <span className="text-slate-400">{maxCap} samples</span>
                                    </span>
                                    <span className={`px-1.5 py-0.2 rounded text-[10px] font-extrabold ${
                                      isFull
                                        ? 'bg-rose-950/90 text-rose-300 border border-rose-600/70'
                                        : isNearFull
                                        ? 'bg-amber-950/90 text-amber-300 border border-amber-600/70'
                                        : 'bg-emerald-950/90 text-emerald-300 border border-emerald-600/70'
                                    }`}>
                                      {isFull ? 'FULL' : `${pct}%`}
                                    </span>
                                  </div>
                                  
                                  {/* Progress track */}
                                  <div className="w-full h-2 bg-[#091812] rounded-full overflow-hidden border border-emerald-900/60 p-0.5">
                                    <div
                                      className={`h-full rounded-full transition-all duration-300 shadow-sm ${barColor}`}
                                      style={{ width: `${Math.min(100, Math.max(actualCount > 0 ? 5 : 0, pct))}%` }}
                                      title={`${actualCount} of ${maxCap} slots occupied (${pct}%)`}
                                    />
                                  </div>
                                </div>
                              );
                            })()}
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            {getStatusBadge(box.status)}
                          </td>
                          <td className="p-2.5 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end space-x-1.5">
                              <button
                                onClick={() => handlePrintA6Label(box)}
                                className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 shadow-xs transition-colors"
                                title="Print A6 / QR Label"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleSelectBoxFromMasterlist(box)}
                                className="p-1 bg-pink-900/60 hover:bg-pink-800 text-pink-200 rounded border border-pink-600/60 shadow-xs transition-colors"
                                title="Open Multi-tab Workspace"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              {canManageBoxes && (
                                <button
                                  onClick={() => handleDeleteBox(box)}
                                  className="p-1 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded border border-rose-600/60 shadow-xs transition-colors"
                                  title="Delete Box"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-[#0a1a14] border-t border-emerald-800/60 text-xs text-emerald-300/80 flex justify-between items-center font-mono">
              <span>Showing {filteredBoxes.length} of {boxes.length} registered boxes</span>
              <span>JAE Quality Management Retention Standard</span>
            </div>
          </div>

        </div>
      ) : (
        /* ========================================================================= */
        /* 2. MULTI-TAB WORKSPACE */
        /* ========================================================================= */
        <div className="space-y-4 animate-in fade-in duration-300">
          
          {/* Multitab Navigation Bar (Streamlined without the redundant active box header) */}
          <div className="bg-[#181818] rounded-2xl shadow-lg border border-emerald-800/60 p-2 flex flex-wrap items-center gap-1.5">
            
            {/* Back to Masterlist Button */}
            <button
              type="button"
              onClick={() => setIsMultitabOpen(false)}
              className="py-2.5 px-3.5 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-700/60 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-colors cursor-pointer mr-1"
              title="Return to Masterlist"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Masterlist</span>
            </button>

            {/* Page 1: Box Registration (Disabled for QC Inspector) */}
            <button
              onClick={() => {
                if (canAccessPage1) setActiveTab('BOX_NUMBER_REQUEST');
                else {
                  setFeedbackMsg({
                    type: 'warning',
                    text: 'QC Inspectors are restricted to Page 2 (Sample in Box) only.'
                  });
                }
              }}
              disabled={!canAccessPage1}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                !canAccessPage1
                  ? 'opacity-40 cursor-not-allowed bg-[#1a1a1a] text-slate-500 border border-slate-800'
                  : activeTab === 'BOX_NUMBER_REQUEST'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Page 1: Registration of Box</span>
              {!canAccessPage1 && <Lock className="w-3 h-3 text-slate-500 ml-1" />}
            </button>

            {/* Page 2: Sample in Box (Accessible to QC Inspector & QC Hold) */}
            <button
              onClick={() => setActiveTab('KEEP_SAMPLES_LIST')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'KEEP_SAMPLES_LIST'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Page 2: Sample in Box ({samples.length})</span>
            </button>

            {/* Page 3: QC Hold & QR Scan (Enabled for QC Hold only AFTER Save as Closed) */}
            <button
              onClick={() => {
                if (canAccessPage3) {
                  setActiveTab('QC_HOLD_VERIFICATION');
                } else if (boxState !== 'closed') {
                  setFeedbackMsg({
                    type: 'warning',
                    text: 'Page 3 is enabled only after the box is "Saved as Closed". Please close the box first.'
                  });
                } else {
                  setFeedbackMsg({
                    type: 'warning',
                    text: 'Page 3 is restricted to QC Hold and QM Authorities.'
                  });
                }
              }}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                !canAccessPage3
                  ? 'opacity-50 bg-[#1e1e1e] text-slate-500 border border-slate-800'
                  : activeTab === 'QC_HOLD_VERIFICATION'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>Page 3: QC Hold & QR Scan</span>
              {!canAccessPage3 && <Lock className="w-3 h-3 text-slate-500 ml-1" />}
            </button>

            {/* Audit Trail */}
            <button
              onClick={() => setActiveTab('AUDIT_TRAIL')}
              className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'AUDIT_TRAIL'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Audit</span>
            </button>

            {/* Quick Actions inside Nav Bar */}
            <div className="flex items-center space-x-1.5 ml-auto pl-1">
              {boxState === 'closed' && canEditWhenClosed && (
                <button
                  type="button"
                  onClick={handleUnlockBox}
                  className="px-2.5 py-2 bg-amber-900/70 hover:bg-amber-800 text-amber-200 border border-amber-600/60 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all"
                  title="Unlock box to allow QC Inspector to scan further samples"
                >
                  <Unlock className="w-3.5 h-3.5 text-amber-300" />
                  <span className="hidden sm:inline">Unlock Box</span>
                </button>
              )}
              <button
                type="button"
                onClick={() => handlePrintA6Label()}
                className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all shadow-xs"
                title="Print A6 Physical Box Label"
              >
                <Printer className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Print A6</span>
              </button>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* TAB 1: PAGE 1 REGISTRATION OF BOX (Clean form without QR scanner) */}
          {/* ========================================================================= */}
          {activeTab === 'BOX_NUMBER_REQUEST' && (
            <div className="bg-[#141a16] rounded-xl shadow-lg border border-emerald-800/60 p-6 space-y-6 text-white">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    Page 1: Registration of Box (QC Hold / QM Section)
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-pink-300 bg-pink-950/80 px-3 py-1 rounded-lg border border-pink-700/60 shadow-xs">
                  {factory}
                </span>
              </div>

              {isBoxLocked && (
                <div className="p-3 bg-rose-950/60 border border-rose-600/70 rounded-xl text-xs text-rose-200 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Lock className="w-4 h-4 text-rose-400" />
                    <span>This box is currently <strong>CLOSED & LOCKED</strong>. Only QM Hold / QM Admin can edit registration details.</span>
                  </div>
                </div>
              )}

              <form onSubmit={handleSaveBoxRegistration} className="space-y-4 text-xs">
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      FACTORY: <span className="text-pink-400">*</span>
                    </label>
                    <select
                      value={factory}
                      onChange={(e) => handleFactoryChange(e.target.value as FactoryType)}
                      disabled={isBoxLocked}
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    >
                      <option value="First Factory">First Factory (1F)</option>
                      <option value="Second Factory">Second Factory (2F)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      BOX NUMBER: <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={boxNumber}
                      onChange={(e) => setBoxNumber(e.target.value)}
                      disabled={isBoxLocked}
                      required
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      REGISTERED BY (P.I.C): <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={requestedBy}
                      onChange={(e) => setRequestedBy(e.target.value)}
                      disabled={isBoxLocked}
                      required
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      SECTION: <span className="text-pink-400">*</span>
                    </label>
                    <select
                      value={section}
                      onChange={(e) => setSection(e.target.value as SectionType)}
                      disabled={isBoxLocked}
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    >
                      {sectionsList.map((sec) => (
                        <option key={sec} value={sec}>{sec}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      STORAGE AREA: <span className="text-pink-400">*</span>
                    </label>
                    <select
                      value={storageArea}
                      onChange={(e) => handleStorageAreaChange(e.target.value as StorageAreaType)}
                      disabled={isBoxLocked}
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    >
                      <option value="1F MEZZANINE">1F MEZZANINE</option>
                      <option value="F2B STORAGE">F2B STORAGE</option>
                      <option value="Y2K BUILDING">Y2K BUILDING</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      RACK LOCATION: <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={rackLocation}
                      onChange={(e) => setRackLocation(e.target.value)}
                      disabled={isBoxLocked}
                      placeholder="e.g. On-going or RACK-1F-M04"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-emerald-200 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      PRODUCT FAMILY:
                    </label>
                    <input
                      type="text"
                      value={productFamily}
                      onChange={(e) => setProductFamily(e.target.value)}
                      disabled={isBoxLocked}
                      placeholder="e.g. MX57 Series, MX34 Series, Honda Connector"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      PRIMARY ITEM: <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={item}
                      onChange={(e) => setItem(e.target.value)}
                      disabled={isBoxLocked}
                      placeholder="e.g. MX57 Automotive 24-Pin Male Header Pin Retainer"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      ARCHIVE TYPE: <span className="text-pink-400">*</span>
                    </label>
                    <select
                      value={archiveType}
                      onChange={(e) => handleArchiveTypeChange(e.target.value as ArchiveType)}
                      disabled={isBoxLocked}
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    >
                      <option value="KS">KS (Keep Sample - 3 Years)</option>
                      <option value="IQC KS">IQC KS (1 Year)</option>
                      <option value="RS Sample">RS Sample (1 Year)</option>
                      <option value="DIECON">DIECON (20 Years)</option>
                      <option value="FILES">FILES (20 Years)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      DATE GENERATED: <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="date"
                      value={dateGenerated}
                      onChange={(e) => handleDateGenChange(e.target.value)}
                      disabled={isBoxLocked}
                      required
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      DATE EXPIRATION (CALCULATED):
                    </label>
                    <input
                      type="date"
                      value={dateExpiration}
                      onChange={(e) => setDateExpiration(e.target.value)}
                      disabled={isBoxLocked}
                      required
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-rose-400 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      MAX CAPACITY (SLOTS):
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      value={maxCapacity}
                      onChange={(e) => setMaxCapacity(Number(e.target.value))}
                      disabled={isBoxLocked}
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    REMARKS & APPLICATION DETAILS:
                  </label>
                  <textarea
                    rows={2}
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    disabled={isBoxLocked}
                    placeholder="e.g. Master golden sample for Honda Civic instrument cluster connector"
                    className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl p-2.5 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-50"
                  />
                </div>

                <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setIsMultitabOpen(false)}
                    className="px-4 py-2 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-800/60 font-bold rounded-xl text-xs flex items-center space-x-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>Back to Masterlist</span>
                  </button>
                  
                  <div className="flex items-center space-x-3">
                    <button
                      type="submit"
                      disabled={isBoxLocked}
                      className="px-5 py-2 bg-pink-600 hover:bg-pink-700 disabled:opacity-40 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Box Registration</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        handleSaveBoxRegistration();
                        setActiveTab('KEEP_SAMPLES_LIST');
                      }}
                      className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                    >
                      <span>Proceed to Page 2: Sample in Box →</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 2: PAGE 2 SAMPLE IN BOX (Batch QR Scanner & Auto-Add + Save Draft/Closed) */}
          {/* ========================================================================= */}
          {activeTab === 'KEEP_SAMPLES_LIST' && (
            <div className="bg-[#141a16] rounded-xl shadow-lg border border-emerald-800/60 p-6 space-y-5 text-white">
              
              {/* Header Box Summary & Scanner Toggle */}
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                    <Package className="w-4 h-4 text-pink-400" />
                    <span>Page 2: Samples in Box ({boxNumber})</span>
                  </h3>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsScanSectionOpen(!isScanSectionOpen)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold border flex items-center space-x-1.5 transition-all cursor-pointer ${
                      isScanSectionOpen
                        ? 'bg-pink-600 text-white border-pink-400 shadow-md'
                        : 'bg-emerald-900/70 hover:bg-emerald-800 text-emerald-200 border-emerald-600/60'
                    }`}
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>{isScanSectionOpen ? 'Scanner Active' : 'Scan QR to Add'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setIsAddItemModalOpen(true)}
                    disabled={isBoxLocked}
                    className="px-3.5 py-2 bg-[#0a2820] hover:bg-[#143d30] disabled:opacity-40 text-emerald-200 border border-emerald-600/60 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all cursor-pointer"
                    title="Manual entry fallback"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Manual Entry</span>
                  </button>
                </div>
              </div>

              {/* Status Banner when Box is Locked */}
              {isBoxLocked && (
                <div className="p-3 bg-rose-950/70 border border-rose-600/80 rounded-xl text-xs text-rose-200 flex items-center justify-between shadow-xs">
                  <div className="flex items-center space-x-2">
                    <Lock className="w-4 h-4 text-rose-400" />
                    <span><strong>BOX IS CLOSED & LOCKED</strong>. Further scanning is disabled unless reopened by QM Hold / QM Admin.</span>
                  </div>
                  {canEditWhenClosed && (
                    <button
                      type="button"
                      onClick={handleUnlockBox}
                      className="px-3 py-1 bg-rose-900 hover:bg-rose-800 text-rose-100 rounded-lg text-[11px] font-bold border border-rose-500/60"
                    >
                      Reopen Box
                    </button>
                  )}
                </div>
              )}

              {/* SCAN QR CODE SECTION */}
              {isScanSectionOpen && !isBoxLocked && (
                <div className="p-4 bg-[#0e1713] rounded-xl border-2 border-emerald-500/80 shadow-lg space-y-3 animate-in fade-in duration-200">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-800/80 pb-2.5">
                    <div className="flex items-center space-x-2">
                      <div className="p-1.5 bg-pink-950/80 border border-pink-600/70 rounded-lg text-pink-300">
                        <QrCode className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-black text-white uppercase tracking-wider font-['Chakra_Petch'] flex items-center gap-2">
                          <span>SCAN THE QR CODE HERE</span>
                        </span>
                      </div>
                    </div>

                    {/* Quick Simulation Buttons */}
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (onOpenScanner) {
                            onOpenScanner((scannedVal) => {
                              handleProcessBatchQRScan(scannedVal);
                            });
                          } else {
                            // Quick simulation
                            const mockLot = `L-2602${Math.floor(10 + Math.random() * 80)}-A${Math.floor(1 + Math.random() * 4)}`;
                            handleProcessBatchQRScan(`mx38-2pt-gh|1023603380|8820|${mockLot}|pe-pf|1 EA/CAVITY|${boxNumber}|b|2|5:30am|120-56754`);
                          }
                        }}
                        className="px-2.5 py-1 bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 font-bold rounded-lg text-[11px] flex items-center space-x-1 border border-emerald-600/60 shadow-xs cursor-pointer"
                      >
                        <Camera className="w-3 h-3 text-emerald-300" />
                        <span>Camera Scan</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const mockLot = `L-2602${Math.floor(10 + Math.random() * 80)}-A${Math.floor(1 + Math.random() * 4)}`;
                          handleProcessBatchQRScan(`MX57 Male Header Retainer|PO-2026-HN-9982|2|${mockLot}|Lock arm flash|1 EA/CAVITY|${boxNumber}|Cavity #1|1|08:30am|DWG-MX57-24P-REV04`);
                        }}
                        className="px-2.5 py-1 bg-pink-900/80 hover:bg-pink-800 text-pink-200 font-bold rounded-lg text-[11px] flex items-center space-x-1 border border-pink-600/60 shadow-xs cursor-pointer"
                        title="Simulate valid sample scan for current box"
                      >
                        <Sparkles className="w-3 h-3 text-pink-300" />
                        <span>Simulate Valid Scan</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          // Simulate Wrong Box scan
                          handleProcessBatchQRScan(`MX34 Wire Terminal|PO-2026-TY-4421|3|LOT-WRONG-99|Crimp height|1 EA/CAVITY|99-99-999-9F|Cavity #4|4|13:45|DWG-MX34-16W`);
                        }}
                        className="px-2 py-1 bg-rose-950 hover:bg-rose-900 text-rose-300 font-bold rounded-lg text-[10px] border border-rose-700/60 cursor-pointer"
                        title="Test wrong box validation"
                      >
                        Test Wrong Box
                      </button>
                    </div>
                  </div>

                  {/* Real-time Hardware / Keyboard Barcode Input Box */}
                  <div className="flex flex-col sm:flex-row items-center gap-2">
                    <div className="relative flex-1 w-full">
                      <ScanLine className="w-4 h-4 text-emerald-400 absolute left-3 top-2.5 animate-pulse" />
                      <input
                        type="text"
                        value={page2ScanInput}
                        onChange={(e) => {
                          const val = e.target.value;
                          setPage2ScanInput(val);
                          // If scanner sends newline or delimited string
                          if (val.includes('|') && val.split('|').length >= 4 && (val.endsWith('\n') || val.length > 35)) {
                            handleProcessBatchQRScan(val);
                          }
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && page2ScanInput) {
                            e.preventDefault();
                            handleProcessBatchQRScan(page2ScanInput);
                          }
                        }}
                        autoFocus
                        placeholder="Ready for scan... Barcode scanner / scan QR code string (Press Enter to auto-add)..."
                        className="w-full bg-[#101e18] border-2 border-emerald-500/90 focus:border-pink-500 rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-slate-400 shadow-inner focus:ring-2 focus:ring-pink-500 focus:outline-none"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => handleProcessBatchQRScan(page2ScanInput)}
                      disabled={!page2ScanInput.trim()}
                      className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow-md whitespace-nowrap cursor-pointer"
                    >
                      <Zap className="w-3.5 h-3.5 text-yellow-300" />
                      <span>Auto Add Scan</span>
                    </button>
                  </div>

                  {/* Immediate Scanner Feedback Bar */}
                  {lastScannedFeedback && (
                    <div className={`p-2.5 rounded-lg border text-xs font-mono flex items-center space-x-2 ${
                      lastScannedFeedback.status === 'success'
                        ? 'bg-emerald-950 border-emerald-500 text-emerald-200'
                        : lastScannedFeedback.status === 'duplicate'
                        ? 'bg-amber-950 border-amber-500 text-amber-200'
                        : 'bg-rose-950 border-rose-500 text-rose-200'
                    }`}>
                      {lastScannedFeedback.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />}
                      {lastScannedFeedback.status === 'duplicate' && <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />}
                      {lastScannedFeedback.status === 'error' && <XCircle className="w-4 h-4 text-rose-400 shrink-0" />}
                      <span className="font-bold">{lastScannedFeedback.msg}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Sample Items Table */}
              <div className="border border-emerald-700/60 rounded-xl overflow-hidden shadow-xs bg-[#121815]">
                <div className="p-3 bg-[#062c21] border-b border-emerald-700/60 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-200 font-mono">
                      BATCHED SAMPLES IN THIS BOX ({samples.length} / {maxCapacity} slots)
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-300">
                    Box No: <strong className="text-pink-300">{boxNumber}</strong>
                  </span>
                </div>

                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-[#083629] text-emerald-200 border-b border-emerald-700/60 font-bold uppercase text-[10px] tracking-wider font-mono">
                    <tr>
                      <th className="p-2.5">#</th>
                      <th className="p-2.5">Sample Item Name</th>
                      <th className="p-2.5">Drawing Number</th>
                      <th className="p-2.5">PO Number</th>
                      <th className="p-2.5">Lot Number</th>
                      <th className="p-2.5">Quantity</th>
                      <th className="p-2.5">Classification / Defect</th>
                      <th className="p-2.5">Cavity / Unit</th>
                      <th className="p-2.5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-emerald-900/40">
                    {samples.length === 0 ? (
                      <tr>
                        <td colSpan={9} className="p-8 text-center text-emerald-300/60">
                          <Package className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                          <p className="font-semibold text-emerald-200">No keep samples added to Box {boxNumber} yet.</p>
                          <p className="text-[11px] text-emerald-400/80 mt-1">
                            Scan QR codes continuously using the barcode scanner above to auto-batch samples.
                          </p>
                        </td>
                      </tr>
                    ) : (
                      samples.map((smp, idx) => (
                        <tr key={smp.id} className="hover:bg-[#18392d]/80 text-white">
                          <td className="p-2.5 font-mono font-bold text-emerald-400">{idx + 1}</td>
                          <td className="p-2.5 font-bold text-white">{smp.itemName}</td>
                          <td className="p-2.5 font-mono text-emerald-300">{smp.drawingNumber || '-'}</td>
                          <td className="p-2.5 font-mono text-emerald-300">{smp.poNumber || '-'}</td>
                          <td className="p-2.5 font-mono text-pink-400 font-bold">{smp.lotNumber || '-'}</td>
                          <td className="p-2.5 font-mono font-bold text-white">{smp.quantity} pcs</td>
                          <td className="p-2.5">
                            <span className="px-2 py-0.5 rounded bg-emerald-900/60 text-emerald-300 border border-emerald-700/60 text-[10px] font-bold">
                              {smp.defectType || 'Master Sample'}
                            </span>
                          </td>
                          <td className="p-2.5 font-mono text-[10px] text-emerald-300">
                            {smp.cavity ? `Cavity: ${smp.cavity}` : ''} {smp.unitQty ? `(${smp.unitQty})` : ''}
                          </td>
                          <td className="p-2.5 text-right">
                            {!isBoxLocked && (
                              <button
                                type="button"
                                onClick={() => handleDeleteSampleItem(smp.id)}
                                className="p-1 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded transition-colors cursor-pointer"
                                title="Remove Item"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* SAVE AS DRAFT vs SAVE AS CLOSED ACTION ROW */}
              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (canAccessPage1) setActiveTab('BOX_NUMBER_REQUEST');
                      else setIsMultitabOpen(false);
                    }}
                    className="px-4 py-2 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-800/60 font-bold rounded-xl text-xs flex items-center space-x-1.5 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>{canAccessPage1 ? '← Page 1 Box Registration' : 'Back to Masterlist'}</span>
                  </button>
                </div>

                {/* Save as Draft & Save as Closed Buttons */}
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={handleSaveAsDraft}
                    className="px-4 py-2 bg-[#0a2820] hover:bg-[#143d30] text-emerald-200 border-2 border-emerald-600/70 font-bold rounded-xl text-xs flex items-center space-x-1.5 shadow-sm transition-all cursor-pointer"
                    title="Save current details without locking. Status remains Open."
                  >
                    <Save className="w-4 h-4 text-emerald-400" />
                    <span>Save as Draft (Status: Open)</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveAsClosed}
                    className="px-5 py-2 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white font-black rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all transform active:scale-98 cursor-pointer"
                    title="Lock box and finalize. Status becomes Closed. Enables Page 3."
                  >
                    <Lock className="w-4 h-4 text-white" />
                    <span>Save as Closed (Lock Box) →</span>
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: PAGE 3 QC HOLD & QR SCAN (Enabled only after Save as Closed) */}
          {/* ========================================================================= */}
          {activeTab === 'QC_HOLD_VERIFICATION' && (
            <div className="bg-[#141a16] rounded-xl shadow-lg border border-emerald-800/60 p-6 space-y-6 text-white">
              
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                    <QrCode className="w-4 h-4 text-pink-400" />
                    <span>Page 3: QC Hold Station Intake & A6 Label Printing</span>
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-200 bg-emerald-950/80 px-3 py-1 rounded-lg border border-emerald-700/60 shadow-xs">
                  VERIFIED CLOSED
                </span>
              </div>

              {/* Specific Box Summary Cards as requested */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">BOX NO:</span>
                  <span className="font-mono font-bold text-pink-400 text-sm">{boxNumber}</span>
                </div>
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">SECTION:</span>
                  <span className="font-bold text-white text-sm">{section}</span>
                </div>
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">STORAGE AREA:</span>
                  <span className="font-bold text-white text-sm">{storageArea}</span>
                </div>
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">RACK LOCATION:</span>
                  <span className="font-mono font-bold text-emerald-300 text-sm">{rackLocation}</span>
                </div>
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">PRODUCT FAMILY:</span>
                  <span className="font-bold text-white text-sm">{productFamily || item || 'N/A'}</span>
                </div>
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">ARCHIVE TYPE:</span>
                  <span className="font-bold text-pink-300 text-sm">{archiveType}</span>
                </div>
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">DATE GENERATED:</span>
                  <span className="font-mono text-white text-sm">{dateGenerated}</span>
                </div>
                <div className="bg-[#0c241c] p-3.5 rounded-xl border border-emerald-700/60">
                  <span className="text-[10px] text-emerald-400 block font-mono uppercase">DATE EXPIRATION:</span>
                  <span className="font-mono font-bold text-rose-400 text-sm">{dateExpiration}</span>
                </div>
              </div>

              {/* QR Code & A6 Print Preview Box */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                
                {/* 2D Barcode Preview */}
                <div className="bg-[#0c241c] p-6 rounded-2xl border border-emerald-700/60 flex flex-col items-center justify-center text-center space-y-3">
                  <div className="p-4 bg-white rounded-2xl shadow-md border border-slate-200">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(
                        JSON.stringify({ box: boxNumber, rack: rackLocation, exp: dateExpiration, factory, sec: section })
                      )}`}
                      alt="Box QR"
                      className="w-36 h-36"
                    />
                  </div>
                  <div className="font-mono text-xs font-bold text-pink-300">{boxNumber}</div>
                  <span className="text-[10px] text-emerald-400 font-mono">IATF 16949 2D DataMatrix Encoding</span>
                </div>

                {/* Print Control & Checklist */}
                <div className="md:col-span-2 space-y-4 text-xs">
                  <div className="p-4 bg-emerald-950/70 border border-emerald-700/70 rounded-xl space-y-2 text-emerald-200">
                    <div className="font-bold flex items-center gap-1.5 text-emerald-300">
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                      <span>QC Hold Station Intake Check Passed</span>
                    </div>
                    <p className="text-[11px] text-emerald-400/90 leading-relaxed">
                      Physical samples are sealed and cataloged. This box is ready for rack slot filing at <strong className="text-white font-mono">{rackLocation}</strong> ({storageArea}).
                    </p>
                  </div>

                  <div className="p-4 bg-[#0a1a14] rounded-xl border border-emerald-700/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="font-bold text-white">A6 Size Box Label (105mm × 148mm)</div>
                      <div className="text-[11px] text-emerald-300 font-mono">Prints high-resolution physical card for box outer lid</div>
                    </div>
                    <button
                      type="button"
                      onClick={handlePrintA6Label}
                      className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-2 transition-all cursor-pointer"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Print A6 Box Label</span>
                    </button>
                  </div>
                </div>

              </div>

              {/* Navigation buttons */}
              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('KEEP_SAMPLES_LIST')}
                  className="px-4 py-2 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-800/60 font-bold rounded-xl text-xs flex items-center space-x-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: Page 2 Samples in Box</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('AUDIT_TRAIL')}
                  className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                >
                  <span>Proceed to Audit & Logs →</span>
                </button>
              </div>

            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 4: AUDIT TRAIL */}
          {/* ========================================================================= */}
          {activeTab === 'AUDIT_TRAIL' && (
            <div className="bg-[#141a16] rounded-xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs text-white">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                    <History className="w-4 h-4 text-pink-400" />
                    <span>Box Activity & Transaction Audit Trail</span>
                  </h3>
                </div>
              </div>

              <div className="space-y-2">
                <div className="p-3 bg-[#0c241c] rounded-xl border border-emerald-700/60 flex items-start space-x-3">
                  <CheckSquare className="w-4 h-4 text-emerald-400 mt-0.5" />
                  <div>
                    <div className="font-bold text-emerald-200">Box Registered in iSMS Masterlist</div>
                    <div className="text-[11px] text-emerald-400 font-mono">Date: {dateGenerated} • Registered by: {requestedBy} • Box State: {boxState.toUpperCase()}</div>
                  </div>
                </div>

                {samples.map((s, i) => (
                  <div key={i} className="p-3 bg-[#0c241c] rounded-xl border border-emerald-700/60 flex items-start space-x-3">
                    <Package className="w-4 h-4 text-pink-400 mt-0.5" />
                    <div>
                      <div className="font-bold text-white">Sample Added: {s.itemName} (Lot: {s.lotNumber || 'N/A'})</div>
                      <div className="text-[11px] text-emerald-400 font-mono">
                        Quantity: {s.quantity} pcs • DWG: {s.drawingNumber || '-'} • Cavity: {s.cavity || '-'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('KEEP_SAMPLES_LIST')}
                  className="px-4 py-2 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-800/60 font-bold rounded-xl text-xs flex items-center space-x-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Back to Samples List</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsMultitabOpen(false)}
                  className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                >
                  <span>Return to Box Masterlist</span>
                </button>
              </div>
            </div>
          )}

        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. MANUAL ADD SAMPLE ITEM MODAL (Fallback) */}
      {/* ========================================================================= */}
      {isAddItemModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-['Plus_Jakarta_Sans']">
          <div className="bg-[#141a16] rounded-2xl shadow-2xl border border-emerald-800/80 w-full max-w-2xl max-h-[90vh] overflow-y-auto text-white">
            
            <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white px-6 py-4 flex items-center justify-between border-b border-emerald-700/60 sticky top-0 z-10">
              <div className="flex items-center space-x-2.5">
                <Package className="w-5 h-5 text-pink-400" />
                <h3 className="text-sm font-bold tracking-tight font-['Chakra_Petch'] uppercase">
                  Manual Add Keep Sample to Box {boxNumber}
                </h3>
              </div>
              <button
                onClick={() => setIsAddItemModalOpen(false)}
                className="text-emerald-300 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <form onSubmit={handleManualAddSampleItem} className="space-y-4">
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      ITEM NAME / DESCRIPTION: <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      required
                      placeholder="e.g. mx38-2pt-gh"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      DRAWING NUMBER:
                    </label>
                    <input
                      type="text"
                      value={newDrawingNumber}
                      onChange={(e) => setNewDrawingNumber(e.target.value)}
                      placeholder="e.g. 120-56754"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-semibold text-emerald-200 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      P.O / NUMBER:
                    </label>
                    <input
                      type="text"
                      value={newPoNumber}
                      onChange={(e) => setNewPoNumber(e.target.value)}
                      placeholder="e.g. 1023603380"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-300 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      LOT NUMBER:
                    </label>
                    <input
                      type="text"
                      value={newLotNumber}
                      onChange={(e) => setNewLotNumber(e.target.value)}
                      placeholder="e.g. m7 240618-12"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      QTY: <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={newQuantity}
                      onChange={(e) => setNewQuantity(Number(e.target.value))}
                      required
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      UNIT QUANTITY:
                    </label>
                    <input
                      type="text"
                      value={newUnitQty}
                      onChange={(e) => setNewUnitQty(e.target.value)}
                      placeholder="e.g. 1 EA/CAVITY"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-emerald-200 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      CAVITY:
                    </label>
                    <input
                      type="text"
                      value={newCavity}
                      onChange={(e) => setNewCavity(e.target.value)}
                      placeholder="e.g. b"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      CAVITY NO:
                    </label>
                    <input
                      type="text"
                      value={newCavityNo}
                      onChange={(e) => setNewCavityNo(e.target.value)}
                      placeholder="e.g. 2"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                      TIME:
                    </label>
                    <input
                      type="text"
                      value={newTime}
                      onChange={(e) => setNewTime(e.target.value)}
                      placeholder="e.g. 5:30am"
                      className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl px-3 py-2 text-xs font-mono font-semibold text-emerald-200 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    REMARKS & NOTES:
                  </label>
                  <textarea
                    rows={2}
                    value={newItemRemarks}
                    onChange={(e) => setNewItemRemarks(e.target.value)}
                    placeholder="Additional traceability notes..."
                    className="w-full bg-[#0a2820] border border-emerald-600/60 rounded-xl p-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <div className="pt-3 flex items-center justify-end space-x-3 border-t border-emerald-800/60">
                  <button
                    type="button"
                    onClick={() => setIsAddItemModalOpen(false)}
                    className="px-4 py-2 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-800/60 font-bold rounded-xl text-xs cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Item</span>
                  </button>
                </div>

              </form>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. PRINTABLE A6 (105mm × 148mm) BARCODE & QR LABEL MODAL */}
      {/* ========================================================================= */}
      {printingBox && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200 font-['Plus_Jakarta_Sans']">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-lg overflow-hidden text-slate-800">
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center space-x-2.5">
                <Printer className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm font-bold font-['Chakra_Petch'] uppercase">
                  IATF 16949 A6 Box Label Print Preview
                </h3>
              </div>
              <button
                onClick={() => setPrintingBox(null)}
                className="text-slate-400 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4">
              {/* Physical A6 Card Mockup */}
              <div className="border-2 border-dashed border-slate-400 rounded-xl p-5 bg-white shadow-inner space-y-3 font-mono">
                <div className="flex items-center justify-between border-b-2 border-slate-800 pb-2">
                  <div className="flex items-center space-x-2">
                    <JAELogo size="sm" />
                    <div>
                      <span className="font-extrabold text-xs text-slate-900 tracking-wider">JAE PHILIPPINES, INC.</span>
                      <span className="block text-[9px] text-slate-600 font-sans">Quality Management Dept - Retention Archive</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold bg-slate-900 text-white px-2 py-0.5 rounded">
                    {printingBox.factory === 'First Factory' ? '1F' : '2F'}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-1 text-xs">
                    <div>
                      <span className="text-[9px] text-slate-500 block uppercase">BOX NUMBER:</span>
                      <span className="text-base font-black text-pink-700 tracking-wider">{printingBox.boxNumber}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block uppercase">PRODUCT FAMILY:</span>
                      <span className="font-bold text-slate-800">{printingBox.productFamily || printingBox.item || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block uppercase">SECTION & AREA:</span>
                      <span className="font-bold text-slate-800">{printingBox.section} • {printingBox.storageArea}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block uppercase">RACK LOCATION:</span>
                      <span className="font-bold text-emerald-700">{printingBox.rackLocation || 'RACK-1F-M01'}</span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-500 block uppercase">RETENTION EXPIRATION:</span>
                      <span className="font-bold text-rose-600">{printingBox.dateExpiration || 'N/A'}</span>
                    </div>
                  </div>

                  <div className="p-2 border border-slate-300 rounded-lg bg-white flex flex-col items-center shrink-0">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=110x110&data=${encodeURIComponent(
                        JSON.stringify({
                          box: printingBox.boxNumber,
                          rack: printingBox.rackLocation,
                          exp: printingBox.dateExpiration,
                          sec: printingBox.section,
                          fac: printingBox.factory
                        })
                      )}`}
                      alt="QR Code"
                      className="w-24 h-24"
                    />
                    <span className="text-[8px] text-slate-400 mt-1">2D DataMatrix</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 text-[10px] text-slate-600 flex justify-between">
                  <span>P.I.C: {printingBox.requestedBy}</span>
                  <span>Archive: {printingBox.archiveType}</span>
                  <span>Samples: {printingBox.samples?.length || 0} pcs</span>
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setPrintingBox(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Send to A6 Label Printer</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* JAE Universal Data Import Modal */}
      {isImportModalOpen && (
        <DataImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          onImportComplete={() => {
            setBoxes(storageService.getKeepSampleBoxes());
            onRefreshData();
            setFeedbackMsg({
              type: 'success',
              text: 'Keep Sample Box Masterlist imported and synchronized successfully!'
            });
          }}
          initialCategory="KEEP_SAMPLE_BOX"
        />
      )}

    </div>
  );
};
