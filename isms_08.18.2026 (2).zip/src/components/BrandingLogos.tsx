import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

/**
 * JAE Official Corporate Vector Logo
 * Features the signature JAE typography framed between dual precision corporate blue bars
 */
export const JAELogo: React.FC<{ className?: string; variant?: 'color' | 'white' | 'dark'; size?: 'sm' | 'md' | 'lg' }> = ({
  className = '',
  variant = 'color',
  size = 'md'
}) => {
  const heightClasses = {
    sm: 'h-6',
    md: 'h-8',
    lg: 'h-11'
  };

  const primaryColor = variant === 'white' ? '#ffffff' : variant === 'dark' ? '#0f172a' : '#007fc4';
  const barColor = variant === 'white' ? 'rgba(255,255,255,0.9)' : variant === 'dark' ? '#334155' : '#007fc4';

  return (
    <div className={`inline-flex items-center select-none ${className}`} title="Japan Aviation Electronics Industry, Ltd. (JAE)">
      <svg
        viewBox="0 0 240 64"
        className={`${heightClasses[size]} w-auto drop-shadow-sm`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Top precision horizontal corporate bar */}
        <rect x="0" y="3" width="240" height="7" rx="3.5" fill={barColor} />
        
        {/* Bottom precision horizontal corporate bar */}
        <rect x="0" y="54" width="240" height="7" rx="3.5" fill={barColor} />

        {/* Central JAE Distinctive Glyph Text */}
        <g fill={primaryColor}>
          {/* 'J' */}
          <path d="M 38 18 H 58 V 39.5 C 58 45 54 48 47 48 C 40 48 36 44.5 35 40.5 L 43.5 39 C 44 40.8 45.2 42.2 47 42.2 C 48.8 42.2 50 41.2 50 39 V 24.5 H 38 V 18 Z" />
          
          {/* 'A' */}
          <path d="M 108 18 H 128 L 143 47 H 132.5 L 129 39.5 H 107 L 103.5 47 H 93 L 108 18 Z M 118 24.5 L 109.8 34 H 126.2 L 118 24.5 Z" />

          {/* 'E' */}
          <path d="M 175 18 H 207 V 24 H 183.5 V 29.5 H 203 V 35 H 183.5 V 41.5 H 207.5 V 47.5 H 175 V 18 Z" />
        </g>
      </svg>
    </div>
  );
};

/**
 * iSMS 3D Emblem Vector Logo
 * Features:
 * - 3D glossy metallic blue "iSMS" lettering
 * - Industrial precision green gear
 * - Eco-smart manufacturing factory building
 * - Barcode scanner lens and document checklist
 * - Quality sample testing vials with meniscus
 * - High-contrast ribbon with "INTEGRATED SAMPLE MANAGEMENT SYSTEM"
 */
export const ISMSLogo: React.FC<LogoProps> = ({
  className = '',
  size = 'md',
  showText = true
}) => {
  const dim = {
    sm: { icon: 'w-8 h-8', textTitle: 'text-sm', subText: 'text-[9px]' },
    md: { icon: 'w-12 h-12', textTitle: 'text-lg', subText: 'text-[10px]' },
    lg: { icon: 'w-16 h-16', textTitle: 'text-2xl', subText: 'text-xs' },
    xl: { icon: 'w-24 h-24', textTitle: 'text-3xl', subText: 'text-sm' }
  }[size];

  return (
    <div className={`inline-flex items-center gap-2.5 select-none ${className}`} title="iSMS - Integrated Sample Management System">
      {/* Emblem SVG with 3D Gradients and Shading */}
      <svg
        viewBox="0 0 200 200"
        className={`${dim.icon} flex-shrink-0 drop-shadow-md`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Blue Metallic 3D Gradients */}
          <linearGradient id="ismsBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#38bdf8" />
            <stop offset="35%" stopColor="#0284c7" />
            <stop offset="70%" stopColor="#0369a1" />
            <stop offset="100%" stopColor="#0c4a6e" />
          </linearGradient>
          <linearGradient id="ismsBlueBevel" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#082f49" stopOpacity="0.6" />
          </linearGradient>

          {/* Green Industrial Gear Gradient */}
          <linearGradient id="ismsGearGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#4ade80" />
            <stop offset="60%" stopColor="#16a34a" />
            <stop offset="100%" stopColor="#14532d" />
          </linearGradient>

          {/* Golden Orange Sample Box Gradient */}
          <linearGradient id="ismsBoxGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#fbbf24" />
            <stop offset="100%" stopColor="#d97706" />
          </linearGradient>

          {/* Ribbon Green Gradient */}
          <linearGradient id="ismsRibbonGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#15803d" />
            <stop offset="50%" stopColor="#22c55e" />
            <stop offset="100%" stopColor="#15803d" />
          </linearGradient>

          {/* Specular Glow Filter */}
          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="2" stdDeviation="2" floodColor="#0284c7" floodOpacity="0.3" />
          </filter>
        </defs>

        {/* Outer Circular Aura */}
        <circle cx="100" cy="92" r="80" fill="#f0fdf4" stroke="#86efac" strokeWidth="2.5" />

        {/* Industrial Gear Behind */}
        <g transform="translate(100, 92) rotate(15) translate(-100, -92)">
          <path
            d="M93 25 h14 l2 12 a60 60 0 0 1 12 5 l9 -8 l10 10 l-8 9 a60 60 0 0 1 5 12 l12 2 v14 l-12 2 a60 60 0 0 1 -5 12 l8 9 l-10 10 l-9 -8 a60 60 0 0 1 -12 5 l-2 12 h-14 l-2 -12 a60 60 0 0 1 -12 -5 l-9 8 l-10 -10 l8 -9 a60 60 0 0 1 -5 -12 l-12 -2 v-14 l12 -2 a60 60 0 0 1 5 -12 l-8 -9 l10 -10 l9 8 a60 60 0 0 1 12 -5 z"
            fill="url(#ismsGearGrad)"
            opacity="0.85"
          />
          <circle cx="100" cy="92" r="46" fill="#ffffff" />
        </g>

        {/* Factory Silhouettes & Eco Leaves */}
        <g fill="#0284c7" opacity="0.25">
          <path d="M 50 115 L 50 82 L 68 95 L 68 82 L 86 95 L 86 115 Z" />
          <path d="M 114 115 L 114 85 L 132 97 L 132 85 L 150 97 L 150 115 Z" />
          {/* Smokestack leaves */}
          <path d="M 68 76 C 68 70 78 65 82 72 C 82 78 74 82 68 76 Z" fill="#22c55e" opacity="0.9" />
          <path d="M 132 78 C 132 72 142 67 146 74 C 146 80 138 84 132 78 Z" fill="#22c55e" opacity="0.9" />
        </g>

        {/* Computer Screen & Checklist Document */}
        <rect x="52" y="60" width="46" height="34" rx="3" fill="#ffffff" stroke="#0284c7" strokeWidth="2" />
        <rect x="56" y="64" width="38" height="22" rx="1.5" fill="#0f172a" />
        {/* Screen lines */}
        <line x1="60" y1="70" x2="80" y2="70" stroke="#38bdf8" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="60" y1="75" x2="88" y2="75" stroke="#4ade80" strokeWidth="1.5" strokeLinecap="round" />
        <line x1="60" y1="80" x2="74" y2="80" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round" />

        {/* Sample Storage Box */}
        <g transform="translate(112, 64)">
          <path d="M 0 8 L 18 0 L 36 8 L 36 28 L 18 36 L 0 28 Z" fill="url(#ismsBoxGrad)" stroke="#b45309" strokeWidth="1.5" />
          <path d="M 0 8 L 18 16 L 36 8" stroke="#92400e" strokeWidth="1.5" />
          <path d="M 18 16 L 18 36" stroke="#92400e" strokeWidth="1.5" />
        </g>

        {/* Barcode Magnifier Lens */}
        <g transform="translate(42, 88)">
          <circle cx="22" cy="22" r="18" fill="#ffffff" fillOpacity="0.85" stroke="#0284c7" strokeWidth="3" />
          {/* Barcode inside lens */}
          <line x1="12" y1="14" x2="12" y2="30" stroke="#0f172a" strokeWidth="2" />
          <line x1="16" y1="14" x2="16" y2="30" stroke="#0f172a" strokeWidth="1" />
          <line x1="19" y1="14" x2="19" y2="30" stroke="#0f172a" strokeWidth="3" />
          <line x1="24" y1="14" x2="24" y2="30" stroke="#0f172a" strokeWidth="1.5" />
          <line x1="28" y1="14" x2="28" y2="30" stroke="#0f172a" strokeWidth="2.5" />
          <line x1="32" y1="14" x2="32" y2="30" stroke="#0f172a" strokeWidth="1" />
          {/* Scan laser line */}
          <line x1="8" y1="22" x2="36" y2="22" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="3 1" />
          {/* Handle */}
          <line x1="36" y1="36" x2="48" y2="48" stroke="#0369a1" strokeWidth="4" strokeLinecap="round" />
        </g>

        {/* Quality Test Tube Vials with Meniscus Fluids */}
        <g transform="translate(132, 84)">
          {/* Tube 1 (Cyan Fluid) */}
          <rect x="0" y="0" width="8" height="30" rx="4" fill="#ffffff" stroke="#64748b" strokeWidth="1.5" />
          <path d="M 0 14 Q 4 16 8 14 L 8 26 A 4 4 0 0 1 0 26 Z" fill="#06b6d4" />
          
          {/* Tube 2 (Green QC Fluid) */}
          <rect x="12" y="-4" width="8" height="34" rx="4" fill="#ffffff" stroke="#64748b" strokeWidth="1.5" />
          <path d="M 12 10 Q 16 12 20 10 L 20 26 A 4 4 0 0 1 12 26 Z" fill="#22c55e" />
        </g>

        {/* 3D GLOSSY "iSMS" CENTRAL TYPOGRAPHY */}
        <g filter="url(#softGlow)">
          {/* 3D Shadow Layers */}
          <text
            x="100"
            y="132"
            textAnchor="middle"
            fontFamily="'Arial Black', 'Impact', sans-serif"
            fontWeight="900"
            fontSize="44"
            fill="#082f49"
            letterSpacing="-1"
          >
            iSMS
          </text>
          {/* Main 3D Gradient Text */}
          <text
            x="100"
            y="130"
            textAnchor="middle"
            fontFamily="'Arial Black', 'Impact', sans-serif"
            fontWeight="900"
            fontSize="44"
            fill="url(#ismsBlueGrad)"
            letterSpacing="-1"
          >
            iSMS
          </text>
          {/* Top Bevel Highlight */}
          <text
            x="100"
            y="129"
            textAnchor="middle"
            fontFamily="'Arial Black', 'Impact', sans-serif"
            fontWeight="900"
            fontSize="44"
            fill="none"
            stroke="url(#ismsBlueBevel)"
            strokeWidth="1.2"
            letterSpacing="-1"
          >
            iSMS
          </text>
        </g>

        {/* Curved Green Banner / Ribbon */}
        <g transform="translate(0, 142)">
          {/* Ribbon Ends */}
          <path d="M 12 22 L 28 14 L 28 30 L 12 38 Z" fill="#14532d" />
          <path d="M 188 22 L 172 14 L 172 30 L 188 38 Z" fill="#14532d" />

          {/* Main Ribbon Body */}
          <path
            d="M 22 18 Q 100 2 178 18 L 174 34 Q 100 18 26 34 Z"
            fill="url(#ismsRibbonGrad)"
            stroke="#14532d"
            strokeWidth="1.5"
          />

          {/* Ribbon Text */}
          <text
            x="100"
            y="28"
            textAnchor="middle"
            fontFamily="'Arial', 'Segoe UI', sans-serif"
            fontWeight="900"
            fontSize="6.8"
            fill="#ffffff"
            letterSpacing="0.8"
          >
            INTEGRATED SAMPLE MANAGEMENT SYSTEM
          </text>
        </g>
      </svg>

      {/* Brand Text Pairing */}
      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center space-x-1.5 leading-none">
            <span className={`font-black tracking-tight font-['Chakra_Petch'] text-[#007fc4] ${dim.textTitle}`}>
              iSMS
            </span>
            <span className="text-[10px] px-1.5 py-0.5 bg-emerald-100 text-emerald-800 rounded font-extrabold uppercase border border-emerald-300">
              QM v2.6
            </span>
          </div>
          <span className={`text-slate-600 font-bold uppercase tracking-wider ${dim.subText}`}>
            Integrated Sample Management System
          </span>
        </div>
      )}
    </div>
  );
};

/**
 * Top-Level Unified Header Branding
 */
export const ISMSBrandBanner: React.FC<{ subtitle?: string; className?: string }> = ({
  subtitle = 'JAE Philippines, Inc. • Quality Management Department',
  className = ''
}) => {
  return (
    <div className={`flex items-center space-x-4 ${className}`}>
      <JAELogo size="md" />
      <div className="h-7 w-[2px] bg-slate-300 rounded-full" />
      <ISMSLogo size="md" showText={true} />
    </div>
  );
};
