import React, { useState } from 'react';
import {
  Users,
  Shield,
  UserPlus,
  Edit2,
  CheckCircle,
  KeyRound,
  Search,
  Lock,
  Building,
  Save,
  Trash2,
  AlertCircle,
  ShieldCheck,
  Download,
  Printer,
  BadgeAlert,
  Sparkles,
  Info,
  X
} from 'lucide-react';
import {
  UserProfile,
  UserRole,
  DepartmentType,
  SectionType,
  PositionType,
  FactoryType,
  EmploymentStatus,
  UserActionPermission
} from '../types';
import { storageService } from '../services/storageService';
import { apiClient } from '../services/apiClient';
import { JAELogo, ISMSLogo } from './BrandingLogos';

interface UserRegistryViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
  onSwitchUser: (u: UserProfile) => void;
}

const FACTORY_OPTIONS: FactoryType[] = [
  'First Factory',
  'Second Factory'
];

const EMPLOYMENT_STATUS_OPTIONS: EmploymentStatus[] = [
  'JAE-Reg.',
  'MDHII-Reg',
  'FAMSI-Reg.',
  'PKIMT-Reg.'
];

const DEPARTMENT_OPTIONS: DepartmentType[] = [
  'Assembly',
  'Molding',
  'Stamping',
  'QA',
  'QM',
  'PC',
  'Warehouse'
];

const SECTION_OPTIONS: SectionType[] = [
  'Mfg. Connector',
  'Mfg. Molding (Inspection)',
  'Mfg. Molding (Operation)',
  'Mfg. Stamping',
  'Mfg. Harness (Process)',
  'Mfg. Harness (Taping)',
  'Mfg. PreAssy',
  'Assembly Tech 1F',
  'Assembly Tech 2F',
  'Mfg. Training',
  'Mfg. 8D Team',
  'Mfg. IQT',
  "Eng'g Ass'y (Connector)",
  "Eng'g Molding",
  "Eng'g Stamping",
  "Eng'g Harness (Process)",
  "Eng'g Harness (Taping)",
  "Eng'g Ass'y (Pre-Assy)",
  'QA 1F',
  'QA 2F',
  'QM 1F',
  'QM 2F',
  'PC 1F',
  'PC 2F',
  'Warehouse 1F',
  'Warehouse 2F'
];

const POSITION_OPTIONS: PositionType[] = [
  'Engineer_E',
  'Engineer_N',
  'Foreman_E',
  'Foreman_N',
  'Safety Officer_E',
  'Safety Officer_N',
  'Sr. Staff_E',
  'Sr. Staff_N',
  'Sr. Supervisor',
  'Sr. Trainer_E',
  'Sr. Trainer_N',
  'Staff_E',
  'Staff_N',
  'Supervisor',
  'Technical Foreman',
  'Trainer_E',
  'Trainer_N'
];

const ALL_ROLES: UserRole[] = ['User', 'QC Hold', 'QM', 'QA', 'Admin', 'Sysadmin'];

export const UserRegistryView: React.FC<UserRegistryViewProps> = ({
  currentUser,
  onRefreshData,
  onSwitchUser
}) => {
  const [users, setUsers] = useState<UserProfile[]>(storageService.getUsers());
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('All');
  const [departmentFilter, setDepartmentFilter] = useState<string>('All');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [isUserModalOpen, setIsUserModalOpen] = useState<boolean>(false);

  // Form State matching explicit user specification
  const [idNumber, setIdNumber] = useState(`JAE-${Math.floor(10000 + Math.random() * 90000)}`);
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [factory, setFactory] = useState<FactoryType>('First Factory');
  const [employmentStatus, setEmploymentStatus] = useState<EmploymentStatus>('JAE-Reg.');
  const [department, setDepartment] = useState<DepartmentType>('Assembly');
  const [section, setSection] = useState<SectionType>('Mfg. Connector');
  const [position, setPosition] = useState<PositionType>('Staff_E');
  const [username, setUsername] = useState('');
  const [initialPassword, setInitialPassword] = useState('123456');
  const [role, setRole] = useState<UserRole>('User');
  const [email, setEmail] = useState('');

  // Password Reset Modal State
  const [resetModalUser, setResetModalUser] = useState<UserProfile | null>(null);
  const [adminNewPassword, setAdminNewPassword] = useState('');
  const [resetStatus, setResetStatus] = useState<string | null>(null);

  // Granular Section Permissions Modal State (Request #3)
  const [permissionModalUser, setPermissionModalUser] = useState<UserProfile | null>(null);
  const [allowedSections, setAllowedSections] = useState<SectionType[]>([]);
  const [allowedActions, setAllowedActions] = useState<UserActionPermission[]>(['view', 'entry', 'request', 'display']);
  const [permissionModalSuccess, setPermissionModalSuccess] = useState<string | null>(null);

  const ALL_ACTIONS: { id: UserActionPermission; label: string; desc: string; color: string }[] = [
    { id: 'view', label: 'View / Read', desc: 'Browse sample boxes, masterlists, inspection logs, and schedules', color: 'text-sky-400 bg-sky-950/60 border-sky-600' },
    { id: 'entry', label: 'Entry / Registration', desc: 'Register new boxes, scan incoming samples, and create RSIS records', color: 'text-emerald-400 bg-emerald-950/60 border-emerald-600' },
    { id: 'request', label: 'Request / Borrow', desc: 'File Keep Sample borrow requests & RS/IS sample requisition forms', color: 'text-pink-400 bg-pink-950/60 border-pink-600' },
    { id: 'update', label: 'Update / Disposition', desc: 'Endorse requests, update QC statuses, and change QA disposition stages', color: 'text-purple-400 bg-purple-950/60 border-purple-600' },
    { id: 'edit', label: 'Edit / Modify', desc: 'Modify existing box metadata, item remarks, and cavity specifications', color: 'text-amber-400 bg-amber-950/60 border-amber-600' },
    { id: 'lock', label: 'Lock / Close Boxes', desc: 'Seal completed boxes and lock records from unauthorized modification', color: 'text-rose-400 bg-rose-950/60 border-rose-600' },
    { id: 'display', label: 'Display / Monitor', desc: 'View digital production dashboards, real-time board, and live trends', color: 'text-teal-400 bg-teal-950/60 border-teal-600' },
    { id: 'export', label: 'Export & PDF Reports', desc: 'Generate printable PDF routing sheets, borrow slips, and CSV datasets', color: 'text-indigo-400 bg-indigo-950/60 border-indigo-600' },
    { id: 'delete', label: 'Delete Records', desc: 'Permanently remove draft samples or obsolete box registrations', color: 'text-red-400 bg-red-950/60 border-red-600' }
  ];

  const handleOpenPermissionsModal = (u: UserProfile) => {
    setPermissionModalUser(u);
    // Initialize with existing allowedSections or default to user's home section
    const userSections: SectionType[] = u.allowedSections && u.allowedSections.length > 0 
      ? u.allowedSections 
      : [u.section];
    setAllowedSections(userSections);

    // Initialize with existing allowedActions or derive smart defaults from role
    const defaultActions: UserActionPermission[] = u.allowedActions && u.allowedActions.length > 0
      ? u.allowedActions
      : u.role === 'Sysadmin' || u.role === 'Admin'
      ? ['view', 'entry', 'request', 'update', 'edit', 'lock', 'display', 'export', 'delete']
      : u.role === 'QM' || u.role === 'QA'
      ? ['view', 'entry', 'request', 'update', 'edit', 'lock', 'display', 'export']
      : u.role === 'QC Hold'
      ? ['view', 'entry', 'request', 'update', 'lock', 'display', 'export']
      : ['view', 'request', 'display'];
    
    setAllowedActions(defaultActions);
    setPermissionModalSuccess(null);
  };

  const handleSaveUserPermissions = () => {
    if (!permissionModalUser) return;
    if (!canManageUsers) {
      alert('Access Denied: Only Admin or Sysadmin can configure user section permissions.');
      return;
    }

    try {
      const updatedUser: UserProfile = {
        ...permissionModalUser,
        allowedSections,
        allowedActions,
        permissions: allowedActions.map(a => `section_${a}`)
      };

      storageService.saveUser(updatedUser);
      setUsers(storageService.getUsers());
      onRefreshData();
      setPermissionModalSuccess(`Section access & actions updated for ${permissionModalUser.firstName} ${permissionModalUser.lastName}!`);
      setTimeout(() => {
        setPermissionModalUser(null);
      }, 1200);
    } catch (err: any) {
      alert(`Failed to save permissions: ${err.message}`);
    }
  };

  // Validation States
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  // RBAC Permission Checks
  const isSysadmin = currentUser.role === 'Sysadmin';
  const isAdmin = currentUser.role === 'Admin';
  const canManageUsers = isSysadmin || isAdmin;

  // Roles available for assignment based on current user's role hierarchy
  const availableRolesToAssign: UserRole[] = isSysadmin
    ? ALL_ROLES
    : isAdmin
    ? ['User', 'QC Hold', 'QM', 'QA', 'Admin']
    : [];

  const handleSelectUser = (u: UserProfile) => {
    setSelectedUserId(u.id);
    setIdNumber(u.idNumber || u.employeeId || '');
    setFirstName(u.firstName || '');
    setMiddleName(u.middleName || '');
    setLastName(u.lastName || '');
    setFactory(u.factory || 'First Factory');
    setEmploymentStatus(u.employmentStatus || 'JAE-Reg.');
    setDepartment(u.department || 'Assembly');
    setSection(u.section || 'Mfg. Connector');
    setPosition(u.position || 'Staff_E');
    setUsername(u.username || '');
    setRole(u.role || 'User');
    setEmail(u.email || '');
    setFormError(null);
    setFormSuccess(null);
  };

  const handleResetForm = () => {
    setSelectedUserId(null);
    setIdNumber(`JAE-${Math.floor(10000 + Math.random() * 90000)}`);
    setFirstName('');
    setMiddleName('');
    setLastName('');
    setFactory('First Factory');
    setEmploymentStatus('JAE-Reg.');
    setDepartment('Assembly');
    setSection('Mfg. Connector');
    setPosition('Staff_E');
    setUsername('');
    setInitialPassword('123456');
    setRole('User');
    setEmail('');
    setFormError(null);
    setFormSuccess(null);
  };

  // Auto-generate email & username proposal when name changes
  const handleNameChange = (first: string, last: string) => {
    setFirstName(first);
    setLastName(last);
    if (!selectedUserId && first.trim() && last.trim()) {
      const cleanFirst = first.toLowerCase().replace(/[^a-z0-9]/g, '');
      const cleanLast = last.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!username) {
        setUsername(`${cleanFirst}_${cleanLast}`);
      }
      if (!email) {
        setEmail(`${cleanFirst}.${cleanLast}@jae.com.ph`);
      }
    }
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(null);

    // 1. Permission Check
    if (!canManageUsers) {
      setFormError('Access Denied: Only Admin or Sysadmin can create or update user accounts.');
      return;
    }

    // 2. Validate Required Fields
    if (!idNumber.trim() || !firstName.trim() || !lastName.trim()) {
      setFormError('Please provide ID Number, First Name, and Last Name.');
      return;
    }

    // 3. Username Validation: Must be unique
    const trimmedUsername = username.trim().toLowerCase();
    if (!trimmedUsername) {
      setFormError('Username is required.');
      return;
    }

    const existingUsername = users.find(
      (u) => (u.username || '').toLowerCase() === trimmedUsername && u.id !== selectedUserId
    );
    if (existingUsername) {
      setFormError(`Username "${username}" is already taken. Username must be unique across all personnel.`);
      return;
    }

    // 4. Initial Password Validation (For new user creation)
    if (!selectedUserId) {
      const trimmedPassword = initialPassword.trim();
      if (!trimmedPassword || trimmedPassword.length < 6) {
        setFormError('Initial temporary password must be at least 6 characters.');
        return;
      }
    }

    // 5. Admin cannot assign or edit Sysadmin
    if (isAdmin && !isSysadmin) {
      if (role === 'Sysadmin') {
        setFormError('Admin accounts cannot assign the "Sysadmin" role. Only Sysadmin can manage Sysadmin roles.');
        return;
      }
      if (selectedUserId) {
        const target = users.find((u) => u.id === selectedUserId);
        if (target && target.role === 'Sysadmin') {
          setFormError('Admin accounts cannot modify Sysadmin accounts.');
          return;
        }
      }
    }

    try {
      const saved = storageService.saveUser({
        id: selectedUserId || undefined,
        idNumber: idNumber.trim(),
        employeeId: idNumber.trim(),
        firstName: firstName.trim(),
        middleName: middleName.trim(),
        lastName: lastName.trim(),
        factory,
        employmentStatus,
        department,
        section,
        position,
        username: trimmedUsername,
        role,
        email: email.trim() || `${trimmedUsername}@jae.com.ph`,
        isActive: true,
        status: 'Active'
      });

      const updatedList = storageService.getUsers();
      setUsers(updatedList);
      onRefreshData();
      setFormSuccess(`User profile for ${saved.firstName} ${saved.lastName} (${saved.role}) successfully ${selectedUserId ? 'updated' : 'registered'}!`);
      
      if (!selectedUserId) {
        handleResetForm();
      }
    } catch (err: any) {
      setFormError(`Failed to save user: ${err.message}`);
    }
  };

  const handleDeleteUser = (u: UserProfile) => {
    if (!canManageUsers) {
      alert('Access Denied: Only Admin or Sysadmin can delete user accounts.');
      return;
    }

    if (u.id === currentUser.id) {
      alert('You cannot delete your own currently active user account.');
      return;
    }

    if (isAdmin && !isSysadmin && u.role === 'Sysadmin') {
      alert('Admins cannot delete Sysadmin accounts.');
      return;
    }

    const confirmMsg = `Are you sure you want to permanently delete user account: ${u.firstName} ${u.lastName} (${u.username || u.idNumber})?`;
    if (window.confirm(confirmMsg)) {
      try {
        storageService.deleteUser(u.id);
        setUsers(storageService.getUsers());
        onRefreshData();
        if (selectedUserId === u.id) {
          handleResetForm();
        }
        setFormSuccess(`User ${u.firstName} ${u.lastName} deleted successfully.`);
      } catch (err: any) {
        alert(`Error deleting user: ${err.message}`);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'ID Number',
      'First Name',
      'Middle Name',
      'Last Name',
      'Factory',
      'Employment Status',
      'Department',
      'Section',
      'Position',
      'Username',
      'Role',
      'Email',
      'Status'
    ];

    const rows = users.map((u) => [
      `"${u.idNumber || u.employeeId || ''}"`,
      `"${u.firstName || ''}"`,
      `"${u.middleName || ''}"`,
      `"${u.lastName || ''}"`,
      `"${u.factory || ''}"`,
      `"${u.employmentStatus || ''}"`,
      `"${u.department || ''}"`,
      `"${u.section || ''}"`,
      `"${u.position || ''}"`,
      `"${u.username || ''}"`,
      `"${u.role || ''}"`,
      `"${u.email || ''}"`,
      `"${u.isActive ? 'Active' : 'Inactive'}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `JAE_iSMS_User_Registry_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredUsers = users.filter((u) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      (u.idNumber || '').toLowerCase().includes(q) ||
      `${u.firstName} ${u.lastName}`.toLowerCase().includes(q) ||
      (u.username || '').toLowerCase().includes(q) ||
      (u.section || '').toLowerCase().includes(q) ||
      (u.position || '').toLowerCase().includes(q) ||
      (u.email || '').toLowerCase().includes(q);

    const matchesRole = roleFilter === 'All' || u.role === roleFilter;
    const matchesDept = departmentFilter === 'All' || u.department === departmentFilter;
    return matchesSearch && matchesRole && matchesDept;
  });

  return (
    <div id="user-registry-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette, compact 3/4 layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <Users className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                User Registry & Role Management
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                iSMS RBAC
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2 w-full md:w-auto justify-end">
          <button
            onClick={handleExportCSV}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold border border-slate-700 flex items-center space-x-1.5 shadow-sm transition-colors cursor-pointer"
            title="Export Personnel to CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => {
              handleResetForm();
              setIsUserModalOpen(true);
            }}
            className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow flex items-center space-x-1.5 transition-all cursor-pointer"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>+ Register User</span>
          </button>
        </div>
      </div>

      {/* ROLE PERMISSION HIERARCHY MATRIX CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
        
        {/* Sysadmin */}
        <div className={`p-3 rounded-xl border shadow-sm space-y-1.5 ${currentUser.role === 'Sysadmin' ? 'bg-amber-950/80 border-amber-500 ring-1 ring-amber-400' : 'bg-[#1A1A1A] border-emerald-800/40'}`}>
          <div className="flex items-center justify-between">
            <span className="font-bold text-[11px] text-amber-300 uppercase font-['Chakra_Petch'] flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Sysadmin</span>
            </span>
            <span className="text-[9px] bg-amber-900/80 text-amber-200 border border-amber-600/50 px-1.5 py-0.5 rounded font-extrabold">
              Root
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-snug">
            Full system control. Manages Admin roles, database configs, and role assignments.
          </p>
        </div>

        {/* Admin */}
        <div className={`p-3 rounded-xl border shadow-sm space-y-1.5 ${currentUser.role === 'Admin' ? 'bg-emerald-950/80 border-emerald-500 ring-1 ring-emerald-400' : 'bg-[#1A1A1A] border-emerald-800/40'}`}>
          <div className="flex items-center justify-between">
            <span className="font-bold text-[11px] text-emerald-300 uppercase font-['Chakra_Petch'] flex items-center space-x-1">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Admin</span>
            </span>
            <span className="text-[9px] bg-emerald-900/80 text-emerald-200 border border-emerald-600/50 px-1.5 py-0.5 rounded font-bold">
              Dept Admin
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-snug">
            Manages user role assignments (User, QC Hold, QM, QA, Admin). Full sample approvals.
          </p>
        </div>

        {/* QM */}
        <div className={`p-3 rounded-xl border shadow-sm space-y-1.5 ${currentUser.role === 'QM' ? 'bg-cyan-950/80 border-cyan-500 ring-1 ring-cyan-400' : 'bg-[#1A1A1A] border-emerald-800/40'}`}>
          <div className="flex items-center justify-between">
            <span className="font-bold text-[11px] text-cyan-300 uppercase font-['Chakra_Petch'] flex items-center space-x-1">
              <Building className="w-3.5 h-3.5 text-cyan-400" />
              <span>QM</span>
            </span>
            <span className="text-[9px] bg-cyan-900/80 text-cyan-200 border border-cyan-600/50 px-1.5 py-0.5 rounded font-bold">
              Quality Mgmt
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-snug">
            Keep Sample & RS/IS categorization, endorsement to QA, golden master retention.
          </p>
        </div>

        {/* QA */}
        <div className={`p-3 rounded-xl border shadow-sm space-y-1.5 ${currentUser.role === 'QA' ? 'bg-purple-950/80 border-purple-500 ring-1 ring-purple-400' : 'bg-[#1A1A1A] border-emerald-800/40'}`}>
          <div className="flex items-center justify-between">
            <span className="font-bold text-[11px] text-purple-300 uppercase font-['Chakra_Petch'] flex items-center space-x-1">
              <KeyRound className="w-3.5 h-3.5 text-purple-400" />
              <span>QA</span>
            </span>
            <span className="text-[9px] bg-purple-900/80 text-purple-200 border border-purple-600/50 px-1.5 py-0.5 rounded font-bold">
              Engineering
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-snug">
            Defect investigation, 8D failure findings, QA disposition status update and closure.
          </p>
        </div>

        {/* QC Hold */}
        <div className={`p-3 rounded-xl border shadow-sm space-y-1.5 ${currentUser.role === 'QC Hold' ? 'bg-pink-950/80 border-pink-500 ring-1 ring-pink-400' : 'bg-[#1A1A1A] border-emerald-800/40'}`}>
          <div className="flex items-center justify-between">
            <span className="font-bold text-[11px] text-pink-300 uppercase font-['Chakra_Petch'] flex items-center space-x-1">
              <Lock className="w-3.5 h-3.5 text-pink-400" />
              <span>QC Hold</span>
            </span>
            <span className="text-[9px] bg-pink-900/80 text-pink-200 border border-pink-600/50 px-1.5 py-0.5 rounded font-bold">
              Intake
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-snug">
            Sample intake verification, "No Received Sample" trigger, physical lot handover.
          </p>
        </div>

        {/* User / Requestor */}
        <div className={`p-3 rounded-xl border shadow-sm space-y-1.5 ${currentUser.role === 'User' ? 'bg-slate-800/90 border-slate-500 ring-1 ring-slate-400' : 'bg-[#1A1A1A] border-emerald-800/40'}`}>
          <div className="flex items-center justify-between">
            <span className="font-bold text-[11px] text-slate-200 uppercase font-['Chakra_Petch'] flex items-center space-x-1">
              <Users className="w-3.5 h-3.5 text-slate-400" />
              <span>User</span>
            </span>
            <span className="text-[9px] bg-slate-800 text-slate-300 border border-slate-700 px-1.5 py-0.5 rounded font-bold">
              Mfg Line
            </span>
          </div>
          <p className="text-[10px] text-slate-400 leading-snug">
            Creates Keep Sample borrowing requests, encodes reject RS/IS samples.
          </p>
        </div>

      </div>

      {/* REGISTERED USERS DATABASE TABLE */}
      <div className="bg-[#141414] rounded-2xl shadow-xl border-2 border-emerald-800/80 overflow-hidden">
        <div className="p-4 border-b border-emerald-800/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-gradient-to-r from-[#18231c] via-[#141a16] to-[#121212]">
          <div className="flex items-center space-x-2">
            <span className="text-pink-400 font-bold text-sm tracking-wider uppercase font-['Chakra_Petch']">REGISTERED PERSONNEL DIRECTORY</span>
            <span className="text-xs text-emerald-400 font-mono">({filteredUsers.length} Users Found)</span>
            <span className="hidden md:inline text-[11px] text-slate-400 bg-black/40 px-2 py-0.5 rounded border border-emerald-800/50">
              💡 Double-click any row to edit user profile & role
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <div className="relative w-full sm:w-48">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search staff / ID / user..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1e1e1e] text-white border border-emerald-800/70 pl-8 pr-2 py-1.5 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-pink-500"
              />
            </div>

            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="bg-[#1e1e1e] text-white border border-emerald-800/70 px-2 py-1.5 rounded-lg text-xs focus:outline-none"
            >
              <option value="All">All Roles</option>
              {ALL_ROLES.map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>

            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="bg-[#1e1e1e] text-white border border-emerald-800/70 px-2 py-1.5 rounded-lg text-xs focus:outline-none"
            >
              <option value="All">All Depts</option>
              {DEPARTMENT_OPTIONS.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse isms-table">
            <thead>
              <tr className="bg-[#0b1912] text-white border-b border-emerald-800/80 font-bold uppercase text-[11px] tracking-wider">
                <th className="p-3 border-r border-emerald-800/60">ID NUMBER</th>
                <th className="p-3 border-r border-emerald-800/60">NAME (REQUESTOR)</th>
                <th className="p-3 border-r border-emerald-800/60">USERNAME</th>
                <th className="p-3 border-r border-emerald-800/60">ROLE</th>
                <th className="p-3 border-r border-emerald-800/60">FACTORY</th>
                <th className="p-3 border-r border-emerald-800/60">STATUS</th>
                <th className="p-3 border-r border-emerald-800/60">DEPARTMENT</th>
                <th className="p-3 border-r border-emerald-800/60">SECTION</th>
                <th className="p-3 border-r border-emerald-800/60">POSITION</th>
                <th className="p-3 text-center">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-emerald-900/40 bg-[#161616] text-slate-200 font-mono">
              {filteredUsers.map((u) => {
                const isSelected = selectedUserId === u.id;
                const isCurrent = currentUser.id === u.id;

                return (
                  <tr
                    key={u.id}
                    onClick={() => handleSelectUser(u)}
                    onDoubleClick={() => {
                      handleSelectUser(u);
                      setIsUserModalOpen(true);
                    }}
                    className={`hover:bg-pink-950/30 cursor-pointer transition-colors border-b border-emerald-900/40 ${
                      isSelected ? 'bg-pink-950/40 font-semibold' : ''
                    }`}
                  >
                    <td className="p-3 border-r border-emerald-900/40 font-mono font-bold text-pink-400 whitespace-nowrap">
                      {u.idNumber || u.employeeId}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 font-semibold text-white whitespace-nowrap">
                      {u.firstName} {u.middleName ? `${u.middleName} ` : ''}{u.lastName}
                      {isCurrent && (
                        <span className="ml-1.5 text-[9px] bg-emerald-950 text-emerald-300 px-1.5 py-0.5 rounded font-extrabold border border-emerald-500">
                          CURRENT
                        </span>
                      )}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 font-mono text-slate-300 whitespace-nowrap">
                      @{u.username || 'user'}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        u.role === 'Sysadmin'
                          ? 'bg-amber-950 text-amber-300 border border-amber-600/50'
                          : u.role === 'Admin'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-600/50'
                          : u.role === 'QM'
                          ? 'bg-cyan-950 text-cyan-300 border border-cyan-600/50'
                          : u.role === 'QA'
                          ? 'bg-purple-950 text-purple-300 border border-purple-600/50'
                          : u.role === 'QC Hold'
                          ? 'bg-pink-950 text-pink-300 border border-pink-600/50'
                          : 'bg-slate-800 text-slate-300 border border-slate-700/50'
                      }`}>
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 text-slate-300 whitespace-nowrap">
                      {u.factory === 'First Factory' ? '1F (Plant 1)' : '2F (Plant 2)'}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 text-slate-300 whitespace-nowrap font-medium">
                      {u.employmentStatus || 'JAE-Reg.'}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 text-slate-300 whitespace-nowrap">
                      {u.department}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 text-slate-300 whitespace-nowrap max-w-[180px] truncate" title={u.section}>
                      {u.section}
                    </td>
                    <td className="p-3 border-r border-emerald-900/40 text-slate-300 whitespace-nowrap">
                      {u.position || 'Staff_E'}
                    </td>
                    <td className="p-3 text-center whitespace-nowrap space-x-1.5">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSwitchUser(u);
                        }}
                        className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg text-[10px] font-bold shadow-xs transition-colors cursor-pointer"
                        title="Switch active logged-in session to this user"
                      >
                        Login As
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenPermissionsModal(u);
                        }}
                        className="px-2 py-1 bg-gradient-to-r from-pink-900/60 to-rose-900/60 hover:from-pink-800 hover:to-rose-800 text-pink-200 rounded-lg text-[10px] font-bold border border-pink-700/60 shadow-xs transition-all cursor-pointer inline-flex items-center gap-1"
                        title="Configure Allowed Sections & Action Permissions (View, Edit, Update, Entry, Request, Lock, Display)"
                      >
                        <Shield className="w-3 h-3 text-pink-400" />
                        <span>Permissions</span>
                      </button>

                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectUser(u);
                          setIsUserModalOpen(true);
                        }}
                        className="px-2 py-1 bg-slate-800 hover:bg-pink-900/60 text-slate-200 hover:text-pink-300 rounded-lg text-[10px] font-bold border border-emerald-800/60 transition-colors cursor-pointer"
                        title="Edit user details"
                      >
                        Edit
                      </button>

                      {canManageUsers && !isCurrent && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteUser(u);
                          }}
                          className="px-2 py-1 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-lg text-[10px] font-bold border border-rose-800/60 transition-colors cursor-pointer"
                          title="Delete user profile"
                        >
                          <Trash2 className="w-3 h-3 inline" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
              {filteredUsers.length === 0 && (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400">
                    No personnel profiles match the search query.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* USER REGISTRATION & PROFILE EDIT MODAL */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in">
          <div className="relative w-full max-w-2xl bg-[#141414] border-2 border-emerald-600 rounded-2xl shadow-2xl overflow-hidden my-8 text-white">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#121212] px-5 py-4 border-b border-emerald-700/60 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40">
                  {selectedUserId ? <Edit2 className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-base md:text-lg font-bold font-['Chakra_Petch'] uppercase tracking-wider text-white">
                    {selectedUserId ? 'Edit Personnel Profile' : 'Register New Personnel'}
                  </h3>
                  <p className="text-xs text-emerald-300/80">
                    {selectedUserId ? `Update profile and RBAC role for ${firstName} ${lastName}` : 'Configure personnel ID, section, role assignment, and credentials'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsUserModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form Content */}
            <form onSubmit={handleSaveUser} className="p-5 md:p-6 space-y-4 max-h-[calc(85vh-120px)] overflow-y-auto">
              {formError && (
                <div className="p-3 bg-rose-950/80 border border-rose-600 rounded-xl text-rose-200 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{formError}</span>
                </div>
              )}

              {formSuccess && (
                <div className="p-3 bg-emerald-950/80 border border-emerald-600 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{formSuccess}</span>
                </div>
              )}

              {/* Row 1: ID Number & Employment */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    ID NUMBER <span className="text-pink-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    required
                    placeholder="e.g. JAE-10294"
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    FACTORY LOCATION
                  </label>
                  <select
                    value={factory}
                    onChange={(e) => setFactory(e.target.value as FactoryType)}
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    {FACTORY_OPTIONS.map((f) => (
                      <option key={f} value={f}>{f === 'First Factory' ? 'First Factory (Plant 1)' : 'Second Factory (Plant 2)'}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    EMPLOYMENT STATUS
                  </label>
                  <select
                    value={employmentStatus}
                    onChange={(e) => setEmploymentStatus(e.target.value as EmploymentStatus)}
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    {EMPLOYMENT_STATUS_OPTIONS.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 2: Names */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    FIRST NAME <span className="text-pink-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => handleNameChange(e.target.value, lastName)}
                    required
                    placeholder="e.g. Maria"
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    MIDDLE NAME
                  </label>
                  <input
                    type="text"
                    value={middleName}
                    onChange={(e) => setMiddleName(e.target.value)}
                    placeholder="e.g. Santos"
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    LAST NAME <span className="text-pink-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => handleNameChange(firstName, e.target.value)}
                    required
                    placeholder="e.g. Reyes"
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Row 3: Department, Section & Position */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    DEPARTMENT <span className="text-pink-400">*</span>
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value as DepartmentType)}
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    {DEPARTMENT_OPTIONS.map((d) => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    SECTION <span className="text-pink-400">*</span>
                  </label>
                  <select
                    value={section}
                    onChange={(e) => setSection(e.target.value as SectionType)}
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    {SECTION_OPTIONS.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    POSITION
                  </label>
                  <select
                    value={position}
                    onChange={(e) => setPosition(e.target.value as PositionType)}
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    {POSITION_OPTIONS.map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 4: Account & RBAC Role */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    USERNAME <span className="text-pink-400">*</span>
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2 text-slate-400 text-xs font-mono">@</span>
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      required
                      placeholder="username"
                      className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg pl-7 pr-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    EMAIL ADDRESS
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@jae.com.ph"
                    className="w-full bg-[#1e1e1e] border border-emerald-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                    ROLE ASSIGNMENT <span className="text-pink-400">*</span>
                  </label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full bg-[#1e1e1e] border-2 border-pink-600/80 rounded-lg px-3 py-2 text-xs font-bold text-pink-300 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    {ALL_ROLES.map((r) => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Initial Password / Password Reset */}
              <div className="p-3.5 bg-[#18231c] border border-emerald-700/60 rounded-xl space-y-2">
                {!selectedUserId ? (
                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-pink-400" />
                      INITIAL TEMPORARY PASSWORD (MIN 6 CHARS) <span className="text-pink-400">*</span>
                    </label>
                    <input
                      type="password"
                      value={initialPassword}
                      onChange={(e) => setInitialPassword(e.target.value)}
                      placeholder="Enter temporary password"
                      className="w-full sm:w-1/2 bg-[#121212] border border-emerald-700/80 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                    <p className="text-[10px] text-slate-400 mt-1">
                      User will be required to change this temporary password upon first login.
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <KeyRound className="w-4 h-4 text-amber-400" />
                        <span>Security Credentials & Password</span>
                      </div>
                      <p className="text-[11px] text-slate-400">
                        Password is securely hashed. Admins can trigger a temporary reset.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const targetUser = users.find(u => u.id === selectedUserId);
                        if (targetUser) {
                          setResetModalUser(targetUser);
                          setAdminNewPassword('123456');
                          setResetStatus(null);
                        }
                      }}
                      className="px-3 py-1.5 bg-amber-600/30 hover:bg-amber-600/50 text-amber-300 border border-amber-500/50 rounded-lg text-xs font-bold transition-colors cursor-pointer self-start sm:self-center"
                    >
                      Reset User Password
                    </button>
                  </div>
                )}
              </div>

              {/* Modal Footer Buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-emerald-800/60">
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                >
                  Clear / New
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsUserModalOpen(false)}
                    className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow flex items-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{selectedUserId ? 'Save Profile Changes' : 'Complete Registration'}</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Granular Section Access & Permissions Modal (Request #3) */}
      {permissionModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in">
          <div className="relative w-full max-w-3xl bg-[#141414] border-2 border-pink-600/80 rounded-2xl shadow-2xl overflow-hidden my-6 text-white">
            
            {/* Header */}
            <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#1a1018] px-5 py-4 border-b border-pink-700/60 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40">
                  <ShieldCheck className="w-5 h-5 text-pink-400" />
                </div>
                <div>
                  <h3 className="text-base md:text-lg font-bold font-['Chakra_Petch'] uppercase tracking-wider text-white flex items-center gap-2">
                    <span>Section Access & Action Permissions</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-pink-950 text-pink-300 border border-pink-600 font-mono">
                      {permissionModalUser.role}
                    </span>
                  </h3>
                  <p className="text-xs text-emerald-300">
                    Personnel: <strong>{permissionModalUser.firstName} {permissionModalUser.lastName}</strong> ({permissionModalUser.idNumber || permissionModalUser.employeeId}) • Section: <strong>{permissionModalUser.section}</strong>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPermissionModalUser(null)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 md:p-6 space-y-6 max-h-[calc(85vh-120px)] overflow-y-auto">
              
              {permissionModalSuccess && (
                <div className="p-3 bg-emerald-950/90 border border-emerald-500 rounded-xl text-emerald-200 text-xs flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{permissionModalSuccess}</span>
                </div>
              )}

              {/* Quick Preset Toolbar */}
              <div className="bg-[#1a1a1a] p-3.5 rounded-xl border border-emerald-800/40 space-y-2">
                <div className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider font-mono flex items-center justify-between">
                  <span>⚡ Quick Permission Presets</span>
                  <span className="text-slate-400 text-[10px] lowercase">click to apply predefined capability matrix</span>
                </div>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setAllowedSections(SECTION_OPTIONS);
                      setAllowedActions(['view', 'entry', 'request', 'update', 'edit', 'lock', 'display', 'export', 'delete']);
                    }}
                    className="px-2.5 py-1 bg-amber-950/80 hover:bg-amber-900 text-amber-200 border border-amber-600/60 rounded text-[11px] font-bold transition-colors cursor-pointer"
                  >
                    👑 Full Access (All Sections & Actions)
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAllowedSections([permissionModalUser.section]);
                      setAllowedActions(['view', 'entry', 'update', 'display']);
                    }}
                    className="px-2.5 py-1 bg-emerald-950/80 hover:bg-emerald-900 text-emerald-200 border border-emerald-600/60 rounded text-[11px] font-bold transition-colors cursor-pointer"
                  >
                    🔍 QC Inspector / Entry Preset
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAllowedSections([permissionModalUser.section]);
                      setAllowedActions(['view', 'request', 'display']);
                    }}
                    className="px-2.5 py-1 bg-pink-950/80 hover:bg-pink-900 text-pink-200 border border-pink-600/60 rounded text-[11px] font-bold transition-colors cursor-pointer"
                  >
                    📋 Production Requestor Preset
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAllowedSections(SECTION_OPTIONS);
                      setAllowedActions(['view', 'display', 'export']);
                    }}
                    className="px-2.5 py-1 bg-sky-950/80 hover:bg-sky-900 text-sky-200 border border-sky-600/60 rounded text-[11px] font-bold transition-colors cursor-pointer"
                  >
                    📊 Auditor / Monitor Only
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAllowedSections([permissionModalUser.section]);
                      setAllowedActions(['view']);
                    }}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded text-[11px] font-bold transition-colors cursor-pointer"
                  >
                    🔒 Read-Only Strict
                  </button>
                </div>
              </div>

              {/* 1. ALLOWED ACTIONS (View, Edit, Update, Entry, Request, Lock, Display, etc.) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-emerald-900/60 pb-2">
                  <div>
                    <h4 className="text-xs md:text-sm font-bold uppercase tracking-wider text-pink-300 font-['Chakra_Petch']">
                      1. Authorized Section Actions
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Grant fine-grained capabilities to this user (no need to create custom roles).
                    </p>
                  </div>
                  <div className="space-x-1.5 text-[10px]">
                    <button
                      type="button"
                      onClick={() => setAllowedActions(ALL_ACTIONS.map(a => a.id))}
                      className="px-2 py-0.5 bg-pink-900/40 hover:bg-pink-800 text-pink-200 rounded border border-pink-700 font-mono"
                    >
                      Select All
                    </button>
                    <button
                      type="button"
                      onClick={() => setAllowedActions([])}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 font-mono"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {ALL_ACTIONS.map((act) => {
                    const isChecked = allowedActions.includes(act.id);
                    return (
                      <div
                        key={act.id}
                        onClick={() => {
                          if (isChecked) {
                            setAllowedActions(allowedActions.filter(a => a !== act.id));
                          } else {
                            setAllowedActions([...allowedActions, act.id]);
                          }
                        }}
                        className={`p-2.5 rounded-xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                          isChecked
                            ? `${act.color} ring-1 ring-pink-500/50 shadow-md`
                            : 'bg-[#181818] border-slate-800 text-slate-400 hover:bg-[#202020]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-xs uppercase tracking-wide">
                            {act.label}
                          </span>
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="rounded text-pink-600 focus:ring-pink-500 w-4 h-4"
                          />
                        </div>
                        <p className="text-[10px] text-slate-400 mt-1 leading-snug">
                          {act.desc}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* 2. ALLOWED SECTION JURISDICTIONS */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-emerald-900/60 pb-2">
                  <div>
                    <h4 className="text-xs md:text-sm font-bold uppercase tracking-wider text-emerald-300 font-['Chakra_Petch']">
                      2. Allowed Section Jurisdictions
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      Specify which manufacturing and quality sections this personnel is permitted to operate within.
                    </p>
                  </div>
                  <div className="space-x-1.5 text-[10px]">
                    <button
                      type="button"
                      onClick={() => setAllowedSections(SECTION_OPTIONS)}
                      className="px-2 py-0.5 bg-emerald-900/40 hover:bg-emerald-800 text-emerald-200 rounded border border-emerald-700 font-mono"
                    >
                      All Sections
                    </button>
                    <button
                      type="button"
                      onClick={() => setAllowedSections([permissionModalUser.section])}
                      className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-slate-700 font-mono"
                    >
                      Home Section Only
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto p-1 bg-[#101010] rounded-xl border border-emerald-900/40">
                  {SECTION_OPTIONS.map((sec) => {
                    const isSecSelected = allowedSections.includes(sec);
                    const isHome = sec === permissionModalUser.section;
                    return (
                      <label
                        key={sec}
                        className={`flex items-center space-x-2 p-2 rounded-lg border text-xs cursor-pointer select-none transition-colors ${
                          isSecSelected
                            ? 'bg-emerald-950/80 border-emerald-500/80 text-emerald-100 font-semibold'
                            : 'bg-[#181818] border-slate-800 text-slate-400 hover:bg-[#202020]'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSecSelected}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setAllowedSections([...allowedSections, sec]);
                            } else {
                              setAllowedSections(allowedSections.filter(s => s !== sec));
                            }
                          }}
                          className="rounded text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
                        />
                        <span className="truncate text-[11px]" title={sec}>
                          {sec} {isHome && <span className="text-[9px] text-pink-400 font-bold font-mono">(Home)</span>}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3.5 bg-[#101010] border-t border-emerald-800/60 flex items-center justify-between">
              <div className="text-[11px] text-slate-400 font-mono">
                Active Sections: <span className="text-emerald-300 font-bold">{allowedSections.length}</span> • Actions: <span className="text-pink-300 font-bold">{allowedActions.length}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setPermissionModalUser(null)}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleSaveUserPermissions}
                  className="px-4 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow flex items-center space-x-1.5 transition-all cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save User Permissions</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Administrative Password Reset Modal */}
      {resetModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/60 rounded-2xl p-5 shadow-2xl text-white">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold uppercase font-['Chakra_Petch'] text-amber-300">
                  Reset Password: {resetModalUser.firstName} {resetModalUser.lastName}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setResetModalUser(null)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-3 text-xs">
              <p className="text-slate-300">
                User: <span className="text-white font-bold">{resetModalUser.username} ({resetModalUser.employeeId || resetModalUser.idNumber})</span>
              </p>
              <p className="text-slate-400 text-[11px]">
                Resetting the password will hash the new credential with BCrypt and flag the user account to rotate password upon their next login.
              </p>

              {resetStatus && (
                <div className="p-2.5 bg-emerald-950/80 border border-emerald-600 rounded text-emerald-300 font-semibold text-xs">
                  {resetStatus}
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-bold uppercase mb-1">
                  New Temporary Password (min 6 chars):
                </label>
                <input
                  type="password"
                  value={adminNewPassword}
                  onChange={(e) => setAdminNewPassword(e.target.value)}
                  placeholder="Enter new password (e.g. 123456)"
                  className="w-full bg-slate-800 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:border-amber-400 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setResetModalUser(null)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    if (!adminNewPassword || adminNewPassword.length < 6) {
                      alert('Password must be at least 6 characters.');
                      return;
                    }
                    try {
                      const res = await apiClient.resetUserPassword(resetModalUser.id, adminNewPassword);
                      if (res.ok) {
                        setResetStatus('Password successfully reset in SQL Server!');
                        setTimeout(() => {
                          setResetModalUser(null);
                        }, 1200);
                      } else {
                        alert(res.error || 'Failed to reset password');
                      }
                    } catch (e: any) {
                      setResetStatus('Password reset updated locally (offline fallback mode)');
                      setTimeout(() => {
                        setResetModalUser(null);
                      }, 1200);
                    }
                  }}
                  className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-slate-950 font-bold rounded text-xs uppercase"
                >
                  Confirm Reset
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
