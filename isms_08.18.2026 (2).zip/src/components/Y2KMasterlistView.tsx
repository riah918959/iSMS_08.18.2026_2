import React, { useState } from 'react';
import {
  MapPin,
  Search,
  Filter,
  Plus,
  Edit2,
  FileSpreadsheet,
  Layers,
  Save,
  CheckCircle,
  AlertTriangle,
  Archive,
  RefreshCw,
  Trash2,
  Lock,
  Printer,
  QrCode,
  Info,
  Building,
  ArrowLeft,
  Calendar,
  History,
  Package,
  ShieldCheck,
  CheckSquare
} from 'lucide-react';
import {
  Y2KSampleLocation,
  StorageAreaType,
  SectionType,
  ArchiveType,
  KeepSampleBoxStatus,
  UserProfile
} from '../types';
import { storageService, evaluateKeepSampleStatus } from '../services/storageService';
import { JAELogo } from './BrandingLogos';

interface Y2KMasterlistViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
}

type Y2KTab = 
  | 'LOCATION_ALLOCATION'
  | 'SHELF_CAPACITY'
  | 'QM_AUDIT'
  | 'AUDIT_TRAIL';

export const Y2KMasterlistView: React.FC<Y2KMasterlistViewProps> = ({
  currentUser,
  onRefreshData
}) => {
  const [locations, setLocations] = useState<Y2KSampleLocation[]>(storageService.getY2KLocations());
  const [isMultitabOpen, setIsMultitabOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<Y2KTab>('LOCATION_ALLOCATION');
  const [selectedLocationId, setSelectedLocationId] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAreaFilter, setSelectedAreaFilter] = useState<string>('All');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('All');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Form State
  const [rackLocation, setRackLocation] = useState<string>('RACK-1F-M05');
  const [boxNumber, setBoxNumber] = useState<string>('24-08-005-1F');
  const [storageArea, setStorageArea] = useState<StorageAreaType>('1F MEZZANINE');
  const [year, setYear] = useState<number>(new Date().getFullYear());
  const [section, setSection] = useState<SectionType>('MX CONNECTOR');
  const [item, setItem] = useState<string>('');
  const [archiveType, setArchiveType] = useState<ArchiveType>('KS');
  const [dateGenerated, setDateGenerated] = useState<string>(new Date().toISOString().split('T')[0]);
  const [expirationDate, setExpirationDate] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  // RBAC Permission Checks
  const isSysadmin = currentUser.role === 'Sysadmin';
  const isAdmin = currentUser.role === 'Admin';
  const isQM = currentUser.role === 'QM';
  const isQA = currentUser.role === 'QA';
  const canManageLocations = isSysadmin || isAdmin || isQM || isQA;

  const calculatedStatus: KeepSampleBoxStatus = evaluateKeepSampleStatus(
    Boolean(item && item.trim()),
    expirationDate
  );

  const sectionsList: SectionType[] = [
    'MX CONNECTOR',
    'MX HARNESS',
    'MX PRE ASSY',
    'MX57 MANUAL',
    'MX57 AUTO',
    'VARIOUS',
    'MX HONDA',
    'QM/IQC',
    'OQC',
    'QA/QC',
    'STAMPING',
    'MOLDING',
    'WAREHOUSE'
  ];

  const handleOpenNewLocation = () => {
    setSelectedLocationId(null);
    setRackLocation(`RACK-Y2K-${Math.floor(10 + Math.random() * 90)}`);
    setBoxNumber(`24-08-${Math.floor(100 + Math.random() * 900)}-2F`);
    setStorageArea('Y2K BUILDING');
    setYear(new Date().getFullYear());
    setSection(currentUser.section || 'MX CONNECTOR');
    setItem('');
    setArchiveType('KS');
    setDateGenerated(new Date().toISOString().split('T')[0]);
    setExpirationDate(new Date(Date.now() + 3 * 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
    setRemarks('');
    setActiveTab('LOCATION_ALLOCATION');
    setIsMultitabOpen(true);
    setFeedbackMsg({
      type: 'info',
      text: 'Assign location coordinates and verify shelf allocation.'
    });
  };

  const handleSelectLocationFromMasterlist = (loc: Y2KSampleLocation) => {
    setSelectedLocationId(loc.id);
    setRackLocation(loc.rackLocation);
    setBoxNumber(loc.boxNumber);
    setStorageArea(loc.storageArea);
    setYear(loc.year);
    setSection(loc.section);
    setItem(loc.item || '');
    setArchiveType(loc.archiveType);
    setDateGenerated(loc.dateGenerated);
    setExpirationDate(loc.expirationDate || '');
    setRemarks(loc.remarks || '');
    setActiveTab('LOCATION_ALLOCATION');
    setIsMultitabOpen(true);
  };

  const handleSaveLocation = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!canManageLocations) {
      setFeedbackMsg({
        type: 'error',
        text: `Permission Denied: User role "${currentUser.role}" cannot modify rack locations.`
      });
      return;
    }

    try {
      const saved = storageService.saveY2KLocation({
        id: selectedLocationId || undefined,
        rackLocation,
        boxNumber,
        storageArea,
        year,
        section,
        item,
        archiveType,
        dateGenerated,
        expirationDate,
        status: calculatedStatus,
        remarks
      });

      const updated = storageService.getY2KLocations();
      setLocations(updated);
      onRefreshData();
      setSelectedLocationId(saved.id);

      setFeedbackMsg({
        type: 'success',
        text: `Rack Location ${saved.rackLocation} successfully updated!`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed to save location: ${err.message}`
      });
    }
  };

  const handleDeleteLocation = (loc: Y2KSampleLocation) => {
    if (!isSysadmin && !isAdmin && !isQM) {
      alert('Access Denied: Only Admin, Sysadmin, or QM can delete Y2K Location records.');
      return;
    }

    if (window.confirm(`Delete Location ${loc.rackLocation} (${loc.boxNumber})?`)) {
      try {
        storageService.deleteY2KLocation(loc.id);
        setLocations(storageService.getY2KLocations());
        onRefreshData();
        if (selectedLocationId === loc.id) {
          setIsMultitabOpen(false);
        }
        setFeedbackMsg({
          type: 'success',
          text: `Location ${loc.rackLocation} deleted.`
        });
      } catch (err: any) {
        alert(`Error deleting location: ${err.message}`);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Rack Location',
      'Box Number',
      'Storage Area',
      'Year',
      'Section',
      'Item Description',
      'Archive Type',
      'Date Generated',
      'Expiration Date',
      'Status',
      'Remarks'
    ];

    const rows = locations.map((loc) => [
      `"${loc.rackLocation}"`,
      `"${loc.boxNumber}"`,
      `"${loc.storageArea}"`,
      `"${loc.year}"`,
      `"${loc.section}"`,
      `"${loc.item || ''}"`,
      `"${loc.archiveType}"`,
      `"${loc.dateGenerated}"`,
      `"${loc.expirationDate || ''}"`,
      `"${loc.status}"`,
      `"${loc.remarks || ''}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `JAE_Y2K_Sample_Locations_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredLocations = locations.filter((loc) => {
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (loc.rackLocation || '').toLowerCase().includes(q) ||
      (loc.boxNumber || '').toLowerCase().includes(q) ||
      (loc.item && loc.item.toLowerCase().includes(q)) ||
      (loc.section || '').toLowerCase().includes(q);

    const matchesArea = selectedAreaFilter === 'All' || loc.storageArea === selectedAreaFilter;
    const matchesStatus = selectedStatusFilter === 'All' || loc.status === selectedStatusFilter;

    return matchesSearch && matchesArea && matchesStatus;
  });

  const getStatusBadge = (status: KeepSampleBoxStatus) => {
    switch (status) {
      case 'NOT YET EXPIRED':
        return <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded text-[11px] font-bold">NOT YET EXPIRED</span>;
      case 'EXPIRED':
        return <span className="bg-rose-100 text-rose-800 border border-rose-300 px-2 py-0.5 rounded text-[11px] font-bold">EXPIRED</span>;
      case 'FOR CHECKING':
        return <span className="bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded text-[11px] font-bold">FOR CHECKING</span>;
      case 'AVAILABLE SPACE':
        return <span className="bg-blue-100 text-blue-800 border border-blue-300 px-2 py-0.5 rounded text-[11px] font-bold">AVAILABLE SPACE</span>;
    }
  };

  return (
    <div id="y2k-masterlist-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette, compact 3/4 layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <MapPin className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                Y2K Location Masterlist
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                PHYSICAL RACK COORDINATES
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 w-full md:w-auto justify-start md:justify-end">
          {isMultitabOpen ? (
            <button
              onClick={() => setIsMultitabOpen(false)}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5 shadow-sm transition-all"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Masterlist</span>
            </button>
          ) : (
            <>
              <button
                onClick={handleExportCSV}
                className="px-3 py-1.5 bg-slate-900/80 hover:bg-slate-800 text-emerald-300 rounded-lg text-xs font-bold border border-emerald-700/50 flex items-center space-x-1.5 shadow-xs transition-colors"
                title="Export Location Masterlist to CSV"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>

              <button
                id="btn-new-y2k-location"
                onClick={handleOpenNewLocation}
                className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-sm flex items-center space-x-1.5 transition-all transform active:scale-98"
                title="Register a new Location Allocation"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ New Location Allocation</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-xs ${
          feedbackMsg.type === 'success'
            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
            : feedbackMsg.type === 'error'
            ? 'bg-rose-50 border-rose-300 text-rose-800'
            : 'bg-blue-50 border-blue-300 text-blue-800'
        }`}>
          <div className="flex items-center space-x-2">
            {feedbackMsg.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />}
            {feedbackMsg.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />}
            {feedbackMsg.type === 'info' && <Info className="w-4 h-4 text-blue-600 shrink-0" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-[11px] underline ml-2 opacity-80 hover:opacity-100"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. MASTERLIST VIEW */}
      {/* ========================================================================= */}
      {!isMultitabOpen ? (
        <div className="space-y-4 animate-in fade-in duration-200">
          
          {/* Top KPIs / Metric Cubes with Vibrant Colored Top Strips */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Cube 1: Total Rack Slots (Emerald/Green Theme) */}
            <div className="bg-white rounded-xl border border-emerald-500/50 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-emerald-600 to-green-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">TOTAL RACK SLOTS</span>
                <MapPin className="w-3.5 h-3.5 text-emerald-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-emerald-950">{locations.length}</div>
                <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg border border-emerald-200">
                  <MapPin className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 2: 1F Mezzanine (Teal Theme) */}
            <div className="bg-white rounded-xl border border-teal-400/50 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-teal-600 to-emerald-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">1F MEZZANINE</span>
                <Building className="w-3.5 h-3.5 text-teal-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-teal-700">
                  {locations.filter(l => l.storageArea === '1F MEZZANINE').length}
                </div>
                <div className="p-2 bg-teal-50 text-teal-600 rounded-lg border border-teal-200">
                  <Building className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 3: F2B Storage (Blue Theme) */}
            <div className="bg-white rounded-xl border border-blue-400/50 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">F2B STORAGE</span>
                <Archive className="w-3.5 h-3.5 text-blue-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-blue-700">
                  {locations.filter(l => l.storageArea === 'F2B STORAGE').length}
                </div>
                <div className="p-2 bg-blue-50 text-blue-600 rounded-lg border border-blue-200">
                  <Archive className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 4: Y2K Vault (Purple Theme) */}
            <div className="bg-white rounded-xl border border-purple-400/50 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">Y2K VAULT</span>
                <Layers className="w-3.5 h-3.5 text-purple-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-purple-700">
                  {locations.filter(l => l.storageArea === 'Y2K BUILDING').length}
                </div>
                <div className="p-2 bg-purple-50 text-purple-600 rounded-lg border border-purple-200">
                  <Layers className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

          {/* Masterlist Container with High-Contrast Dark-Green Header */}
          <div className="bg-[#121815] rounded-xl shadow-lg border border-emerald-700/60 overflow-hidden">
            <div className="px-4 py-2.5 border-b border-emerald-700/60 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-gradient-to-r from-[#064e3b] via-[#095742] to-[#043d2e]">
              <div>
                <h2 className="text-sm md:text-base font-bold text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-pink-300" />
                  <span className="text-white">REGISTERED Y2K SAMPLE LOCATIONS</span>
                </h2>
                {/* <p className="text-[11px] text-emerald-100 font-medium mt-0.5">
                  <span className="font-bold text-pink-300">💡 Tip:</span> Click status badges to quick-update, or double-click row to open location details workspace.
                </p> */}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-[190px]">
                  <Search className="w-3.5 h-3.5 text-emerald-300 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search rack, box, part..."
                    className="w-full bg-[#0a2820] border border-emerald-500/70 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-emerald-200/60 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <select
                  value={selectedAreaFilter}
                  onChange={(e) => setSelectedAreaFilter(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Storage Areas</option>
                  <option value="1F MEZZANINE">1F Mezzanine</option>
                  <option value="F2B STORAGE">F2B Storage</option>
                  <option value="Y2K BUILDING">Y2K Building</option>
                  <option value="QC HOLD RACK">QC Hold Rack</option>
                  <option value="MOLDING VAULT">Molding Vault</option>
                </select>

                <select
                  value={selectedStatusFilter}
                  onChange={(e) => setSelectedStatusFilter(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Statuses</option>
                  <option value="NOT YET EXPIRED">Not Yet Expired</option>
                  <option value="EXPIRED">Expired</option>
                  <option value="AVAILABLE SPACE">Available Space</option>
                </select>
              </div>
            </div>

            {/* Space-Maximized Table */}
            <div className="overflow-x-auto">
              <table className="isms-table w-full text-xs">
                <thead>
                  <tr className="bg-[#062c21] text-emerald-200 uppercase text-[10px] tracking-wider border-b border-emerald-700/60">
                    <th className="p-2.5 font-bold text-emerald-100">Rack Location</th>
                    <th className="p-2.5 font-bold text-emerald-100">Box Number</th>
                    <th className="p-2.5 font-bold text-emerald-100">Storage Area</th>
                    <th className="p-2.5 font-bold text-emerald-100">Year</th>
                    <th className="p-2.5 font-bold text-emerald-100">Section</th>
                    <th className="p-2.5 font-bold text-emerald-100">Item Description</th>
                    <th className="p-2.5 font-bold text-emerald-100">Type</th>
                    <th className="p-2.5 font-bold text-emerald-100">Expiration Date</th>
                    <th className="p-2.5 font-bold text-emerald-100">Status</th>
                    <th className="p-2.5 text-right font-bold text-emerald-100">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-900/40">
                  {filteredLocations.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="p-6 text-center text-emerald-200/70">
                        No locations found matching criteria. Click "+ New Location Allocation" to add one.
                      </td>
                    </tr>
                  ) : (
                    filteredLocations.map((loc) => {
                      const isSelected = selectedLocationId === loc.id;
                      return (
                        <tr
                          key={loc.id}
                          onClick={() => setSelectedLocationId(loc.id)}
                          onDoubleClick={() => handleSelectLocationFromMasterlist(loc)}
                          className={`cursor-pointer transition-colors duration-150 group hover:bg-[#18392d]/80 ${
                            isSelected ? 'bg-pink-950/50' : 'bg-[#101e18]'
                          }`}
                          title="Double-click to open location details"
                        >
                          <td className="p-2.5 font-mono font-bold text-pink-300 group-hover:text-pink-200 whitespace-nowrap">
                            {loc.rackLocation}
                          </td>
                          <td className="p-2.5 font-mono text-emerald-300 font-bold whitespace-nowrap">
                            {loc.boxNumber}
                          </td>
                          <td className="p-2.5 whitespace-nowrap font-medium text-slate-100">
                            {loc.storageArea}
                          </td>
                          <td className="p-2.5 font-mono text-slate-200 whitespace-nowrap">
                            {loc.year}
                          </td>
                          <td className="p-2.5 font-semibold text-emerald-100 whitespace-nowrap">
                            {loc.section}
                          </td>
                          <td className="p-2.5 text-slate-100 max-w-xs truncate" title={loc.item}>
                            {loc.item || <span className="text-slate-400 italic">Empty rack slot</span>}
                          </td>
                          <td className="p-2.5 font-mono text-[11px] font-bold text-slate-200 whitespace-nowrap">
                            {loc.archiveType}
                          </td>
                          <td className="p-2.5 font-mono text-slate-200 whitespace-nowrap">
                            {loc.expirationDate || '-'}
                          </td>
                          <td className="p-2.5 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                const nextStatus = loc.status === 'NOT YET EXPIRED' ? 'EXPIRED' : 'NOT YET EXPIRED';
                                storageService.updateY2KLocation(loc.id, { status: nextStatus });
                                setLocations(storageService.getY2KLocations());
                                onRefreshData();
                              }}
                              className="transition-transform active:scale-95 text-left"
                              title="Click to toggle status"
                            >
                              {getStatusBadge(loc.status)}
                            </button>
                          </td>
                          <td className="p-2.5 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end space-x-1.5">
                              <button
                                onClick={() => handleSelectLocationFromMasterlist(loc)}
                                className="p-1 bg-pink-900/60 hover:bg-pink-800 text-pink-200 rounded border border-pink-600/60 shadow-xs"
                                title="Open Multitab Details"
                              >
                                <Layers className="w-3.5 h-3.5" />
                              </button>
                              {(isSysadmin || isAdmin || isQM) && (
                                <button
                                  onClick={() => handleDeleteLocation(loc)}
                                  className="p-1 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded border border-rose-600/60 shadow-xs"
                                  title="Delete Location"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex justify-between items-center">
              <span>Showing {filteredLocations.length} of {locations.length} rack locations</span>
              <span className="font-mono text-[11px]">JAE Facility Asset Tracking Standard</span>
            </div>
          </div>

        </div>
      ) : (
        /* ========================================================================= */
        /* 2. MULTI-TAB WORKSPACE PER ROLES */
        /* ========================================================================= */
        <div className="space-y-6 animate-in fade-in duration-300">
          
          {/* Multitab Navigation */}
          <div className="bg-white rounded-2xl shadow-xs border border-slate-200 p-2 flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab('LOCATION_ALLOCATION')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'LOCATION_ALLOCATION'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
              }`}
            >
              <MapPin className="w-4 h-4" />
              <span>1. Location & Rack Assignment</span>
            </button>

            <button
              onClick={() => setActiveTab('SHELF_CAPACITY')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'SHELF_CAPACITY'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>2. Shelf Slot & Sensor Status</span>
            </button>

            <button
              onClick={() => setActiveTab('QM_AUDIT')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'QM_AUDIT'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>3. QM Stocktaking Audit</span>
            </button>

            <button
              onClick={() => setActiveTab('AUDIT_TRAIL')}
              className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'AUDIT_TRAIL'
                  ? 'bg-pink-600 text-white shadow-sm'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
              }`}
            >
              <History className="w-4 h-4" />
              <span>4. Audit Trail</span>
            </button>
          </div>

          {/* Tab 1 Form */}
          {activeTab === 'LOCATION_ALLOCATION' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4 text-xs">
              <div className="border-b pb-3 border-slate-200">
                <h3 className="font-bold text-sm text-slate-900 font-['Chakra_Petch'] uppercase">
                  P.I.C. Rack Location Details
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">RACK LOCATION ID:</label>
                  <input
                    type="text"
                    value={rackLocation}
                    onChange={(e) => setRackLocation(e.target.value)}
                    required
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-700"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">BOX NUMBER:</label>
                  <input
                    type="text"
                    value={boxNumber}
                    onChange={(e) => setBoxNumber(e.target.value)}
                    required
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-800"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">STORAGE AREA:</label>
                  <select
                    value={storageArea}
                    onChange={(e) => setStorageArea(e.target.value as StorageAreaType)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  >
                    <option value="1F MEZZANINE">1F MEZZANINE</option>
                    <option value="F2B STORAGE">F2B STORAGE</option>
                    <option value="Y2K BUILDING">Y2K BUILDING</option>
                    <option value="QC HOLD RACK">QC HOLD RACK</option>
                    <option value="MOLDING VAULT">MOLDING VAULT</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">YEAR ALLOCATED:</label>
                  <input
                    type="number"
                    value={year}
                    onChange={(e) => setYear(Number(e.target.value))}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">SECTION:</label>
                  <select
                    value={section}
                    onChange={(e) => setSection(e.target.value as SectionType)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  >
                    {sectionsList.map((sec) => (
                      <option key={sec} value={sec}>{sec}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">ARCHIVE TYPE:</label>
                  <select
                    value={archiveType}
                    onChange={(e) => setArchiveType(e.target.value as ArchiveType)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-pink-700"
                  >
                    <option value="KS">KS (3 Years)</option>
                    <option value="IQC KS">IQC KS (1 Year)</option>
                    <option value="RS Sample">RS Sample (1 Year)</option>
                    <option value="DIECON">DIECON (20 Years)</option>
                    <option value="FILES">FILES (20 Years)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">STORED ITEM / PRODUCT DESCRIPTION:</label>
                <input
                  type="text"
                  value={item}
                  onChange={(e) => setItem(e.target.value)}
                  placeholder="e.g. MX57 Header Male Pin Golden Reference"
                  className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-semibold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">DATE GENERATED:</label>
                  <input
                    type="date"
                    value={dateGenerated}
                    onChange={(e) => setDateGenerated(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">EXPIRATION DATE:</label>
                  <input
                    type="date"
                    value={expirationDate}
                    onChange={(e) => setExpirationDate(e.target.value)}
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-rose-700"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Tab 2 */}
          {activeTab === 'SHELF_CAPACITY' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4 text-xs">
              <div className="border-b pb-3 border-slate-200">
                <h3 className="font-bold text-sm text-slate-900 font-['Chakra_Petch'] uppercase">
                  Physical Shelf & Slot Metrics
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 font-bold block">BAY / SHELF NUMBER:</span>
                  <span className="text-base font-bold font-mono text-slate-800">BAY-04 / LEVEL-2</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 font-bold block">STORAGE TEMPERATURE:</span>
                  <span className="text-base font-bold font-mono text-emerald-600">22.4 °C (IATF Compliant)</span>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <span className="text-slate-400 font-bold block">RELATIVE HUMIDITY:</span>
                  <span className="text-base font-bold font-mono text-blue-600">48.2 % RH</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3 */}
          {activeTab === 'QM_AUDIT' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4 text-xs">
              <div className="border-b pb-3 border-slate-200">
                <h3 className="font-bold text-sm text-slate-900 font-['Chakra_Petch'] uppercase">
                  QM Stocktaking & Audit Certification
                </h3>
              </div>
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 text-emerald-900">
                <div className="font-bold flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Annual Physical Inventory Audit Passed</span>
                </div>
                <p className="text-[11px]">
                  Physical sample verified on rack location {rackLocation} during JAE annual IATF 16949 surveillance cycle.
                </p>
              </div>
            </div>
          )}

          {/* Tab 4 */}
          {activeTab === 'AUDIT_TRAIL' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-4 text-xs">
              <div className="border-b pb-3 border-slate-200">
                <h3 className="font-bold text-sm text-slate-900 font-['Chakra_Petch'] uppercase">
                  Location Reallocation Audit History
                </h3>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-start space-x-3">
                <CheckSquare className="w-4 h-4 text-emerald-600 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-800">Assigned to Rack Location: {rackLocation}</div>
                  <div className="text-[11px] text-slate-500 font-mono">Date: {dateGenerated} • Box: {boxNumber}</div>
                </div>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
