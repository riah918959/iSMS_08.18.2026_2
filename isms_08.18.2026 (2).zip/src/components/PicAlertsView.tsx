import React, { useState } from 'react';
import {
  Mail,
  Send,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Bell,
  RefreshCw,
  Search,
  Sliders,
  ShieldAlert,
  Flame,
  UserCheck,
  Package,
  Layers,
  Inbox,
  FileText,
  Building,
  CheckCircle,
  Eye,
  ArrowRight,
  Filter,
  Sparkles,
  Zap,
  Calendar,
  AlertCircle,
  Timer,
  Activity,
  Cpu
} from 'lucide-react';
import {
  EmailAlertNotification,
  UserProfile,
  KeepSampleRequest,
  RSISSampleRecord,
  QCHoldExpirationAnalysis
} from '../types';
import { storageService } from '../services/storageService';
import { JAELogo } from './BrandingLogos';

interface PicAlertsViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
}

export const PicAlertsView: React.FC<PicAlertsViewProps> = ({
  currentUser,
  onRefreshData
}) => {
  const [alerts, setAlerts] = useState<EmailAlertNotification[]>(storageService.getEmailAlerts());
  const [keepSampleRequests, setKeepSampleRequests] = useState<KeepSampleRequest[]>(storageService.getKeepSampleRequests());
  const [rsisRecords, setRsisRecords] = useState<RSISSampleRecord[]>(storageService.getRSISRecords());
  const [preemptiveAnalyses, setPreemptiveAnalyses] = useState<QCHoldExpirationAnalysis[]>(
    storageService.analyzeBatchScheduleQCHoldExpirations()
  );
  const [isScanning, setIsScanning] = useState(false);
  
  const [activeTab, setActiveTab] = useState<'PREEMPTIVE_FORECAST' | 'EMAILS' | 'REQUESTS_BY_ROLE' | 'DISPATCH_SIMULATOR'>('PREEMPTIVE_FORECAST');
  const [forecastFilter, setForecastFilter] = useState<'ALL' | 'CRITICAL' | 'HIGH' | 'MEDIUM'>('ALL');
  const [forecastSourceFilter, setForecastSourceFilter] = useState<string>('ALL');
  const [selectedRoleFilter, setSelectedRoleFilter] = useState<'ALL' | 'REQUESTOR' | 'QC_HOLD' | 'QM' | 'QA'>('ALL');
  const [selectedAlert, setSelectedAlert] = useState<EmailAlertNotification | null>(alerts[0] || null);

  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Manual Trigger Form
  const [recipientEmail, setRecipientEmail] = useState('r.bautista@jae.com.ph');
  const [recipientName, setRecipientName] = useState('Rodel Bautista (QC Hold)');
  const [alertType, setAlertType] = useState<EmailAlertNotification['alertType']>('NO_RECEIVED_SAMPLE');
  const [referenceControlNo, setReferenceControlNo] = useState('RS-2026-0150');
  const [subject, setSubject] = useState('[CRITICAL] No Received Sample Notification - Action Required');
  const [body, setBody] = useState('QC Hold reported missing physical sample for RS-2026-0150. Please locate and surrender sample immediately to QC Hold station.');

  const refreshAll = () => {
    setAlerts(storageService.getEmailAlerts());
    setKeepSampleRequests(storageService.getKeepSampleRequests());
    setRsisRecords(storageService.getRSISRecords());
    setPreemptiveAnalyses(storageService.analyzeBatchScheduleQCHoldExpirations());
    onRefreshData();
  };

  const handleRunPreemptiveScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      try {
        const result = storageService.runPreemptiveQCHoldScan(`${currentUser.firstName} ${currentUser.lastName} (${currentUser.role})`);
        refreshAll();
        setIsScanning(false);
        setFeedbackMsg({
          type: 'success',
          text: `Preemptive Batch Schedule Analysis Complete: Scanned ${result.totalAnalyzed} correlated schedule/hold items. Found ${result.criticalAlertsCount} urgent/critical risks. Dispatched ${result.dispatchedAlerts} automated alerts.`
        });
      } catch (err: any) {
        setIsScanning(false);
        setFeedbackMsg({
          type: 'error',
          text: `Failed running preemptive scan: ${err.message}`
        });
      }
    }, 450);
  };

  const handleDispatchSinglePreemptiveAlert = (item: QCHoldExpirationAnalysis) => {
    try {
      const newAlert = storageService.sendEmailAlert({
        recipientEmail: item.picEmail,
        recipientName: `${item.picName} (${item.department})`,
        alertType: 'EXPIRATION_WARNING',
        referenceControlNo: item.referenceControlNo,
        subject: `[PREEMPTIVE QC NOTICE] Imminent Hold Expiration for ${item.referenceControlNo} (${item.riskLevel})`,
        body: `PREEMPTIVE SCHEDULE CORRELATION ALERT:
Reference Control No: ${item.referenceControlNo}
Part/Item: ${item.partDescription}
QC Hold Status: ${item.qcHoldStatus}
Expiration Due Date: ${item.expirationDate} (${item.daysRemaining <= 0 ? 'OVERDUE' : `${item.daysRemaining} days remaining`})
Risk Assessment: ${item.riskLevel} - ${item.impactAnalysis}
Recommended Action: ${item.recommendedAction}
${item.batchScheduleImpact ? `Batch Schedule Impact: Job Order ${item.batchScheduleImpact.jobOrderNo}, Stage: ${item.batchScheduleImpact.stage}, Target Run Date: ${item.batchScheduleImpact.scheduledDate}` : ''}

Please review and take prompt quality disposition action.`
      });

      refreshAll();
      setSelectedAlert(newAlert);
      setFeedbackMsg({
        type: 'success',
        text: `Preemptive alert dispatched successfully to ${item.picEmail} (${item.picName}) for ${item.referenceControlNo}!`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Error dispatching alert: ${err.message}`
      });
    }
  };

  const handleSendTestAlert = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const newAlert = storageService.sendEmailAlert({
        recipientEmail,
        recipientName,
        alertType,
        referenceControlNo,
        subject,
        body
      });

      refreshAll();
      setSelectedAlert(newAlert);
      setFeedbackMsg({
        type: 'success',
        text: `Automated P.I.C. Email Alert sent successfully to ${recipientEmail} (${recipientName})!`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Error dispatching alert: ${err.message}`
      });
    }
  };

  const handleTriggerQuickAlert = (referenceNo: string, targetRole: string, targetName: string, reason: string) => {
    try {
      const newAlert = storageService.sendEmailAlert({
        recipientEmail: `${targetName.toLowerCase().replace(/\s+/g, '.')}@jae.com.ph`,
        recipientName: `${targetName} (${targetRole})`,
        alertType: 'OVERDUE_BORROWING',
        referenceControlNo: referenceNo,
        subject: `[ACTION REQUIRED] Urgent Sample Notice for ${referenceNo}`,
        body: `Automated reminder from JAE Quality System regarding sample request ${referenceNo}. Reason: ${reason}. Please update custody status.`
      });

      refreshAll();
      setSelectedAlert(newAlert);
      setFeedbackMsg({
        type: 'success',
        text: `Urgent notification dispatched to ${targetName} (${targetRole}) for ${referenceNo}!`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed sending alert: ${err.message}`
      });
    }
  };

  const filteredAlerts = alerts.filter((a) => {
    const rName = (a.recipientName || a.picName || '').toLowerCase();
    const rEmail = (a.recipientEmail || a.toEmail || '').toLowerCase();
    const rCtrl = (a.referenceControlNo || a.relatedControlNo || '').toLowerCase();
    const subj = (a.subject || '').toLowerCase();
    const q = searchQuery.toLowerCase();

    const matchesSearch =
      rName.includes(q) ||
      rEmail.includes(q) ||
      rCtrl.includes(q) ||
      subj.includes(q);

    const matchesType = typeFilter === 'All' || a.alertType === typeFilter || a.triggerReason === typeFilter;
    return matchesSearch && matchesType;
  });

  const filteredForecast = preemptiveAnalyses.filter((item) => {
    const matchesRisk = forecastFilter === 'ALL' || item.riskLevel === forecastFilter;
    const matchesSource = forecastSourceFilter === 'ALL' || item.sourceType === forecastSourceFilter;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      (item.referenceControlNo || '').toLowerCase().includes(q) ||
      (item.partDescription || '').toLowerCase().includes(q) ||
      (item.picName || '').toLowerCase().includes(q) ||
      (item.section || '').toLowerCase().includes(q) ||
      (item.department || '').toLowerCase().includes(q) ||
      (item.jobOrderNo && item.jobOrderNo.toLowerCase().includes(q)) ||
      (item.lotNumber && item.lotNumber.toLowerCase().includes(q));
    return matchesRisk && matchesSource && matchesSearch;
  });

  const criticalForecastCount = preemptiveAnalyses.filter((i) => i.riskLevel === 'CRITICAL').length;
  const highForecastCount = preemptiveAnalyses.filter((i) => i.riskLevel === 'HIGH').length;
  const batchCollisionsCount = preemptiveAnalyses.filter((i) => i.batchScheduleImpact).length;

  return (
    <div id="pic-alerts-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Module Header */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <Sparkles className="w-5 h-5 text-pink-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                P.I.C. Notification Center & Schedule Forecaster
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                PREEMPTIVE AI ENGINE
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleRunPreemptiveScan}
            disabled={isScanning}
            className="px-3 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 disabled:opacity-60 text-white rounded-lg text-xs font-bold font-['Chakra_Petch'] flex items-center space-x-1.5 shadow-sm transition-all cursor-pointer"
            title="Scan active batch schedules against QC Hold expirations"
          >
            <Zap className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>{isScanning ? 'Analyzing Schedules...' : 'Run Preemptive Batch Scan'}</span>
          </button>

          <span className="text-xs font-mono font-bold bg-emerald-950 text-emerald-300 px-3 py-1.5 rounded-lg border border-emerald-700/60 flex items-center space-x-1.5 shadow-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Forecast Engine Active</span>
          </span>
          <button
            onClick={refreshAll}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700 shadow-xs transition-colors"
            title="Refresh All Data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-xs ${
          feedbackMsg.type === 'success'
            ? 'bg-emerald-950/80 border-emerald-700 text-emerald-300'
            : feedbackMsg.type === 'error'
            ? 'bg-rose-950/80 border-rose-700 text-rose-300'
            : 'bg-blue-950/80 border-blue-700 text-blue-300'
        }`}>
          <div className="flex items-center space-x-2">
            {feedbackMsg.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
            {feedbackMsg.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-[11px] underline ml-2 opacity-80 hover:opacity-100 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Top Preemptive & Alert KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-rose-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Imminent / Overdue Holds</span>
            <div className="text-2xl font-bold font-mono text-rose-400 mt-0.5">
              {criticalForecastCount} <span className="text-xs text-rose-300 font-normal">(&lt;24h / expired)</span>
            </div>
          </div>
          <div className="p-3 bg-rose-950/60 text-rose-400 rounded-xl border border-rose-700/50">
            <Flame className="w-5 h-5 animate-pulse" />
          </div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-amber-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Upcoming Expirations (1-3d)</span>
            <div className="text-2xl font-bold font-mono text-amber-400 mt-0.5">
              {highForecastCount} <span className="text-xs text-amber-300 font-normal">preemptive</span>
            </div>
          </div>
          <div className="p-3 bg-amber-950/60 text-amber-400 rounded-xl border border-amber-700/50">
            <Timer className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-pink-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Batch Schedule Collisions</span>
            <div className="text-2xl font-bold font-mono text-pink-400 mt-0.5">
              {batchCollisionsCount} <span className="text-xs text-pink-300 font-normal">active runs</span>
            </div>
          </div>
          <div className="p-3 bg-pink-950/60 text-pink-400 rounded-xl border border-pink-700/50">
            <Cpu className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Dispatched Emails</span>
            <div className="text-2xl font-bold font-mono text-emerald-400 mt-0.5">{alerts.length}</div>
          </div>
          <div className="p-3 bg-emerald-950/60 text-emerald-400 rounded-xl border border-emerald-700/50">
            <Mail className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="bg-[#1A1A1A] rounded-xl shadow-xs border border-emerald-800/40 p-2 flex flex-wrap gap-2">
        <button
          onClick={() => setActiveTab('PREEMPTIVE_FORECAST')}
          className={`flex-1 min-w-[220px] py-2 px-4 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
            activeTab === 'PREEMPTIVE_FORECAST'
              ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-sm ring-1 ring-pink-400/50'
              : 'bg-[#141414] hover:bg-slate-800 text-slate-300'
          }`}
        >
          <Sparkles className="w-4 h-4 text-pink-300" />
          <span>1. Preemptive QC Hold & Batch Forecast ({preemptiveAnalyses.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('EMAILS')}
          className={`flex-1 min-w-[200px] py-2 px-4 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
            activeTab === 'EMAILS'
              ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-sm'
              : 'bg-[#141414] hover:bg-slate-800 text-slate-300'
          }`}
        >
          <Mail className="w-4 h-4" />
          <span>2. Email Notification Logs ({alerts.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('REQUESTS_BY_ROLE')}
          className={`flex-1 min-w-[200px] py-2 px-4 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
            activeTab === 'REQUESTS_BY_ROLE'
              ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-sm'
              : 'bg-[#141414] hover:bg-slate-800 text-slate-300'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>3. All Sample Requests per Role</span>
        </button>

        <button
          onClick={() => setActiveTab('DISPATCH_SIMULATOR')}
          className={`flex-1 min-w-[200px] py-2 px-4 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
            activeTab === 'DISPATCH_SIMULATOR'
              ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-sm'
              : 'bg-[#141414] hover:bg-slate-800 text-slate-300'
          }`}
        >
          <Send className="w-4 h-4" />
          <span>4. Manual SMTP Alert Dispatcher</span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* 1. PREEMPTIVE QC HOLD & BATCH SCHEDULE FORECASTER */}
      {/* ========================================================================= */}
      {activeTab === 'PREEMPTIVE_FORECAST' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          {/* Controls & Filter Bar */}
          <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-300 font-['Chakra_Petch'] uppercase mr-2 flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-pink-400" />
                Filter Risk:
              </span>
              {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setForecastFilter(r)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    forecastFilter === r
                      ? r === 'CRITICAL'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : r === 'HIGH'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : r === 'MEDIUM'
                        ? 'bg-yellow-600 text-slate-900 shadow-xs'
                        : 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {r === 'ALL' ? 'All Risks' : r}
                  {r === 'CRITICAL' && criticalForecastCount > 0 && ` (${criticalForecastCount})`}
                  {r === 'HIGH' && highForecastCount > 0 && ` (${highForecastCount})`}
                </button>
              ))}

              <div className="h-4 w-px bg-slate-700 mx-1 hidden sm:block"></div>

              <select
                value={forecastSourceFilter}
                onChange={(e) => setForecastSourceFilter(e.target.value)}
                aria-label="Filter by sample source category"
                className="bg-[#141414] border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1 focus:border-pink-500 focus:outline-none"
              >
                <option value="ALL">All Source Types</option>
                <option value="RSIS_HOLD">RS/IS QC Hold Defect</option>
                <option value="BORROW_RETURN_HOLD">Borrowed Keep Sample Return</option>
                <option value="BOX_RETENTION_EXPIRY">Keep Sample Box Retention Expiry</option>
              </select>
            </div>

            <div className="relative min-w-[240px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search Lot, Part, Job Order, Control No..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#141414] border border-slate-700 text-slate-200 text-xs rounded-lg pl-8 pr-3 py-1.5 focus:border-pink-500 focus:outline-none placeholder-slate-500"
              />
            </div>
          </div>

          {/* Forecast Radar Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredForecast.map((item) => {
              const isUrgent = item.riskLevel === 'CRITICAL';
              const isHigh = item.riskLevel === 'HIGH';
              const isOverdue = item.daysRemaining <= 0;

              return (
                <div
                  key={item.id}
                  className={`bg-[#1A1A1A] rounded-xl border p-4 flex flex-col justify-between space-y-3 transition-all hover:border-pink-500/50 shadow-sm ${
                    isUrgent
                      ? 'border-rose-700/70 bg-gradient-to-b from-[#201015] to-[#1A1A1A]'
                      : isHigh
                      ? 'border-amber-700/60 bg-gradient-to-b from-[#201a10] to-[#1A1A1A]'
                      : 'border-slate-800 bg-[#1A1A1A]'
                  }`}
                >
                  {/* Card Header */}
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                          item.sourceType === 'RSIS_HOLD'
                            ? 'bg-blue-950 text-blue-300 border-blue-700/60'
                            : item.sourceType === 'BORROW_RETURN_HOLD'
                            ? 'bg-purple-950 text-purple-300 border-purple-700/60'
                            : 'bg-emerald-950 text-emerald-300 border-emerald-700/60'
                        }`}>
                          {item.sourceType === 'RSIS_HOLD' ? 'RS/IS QC HOLD' : item.sourceType === 'BORROW_RETURN_HOLD' ? 'BORROWED SAMPLE' : 'BOX RETENTION'}
                        </span>
                        <span className="font-mono font-bold text-xs text-white">
                          {item.referenceControlNo}
                        </span>
                      </div>

                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider flex items-center gap-1 ${
                        isUrgent
                          ? 'bg-rose-600 text-white animate-pulse'
                          : isHigh
                          ? 'bg-amber-600 text-white'
                          : 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40'
                      }`}>
                        {isUrgent && <Flame className="w-3 h-3" />}
                        {item.riskLevel}
                      </span>
                    </div>

                    <h2 className="text-sm font-bold text-white line-clamp-1">
                      {item.partDescription}
                    </h2>
                    <p className="text-[11px] text-slate-400 font-mono mt-0.5">
                      {item.partNumber && `Part: ${item.partNumber} `}
                      {item.lotNumber && `• Lot: ${item.lotNumber}`}
                    </p>
                  </div>

                  {/* Status & Timing Metrics */}
                  <div className="bg-[#141414] rounded-lg p-2.5 border border-slate-800 space-y-1.5 text-xs">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">QC Hold Status:</span>
                      <span className="font-bold text-slate-200">{item.qcHoldStatus}</span>
                    </div>

                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Expiration / Due:</span>
                      <span className={`font-mono font-bold ${isOverdue ? 'text-rose-400' : 'text-amber-300'}`}>
                        {item.expirationDate} ({isOverdue ? `Overdue ${Math.abs(item.daysRemaining)}d` : `${item.daysRemaining}d left`})
                      </span>
                    </div>

                    {item.batchScheduleImpact && (
                      <div className="pt-1.5 border-t border-slate-800/80">
                        <div className="flex items-center gap-1 text-[11px] text-pink-300 font-bold mb-0.5">
                          <Cpu className="w-3 h-3" />
                          <span>Batch Collision Impact:</span>
                        </div>
                        <p className="text-[10px] text-slate-300">
                          Job Order <span className="font-mono text-white font-bold">{item.batchScheduleImpact.jobOrderNo}</span> ({item.batchScheduleImpact.stage}) scheduled for <span className="font-mono text-emerald-300">{item.batchScheduleImpact.scheduledDate}</span>.
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Impact Analysis & Recommended Action */}
                  <div className="space-y-1 text-xs">
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      <span className="font-semibold text-slate-400">Assessment: </span>
                      {item.impactAnalysis}
                    </p>
                    <div className="bg-slate-900/80 p-2 rounded border border-slate-800 text-[11px] text-emerald-300/90 font-medium">
                      <span className="text-pink-400 font-bold">Action: </span>
                      {item.recommendedAction}
                    </div>
                  </div>

                  {/* PIC & Quick Dispatch Action */}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2">
                    <div className="text-[10px] text-slate-400 truncate">
                      <span className="font-bold text-slate-300">{item.picName}</span>
                      <div className="text-slate-500 font-mono">
                        {item.department || 'Assembly'} • <span className="text-emerald-400 font-semibold">{item.section || 'MX CONNECTOR'}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDispatchSinglePreemptiveAlert(item)}
                      className="px-2.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-[11px] font-bold font-['Chakra_Petch'] flex items-center space-x-1 shadow-xs transition-all shrink-0 cursor-pointer"
                    >
                      <Send className="w-3 h-3" />
                      <span>Notify PIC</span>
                    </button>
                  </div>
                </div>
              );
            })}

            {filteredForecast.length === 0 && (
              <div className="col-span-full py-12 text-center bg-[#1A1A1A] rounded-xl border border-slate-800 text-slate-400">
                <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-400 mb-2" />
                <p className="font-bold text-white text-sm">No Pending QC Hold Expirations Detected</p>
                <p className="text-xs text-slate-400 mt-1">All active batch schedules and QC hold retention SLAs are currently on-track.</p>
              </div>
            )}
          </div>
        </div>
      )}


      {/* ========================================================================= */}
      {/* 1. EMAIL NOTIFICATION LOGS & DETAILS */}
      {/* ========================================================================= */}
      {activeTab === 'EMAILS' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-in fade-in duration-200">
          
          {/* Email List Column */}
          <div className="lg:col-span-5 bg-[#1A1A1A] rounded-xl shadow-sm border border-emerald-800/40 overflow-hidden flex flex-col h-[650px]">
            <div className="p-4 border-b border-slate-800 bg-[#161616] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-white font-['Chakra_Petch'] uppercase">
                  Dispatched Notification History
                </span>
                <span className="text-[10px] font-mono font-bold bg-pink-950 text-pink-300 border border-pink-700/60 px-2 py-0.5 rounded">
                  {filteredAlerts.length} Emails
                </span>
              </div>

              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search recipient, control no..."
                    className="w-full bg-[#141414] border border-slate-700 rounded-lg pl-8 pr-2 py-1 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
                  />
                </div>
                <select
                  value={typeFilter}
                  onChange={(e) => setTypeFilter(e.target.value)}
                  className="bg-[#141414] border border-slate-700 rounded-lg px-2 py-1 text-xs font-semibold text-slate-200 focus:outline-none"
                >
                  <option value="All">All Types</option>
                  <option value="NO_RECEIVED_SAMPLE">No Received</option>
                  <option value="OVERDUE_BORROWING">Overdue</option>
                  <option value="EXPIRATION_ALERT">Expired</option>
                  <option value="SCHEDULE_HOLD">Prod Hold</option>
                </select>
              </div>
            </div>

            {/* Email List Items */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-800">
              {filteredAlerts.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-400">
                  No email alerts found.
                </div>
              ) : (
                filteredAlerts.map((alt) => (
                  <div
                    key={alt.id}
                    onClick={() => setSelectedAlert(alt)}
                    className={`p-3.5 cursor-pointer transition-all ${
                      selectedAlert?.id === alt.id
                        ? 'bg-pink-950/40 border-l-4 border-pink-500'
                        : 'hover:bg-slate-800/40'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-white truncate max-w-[200px]">
                        {alt.recipientName}
                      </span>
                      <span className="font-mono text-[10px] text-slate-400">
                        {alt.timestamp ? alt.timestamp.split('T')[0] : 'Today'}
                      </span>
                    </div>

                    <div className="font-semibold text-[11px] text-slate-300 mt-1 truncate" title={alt.subject}>
                      {alt.subject}
                    </div>

                    <div className="flex items-center gap-1.5 mt-2">
                      <span className="font-mono text-[10px] font-bold bg-[#141414] text-slate-300 border border-slate-700 px-1.5 py-0.5 rounded">
                        {alt.referenceControlNo}
                      </span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                        alt.urgency === 'CRITICAL' ? 'bg-rose-950 text-rose-300 border border-rose-700/60' :
                        alt.urgency === 'HIGH' ? 'bg-amber-950 text-amber-300 border border-amber-700/60' :
                        'bg-sky-950 text-sky-300 border border-sky-700/60'
                      }`}>
                        {alt.urgency || alt.alertType}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Email Preview Details Column */}
          <div className="lg:col-span-7 bg-[#1A1A1A] rounded-xl shadow-sm border border-emerald-800/40 overflow-hidden flex flex-col h-[650px]">
            {selectedAlert ? (
              <div className="flex-1 flex flex-col">
                
                {/* Email Header */}
                <div className="p-5 border-b border-slate-800 bg-[#161616] space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-pink-400 font-mono">
                        SMTP INVOICE #{selectedAlert.id}
                      </span>
                      <h2 className="text-base font-bold text-white mt-0.5">
                        {selectedAlert.subject}
                      </h2>
                    </div>
                    <span className="font-mono text-[11px] font-bold bg-emerald-950 text-emerald-300 px-2.5 py-1 rounded-lg border border-emerald-700/60 shrink-0">
                      DELIVERED
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 font-bold block text-[10px] uppercase">To:</span>
                      <strong className="text-white">{selectedAlert.recipientName}</strong>
                      <span className="text-slate-400 font-mono block text-[11px]">&lt;{selectedAlert.recipientEmail}&gt;</span>
                    </div>
                    <div>
                      <span className="text-slate-400 font-bold block text-[10px] uppercase">Reference No:</span>
                      <span className="font-mono font-bold text-pink-400">{selectedAlert.referenceControlNo}</span>
                      <span className="text-slate-400 block text-[11px]">{selectedAlert.timestamp || '2026-02-14'}</span>
                    </div>
                  </div>
                </div>

                {/* Email Rendered Body */}
                <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-[#141414] text-xs text-slate-200">
                  <div className="p-4 rounded-xl border border-slate-800 bg-[#1A1A1A] space-y-3 font-mono leading-relaxed">
                    <div className="border-b pb-2 border-slate-800 font-bold text-pink-400">
                      *** JAE PHILIPPINES QUALITY SYSTEM AUTOMATED ALERT ***
                    </div>
                    
                    <p className="text-slate-300">{selectedAlert.body}</p>

                    <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
                      <div>Sender: Quality Assurance Automated Dispatch System (QA-ADS-01)</div>
                      <div>Factory: JAE Philippines (Special Economic Zone, Cavite)</div>
                      <div>System ID: JAE-QM-ISMS-V2026</div>
                    </div>
                  </div>
                </div>

                {/* Email Footer Actions */}
                <div className="p-4 border-t border-slate-800 bg-[#161616] flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">Auto-sent on trigger event: {selectedAlert.triggerReason || 'SYSTEM_SWEEP'}</span>
                  <button
                    onClick={() => handleTriggerQuickAlert(selectedAlert.referenceControlNo, 'Requestor', selectedAlert.recipientName, 'Manual Resend Confirmation')}
                    className="px-3 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Resend Email Notice</span>
                  </button>
                </div>

              </div>
            ) : (
              <div className="flex-1 flex items-center justify-center p-8 text-center text-slate-400 text-xs">
                Select an email from the list to view full headers and rendered body.
              </div>
            )}
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ALL SAMPLE REQUESTS PER ROLE WORKSPACE */}
      {/* ========================================================================= */}
      {activeTab === 'REQUESTS_BY_ROLE' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          
          {/* Role Selector Filter */}
          <div className="bg-[#1A1A1A] p-4 rounded-xl shadow-sm border border-emerald-800/40 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase">
                Filter Requests by Department Role
              </h3>
              <p className="text-xs text-slate-400">
                View all pending actions and send automated alerts to responsible personnel.
              </p>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {(['ALL', 'REQUESTOR', 'QC_HOLD', 'QM', 'QA'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setSelectedRoleFilter(r)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    selectedRoleFilter === r
                      ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white shadow-xs'
                      : 'bg-[#141414] hover:bg-slate-800 text-slate-300 border border-slate-700'
                  }`}
                >
                  {r.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Keep Sample Requests Section */}
          <div className="bg-[#1A1A1A] rounded-xl shadow-sm border border-emerald-800/40 overflow-hidden">
            <div className="p-4 border-b border-slate-800 bg-[#161616] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <FileText className="w-4 h-4 text-pink-400" />
                <span className="font-bold text-xs text-white font-['Chakra_Petch'] uppercase">
                  Keep Sample Borrow Requests ({keepSampleRequests.length})
                </span>
              </div>
              <span className="text-xs text-slate-400">Unreturned: {keepSampleRequests.filter(r => r.status === 'Unreturned').length}</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#141414] text-slate-300 font-bold uppercase text-[10px] font-mono border-b border-slate-800">
                  <tr>
                    <th className="p-3">Control No</th>
                    <th className="p-3">Requestor (P.I.C)</th>
                    <th className="p-3">Target Box</th>
                    <th className="p-3">QM Status</th>
                    <th className="p-3">QC Delivery</th>
                    <th className="p-3">Return Status</th>
                    <th className="p-3 text-right">Quick Alert</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {keepSampleRequests.map((req) => (
                    <tr key={req.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-3 font-mono font-bold text-pink-400 whitespace-nowrap">{req.controlNo}</td>
                      <td className="p-3 whitespace-nowrap">
                        <div className="font-semibold text-white">{req.requestorName}</div>
                        <div className="text-[10px] text-pink-400 font-medium">
                          {req.department} • <span className="text-slate-300 font-mono">{req.section || (req.factory === 'First Factory' ? 'MX CONNECTOR' : 'MX HARNESS')}</span>
                        </div>
                      </td>
                      <td className="p-3 font-mono text-slate-300 whitespace-nowrap">{req.boxNumber}</td>
                      <td className="p-3 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          req.qmStatus === 'Approved' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60' : 'bg-amber-950 text-amber-300 border border-amber-700/60'
                        }`}>
                          {req.qmStatus || 'Approved'}
                        </span>
                      </td>
                      <td className="p-3 font-semibold text-slate-300 whitespace-nowrap">
                        {req.deliveredBy || 'QC Hold Area'}
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          req.status === 'Returned' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60' : 'bg-rose-950 text-rose-300 border border-rose-700/60'
                        }`}>
                          {req.status}
                        </span>
                      </td>
                      <td className="p-3 text-right whitespace-nowrap">
                        <button
                          onClick={() => handleTriggerQuickAlert(req.controlNo, 'Requestor', req.requestorName, 'Unreturned Keep Sample Overdue Notice')}
                          className="px-2.5 py-1 bg-pink-950/60 hover:bg-pink-900 text-pink-300 rounded-lg font-bold text-[11px] border border-pink-700/50 transition-colors"
                        >
                          Send Reminder
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* RS/IS Sample Requisitions Section */}
          <div className="bg-[#1A1A1A] rounded-xl shadow-sm border border-emerald-800/40 overflow-hidden">
            <div className="p-4 border-b border-slate-800 bg-[#161616] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Send className="w-4 h-4 text-pink-400" />
                <span className="font-bold text-xs text-white font-['Chakra_Petch'] uppercase">
                  RS / IS Sample Requisitions ({rsisRecords.length})
                </span>
              </div>
              <span className="text-xs text-slate-400">QA Open: {rsisRecords.filter(r => r.qaStatus === 'Open').length}</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-[#141414] text-slate-300 font-bold uppercase text-[10px] font-mono border-b border-slate-800">
                  <tr>
                    <th className="p-3">Control No</th>
                    <th className="p-3">Type</th>
                    <th className="p-3">Part Description</th>
                    <th className="p-3">Issued By</th>
                    <th className="p-3">QC Hold Status</th>
                    <th className="p-3">QA Disposition</th>
                    <th className="p-3 text-right">Quick Alert</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {rsisRecords.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="p-3 font-mono font-bold text-pink-400 whitespace-nowrap">{rec.controlNo}</td>
                      <td className="p-3 font-mono text-[10px] font-bold text-slate-300 whitespace-nowrap">{rec.sampleType}</td>
                      <td className="p-3 font-semibold text-white max-w-xs truncate">{rec.itemName}</td>
                      <td className="p-3 whitespace-nowrap">
                        <div className="font-semibold text-white">{rec.issuedBy || rec.requestorName}</div>
                        <div className="text-[10px] text-pink-400 font-medium">
                          {rec.department || 'Assembly'} • <span className="text-slate-300 font-mono">{rec.section || 'MX CONNECTOR'}</span>
                        </div>
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                          rec.qcHoldStatus === 'No Received Sample' ? 'bg-rose-950 text-rose-300 border-rose-700/60' :
                          rec.qcHoldStatus === 'For Disposition' ? 'bg-amber-950 text-amber-300 border-amber-700/60' :
                          'bg-emerald-950 text-emerald-300 border-emerald-700/60'
                        }`}>
                          {rec.qcHoldStatus}
                        </span>
                      </td>
                      <td className="p-3 whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          rec.qaStatus === 'Closed' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700/60' : 'bg-sky-950 text-sky-300 border border-sky-700/60'
                        }`}>
                          {rec.qaStatus || 'Open'}
                        </span>
                      </td>
                      <td className="p-3 text-right whitespace-nowrap">
                        <button
                          onClick={() => handleTriggerQuickAlert(rec.controlNo, 'QC Hold', rec.receivedBy || 'Rodel Bautista', 'Missing Physical Sample Action')}
                          className="px-2.5 py-1 bg-pink-950/60 hover:bg-pink-900 text-pink-300 rounded-lg font-bold text-[11px] border border-pink-700/50 transition-colors"
                        >
                          Alert QC Hold
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. MANUAL SMTP ALERT DISPATCHER */}
      {/* ========================================================================= */}
      {activeTab === 'DISPATCH_SIMULATOR' && (
        <div className="bg-[#1A1A1A] rounded-xl shadow-sm border border-emerald-800/40 p-6 max-w-3xl mx-auto space-y-6 animate-in fade-in duration-200 text-xs">
          <div className="border-b pb-3 border-slate-800">
            <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase">
              Manual P.I.C. Notification Dispatcher
            </h3>
            <p className="text-slate-400">
              Directly dispatch formatted email notifications to factory personnel.
            </p>
          </div>

          <form onSubmit={handleSendTestAlert} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">RECIPIENT NAME:</label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  required
                  className="w-full bg-[#141414] border border-slate-700 rounded-lg px-3 py-2 text-xs font-semibold text-white focus:border-pink-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">RECIPIENT EMAIL:</label>
                <input
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  required
                  className="w-full bg-[#141414] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-pink-300 focus:border-pink-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">ALERT TYPE:</label>
                <select
                  value={alertType}
                  onChange={(e) => setAlertType(e.target.value as any)}
                  className="w-full bg-[#141414] border border-slate-700 rounded-lg px-3 py-2 text-xs font-bold text-white focus:border-pink-500 focus:outline-none"
                >
                  <option value="NO_RECEIVED_SAMPLE">No Received Sample Alert</option>
                  <option value="OVERDUE_BORROWING">Overdue Sample Loan</option>
                  <option value="EXPIRATION_ALERT">Keep Sample Box Expiration</option>
                  <option value="SCHEDULE_HOLD">Production Gate Hold</option>
                </select>
              </div>
              <div>
                <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">REFERENCE CONTROL NUMBER:</label>
                <input
                  type="text"
                  value={referenceControlNo}
                  onChange={(e) => setReferenceControlNo(e.target.value)}
                  required
                  className="w-full bg-[#141414] border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:border-pink-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">EMAIL SUBJECT:</label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
                className="w-full bg-[#141414] border border-slate-700 rounded-lg px-3 py-2 text-xs font-bold text-white focus:border-pink-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-300 uppercase tracking-wider mb-1">EMAIL BODY:</label>
              <textarea
                rows={4}
                value={body}
                onChange={(e) => setBody(e.target.value)}
                required
                className="w-full bg-[#141414] border border-slate-700 rounded-lg p-3 text-xs font-mono text-slate-200 focus:border-pink-500 focus:outline-none"
              />
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-md flex items-center space-x-1.5 transition-all"
              >
                <Send className="w-4 h-4" />
                <span>Send SMTP Email Notification</span>
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
