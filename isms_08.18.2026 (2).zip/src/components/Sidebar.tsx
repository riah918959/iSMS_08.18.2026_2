import React from 'react';
import {
  LayoutDashboard,
  Box,
  FileText,
  ScanLine,
  Send,
  MapPin,
  CalendarCheck,
  ShieldAlert,
  Users,
  Database,
  History,
  MailCheck,
  Lock,
  LogOut,
  FolderInput,
  FolderOutput,
  Activity,
  Cpu,
  Sparkles
} from 'lucide-react';
import { UserRole } from '../types';
import { ISMSLogo, JAELogo } from './BrandingLogos';

export type NavTab = 
  | 'dashboard'
  | 'batch_scheduling'
  | 'production_schedule'
  | 'quality_analytics'
  | 'keep_sample_entry'
  | 'rsis_sample_entry'
  | 'y2k_masterlist'
  | 'keep_sample_request'
  | 'rsis_sample_request'
  | 'user_registry'
  | 'pic_alerts'
  | 'sql_hub'
  | 'audit_logs';

export interface SidebarBadgeCounts {
  keepSampleBoxes?: number;
  keepSampleRequests?: number;
  rsisRecords?: number;
  rsisRequests?: number;
  productionAlerts?: number;
  emailAlerts?: number;
  unreturnedCount?: number;
  pendingDispositionCount?: number;
  expiredCount?: number;
  criticalAlertsCount?: number;
}

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  badgeCounts?: SidebarBadgeCounts;
  userRole?: UserRole;
  onLockStation?: () => void;
  onOpenImportModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  badgeCounts = {},
  userRole,
  onLockStation,
  onOpenImportModal
}) => {
  const b: SidebarBadgeCounts = badgeCounts || {};

  const isAdminOrSysadmin = userRole === 'Admin' || userRole === 'Sysadmin';

  const sections = [
    {
      title: 'Summary Notification',
      id: 'sec_summary_notification',
      items: [
        {
          id: 'dashboard' as NavTab,
          label: 'Dashboard',
          icon: LayoutDashboard
        },
        {
          id: 'batch_scheduling' as NavTab,
          label: 'Batch Scheduling',
          badge: 'Automated',
          badgeColor: 'bg-indigo-600 text-white',
          icon: Activity
        },
        {
          id: 'production_schedule' as NavTab,
          label: 'Production Schedules',
          badge: b.productionAlerts ? `${b.productionAlerts}` : undefined,
          badgeColor: 'bg-amber-600 text-white',
          icon: CalendarCheck
        },
        {
          id: 'quality_analytics' as NavTab,
          label: 'Quality & Crimp Analytics',
          icon: ShieldAlert
        }
      ]
    },
    {
      title: 'Sample Entry',
      id: 'sec_sample_entry',
      items: [
        {
          id: 'keep_sample_entry' as NavTab,
          label: 'Keep Sample Entry',
          badge: (b.keepSampleBoxes || b.expiredCount) ? `${b.keepSampleBoxes || b.expiredCount} Exp` : undefined,
          badgeColor: 'bg-rose-600 text-white',
          icon: Box
        },
        {
          id: 'rsis_sample_entry' as NavTab,
          label: 'RS/IS Sample Entry',
          badge: b.pendingDispositionCount ? `${b.pendingDispositionCount}` : undefined,
          badgeColor: 'bg-pink-600 text-white',
          icon: ScanLine
        },
        {
          id: 'y2k_masterlist' as NavTab,
          label: 'Y2K Location Masterlist',
          icon: MapPin
        }
      ]
    },
    {
      title: 'Request Sample',
      id: 'sec_sample_request',
      items: [
        {
          id: 'keep_sample_request' as NavTab,
          label: 'Keep Sample Request',
          badge: b.unreturnedCount ? `${b.unreturnedCount} Active` : undefined,
          badgeColor: 'bg-amber-500 text-slate-900',
          icon: FileText
        },
        {
          id: 'rsis_sample_request' as NavTab,
          label: 'RS/IS Sample Request',
          badge: b.rsisRequests ? `${b.rsisRequests}` : undefined,
          badgeColor: 'bg-purple-600 text-white',
          icon: Send
        }
      ]
    },
    {
      title: 'Administration & System',
      id: 'sec_admin_system',
      items: [
        {
          id: 'pic_alerts' as NavTab,
          label: 'P.I.C. Notifications',
          badge: b.emailAlerts ? `${b.emailAlerts}` : undefined,
          badgeColor: 'bg-emerald-500 text-slate-950 font-bold',
          icon: MailCheck
        },
        ...(isAdminOrSysadmin ? [
          {
            id: 'user_registry' as NavTab,
            label: 'User & Shift Registry',
            icon: Users
          },
          {
            id: 'sql_hub' as NavTab,
            label: 'MS SQL Server Config',
            icon: Database
          },
          {
            id: 'audit_logs' as NavTab,
            label: 'Audit Trail & Telemetry',
            icon: History
          }
        ] : [])
      ]
    }
  ];

  return (
    <aside className="w-64 bg-[#161616] text-slate-300 border-r border-emerald-900/40 flex flex-col justify-between shrink-0 font-['Plus_Jakarta_Sans'] select-none">
      
      {/* Top JAE Philippines + Quality Management Identity Header */}
      <div className="p-4 bg-gradient-to-b from-[#1f2923] via-[#161f1a] to-[#141414] border-b border-emerald-800/50 flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <JAELogo size="sm" variant="white" />
            <div className="h-4 w-[1px] bg-emerald-600/50" />
            <span className="text-[11px] font-mono text-emerald-400 font-extrabold tracking-wider">JAE PHILIPPINES</span>
          </div>
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" title="System Online"></span>
        </div>

        <div className="flex items-center space-x-2.5 pt-0.5">
          <div className="p-1.5 bg-slate-900 rounded-xl border border-emerald-500/40 shadow-sm shadow-emerald-950/50">
            <ISMSLogo size="sm" showText={false} />
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center space-x-1.5 leading-none">
              <span className="font-extrabold font-['Chakra_Petch'] text-sm tracking-wider text-white">
                iSMS
              </span>
              <span className="text-[9px] px-1.5 py-0.5 bg-pink-950/90 text-pink-300 rounded font-mono font-bold border border-pink-700/60">
                v2.6 QM
              </span>
            </div>
            <span className="text-[10px] text-emerald-300/90 font-semibold tracking-tight mt-0.5 truncate">
              Quality Management Dept.
            </span>
          </div>
        </div>

        {/* Subtle Green & Pink Accent Divider Line */}
        <div className="h-[2px] w-full bg-gradient-to-r from-emerald-500 via-pink-500 to-emerald-500 rounded-full opacity-70 mt-0.5" />
      </div>

      {/* Scrollable Nav Item Area */}
      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-5">
        
        {sections.map((section) => (
          <div key={section.id} className="space-y-1">
            <div className="px-3 pb-1.5 text-[10px] font-extrabold uppercase tracking-widest text-emerald-400 font-['Chakra_Petch'] flex items-center justify-between">
              <span>{section.title}</span>
              {section.id === 'sec_admin_system' && !isAdminOrSysadmin && (
                <span className="text-[9px] text-pink-400/80 font-mono lowercase">standard</span>
              )}
            </div>

            <div className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;

                return (
                  <button
                    key={item.id}
                    id={`nav-item-${item.id}`}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 group ${
                      isActive
                        ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md shadow-pink-900/20'
                        : 'text-slate-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 min-w-0">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                          isActive ? 'text-white' : 'text-slate-400 group-hover:text-pink-400'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono shrink-0 ${
                          item.badgeColor || (isActive ? 'bg-white text-pink-700 font-bold' : 'bg-pink-950/80 text-pink-300 border border-pink-700/50')
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

      </div>

      {/* Footer / Utility Quick Actions */}
      <div className="p-3 border-t border-slate-800 space-y-2 bg-[#141414]">
        
        {/* Bulk Data Import Button */}
        {onOpenImportModal && (
          <button
            onClick={onOpenImportModal}
            className="w-full flex items-center justify-center space-x-2 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-pink-300 rounded-xl text-xs font-bold border border-slate-700 transition-colors shadow-xs"
            title="Bulk import CSV data into system"
          >
            <FolderInput className="w-3.5 h-3.5 text-pink-400" />
            <span>Import CSV Data</span>
          </button>
        )}

        {/* Lock Terminal Action */}
        <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-mono text-[10px] text-slate-400">JAE PHILIPPINES</span>
          </div>

          {onLockStation && (
            <button
              onClick={onLockStation}
              className="text-slate-400 hover:text-rose-400 transition-colors flex items-center space-x-1 text-[10px] font-bold"
              title="Lock Terminal & Switch User"
            >
              <Lock className="w-3 h-3" />
              <span>Lock</span>
            </button>
          )}
        </div>

      </div>

    </aside>
  );
};
