import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  KeyRound, 
  ArrowRight, 
  Building2, 
  AlertCircle, 
  CheckCircle2, 
  Eye, 
  EyeOff,
  Database,
  Key,
  ShieldAlert,
  Loader2
} from 'lucide-react';
import { UserProfile } from '../types';
import { storageService } from '../services/storageService';
import { apiClient } from '../services/apiClient';
import { JAELogo, ISMSLogo } from './BrandingLogos';

interface LoginViewProps {
  onLoginSuccess: (user: UserProfile) => void;
  availableUsers: UserProfile[];
}

export const LoginView: React.FC<LoginViewProps> = ({
  onLoginSuccess,
  availableUsers
}) => {
  const [identifier, setIdentifier] = useState<string>('admin_qm');
  const [password, setPassword] = useState<string>('123456');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [rememberMe, setRememberMe] = useState<boolean>(true);

  // Forced Password Change Modal State (IATF 16949 Mandatory Security Policy)
  const [mustChangeModalOpen, setMustChangeModalOpen] = useState<boolean>(false);
  const [pendingUser, setPendingUser] = useState<UserProfile | null>(null);
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [changePasswordError, setChangePasswordError] = useState<string>('');
  const [isChangingPassword, setIsChangingPassword] = useState<boolean>(false);

  // Background image requested by user (JAE 2nd Plant)
  const bgImage = 'https://www.jae.com/files/user/PH_2ndPlant.jpg?v=1630938457';

  const handleManualLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!identifier.trim()) {
      setErrorMsg('Please enter your Employee ID Number or Username.');
      return;
    }

    if (!password.trim()) {
      setErrorMsg('Please enter your password / security PIN.');
      return;
    }

    setIsLoading(true);

    try {
      // 1. Authoritative API Authentication via ASP.NET Core 8 Web API
      const res = await apiClient.login(identifier.trim(), password.trim());

      if (res.success && res.user) {
        if (res.mustChangePassword) {
          setPendingUser(res.user);
          setMustChangeModalOpen(true);
          setIsLoading(false);
          return;
        }

        storageService.setCurrentUser(res.user);
        setIsLoading(false);
        onLoginSuccess(res.user);
        return;
      }

      // If backend responded with invalid credentials
      if (!res.success && res.message && !res.message.includes('API Connection Failed')) {
        setIsLoading(false);
        setErrorMsg(res.message);
        return;
      }

      // 2. Offline / Local Dev Fallback (When ASP.NET Core API daemon is initializing)
      const users = storageService.getUsers();
      const trimmed = identifier.trim().toLowerCase();
      const matched = users.find(
        (u) =>
          (u.username && u.username.toLowerCase() === trimmed) ||
          (u.idNumber && u.idNumber.toLowerCase() === trimmed) ||
          (u.employeeId && u.employeeId.toLowerCase() === trimmed) ||
          (u.email && u.email.toLowerCase() === trimmed)
      );

      if (!matched) {
        setIsLoading(false);
        setErrorMsg('Invalid Credentials: User or ID Number not found in JAE Registry.');
        return;
      }

      storageService.logAudit(
        'SECURITY',
        'LOGIN',
        matched.id,
        `Successful login to iSMS workspace for ${matched.firstName} ${matched.lastName} (${matched.role})`
      );

      storageService.setCurrentUser(matched);
      setIsLoading(false);
      onLoginSuccess(matched);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMsg(err.message || 'Authentication service error. Please try again.');
    }
  };

  const handlePasswordRotationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangePasswordError('');

    if (!newPassword || newPassword.length < 6) {
      setChangePasswordError('New password must be at least 6 characters.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setChangePasswordError('Passwords do not match.');
      return;
    }

    setIsChangingPassword(true);

    try {
      const res = await apiClient.changePassword(password, newPassword);
      if (res.success && pendingUser) {
        setMustChangeModalOpen(false);
        const updatedUser: UserProfile = { ...pendingUser, mustChangePassword: false };
        storageService.setCurrentUser(updatedUser);
        setIsChangingPassword(false);
        onLoginSuccess(updatedUser);
      } else {
        setIsChangingPassword(false);
        setChangePasswordError(res.message || 'Failed to rotate password.');
      }
    } catch (err: any) {
      // Offline fallback for demo environment
      if (pendingUser) {
        setMustChangeModalOpen(false);
        const updatedUser: UserProfile = { ...pendingUser, mustChangePassword: false };
        storageService.setCurrentUser(updatedUser);
        setIsChangingPassword(false);
        onLoginSuccess(updatedUser);
      } else {
        setIsChangingPassword(false);
        setChangePasswordError(err.message || 'Failed to rotate password.');
      }
    }
  };

  const handleQuickSelectUser = (user: UserProfile) => {
    setIdentifier(user.username || user.idNumber);
    setPassword('123456');
    setErrorMsg('');
  };

  return (
    <div className="relative min-h-screen w-full flex items-center justify-center p-4 select-none overflow-y-auto bg-slate-100 font-['Plus_Jakarta_Sans']">
      {/* Background Image Container with JAE 2nd Plant - Bright and Clear */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat transition-all duration-700 filter brightness-105 saturate-110"
        style={{ backgroundImage: `url('${bgImage}')` }}
      />
      
      {/* Clear/Light Translucent Ambient Overlay */}
      <div className="absolute inset-0 bg-gradient-to-tr from-emerald-950/35 via-slate-900/25 to-white/30 backdrop-blur-[4px]" />

      {/* Main Authentication Card - Translucent Glassmorphism */}
      <div className="relative z-10 w-full max-w-4xl bg-white/90 backdrop-blur-xl border border-white/70 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.25)] overflow-hidden flex flex-col md:flex-row my-8 text-slate-800 transition-all duration-300">
        
        {/* Left Side: Brand, Emblem Logo & Plant Identity */}
        <div className="md:w-5/12 bg-gradient-to-br from-[#064e3b]/95 via-[#043e2f]/95 to-[#022c22]/95 backdrop-blur-md p-6 md:p-8 flex flex-col justify-between border-b md:border-b-0 md:border-r border-emerald-700/60 relative overflow-hidden text-white">
          {/* Ambient Glow */}
          <div className="absolute -right-10 -bottom-10 w-44 h-44 bg-emerald-400/20 rounded-full blur-2xl pointer-events-none" />
          
          <div className="space-y-5">
            {/* JAE Official Logo */}
            <div className="flex items-center justify-between">
              <div className="bg-white px-3 py-1.5 rounded-xl shadow-md">
                <JAELogo size="sm" variant="color" />
              </div>
              <span className="text-[10px] bg-emerald-900/90 text-emerald-300 border border-emerald-500/50 px-2 py-0.5 rounded-full font-mono font-bold uppercase tracking-wider shadow-sm">
                JAE PHILIPPINES • IATF 16949
              </span>
            </div>

            {/* iSMS 3D Emblem and Title */}
            <div className="pt-2">
              <div className="flex items-center gap-3">
                <ISMSLogo size="lg" showText={false} />
                <div>
                  <h1 className="text-3xl font-black text-white tracking-tight font-['Chakra_Petch'] leading-none">
                    iSMS
                  </h1>
                  <p className="text-[11px] text-emerald-200 font-extrabold uppercase tracking-wider font-['Chakra_Petch'] mt-1">
                    Integrated Sample Management System
                  </p>
                </div>
              </div>
              <p className="text-[11px] text-emerald-100/95 mt-2 leading-relaxed font-medium">
                Japan Aviation Electronics Industry, Ltd. (JAE Philippines, Inc.) 
                • Quality Management Department
              </p>
            </div>

            {/* Plant Facility Highlights */}
            <div className="pt-3 border-t border-emerald-700/50 space-y-2 text-xs text-emerald-100/95">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-emerald-300 shrink-0" />
                <span className="font-semibold">1st & 2nd Factory — Gateway Business Park</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-300 shrink-0" />
                <span className="font-semibold">Automotive Connector & Wire Harness QMS</span>
              </div>
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-300 shrink-0" />
                <span className="font-mono text-[11px] text-emerald-200">Database: SQL Server (ISMS_QM_DB)</span>
              </div>
            </div>
          </div>

          <div className="pt-6 mt-4 border-t border-emerald-700/50 text-[10px] font-mono text-emerald-200/90 space-y-1">
            <div className="flex items-center justify-between">
              <span>SYSTEM DEVELOPER:</span>
              <span className="text-emerald-300 font-bold">MPax (Mcst Process Automation Xpress)</span>
            </div>
            <div className="flex items-center justify-between">
              <span>CREATED BY:</span>
              <span className="text-emerald-300 font-bold">RIAH MACASAIT & NEPT DATAHAN</span>
            </div>
            <div className="text-[9px] text-emerald-300/80 pt-1">
              Strict RBAC: Sysadmin • Admin • QM • QA • QC Hold • User
            </div>
          </div>
        </div>

        {/* Right Side: Login Form & Role Presets */}
        <div 
          className="md:w-7/12 p-6 md:p-8 flex flex-col justify-between space-y-6 backdrop-blur-lg border"
          style={{ backgroundColor: '#131010', borderColor: '#cdd2de' }}
        >
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 
                  className="text-lg font-bold font-['Chakra_Petch'] uppercase tracking-wide"
                  style={{ color: '#d1d7e6' }}
                >
                  Log In Here
                </h2>
                <p 
                  className="text-xs text-slate-400 font-medium italic"
                  style={{ fontStyle: 'italic' }}
                >
                  Authenticate with your registered username or Employee ID & credentials
                </p>
              </div>
              <span className="p-2.5 bg-pink-50 border border-pink-200 rounded-xl text-pink-600 shadow-sm">
                <Lock className="w-4 h-4" />
              </span>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-800 text-xs font-semibold shadow-sm">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleManualLogin} className="space-y-4">
              <div>
                <label 
                  className="block text-[11px] font-bold uppercase tracking-wider mb-1.5"
                  style={{ color: '#ee7acd' }}
                >
                  Username or Employee ID Number:
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    id="login-input-identifier"
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="e.g. admin_qm, sysadmin, or JAE-88421"
                    required
                    className="w-full bg-white/95 border border-slate-300 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-900 placeholder-slate-400 font-mono shadow-sm focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 focus:bg-white focus:outline-none transition-all"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label 
                    className="block text-[11px] font-bold uppercase tracking-wider"
                    style={{ color: '#73e174' }}
                  >
                    Password / Secret PIN:
                  </label>
                  <span className="text-[10px] text-pink-400 font-mono font-semibold">JWT BCrypt Auth</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    id="login-input-password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter password..."
                    required
                    className="w-full bg-white/95 border border-slate-300 rounded-xl pl-9 pr-10 py-2.5 text-xs text-slate-900 placeholder-slate-400 font-mono tracking-widest shadow-sm focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 focus:bg-white focus:outline-none transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-700 transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer hover:text-white font-medium">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="rounded bg-white border-slate-300 text-pink-600 focus:ring-pink-500"
                  />
                  <span style={{ color: '#d8dfeb' }}>Remember me next login</span>
                </label>
                <span className="text-[11px] text-emerald-400 font-mono font-semibold">● SQL Server / Web API</span>
              </div>

              <button
                id="btn-submit-login"
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white text-xs font-bold uppercase rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 transform active:scale-98 disabled:opacity-50"
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Authenticating via SQL Server API...
                  </span>
                ) : (
                  <>
                    <span>Sign In to iSMS Workspace</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Quick Workstation Profiles */}
          <div className="pt-4 border-t border-slate-800">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center justify-between">
              <span>Quick Workstation Profiles:</span>
              <span className="text-pink-400 font-mono font-bold">1-Click Fast Select</span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {availableUsers.slice(0, 6).map((u) => (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => handleQuickSelectUser(u)}
                  className="p-2.5 bg-white/10 hover:bg-white/20 border border-slate-700 hover:border-pink-400 rounded-xl text-left transition-all group flex flex-col justify-between shadow-xs hover:shadow-sm"
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[11px] font-bold text-slate-200 group-hover:text-pink-400 truncate">
                      {u.firstName.split(' ')[0]} {u.lastName}
                    </span>
                    <span className={`text-[8px] px-1.5 py-0.5 rounded font-mono font-bold uppercase ${
                      u.role === 'Sysadmin' ? 'bg-amber-900/60 text-amber-300 border border-amber-500/50' :
                      u.role === 'Admin' ? 'bg-pink-900/60 text-pink-300 border border-pink-500/50' :
                      u.role === 'QM' ? 'bg-cyan-900/60 text-cyan-300 border border-cyan-500/50' :
                      u.role === 'QA' ? 'bg-purple-900/60 text-purple-300 border border-purple-500/50' :
                      u.role === 'QC Hold' ? 'bg-rose-900/60 text-rose-300 border border-rose-500/50' :
                      'bg-emerald-900/60 text-emerald-300 border border-emerald-500/50'
                    }`}>
                      {u.role}
                    </span>
                  </div>
                  <div className="text-[9px] text-slate-400 font-mono mt-1 truncate">
                    {u.department} • {u.factory === 'First Factory' ? '1F' : '2F'}
                  </div>
                </button>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* Forced Password Change Modal (First-time login) */}
      {mustChangeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/60 rounded-3xl p-6 shadow-2xl text-white">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-500/40">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold font-['Chakra_Petch'] uppercase tracking-wide text-amber-300">
                  Password Rotation Required
                </h3>
                <p className="text-xs text-slate-400">
                  IATF 16949 / ISO 27001 First-Time Login Policy
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 mb-4 leading-relaxed">
              Your account <strong className="text-white">{pendingUser?.employeeId || pendingUser?.username}</strong> requires you to set a confidential personal password before continuing.
            </p>

            {changePasswordError && (
              <div className="mb-4 p-3 bg-rose-950/60 border border-rose-500/50 rounded-xl flex items-center gap-2 text-rose-300 text-xs font-semibold">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{changePasswordError}</span>
              </div>
            )}

            <form onSubmit={handlePasswordRotationSubmit} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  New Password (min 6 characters):
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Key className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new strong password"
                    required
                    minLength={6}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                  Confirm New Password:
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Key className="w-4 h-4" />
                  </div>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    required
                    minLength={6}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-xs text-white placeholder-slate-500 font-mono focus:border-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isChangingPassword}
                className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs uppercase rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
              >
                {isChangingPassword ? (
                  <span className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Updating Credentials...
                  </span>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm & Enter iSMS Workspace</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Footer Info */}
      <div className="absolute bottom-2 text-center text-[10px] text-slate-700 font-mono font-semibold drop-shadow-sm">
        © JAE Philippines, Inc. Quality Management Department • Integrated Sample Management System (iSMS v4.2)
      </div>
    </div>
  );
};
