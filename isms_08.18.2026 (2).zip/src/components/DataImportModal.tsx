import React, { useState } from 'react';
import {
  UploadCloud,
  FileSpreadsheet,
  Download,
  AlertTriangle,
  CheckCircle2,
  X,
  FileText,
  RefreshCw,
  Database,
  ArrowRight
} from 'lucide-react';
import { storageService } from '../services/storageService';

export type ImportCategory = 
  | 'KEEP_SAMPLE_BOX'
  | 'RSIS_RECORD'
  | 'Y2K_LOCATION'
  | 'PRODUCTION_SCHEDULE'
  | 'USER_REGISTRY';

interface DataImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete: () => void;
  initialCategory?: ImportCategory;
}

export const DataImportModal: React.FC<DataImportModalProps> = ({
  isOpen,
  onClose,
  onImportComplete,
  initialCategory = 'KEEP_SAMPLE_BOX'
}) => {
  const [category, setCategory] = useState<ImportCategory>(initialCategory);
  const [csvText, setCsvText] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<any[]>([]);
  const [importResult, setImportResult] = useState<{ successCount: number; errorCount: number; errors: string[] } | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!isOpen) return null;

  const sampleTemplates: Record<ImportCategory, { name: string; headers: string[]; example: string }> = {
    KEEP_SAMPLE_BOX: {
      name: 'keep_sample_boxes_template.csv',
      headers: ['boxNumber', 'factory', 'requestedBy', 'storageArea', 'section', 'item', 'archiveType', 'dateGenerated', 'rackLocation', 'maxCapacity'],
      example: `boxNumber,factory,requestedBy,storageArea,section,item,archiveType,dateGenerated,rackLocation,maxCapacity
24-08-010-1F,First Factory,Arnel Villanueva,1F MEZZANINE,MX CONNECTOR,MX57 24P Male Housing Master Sample,KS,2024-08-15,RACK-1F-M04,12
24-08-011-2F,Second Factory,Jocelyn Tolentino,F2B STORAGE,MX HARNESS,Toyota Wire Harness Golden Sample,KS,2024-08-20,RACK-2F-B09,15`
    },
    RSIS_RECORD: {
      name: 'rsis_samples_template.csv',
      headers: ['rsIsNumber', 'sampleType', 'issuedBy', 'department', 'section', 'itemName', 'drawingNumber', 'poNumber', 'lotNumber', 'typeOfDefect', 'quantity', 'dateNeeded', 'returnedDueDate'],
      example: `rsIsNumber,sampleType,issuedBy,department,section,itemName,drawingNumber,poNumber,lotNumber,typeOfDefect,quantity,dateNeeded,returnedDueDate
RS-2026-0301,RS Sample,Arnel Villanueva,Assembly,MX CONNECTOR,MX57 Automotive 24P Housing,DWG-MX57-H24,PO-2026-HN-9982,L-260214-M1,High Insertion Force,5,2026-02-14,2026-02-21
IS-2026-0099,IS Sample,Jocelyn Tolentino,Assembly,MX HARNESS,Toyota 16-Pin Harness Sub-Assy,DWG-HAR-TY16,PO-2026-TY-4421,L-260212-H4,Insulation Crimp Deformation,3,2026-02-14,2026-02-21`
    },
    Y2K_LOCATION: {
      name: 'y2k_rack_locations_template.csv',
      headers: ['rackLocation', 'boxNumber', 'storageArea', 'year', 'section', 'item', 'archiveType', 'dateGenerated', 'remarks'],
      example: `rackLocation,boxNumber,storageArea,year,section,item,archiveType,dateGenerated,remarks
RACK-Y2K-A01,24-08-001-1F,Y2K BUILDING,2024,MX CONNECTOR,MX57 Automotive Housing Sample,KS,2024-08-12,A-Row Top Shelf
RACK-2F-B04,24-08-002-2F,F2B STORAGE,2024,MX HARNESS,Toyota Harness Sample,KS,2024-08-20,B-Row Middle Shelf`
    },
    PRODUCTION_SCHEDULE: {
      name: 'production_batches_template.csv',
      headers: ['jobOrderNo', 'partNumber', 'customer', 'lineName', 'factory', 'targetQuantity', 'completedQuantity', 'defectQuantity', 'stage', 'status', 'startDate', 'targetEndDate', 'picName'],
      example: `jobOrderNo,partNumber,customer,lineName,factory,targetQuantity,completedQuantity,defectQuantity,stage,status,startDate,targetEndDate,picName
JO-2026-801,MX57-24P-M-CONN,Honda,Line 1 - Automated Assembly,First Factory,30000,18500,12,Pre-Assembly,In Progress,2026-02-10,2026-02-18,Arnel Villanueva
JO-2026-802,MX34-16P-F-HDR,Toyota,Line 3 - Harness Taping,Second Factory,20000,20000,8,Final Harness Assembly,Completed,2026-02-05,2026-02-12,Jocelyn Tolentino`
    },
    USER_REGISTRY: {
      name: 'jae_employees_template.csv',
      headers: ['idNumber', 'firstName', 'middleName', 'lastName', 'factory', 'employmentStatus', 'department', 'section', 'position', 'username', 'passwordNumeric', 'role', 'email'],
      example: `idNumber,firstName,middleName,lastName,factory,employmentStatus,department,section,position,username,passwordNumeric,role,email
JAE-11201,Carlo,Santos,Ramos,First Factory,JAE-Reg.,Assembly,Mfg. Connector,Engineer_E,c_ramos,123456,User,c.ramos@jae.com.ph
JAE-11202,Maricel,Dela Cruz,Fernandez,First Factory,JAE-Reg.,QA,QA 1F,Sr. Staff_E,m_fernandez,123456,QA,m.fernandez@jae.com.ph`
    }
  };

  const handleDownloadTemplate = () => {
    const tmpl = sampleTemplates[category];
    const blob = new Blob([tmpl.example], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', tmpl.name);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const parseCSV = (text: string) => {
    const lines = text.trim().split(/\r\n|\n/).filter(l => l.trim().length > 0);
    if (lines.length <= 1) {
      setParsedRows([]);
      return;
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const rows: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      // Basic CSV token parser supporting quotes
      const values: string[] = [];
      let inQuotes = false;
      let curVal = '';
      for (let c = 0; c < line.length; c++) {
        const ch = line[c];
        if (ch === '"' && (c === 0 || line[c - 1] !== '\\')) {
          inQuotes = !inQuotes;
        } else if (ch === ',' && !inQuotes) {
          values.push(curVal.trim().replace(/^"|"$/g, ''));
          curVal = '';
        } else {
          curVal += ch;
        }
      }
      values.push(curVal.trim().replace(/^"|"$/g, ''));

      const rowObj: any = {};
      headers.forEach((h, idx) => {
        rowObj[h] = values[idx] !== undefined ? values[idx] : '';
      });
      rows.push(rowObj);
    }

    setParsedRows(rows);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setImportResult(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvText(text);
      parseCSV(text);
    };
    reader.readAsText(file);
  };

  const handlePasteChange = (val: string) => {
    setCsvText(val);
    setImportResult(null);
    parseCSV(val);
  };

  const handleExecuteImport = () => {
    if (parsedRows.length === 0) return;
    setIsProcessing(true);

    setTimeout(() => {
      try {
        const result = storageService.bulkImportData(category, parsedRows);
        setImportResult(result);
        if (result.successCount > 0) {
          onImportComplete();
        }
      } catch (err: any) {
        setImportResult({
          successCount: 0,
          errorCount: parsedRows.length,
          errors: [err.message || 'Fatal import execution error']
        });
      } finally {
        setIsProcessing(false);
      }
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200 font-['Plus_Jakarta_Sans']">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden text-slate-800">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-pink-500/20 text-pink-400 rounded-lg border border-pink-500/30">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight font-['Chakra_Petch'] uppercase flex items-center gap-2">
                <span>JAE iSMS Universal Data Importer</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 font-mono px-2 py-0.5 rounded border border-emerald-500/30">
                  CSV / EXCEL / JSON
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Bulk import Masterlist, Sample Records, Schedules, and User Profiles into local SQL storage.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          
          {/* Target Module Selector & Download Template */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="md:col-span-2 space-y-1.5">
              <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                Select Target Import Module:
              </label>
              <select
                value={category}
                onChange={(e) => {
                  setCategory(e.target.value as ImportCategory);
                  setParsedRows([]);
                  setCsvText('');
                  setFileName('');
                  setImportResult(null);
                }}
                className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-semibold text-slate-800 focus:ring-2 focus:ring-pink-500 focus:outline-none"
              >
                <option value="KEEP_SAMPLE_BOX">📦 Keep Sample Box Number Masterlist</option>
                <option value="RSIS_RECORD">🔍 RS/IS Sample Reject & Inspection Records</option>
                <option value="Y2K_LOCATION">📍 Y2K & Storage Rack Location Masterlist</option>
                <option value="PRODUCTION_SCHEDULE">🏭 Production Batches & Job Orders</option>
                <option value="USER_REGISTRY">👥 JAE User Profiles & Employee Registry</option>
              </select>
            </div>

            <div>
              <button
                type="button"
                onClick={handleDownloadTemplate}
                className="w-full bg-white hover:bg-slate-100 text-slate-700 font-bold px-3 py-2 rounded-lg border border-slate-300 shadow-sm flex items-center justify-center space-x-2 transition-colors"
              >
                <Download className="w-4 h-4 text-emerald-600" />
                <span>Download Sample CSV</span>
              </button>
            </div>
          </div>

          {/* File Upload Zone / Drag & Drop */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div className="border-2 border-dashed border-slate-300 hover:border-pink-500 bg-slate-50/70 rounded-xl p-5 flex flex-col items-center justify-center text-center space-y-2 cursor-pointer transition-colors relative">
              <input
                type="file"
                accept=".csv, .txt, .json"
                onChange={handleFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
              />
              <FileSpreadsheet className="w-8 h-8 text-pink-600" />
              <div className="text-xs font-bold text-slate-700">
                {fileName ? fileName : 'Choose CSV File or Drag & Drop'}
              </div>
              <p className="text-[11px] text-slate-500">
                Supports standard comma-separated `.csv` with header row.
              </p>
            </div>

            {/* Direct Text Paste Option */}
            <div className="space-y-1.5 flex flex-col">
              <div className="flex justify-between items-center text-[11px] font-bold text-slate-700">
                <span>Or Paste Raw CSV Data:</span>
                {parsedRows.length > 0 && (
                  <span className="text-emerald-600 font-mono font-bold">
                    {parsedRows.length} rows parsed
                  </span>
                )}
              </div>
              <textarea
                value={csvText}
                onChange={(e) => handlePasteChange(e.target.value)}
                placeholder="Paste CSV text here..."
                rows={4}
                className="w-full flex-1 bg-white border border-slate-300 rounded-lg p-2.5 font-mono text-[11px] text-slate-800 focus:ring-2 focus:ring-pink-500 focus:outline-none resize-none"
              />
            </div>
          </div>

          {/* Parsed Preview Table */}
          {parsedRows.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-700 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-pink-600" />
                  <span>Parsed Data Preview ({parsedRows.length} Records)</span>
                </span>
                <span className="text-[10px] text-slate-500">
                  Showing first 5 sample rows
                </span>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm max-h-48 overflow-y-auto">
                <table className="w-full text-left text-[11px] border-collapse">
                  <thead className="bg-slate-100 text-slate-700 border-b border-slate-200 sticky top-0 font-bold">
                    <tr>
                      <th className="p-2 border-r">#</th>
                      {Object.keys(parsedRows[0] || {}).slice(0, 6).map((k) => (
                        <th key={k} className="p-2 border-r font-mono text-[10px] uppercase">
                          {k}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {parsedRows.slice(0, 5).map((row, idx) => (
                      <tr key={idx} className="hover:bg-pink-50/40">
                        <td className="p-2 border-r font-mono text-slate-400 font-bold">{idx + 1}</td>
                        {Object.keys(parsedRows[0] || {}).slice(0, 6).map((k) => (
                          <td key={k} className="p-2 border-r font-mono text-slate-700 whitespace-nowrap">
                            {String(row[k] || '-')}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Import Execution Result Alert */}
          {importResult && (
            <div
              className={`p-4 rounded-xl border flex items-start space-x-3 ${
                importResult.errorCount === 0
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-amber-50 border-amber-200 text-amber-900'
              }`}
            >
              {importResult.errorCount === 0 ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1 flex-1">
                <div className="font-bold text-xs">
                  Import Summary: {importResult.successCount} Successful records, {importResult.errorCount} Errors.
                </div>
                {importResult.errors.length > 0 && (
                  <ul className="list-disc pl-4 text-[11px] space-y-0.5 font-mono">
                    {importResult.errors.slice(0, 3).map((err, i) => (
                      <li key={i}>{err}</li>
                    ))}
                    {importResult.errors.length > 3 && (
                      <li>...and {importResult.errors.length - 3} more errors</li>
                    )}
                  </ul>
                )}
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="bg-slate-100 px-6 py-3.5 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-slate-200 text-slate-700 font-bold rounded-lg border border-slate-300 text-xs transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            disabled={parsedRows.length === 0 || isProcessing}
            onClick={handleExecuteImport}
            className={`px-5 py-2 font-bold rounded-lg text-xs flex items-center space-x-2 text-white shadow-md transition-all ${
              parsedRows.length === 0 || isProcessing
                ? 'bg-slate-400 cursor-not-allowed'
                : 'bg-pink-600 hover:bg-pink-700 active:scale-98'
            }`}
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Importing Records...</span>
              </>
            ) : (
              <>
                <ArrowRight className="w-4 h-4" />
                <span>Import {parsedRows.length} Valid Records</span>
              </>
            )}
          </button>
        </div>

      </div>
    </div>
  );
};
