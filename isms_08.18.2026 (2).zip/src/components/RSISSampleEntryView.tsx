import React, { useState } from 'react';
import {
  ScanLine,
  QrCode,
  AlertTriangle,
  Save,
  CheckCircle2,
  Send,
  Search,
  RefreshCw,
  Clock,
  ArrowRight,
  ShieldCheck,
  UserCheck,
  Plus,
  Trash2,
  FileSpreadsheet,
  UploadCloud,
  Lock,
  Info,
  CheckCircle,
  Building,
  ArrowLeft,
  FileText,
  Package,
  Layers,
  History,
  MailCheck,
  AlertCircle,
  ClipboardList,
  Camera,
  Sparkles,
  Zap,
  Check,
  Calendar,
  Tag,
  Hash,
  Barcode,
  X,
  Link2,
  Download,
  ExternalLink
} from 'lucide-react';
import {
  RSISSampleRecord,
  UserProfile,
  DepartmentType,
  SectionType,
  SampleCategory
} from '../types';
import { storageService } from '../services/storageService';
import { JAELogo } from './BrandingLogos';
import { DataImportModal } from './DataImportModal';

interface RSISSampleEntryViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
  onOpenScanner: (onScanned: (val: string) => void) => void;
  initialFilterQuery?: string;
  initialLinkedRequestId?: string;
  onNavigateToRequest?: (requestId?: string) => void;
}

type RSISTab = 
  | 'REQUESTOR_ENTRY'
  | 'QC_HOLD_INTAKE'
  | 'QM_ENDORSEMENT'
  | 'QA_DISPOSITION'
  | 'AUDIT_TRAIL';

export const RSISSampleEntryView: React.FC<RSISSampleEntryViewProps> = ({
  currentUser,
  onRefreshData,
  onOpenScanner,
  initialFilterQuery = '',
  initialLinkedRequestId = '',
  onNavigateToRequest
}) => {
  const [records, setRecords] = useState<RSISSampleRecord[]>(storageService.getRSISRecords());
  const [isMultitabOpen, setIsMultitabOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<RSISTab>('REQUESTOR_ENTRY');
  const [selectedRecordId, setSelectedRecordId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState(initialFilterQuery);
  const [linkedRequestFilter, setLinkedRequestFilter] = useState<string>(initialLinkedRequestId || 'ALL');
  const [filterType, setFilterType] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);
  const [isRequestImportModalOpen, setIsRequestImportModalOpen] = useState<boolean>(false);

  // Synchronize when incoming props change
  React.useEffect(() => {
    if (initialFilterQuery) {
      setSearchQuery(initialFilterQuery);
    }
  }, [initialFilterQuery]);

  React.useEffect(() => {
    if (initialLinkedRequestId) {
      setLinkedRequestFilter(initialLinkedRequestId);
      // If there's an exact matching record, select it
      const match = records.find(r => r.controlNo === initialLinkedRequestId || r.id === initialLinkedRequestId);
      if (match) {
        handleSelectRecordFromMasterlist(match);
      }
    }
  }, [initialLinkedRequestId, records]);

  // RBAC Permission Check for Import (Admin and QC Hold allowed)
  const canImport = currentUser.role === 'Admin' || currentUser.role === 'QC Hold' || currentUser.role === 'Sysadmin';

  // Quick Scan Input State
  const [scanInput, setScanInput] = useState<string>('');
  const [lastParsedScan, setLastParsedScan] = useState<{
    itemName?: string;
    drawingNumber?: string;
    poNumber?: string;
    lotNumber?: string;
    rsIsNumber?: string;
    defect?: string;
    quantity?: number;
  } | null>(null);

  // 1. ISSUED BY / REQUESTOR STATE
  const [controlNo, setControlNo] = useState<string>(storageService.generateNextRSISControlNo());
  const [rsIsNumber, setRsIsNumber] = useState<string>(() => `RS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
  const [sampleType, setSampleType] = useState<'RS Sample' | 'IS Sample'>('RS Sample');
  const [itemName, setItemName] = useState<string>('');
  const [drawingNumber, setDrawingNumber] = useState<string>('');
  const [poNumber, setPoNumber] = useState<string>('');
  const [lotNumber, setLotNumber] = useState<string>('');
  const [typeOfDefect, setTypeOfDefect] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [issuedBy, setIssuedBy] = useState<string>(`${currentUser.firstName} ${currentUser.lastName}`);
  const [section, setSection] = useState<SectionType>(currentUser.section);
  const [department, setDepartment] = useState<DepartmentType>(currentUser.department);
  const [dateForwarded, setDateForwarded] = useState<string>(new Date().toISOString().split('T')[0]);

  // QR Code Scanner Parsing Handler
  const handleProcessQRScan = (rawScanned: string) => {
    if (!rawScanned || !rawScanned.trim()) return;
    const trimmed = rawScanned.trim();

    if (trimmed.includes('|')) {
      // Pipe delimited format: Item Name | Drawing No | PO No | Lot No | RS/IS No | Defect | Qty |
      const rawParts = trimmed.split('|');
      const parts = rawParts.map(p => p.trim());

      const pItemName = parts[0] || '';
      const pDrawingNo = parts[1] || '';
      const pPoNo = parts[2] || '';
      const pLotNo = parts[3] || '';
      const pRsIsNo = parts[4] || '';
      const pDefect = parts[5] || '';
      const pQtyRaw = parts[6] ? parts[6].replace(/[^\d]/g, '') : '';
      const pQty = pQtyRaw ? parseInt(pQtyRaw, 10) : 1;

      if (pItemName) setItemName(pItemName);
      if (pDrawingNo) setDrawingNumber(pDrawingNo);
      if (pPoNo) setPoNumber(pPoNo);
      if (pLotNo) setLotNumber(pLotNo);
      if (pRsIsNo) {
        setRsIsNumber(pRsIsNo);
        if (pRsIsNo.toUpperCase().startsWith('IS')) {
          setSampleType('IS Sample');
        } else if (pRsIsNo.toUpperCase().startsWith('RS')) {
          setSampleType('RS Sample');
        }
      }
      if (pDefect) setTypeOfDefect(pDefect);
      if (pQty && !isNaN(pQty)) setQuantity(pQty);

      setLastParsedScan({
        itemName: pItemName,
        drawingNumber: pDrawingNo,
        poNumber: pPoNo,
        lotNumber: pLotNo,
        rsIsNumber: pRsIsNo,
        defect: pDefect,
        quantity: pQty
      });

      setFeedbackMsg({
        type: 'success',
        text: `QR Scanned & Auto-Split Successfully! Item: ${pItemName} | DWG: ${pDrawingNo} | PO: ${pPoNo} | Lot: ${pLotNo} | RS/IS: ${pRsIsNo} | Defect: ${pDefect} | Qty: ${pQty}`
      });
      setScanInput('');
    } else {
      setItemName(trimmed);
      setFeedbackMsg({
        type: 'info',
        text: `Scanned text inserted into Item Name: "${trimmed}"`
      });
    }
  };

  // 2. QC HOLD STATE
  const [receivedBy, setReceivedBy] = useState<string>('');
  const [dateReceived, setDateReceived] = useState<string>('');
  const [qcHoldStatus, setQcHoldStatus] = useState<'For Filling' | 'No Received Sample' | 'For Disposition' | 'Forwarded' | 'Not Yet Forwarded'>('For Disposition');
  const [qcDateForwarded, setQcDateForwarded] = useState<string>('');
  const [qcReturnedBy, setQcReturnedBy] = useState<string>('');
  const [qcDateReturned, setQcDateReturned] = useState<string>('');
  const [qcForwardedTo, setQcForwardedTo] = useState<string>('');
  const [qcRemarks, setQcRemarks] = useState<string>('');

  // 3. QM DEPARTMENT STATE
  const [qmStaffEngineer, setQmStaffEngineer] = useState<string>('');
  const [qmCategoryOfSample, setQmCategoryOfSample] = useState<SampleCategory>('Connector');
  const [qmEndorsedToQA, setQmEndorsedToQA] = useState<string>('');
  const [qmDate, setQmDate] = useState<string>('');
  const [qmStatus, setQmStatus] = useState<'Forwarded' | 'Not Yet Forwarded' | 'Approved' | 'Not Yet Approved'>('Forwarded');

  // 4. QA DEPARTMENT STATE
  const [qaEngineer, setQaEngineer] = useState<string>('');
  const [qaDateReceived, setQaDateReceived] = useState<string>('');
  const [qaReturnedTo, setQaReturnedTo] = useState<string>('');
  const [qaDateReturned, setQaDateReturned] = useState<string>('');
  const [qaStatus, setQaStatus] = useState<'Open' | 'Closed' | 'Returned'>('Open');
  const [qaFindings, setQaFindings] = useState<string>('');

  // RBAC Permission checks:
  const isSysadmin = currentUser.role === 'Sysadmin';
  const isAdmin = currentUser.role === 'Admin';
  const isQM = currentUser.role === 'QM' || currentUser.role === 'QM Admin' || currentUser.role === 'QM Hold';
  const isQA = currentUser.role === 'QA';
  const isQCHold = currentUser.role === 'QC Hold';

  // Read-Only & Access Control Logic:
  // Automatically set form to read-only if entry has already been approved/returned/closed
  const isRecordLocked = qaStatus === 'Closed' || qaStatus === 'Returned';

  // Granular Sequential Progression Locking:
  // If the sample entry has moved forward or been processed by the next personnel in sequence,
  // lock the buttons and fields of previous pages/tabs to READ-ONLY FOR EVERYONE to prevent unwanted edits!
  const isTab1ProcessedByNext = Boolean(selectedRecordId) && (
    (Boolean(receivedBy) && receivedBy.trim() !== '') ||
    (Boolean(dateReceived) && dateReceived.trim() !== '') ||
    qcHoldStatus === 'Forwarded' ||
    (Boolean(qcDateForwarded) && qcDateForwarded.trim() !== '') ||
    (Boolean(qmStaffEngineer) && qmStaffEngineer.trim() !== '') ||
    (Boolean(qaEngineer) && qaEngineer.trim() !== '') ||
    isRecordLocked
  );

  const isTab2ProcessedByNext = Boolean(selectedRecordId) && (
    (Boolean(qmStaffEngineer) && qmStaffEngineer.trim() !== '') ||
    (Boolean(qmDate) && qmDate.trim() !== '') ||
    qmStatus === 'Approved' ||
    (Boolean(qaEngineer) && qaEngineer.trim() !== '') ||
    (Boolean(qaDateReceived) && qaDateReceived.trim() !== '') ||
    isRecordLocked
  );

  const isTab3ProcessedByNext = Boolean(selectedRecordId) && (
    (Boolean(qaEngineer) && qaEngineer.trim() !== '') ||
    (Boolean(qaDateReceived) && qaDateReceived.trim() !== '') ||
    (Boolean(qaFindings) && qaFindings.trim() !== '') ||
    isRecordLocked
  );

  const isTab4Finalized = Boolean(selectedRecordId) && isRecordLocked;

  const isCurrentTabProgressionLocked = (() => {
    if (activeTab === 'REQUESTOR_ENTRY') return isTab1ProcessedByNext;
    if (activeTab === 'QC_HOLD_INTAKE') return isTab2ProcessedByNext;
    if (activeTab === 'QM_ENDORSEMENT') return isTab3ProcessedByNext;
    if (activeTab === 'QA_DISPOSITION') return isTab4Finalized;
    return false;
  })();

  const progressionLockMessage = (() => {
    if (activeTab === 'REQUESTOR_ENTRY' && isTab1ProcessedByNext) {
      return `Sample entry has already been processed by QC Hold (${receivedBy || 'QC Hold Officer'}). Previous Requestor entry is locked in read-only mode for everyone to prevent unwanted edits.`;
    }
    if (activeTab === 'QC_HOLD_INTAKE' && isTab2ProcessedByNext) {
      return `Sample intake has been endorsed and routed to QM / QA (${qmStaffEngineer || 'QM Staff'}). QC Hold custody details are locked in read-only mode for everyone.`;
    }
    if (activeTab === 'QM_ENDORSEMENT' && isTab3ProcessedByNext) {
      return `Sample evaluation has been processed by QA Investigation (${qaEngineer || 'QA Team'}). QM Endorsement details are locked in read-only mode for everyone.`;
    }
    if (activeTab === 'QA_DISPOSITION' && isTab4Finalized) {
      return `Sample disposition has been finalized (${qaStatus}). All fields and controls are permanently locked in read-only mode for all users.`;
    }
    return '';
  })();

  // User identity normalization for P.I.C. verification
  const currentFullName = `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim().toLowerCase();
  const currentUsername = (currentUser.username || '').toLowerCase();
  const currentEmployeeId = (currentUser.employeeId || currentUser.idNumber || '').toLowerCase();

  const isRequestorPIC = (
    !selectedRecordId ||
    currentFullName === (issuedBy || '').toLowerCase() ||
    currentUsername === (issuedBy || '').toLowerCase() ||
    (currentEmployeeId && currentEmployeeId === (issuedBy || '').toLowerCase()) ||
    isSysadmin || isAdmin
  );

  const isQCHoldPIC = (
    currentFullName === (receivedBy || '').toLowerCase() ||
    currentUsername === (receivedBy || '').toLowerCase() ||
    isQCHold || isSysadmin || isAdmin
  );

  const isQMPIC = (
    currentFullName === (qmStaffEngineer || '').toLowerCase() ||
    currentUsername === (qmStaffEngineer || '').toLowerCase() ||
    isQM || isSysadmin || isAdmin
  );

  const isQAPIC = (
    currentFullName === (qaEngineer || '').toLowerCase() ||
    currentUsername === (qaEngineer || '').toLowerCase() ||
    isQA || isSysadmin || isAdmin
  );

  // Tab-specific P.I.C and Edit Permission Evaluation
  const canEditActiveTab = (() => {
    if (isRecordLocked) return false;
    if (isCurrentTabProgressionLocked) return false;
    if (activeTab === 'REQUESTOR_ENTRY') return isRequestorPIC;
    if (activeTab === 'QC_HOLD_INTAKE') return isQCHoldPIC;
    if (activeTab === 'QM_ENDORSEMENT') return isQMPIC;
    if (activeTab === 'QA_DISPOSITION') return isQAPIC;
    return true;
  })();

  const activeTabPICName = (() => {
    if (activeTab === 'REQUESTOR_ENTRY') return issuedBy || 'Original Requestor';
    if (activeTab === 'QC_HOLD_INTAKE') return receivedBy || 'QC Hold Officer';
    if (activeTab === 'QM_ENDORSEMENT') return qmStaffEngineer || 'QM Staff / Engineer';
    if (activeTab === 'QA_DISPOSITION') return qaEngineer || 'QA Engineer';
    return 'Designated P.I.C.';
  })();

  // Module Integration: Import data from RS/IS Sample Request module
  const handleImportFromRequest = (req: RSISSampleRecord) => {
    setControlNo(req.controlNo);
    setRsIsNumber(req.rsIsNumber || `RS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
    setSampleType(req.sampleType || 'RS Sample');
    setItemName(req.itemName || '');
    setDrawingNumber(req.drawingNumber || '');
    setPoNumber(req.poNumber || '');
    setLotNumber(req.lotNumber || '');
    setQuantity(req.quantity || 1);
    setTypeOfDefect(req.typeOfDefect || req.reason || '');
    setIssuedBy(req.requestorName || req.issuedBy || `${currentUser.firstName} ${currentUser.lastName}`);
    setSection(req.section || currentUser.section);
    setDepartment(req.department || currentUser.department);
    setDateForwarded(req.dateRequested || req.dateForwarded || new Date().toISOString().split('T')[0]);
    setIsRequestImportModalOpen(false);
    setFeedbackMsg({
      type: 'success',
      text: `Integrated & Synchronized with RS/IS Request ${req.controlNo} (${req.itemName}). Entry form populated!`
    });
  };

  const handleOpenNewRecord = () => {
    setSelectedRecordId(null);
    const nextCtrl = storageService.generateNextRSISControlNo();
    setControlNo(nextCtrl);
    setRsIsNumber(`RS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
    setSampleType('RS Sample');
    setItemName('');
    setDrawingNumber('');
    setPoNumber('');
    setLotNumber('');
    setTypeOfDefect('');
    setQuantity(1);
    setIssuedBy(`${currentUser.firstName} ${currentUser.lastName}`);
    setSection(currentUser.section);
    setDepartment(currentUser.department);
    setDateForwarded(new Date().toISOString().split('T')[0]);
    setReceivedBy('');
    setDateReceived('');
    setQcDateForwarded('');
    setQcReturnedBy('');
    setQcDateReturned('');
    setQcForwardedTo('');
    setQcRemarks('');
    setQcHoldStatus('For Disposition');
    setQmStaffEngineer('');
    setQmEndorsedToQA('');
    setQmDate('');
    setQmStatus('Forwarded');
    setQaEngineer('');
    setQaDateReceived('');
    setQaReturnedTo('');
    setQaDateReturned('');
    setQaStatus('Open');
    setQaFindings('');
    setActiveTab('REQUESTOR_ENTRY');
    setIsMultitabOpen(true);
    setFeedbackMsg({
      type: 'info',
      text: `Ready to register new RS/IS sample: ${nextCtrl}. Fill in details across role tabs.`
    });
  };

  const handleSelectRecordFromMasterlist = (rec: RSISSampleRecord) => {
    setSelectedRecordId(rec.id);
    setControlNo(rec.controlNo);
    setRsIsNumber(rec.rsIsNumber);
    setSampleType(rec.sampleType);
    setItemName(rec.itemName);
    setDrawingNumber(rec.drawingNumber);
    setPoNumber(rec.poNumber);
    setLotNumber(rec.lotNumber);
    setTypeOfDefect(rec.typeOfDefect);
    setQuantity(rec.quantity);
    setIssuedBy(rec.issuedBy);
    setSection(rec.section);
    setDepartment(rec.department);
    setDateForwarded(rec.dateForwarded);

    setReceivedBy(rec.receivedBy || 'Rodel Bautista');
    setDateReceived(rec.dateReceived || '');
    setQcHoldStatus(rec.qcHoldStatus);
    setQcDateForwarded(rec.qcDateForwarded || '');
    setQcReturnedBy(rec.qcReturnedBy || '');
    setQcDateReturned(rec.qcDateReturned || '');
    setQcForwardedTo(rec.qcForwardedTo || 'QM / QA Engineering');
    setQcRemarks(rec.qcRemarks || '');

    setQmStaffEngineer(rec.qmStaffEngineer || 'Maria Cristina Reyes');
    setQmCategoryOfSample(rec.qmCategoryOfSample || 'Connector');
    setQmEndorsedToQA(rec.qmEndorsedToQA || 'QA 1F - Eduardo Mendoza');
    setQmDate(rec.qmDate || '');
    setQmStatus(rec.qmStatus || 'Forwarded');

    setQaEngineer(rec.qaEngineer || 'Eduardo Mendoza');
    setQaDateReceived(rec.qaDateReceived || '');
    setQaReturnedTo(rec.qaReturnedTo || '');
    setQaDateReturned(rec.qaDateReturned || '');
    setQaStatus(rec.qaStatus || 'Open');
    setQaFindings(rec.qaFindings || '');

    setActiveTab('REQUESTOR_ENTRY');
    setIsMultitabOpen(true);
  };

  const handleSaveRecord = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    try {
      const saved = storageService.saveRSISRecord({
        id: selectedRecordId || undefined,
        controlNo,
        rsIsNumber,
        sampleType,
        itemName,
        drawingNumber,
        poNumber,
        lotNumber,
        typeOfDefect,
        quantity,
        issuedBy,
        section,
        department,
        dateForwarded,
        receivedBy,
        dateReceived,
        qcHoldStatus,
        qcDateForwarded,
        qcReturnedBy,
        qcDateReturned,
        qcForwardedTo,
        qcRemarks,
        qmStaffEngineer,
        qmCategoryOfSample,
        qmEndorsedToQA,
        qmDate,
        qmStatus,
        qaEngineer,
        qaDateReceived,
        qaReturnedTo,
        qaDateReturned,
        qaStatus,
        qaFindings
      });

      const updated = storageService.getRSISRecords();
      setRecords(updated);
      onRefreshData();
      setSelectedRecordId(saved.id);

      setFeedbackMsg({
        type: 'success',
        text: `RS/IS Sample ${saved.controlNo} successfully saved! P.I.C notifications updated.`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed to save RS/IS record: ${err.message}`
      });
    }
  };

  const handleDeleteRecord = (rec: RSISSampleRecord) => {
    if (!isSysadmin && !isAdmin && !isQM) {
      alert('Access Denied: Only Admin, Sysadmin, or QM can delete RS/IS sample records.');
      return;
    }

    if (window.confirm(`Delete RS/IS Sample record ${rec.controlNo}?`)) {
      try {
        storageService.deleteRSISRecord(rec.id);
        setRecords(storageService.getRSISRecords());
        onRefreshData();
        if (selectedRecordId === rec.id) {
          setIsMultitabOpen(false);
        }
        setFeedbackMsg({
          type: 'success',
          text: `Record ${rec.controlNo} deleted.`
        });
      } catch (err: any) {
        alert(`Error deleting record: ${err.message}`);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Control No',
      'RS/IS Number',
      'Sample Type',
      'Item Name',
      'Drawing No',
      'PO Number',
      'Lot Number',
      'Quantity',
      'Defect Type',
      'Issued By',
      'Section',
      'Department',
      'QC Hold Status',
      'QM Category',
      'QA Status'
    ];

    const rows = records.map((r) => [
      `"${r.controlNo}"`,
      `"${r.rsIsNumber}"`,
      `"${r.sampleType}"`,
      `"${r.itemName}"`,
      `"${r.drawingNumber}"`,
      `"${r.poNumber}"`,
      `"${r.lotNumber}"`,
      `"${r.quantity}"`,
      `"${r.typeOfDefect}"`,
      `"${r.issuedBy}"`,
      `"${r.section}"`,
      `"${r.department}"`,
      `"${r.qcHoldStatus}"`,
      `"${r.qmCategoryOfSample || ''}"`,
      `"${r.qaStatus || ''}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `JAE_RSIS_Sample_Masterlist_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredRecords = records.filter((r) => {
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (r.controlNo || '').toLowerCase().includes(q) ||
      (r.rsIsNumber || '').toLowerCase().includes(q) ||
      (r.itemName || '').toLowerCase().includes(q) ||
      (r.drawingNumber || '').toLowerCase().includes(q) ||
      (r.lotNumber || '').toLowerCase().includes(q) ||
      (r.issuedBy || '').toLowerCase().includes(q);

    const matchesType = filterType === 'All' || r.sampleType === filterType;
    const matchesStatus = filterStatus === 'All' || r.qcHoldStatus === filterStatus || r.qaStatus === filterStatus;
    const matchesLinked = !linkedRequestFilter || linkedRequestFilter === 'ALL' || r.controlNo === linkedRequestFilter || r.rsIsNumber === linkedRequestFilter || r.id === linkedRequestFilter;

    return matchesSearch && matchesType && matchesStatus && matchesLinked;
  });

  const availableRequests = storageService.getRSISRequests();

  return (
    <div id="rsis-sample-entry-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">

      {/* Standardized Colorful Module Header (Green + Pink Palette, compact 3/4 layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <ScanLine className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                RS / IS Sample Entry
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                DEFECT FOR DISPOSITION
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 w-full md:w-auto justify-start md:justify-end">
          {isMultitabOpen ? (
            <button
              onClick={() => setIsMultitabOpen(false)}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5 shadow-sm transition-all border border-slate-700"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Masterlist</span>
            </button>
          ) : (
            <>
              <button
                onClick={handleExportCSV}
                className="px-3 py-1.5 bg-slate-900/80 hover:bg-slate-800 text-emerald-300 rounded-lg text-xs font-bold border border-emerald-700/50 flex items-center space-x-1.5 shadow-xs transition-colors"
                title="Export RS/IS Masterlist to CSV"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>

              {canImport && (
                <button
                  onClick={() => setIsImportModalOpen(true)}
                  className="px-3 py-1.5 bg-emerald-900/80 hover:bg-emerald-800 text-emerald-200 rounded-lg text-xs font-bold border border-emerald-600/60 flex items-center space-x-1.5 shadow-xs transition-colors"
                  title="Import RS/IS Masterlist from CSV / Excel (Admin & QC Hold only)"
                >
                  <UploadCloud className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Import Masterlist</span>
                </button>
              )}

              <button
                id="btn-new-rsis-entry"
                onClick={handleOpenNewRecord}
                className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-sm flex items-center space-x-1.5 transition-all transform active:scale-98"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ New RS/IS Entry</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-xs ${
          feedbackMsg.type === 'success'
            ? 'bg-emerald-950/80 border-emerald-500/70 text-emerald-200'
            : feedbackMsg.type === 'error'
            ? 'bg-rose-950/80 border-rose-500/70 text-rose-200'
            : 'bg-blue-950/80 border-blue-500/70 text-blue-200'
        }`}>
          <div className="flex items-center space-x-2">
            {feedbackMsg.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
            {feedbackMsg.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />}
            {feedbackMsg.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-[11px] underline ml-2 opacity-80 hover:opacity-100"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. MASTERLIST VIEW (Shown only when Multitab is not open) */}
      {/* ========================================================================= */}
      {!isMultitabOpen ? (
        <div className="space-y-4 animate-in fade-in duration-200 w-full">
          
          {/* Top KPIs / Metric Cubes with Vibrant Colored Top Strips */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Cube 1: Total Records (Emerald/Green Theme) */}
            <div className="bg-[#141a16] rounded-xl border border-emerald-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-emerald-700 to-green-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">TOTAL RECORDS</span>
                <ScanLine className="w-3.5 h-3.5 text-emerald-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-white">{records.length}</div>
                <div className="p-2 bg-emerald-950/70 text-emerald-400 rounded-lg border border-emerald-700/50">
                  <ScanLine className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 2: For Disposition (Amber/Orange Theme) */}
            <div className="bg-[#141a16] rounded-xl border border-amber-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-amber-700 to-orange-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">FOR DISPOSITION</span>
                <Clock className="w-3.5 h-3.5 text-amber-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-amber-400">
                  {records.filter(r => r.qcHoldStatus === 'For Disposition' || r.qcHoldStatus === 'For Filling').length}
                </div>
                <div className="p-2 bg-amber-950/70 text-amber-400 rounded-lg border border-amber-700/50">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 3: Forwarded to QA (Blue Theme) */}
            <div className="bg-[#141a16] rounded-xl border border-blue-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-blue-700 to-indigo-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">FORWARDED TO QA</span>
                <Send className="w-3.5 h-3.5 text-blue-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-blue-400">
                  {records.filter(r => r.qmStatus === 'Forwarded' || r.qcHoldStatus === 'Forwarded').length}
                </div>
                <div className="p-2 bg-blue-950/70 text-blue-400 rounded-lg border border-blue-700/50">
                  <Send className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 4: QA Closed (Teal Theme) */}
            <div className="bg-[#141a16] rounded-xl border border-teal-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-teal-700 to-emerald-700 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">QA CLOSED</span>
                <ShieldCheck className="w-3.5 h-3.5 text-teal-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-teal-400">
                  {records.filter(r => r.qaStatus === 'Closed').length}
                </div>
                <div className="p-2 bg-teal-950/70 text-teal-400 rounded-lg border border-teal-700/50">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

          {/* Masterlist Container with High-Contrast Dark-Green Header */}
          <div className="bg-[#121815] rounded-xl shadow-lg border border-emerald-700/60 overflow-hidden w-full space-y-0">
            {/* Integrated RS/IS Request Connected Bar */}
            <div className="px-4 py-2 bg-[#0c241b] border-b border-emerald-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2">
                <div className="p-1.5 bg-pink-900/60 text-pink-300 rounded-md border border-pink-500/40">
                  <Link2 className="w-3.5 h-3.5" />
                </div>
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-pink-300 uppercase tracking-wider font-['Chakra_Petch'] text-[11px]">
                    CONNECTED RS/IS REQUEST FILTER:
                  </span>
                  <select
                    value={linkedRequestFilter}
                    onChange={(e) => setLinkedRequestFilter(e.target.value)}
                    className="bg-[#051c14] border border-pink-500/60 text-pink-200 text-xs font-semibold rounded-lg px-2.5 py-1 focus:ring-1 focus:ring-pink-500 focus:outline-none max-w-xs truncate"
                  >
                    <option value="ALL">All Requests ({availableRequests.length} Total in DB)</option>
                    {availableRequests.map((req) => (
                      <option key={req.id} value={req.controlNo || req.rsIsNumber || req.id}>
                        {req.controlNo} - {req.itemName} ({req.issuedBy || 'Req'}) [{req.qaStatus || req.qcHoldStatus || 'Pending'}]
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                {linkedRequestFilter !== 'ALL' && (
                  <button
                    type="button"
                    onClick={() => {
                      setLinkedRequestFilter('ALL');
                      setSearchQuery('');
                    }}
                    className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold rounded-md flex items-center space-x-1 border border-slate-600 transition-all cursor-pointer"
                  >
                    <X className="w-3 h-3 text-rose-400" />
                    <span>Clear Filter</span>
                  </button>
                )}

                {onNavigateToRequest && (
                  <button
                    type="button"
                    onClick={() => onNavigateToRequest(linkedRequestFilter !== 'ALL' ? linkedRequestFilter : undefined)}
                    className="px-2.5 py-1 bg-gradient-to-r from-teal-700 to-emerald-700 hover:from-teal-600 hover:to-emerald-600 text-white text-[11px] font-bold rounded-md flex items-center space-x-1 border border-teal-500/50 shadow-xs transition-all cursor-pointer"
                    title="Open RS/IS Sample Request module"
                  >
                    <ExternalLink className="w-3 h-3 text-teal-200" />
                    <span>Go to RS/IS Request Module</span>
                  </button>
                )}
              </div>
            </div>

            <div className="px-4 py-2.5 border-b border-emerald-700/60 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-gradient-to-r from-[#064e3b] via-[#095742] to-[#043d2e]">
              <div>
                <h2 className="text-sm md:text-base font-bold text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                  <ScanLine className="w-4 h-4 text-pink-300" />
                  <span className="text-white">REGISTERED RS / IS SAMPLE RECORDS</span>
                  {linkedRequestFilter !== 'ALL' && (
                    <span className="text-[10px] bg-pink-900/80 text-pink-200 px-2 py-0.5 rounded-md border border-pink-500/60 font-mono font-bold">
                      Filtered: {linkedRequestFilter}
                    </span>
                  )}
                </h2>
              </div>  

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-[190px]">
                  <Search className="w-3.5 h-3.5 text-emerald-300 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search control no, drawing, lot..."
                    className="w-full bg-[#0a2820] border border-emerald-500/70 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white-100 placeholder-emerald-200/60 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Types</option>
                  <option value="RS Sample">RS Sample</option>
                  <option value="IS Sample">IS Sample</option>
                </select>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Statuses</option>
                  <option value="For Disposition">For Disposition</option>
                  <option value="For Filling">For Filling</option>
                  <option value="Forwarded">Forwarded</option>
                  <option value="Open">QA Open</option>
                  <option value="Closed">QA Closed</option>
                </select>
              </div>
            </div>

            {/* Space-Maximized Table */}
            <div className="overflow-x-auto">
              <table className="isms-table w-full text-xs">
                <thead>
                  <tr className="bg-[#062c21] text-emerald-200 uppercase text-[10px] tracking-wider border-b border-emerald-700/60">
                    <th className="p-2.5 font-bold text-emerald-100">Control No</th>
                    <th className="p-2.5 font-bold text-emerald-100">Type</th>
                    <th className="p-2.5 font-bold text-emerald-100">Item Description</th>
                    <th className="p-2.5 font-bold text-emerald-100">Drawing / Lot No</th>
                    <th className="p-2.5 font-bold text-emerald-100">Qty</th>
                    <th className="p-2.5 font-bold text-emerald-100">Issued By</th>
                    <th className="p-2.5 font-bold text-emerald-100">QC Status</th>
                    <th className="p-2.5 font-bold text-emerald-100">QM Cat.</th>
                    <th className="p-2.5 font-bold text-emerald-100">QA Status</th>
                    <th className="p-2.5 text-right font-bold text-emerald-100">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-900/40">
                  {filteredRecords.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="p-6 text-center text-emerald-200/70">
                        No RS/IS sample records found. Click "+ New RS/IS Entry" to add one.
                      </td>
                    </tr>
                  ) : (
                    filteredRecords.map((rec) => {
                      const isSelected = selectedRecordId === rec.id;
                      return (
                        <tr
                          key={rec.id}
                          onClick={() => setSelectedRecordId(rec.id)}
                          onDoubleClick={() => handleSelectRecordFromMasterlist(rec)}
                          className={`cursor-pointer transition-colors duration-150 group hover:bg-[#18392d]/80 ${
                            isSelected ? 'bg-pink-950/50' : 'bg-[#101e18]'
                          }`}
                          title="Double-click to open multi-tab workspace"
                        >
                          <td className="p-2.5 font-mono font-bold text-pink-300 group-hover:text-pink-200 whitespace-nowrap">
                            {rec.controlNo}
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              rec.sampleType === 'RS Sample' ? 'bg-amber-900/80 text-amber-200 border border-amber-600' : 'bg-purple-900/80 text-purple-200 border border-purple-600'
                            }`}>
                              {rec.sampleType}
                            </span>
                          </td>
                          <td className="p-2.5 font-semibold text-slate-100 max-w-xs truncate" title={rec.itemName}>
                            {rec.itemName}
                          </td>
                          <td className="p-2.5 font-mono text-emerald-200 whitespace-nowrap">
                            <div>{rec.drawingNumber}</div>
                            <div className="text-[10px] text-pink-300 font-bold">{rec.lotNumber}</div>
                          </td>
                          <td className="p-2.5 font-mono font-bold text-white whitespace-nowrap">
                            {rec.quantity} pcs
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            <div className="font-semibold text-white">{rec.issuedBy}</div>
                            <div className="text-[10px] text-emerald-300">{rec.section}</div>
                          </td>
                          <td className="p-2.5 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                const nextQC = rec.qcHoldStatus === 'Forwarded' ? 'For Disposition' : 'Forwarded';
                                storageService.updateRSISRecord(rec.id, { qcHoldStatus: nextQC as any });
                                setRecords(storageService.getRSISRecords());
                                onRefreshData();
                              }}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-transform active:scale-95 ${
                                rec.qcHoldStatus === 'For Disposition' ? 'bg-rose-900/80 text-rose-200 border-rose-600' :
                                rec.qcHoldStatus === 'Forwarded' ? 'bg-emerald-900/80 text-emerald-200 border-emerald-600' :
                                'bg-blue-900/80 text-blue-200 border-blue-600'
                              }`}
                              title="Click to toggle QC status"
                            >
                              {rec.qcHoldStatus}
                            </button>
                          </td>
                          <td className="p-2.5 font-mono text-emerald-100 whitespace-nowrap">
                            {rec.qmCategoryOfSample || '-'}
                          </td>
                          <td className="p-2.5 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                const nextQA = rec.qaStatus === 'Closed' ? 'Open' : 'Closed';
                                storageService.updateRSISRecord(rec.id, { qaStatus: nextQA });
                                setRecords(storageService.getRSISRecords());
                                onRefreshData();
                              }}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-transform active:scale-95 ${
                                rec.qaStatus === 'Closed' ? 'bg-teal-900/80 text-teal-200 border-teal-600' :
                                rec.qaStatus === 'Returned' ? 'bg-amber-900/80 text-amber-200 border-amber-600' :
                                'bg-blue-900/80 text-blue-200 border-blue-600'
                              }`}
                              title="Click to toggle QA status"
                            >
                              {rec.qaStatus || 'Open'}
                            </button>
                          </td>
                          <td className="p-2.5 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end space-x-1.5">
                              <button
                                onClick={() => handleSelectRecordFromMasterlist(rec)}
                                className="p-1 bg-pink-900/60 hover:bg-pink-800 text-pink-200 rounded border border-pink-600/60 shadow-xs"
                                title="Open Multitab per Roles"
                              >
                                <Layers className="w-3.5 h-3.5" />
                              </button>
                              {(isSysadmin || isAdmin || isQM) && (
                                <button
                                  onClick={() => handleDeleteRecord(rec)}
                                  className="p-1 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded border border-rose-600/60 shadow-xs"
                                  title="Delete"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-[#0d1612] border-t border-emerald-800/60 text-xs text-emerald-300/80 flex justify-between items-center">
              <span>Showing {filteredRecords.length} of {records.length} records</span>
              <span className="font-mono text-[11px] text-pink-300/80">JAE Quality Control Defect Verification Standards</span>
            </div>
          </div>

        </div>
      ) : (
        /* ========================================================================= */
        /* 2. MULTI-TAB WORKSPACE PER ROLES */
        /* ========================================================================= */
        <div className="space-y-6 animate-in fade-in duration-300 w-full">
          
          {/* Multitab Navigation Bar per Roles */}
          <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-2 flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab('REQUESTOR_ENTRY')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'REQUESTOR_ENTRY'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>1. Requestor / P.I.C Entry</span>
            </button>

            <button
              onClick={() => setActiveTab('QC_HOLD_INTAKE')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'QC_HOLD_INTAKE'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>2. QC Hold Intake</span>
            </button>

            <button
              onClick={() => setActiveTab('QM_ENDORSEMENT')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'QM_ENDORSEMENT'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>3. QM Routing & Category</span>
            </button>

            <button
              onClick={() => setActiveTab('QA_DISPOSITION')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'QA_DISPOSITION'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>4. QA Investigation & Result</span>
            </button>

            <button
              onClick={() => setActiveTab('AUDIT_TRAIL')}
              className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'AUDIT_TRAIL'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <History className="w-4 h-4" />
              <span>5. Audit & Alerts</span>
            </button>
          </div>

          {/* Role Tab 1: Requestor / Issued By Form */}
          {activeTab === 'REQUESTOR_ENTRY' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-5 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <FileText className="w-5 h-5 text-pink-400" />
                  <div>
                    <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                      Role: Requestor / Section P.I.C. Entry
                    </h3>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsRequestImportModalOpen(true)}
                    className="px-3 py-1 bg-teal-800/90 hover:bg-teal-700 text-teal-100 font-bold rounded-lg text-xs flex items-center space-x-1.5 border border-teal-500/60 shadow-xs transition-all cursor-pointer"
                    title="Import data directly from RS/IS Sample Request module"
                  >
                    <UploadCloud className="w-3.5 h-3.5 text-teal-300" />
                    <span>Import from RS/IS Request</span>
                  </button>
                  <span className="text-xs font-mono font-bold text-pink-300 bg-pink-950/80 px-3 py-1 rounded-lg border border-pink-700/60 shadow-xs">
                    {controlNo}
                  </span>
                </div>
              </div>

              {/* Status & Access Banners */}
              {isRecordLocked && (
                <div className="p-3 bg-rose-950/80 border border-rose-600/70 rounded-xl flex items-center gap-3 text-rose-200">
                  <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY LOCKED:</span> This RS/IS sample entry has already been completed / dispositioned (Status: {qaStatus}). Modifications are disabled for all users.
                  </div>
                </div>
              )}

              {!isRecordLocked && isCurrentTabProgressionLocked && (
                <div className="p-3 bg-purple-950/80 border border-purple-600/70 rounded-xl flex items-center gap-3 text-purple-200">
                  <Lock className="w-4 h-4 text-purple-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY (STAGE PROCESSED):</span> {progressionLockMessage}
                  </div>
                </div>
              )}

              {!isRecordLocked && !isCurrentTabProgressionLocked && !canEditActiveTab && (
                <div className="p-3 bg-amber-950/80 border border-amber-600/70 rounded-xl flex items-center gap-3 text-amber-200">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 P.I.C. RESTRICTION:</span> You are not the designated Person-in-Charge for this section ({activeTabPICName}). Editing permissions are restricted to read-only.
                  </div>
                </div>
              )}

              {/* QR / 2D Barcode Scan & Quick-Split Intake Section */}
              <div className="p-4 bg-gradient-to-br from-[#0c221a] to-[#091812] border-2 border-emerald-500/70 rounded-xl space-y-3 shadow-md">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <div className="p-2 bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg shadow-xs">
                      <QrCode className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white font-['Chakra_Petch'] uppercase flex items-center gap-2">
                        <span>SCAN THE QR CODE HERE</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={!canEditActiveTab}
                      onClick={() => onOpenScanner((val) => handleProcessQRScan(val))}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-lg text-xs flex items-center space-x-1.5 shadow-xs transition-all cursor-pointer"
                      title="Open Live Camera Barcode / QR Scanner"
                    >
                      <Camera className="w-3.5 h-3.5 text-emerald-200" />
                      <span>Camera Scan</span>
                    </button>
                    <button
                      type="button"
                      disabled={!canEditActiveTab}
                      onClick={() => handleProcessQRScan('MX59A04HF3|A115346 Rev. 4|1026488122|k267284|RS-PHS2600630-1F|Dent on Shield Shell|1008|')}
                      className="px-3 py-1.5 bg-pink-900/80 hover:bg-pink-800 disabled:opacity-50 disabled:cursor-not-allowed text-pink-200 font-bold rounded-lg text-xs flex items-center space-x-1.5 border border-pink-600/60 shadow-xs transition-all cursor-pointer"
                      title="Load sample test string"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-pink-300" />
                      <span>Test QR Example</span>
                    </button>
                  </div>
                </div>

                {/* Scan Input & Action Row */}
                <div className="flex flex-col sm:flex-row items-center gap-2">
                  <div className="relative flex-1 w-full">
                    <ScanLine className="w-4 h-4 text-emerald-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      disabled={!canEditActiveTab}
                      value={scanInput}
                      onChange={(e) => {
                        const val = e.target.value;
                        setScanInput(val);
                        if (val.includes('|') && val.split('|').length >= 4) {
                          handleProcessQRScan(val);
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && scanInput) {
                          e.preventDefault();
                          handleProcessQRScan(scanInput);
                        }
                      }}
                      placeholder="Scan or paste QR (e.g. MX59A04HF3|A115346 Rev. 4|1026488122|k267284|RS-PHS2600630-1F|Dent on Shield Shell|1008|)"
                      className="w-full bg-[#101e18] border-2 border-emerald-500/80 focus:border-pink-500 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-slate-400 shadow-inner focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => handleProcessQRScan(scanInput)}
                    disabled={!scanInput.trim() || !canEditActiveTab}
                    className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow-md transition-all whitespace-nowrap cursor-pointer"
                  >
                    <Zap className="w-3.5 h-3.5 text-yellow-300" />
                    <span>Auto-Split & Fill</span>
                  </button>
                </div>
              </div>

              {/* Form Row 1: Identification & Classification */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Tag className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    CONTROL NUMBER:
                  </label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={controlNo}
                    onChange={(e) => setControlNo(e.target.value)}
                    required
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Layers className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    SAMPLE TYPE:
                  </label>
                  <select
                    disabled={!canEditActiveTab}
                    value={sampleType}
                    onChange={(e) => setSampleType(e.target.value as any)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-bold text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="RS Sample">RS Sample (Reject Sample)</option>
                    <option value="IS Sample">IS Sample (Inspection Sample)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Barcode className="w-3.5 h-3.5 text-pink-400 mr-1.5" />
                    RS / IS NUMBER: <span className="text-pink-400 ml-1 font-bold">*</span>
                  </label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={rsIsNumber}
                    onChange={(e) => setRsIsNumber(e.target.value)}
                    placeholder="e.g. RS-PHS2600630-1F"
                    className="w-full bg-[#0a2820] border-2 border-emerald-500/80 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-300 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Form Row 2: Part & Specifications (Item Name, Drawing No, P.O No) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Package className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    ITEM NAME / DESCRIPTION: <span className="text-pink-400 ml-1 font-bold">*</span>
                  </label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    required
                    placeholder="e.g. MX59A04HF3"
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <FileText className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    DRAWING NUMBER:
                  </label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={drawingNumber}
                    onChange={(e) => setDrawingNumber(e.target.value)}
                    placeholder="e.g. A115346 Rev. 4"
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono font-semibold text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Hash className="w-3.5 h-3.5 text-pink-400 mr-1.5" />
                    P.O. NUMBER (PURCHASE ORDER):
                  </label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={poNumber}
                    onChange={(e) => setPoNumber(e.target.value)}
                    placeholder="e.g. 1026488122"
                    className="w-full bg-[#0a2820] border-2 border-emerald-500/80 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-300 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Form Row 3: Lot, Quantity & Schedule */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Layers className="w-3.5 h-3.5 text-pink-400 mr-1.5" />
                    LOT NUMBER:
                  </label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={lotNumber}
                    onChange={(e) => setLotNumber(e.target.value)}
                    placeholder="e.g. k267284"
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Hash className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    QUANTITY (PCS):
                  </label>
                  <input
                    type="number"
                    min={1}
                    disabled={!canEditActiveTab}
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Calendar className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    DATE FORWARDED:
                  </label>
                  <input
                    type="date"
                    disabled={!canEditActiveTab}
                    value={dateForwarded}
                    onChange={(e) => setDateForwarded(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Form Row 4: Defect / Phenomenon Portion */}
              <div>
                <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 mr-1.5" />
                  TYPE OF DEFECT / PHENOMENON (REASON):
                </label>
                <textarea
                  rows={2}
                  disabled={!canEditActiveTab}
                  value={typeOfDefect}
                  onChange={(e) => setTypeOfDefect(e.target.value)}
                  placeholder="Describe failure phenomenon observed during production or test (e.g. Dent on Shield Shell)..."
                  className="w-full bg-[#0a2820] border-2 border-emerald-500/80 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl p-2.5 text-xs text-white placeholder-emerald-400/50 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                />
              </div>

              {/* Form Row 5: Requestor Identity & Location Attribution */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-emerald-800/60">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    ISSUED BY (REQUESTOR):
                  </label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={issuedBy}
                    onChange={(e) => setIssuedBy(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Building className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    SECTION:
                  </label>
                  <select
                    disabled={!canEditActiveTab}
                    value={section}
                    onChange={(e) => setSection(e.target.value as SectionType)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-bold text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="MX CONNECTOR">MX CONNECTOR</option>
                    <option value="MX HARNESS">MX HARNESS</option>
                    <option value="MX PRE ASSY">MX PRE ASSY</option>
                    <option value="MX57 MANUAL">MX57 MANUAL</option>
                    <option value="MX57 AUTO">MX57 AUTO</option>
                    <option value="VARIOUS">VARIOUS</option>
                    <option value="MX HONDA">MX HONDA</option>
                    <option value="QM/IQC">QM/IQC</option>
                    <option value="OQC">OQC</option>
                    <option value="QA/QC">QA/QC</option>
                    <option value="STAMPING">STAMPING</option>
                    <option value="MOLDING">MOLDING</option>
                    <option value="WAREHOUSE">WAREHOUSE</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1.5 flex items-center">
                    <Building className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    DEPARTMENT:
                  </label>
                  <select
                    disabled={!canEditActiveTab}
                    value={department}
                    onChange={(e) => setDepartment(e.target.value as DepartmentType)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-bold text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="Assembly">Assembly</option>
                    <option value="Engineering">Engineering</option>
                    <option value="Quality Assurance">Quality Assurance</option>
                    <option value="Production Control">Production Control</option>
                    <option value="Warehouse & Logistics">Warehouse & Logistics</option>
                    <option value="Quality Management">Quality Management</option>
                    <option value="Administration">Administration</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setIsMultitabOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to Masterlist</span>
                </button>
                <div className="flex items-center space-x-3">
                  {canEditActiveTab && (
                    <button
                      type="button"
                      onClick={() => handleSaveRecord()}
                      className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Record</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      if (canEditActiveTab) handleSaveRecord();
                      setActiveTab('QC_HOLD_INTAKE');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <span>Proceed to QC Hold Intake →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Role Tab 2: QC Hold Intake */}
          {activeTab === 'QC_HOLD_INTAKE' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    Role: QC Hold Area Custody & Intake
                  </h3>
                </div>
              </div>

              {/* Status & Access Banners */}
              {isRecordLocked && (
                <div className="p-3 bg-rose-950/80 border border-rose-600/70 rounded-xl flex items-center gap-3 text-rose-200">
                  <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY LOCKED:</span> This RS/IS sample entry has already been completed / dispositioned (Status: {qaStatus}). Modifications are disabled for all users.
                  </div>
                </div>
              )}

              {!isRecordLocked && isCurrentTabProgressionLocked && (
                <div className="p-3 bg-purple-950/80 border border-purple-600/70 rounded-xl flex items-center gap-3 text-purple-200">
                  <Lock className="w-4 h-4 text-purple-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY (STAGE PROCESSED):</span> {progressionLockMessage}
                  </div>
                </div>
              )}

              {!isRecordLocked && !isCurrentTabProgressionLocked && !canEditActiveTab && (
                <div className="p-3 bg-amber-950/80 border border-amber-600/70 rounded-xl flex items-center gap-3 text-amber-200">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 P.I.C. RESTRICTION:</span> You are not the designated Person-in-Charge for QC Hold Intake ({activeTabPICName}). Editing permissions are restricted to read-only.
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">RECEIVED BY (QC HOLD):</label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={receivedBy}
                    onChange={(e) => setReceivedBy(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">DATE RECEIVED:</label>
                  <input
                    type="date"
                    disabled={!canEditActiveTab}
                    value={dateReceived}
                    onChange={(e) => setDateReceived(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QC HOLD STATUS:</label>
                  <select
                    disabled={!canEditActiveTab}
                    value={qcHoldStatus}
                    onChange={(e) => setQcHoldStatus(e.target.value as any)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="For Disposition">For Disposition</option>
                    <option value="For Filling">For Filling</option>
                    <option value="No Received Sample">No Received Sample</option>
                    <option value="Forwarded">Forwarded</option>
                    <option value="Not Yet Forwarded">Not Yet Forwarded</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">FORWARDED TO:</label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={qcForwardedTo}
                    onChange={(e) => setQcForwardedTo(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">DATE FORWARDED TO QM/QA:</label>
                  <input
                    type="date"
                    disabled={!canEditActiveTab}
                    value={qcDateForwarded}
                    onChange={(e) => setQcDateForwarded(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QC REMARKS:</label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={qcRemarks}
                    onChange={(e) => setQcRemarks(e.target.value)}
                    placeholder="Inspection note..."
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs text-white placeholder-emerald-400/50 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('REQUESTOR_ENTRY')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: Requestor Entry</span>
                </button>
                <div className="flex items-center space-x-3">
                  {canEditActiveTab && (
                    <button
                      type="button"
                      onClick={() => handleSaveRecord()}
                      className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Changes</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      if (canEditActiveTab) handleSaveRecord();
                      setActiveTab('QM_ENDORSEMENT');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <span>Proceed to QM Routing & Category →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Role Tab 3: QM Department Endorsement */}
          {activeTab === 'QM_ENDORSEMENT' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    Role: Quality Management (QM) Evaluation & Routing
                  </h3>
                </div>
              </div>

              {/* Status & Access Banners */}
              {isRecordLocked && (
                <div className="p-3 bg-rose-950/80 border border-rose-600/70 rounded-xl flex items-center gap-3 text-rose-200">
                  <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY LOCKED:</span> This RS/IS sample entry has already been completed / dispositioned (Status: {qaStatus}). Modifications are disabled for all users.
                  </div>
                </div>
              )}

              {!isRecordLocked && isCurrentTabProgressionLocked && (
                <div className="p-3 bg-purple-950/80 border border-purple-600/70 rounded-xl flex items-center gap-3 text-purple-200">
                  <Lock className="w-4 h-4 text-purple-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY (STAGE PROCESSED):</span> {progressionLockMessage}
                  </div>
                </div>
              )}

              {!isRecordLocked && !isCurrentTabProgressionLocked && !canEditActiveTab && (
                <div className="p-3 bg-amber-950/80 border border-amber-600/70 rounded-xl flex items-center gap-3 text-amber-200">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 P.I.C. RESTRICTION:</span> You are not the designated Person-in-Charge for QM Routing ({activeTabPICName}). Editing permissions are restricted to read-only.
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QM STAFF / ENGINEER:</label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={qmStaffEngineer}
                    onChange={(e) => setQmStaffEngineer(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">CATEGORY OF SAMPLE:</label>
                  <select
                    disabled={!canEditActiveTab}
                    value={qmCategoryOfSample}
                    onChange={(e) => setQmCategoryOfSample(e.target.value as SampleCategory)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-bold text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="Connector">Connector</option>
                    <option value="Harness">Harness</option>
                    <option value="Molding">Molding</option>
                    <option value="Stamping">Stamping</option>
                    <option value="Pre-Assy">Pre-Assy</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">ENDORSED TO QA PIC:</label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={qmEndorsedToQA}
                    onChange={(e) => setQmEndorsedToQA(e.target.value)}
                    placeholder="e.g. QA 1F - Eduardo Mendoza"
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QM ENDORSEMENT DATE:</label>
                  <input
                    type="date"
                    disabled={!canEditActiveTab}
                    value={qmDate}
                    onChange={(e) => setQmDate(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QM ROUTING STATUS:</label>
                  <select
                    disabled={!canEditActiveTab}
                    value={qmStatus}
                    onChange={(e) => setQmStatus(e.target.value as any)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-bold text-emerald-300 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="Forwarded">Forwarded to QA</option>
                    <option value="Not Yet Forwarded">Not Yet Forwarded</option>
                    <option value="Approved">Approved</option>
                    <option value="Not Yet Approved">Not Yet Approved</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('QC_HOLD_INTAKE')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: QC Hold Intake</span>
                </button>
                <div className="flex items-center space-x-3">
                  {canEditActiveTab && (
                    <button
                      type="button"
                      onClick={() => handleSaveRecord()}
                      className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Changes</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      if (canEditActiveTab) handleSaveRecord();
                      setActiveTab('QA_DISPOSITION');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <span>Proceed to QA Investigation & Result →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Role Tab 4: QA Department Disposition */}
          {activeTab === 'QA_DISPOSITION' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    Role: Quality Assurance (QA) Investigation & Root Cause Disposition
                  </h3>
                </div>
              </div>

              {/* Status & Access Banners */}
              {isRecordLocked && (
                <div className="p-3 bg-rose-950/80 border border-rose-600/70 rounded-xl flex items-center gap-3 text-rose-200">
                  <Lock className="w-4 h-4 text-rose-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY LOCKED:</span> This RS/IS sample entry has already been completed / dispositioned (Status: {qaStatus}). Modifications are disabled for all users.
                  </div>
                </div>
              )}

              {!isRecordLocked && isCurrentTabProgressionLocked && (
                <div className="p-3 bg-purple-950/80 border border-purple-600/70 rounded-xl flex items-center gap-3 text-purple-200">
                  <Lock className="w-4 h-4 text-purple-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 READ-ONLY (STAGE PROCESSED):</span> {progressionLockMessage}
                  </div>
                </div>
              )}

              {!isRecordLocked && !isCurrentTabProgressionLocked && !canEditActiveTab && (
                <div className="p-3 bg-amber-950/80 border border-amber-600/70 rounded-xl flex items-center gap-3 text-amber-200">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <span className="font-bold">🔒 P.I.C. RESTRICTION:</span> You are not the designated Person-in-Charge for QA Disposition ({activeTabPICName}). Editing permissions are restricted to read-only.
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QA ENGINEER:</label>
                  <input
                    type="text"
                    disabled={!canEditActiveTab}
                    value={qaEngineer}
                    onChange={(e) => setQaEngineer(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QA DATE RECEIVED:</label>
                  <input
                    type="date"
                    disabled={!canEditActiveTab}
                    value={qaDateReceived}
                    onChange={(e) => setQaDateReceived(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QA INVESTIGATION STATUS:</label>
                  <select
                    disabled={!canEditActiveTab}
                    value={qaStatus}
                    onChange={(e) => setQaStatus(e.target.value as any)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl px-3 py-2 text-xs font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="Open">Open (Under Investigation)</option>
                    <option value="Closed">Closed (Disposition Concluded)</option>
                    <option value="Returned">Returned to Production</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-emerald-200 uppercase tracking-wider mb-1">QA FINDINGS & ROOT CAUSE ANALYSIS:</label>
                <textarea
                  rows={3}
                  disabled={!canEditActiveTab}
                  value={qaFindings}
                  onChange={(e) => setQaFindings(e.target.value)}
                  placeholder="Root cause, tooling inspection results, corrective action reference (CAR / 8D)..."
                  className="w-full bg-[#0a2820] border border-emerald-600/70 disabled:opacity-60 disabled:cursor-not-allowed rounded-xl p-2.5 text-xs text-white placeholder-emerald-400/50 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                />
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('QM_ENDORSEMENT')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: QM Routing</span>
                </button>
                <div className="flex items-center space-x-3">
                  {canEditActiveTab && (
                    <button
                      type="button"
                      onClick={() => handleSaveRecord()}
                      className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save & Finalize QA</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      if (canEditActiveTab) handleSaveRecord();
                      setActiveTab('AUDIT_TRAIL');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <span>Proceed to Audit & Alerts →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Role Tab 5: Audit & Notification */}
          {activeTab === 'AUDIT_TRAIL' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                    <MailCheck className="w-4 h-4 text-pink-400" />
                    <span>Automated Personnel Notifications & Sign-Off History</span>
                  </h3>
                </div>
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-[#0d1f18] rounded-xl border border-emerald-700/60 flex items-start space-x-3">
                  <CheckCircle className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-bold text-emerald-200">Personnel Email Notification Triggered</div>
                    <p className="text-[11px] text-emerald-300/80">
                      Alert sent to {issuedBy} ({section}) and QA Engineer {qaEngineer} on status update ({qaStatus}).
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-[#17231c] rounded-xl border border-emerald-800/60 flex items-start space-x-3">
                  <Clock className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                  <div>
                    <div className="font-bold text-emerald-100">Forwarded to QC Hold</div>
                    <p className="text-[11px] text-emerald-400/70 font-mono">Date: {dateForwarded} by {issuedBy}</p>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('QA_DISPOSITION')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: QA Investigation</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsMultitabOpen(false)}
                  className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all border border-slate-700"
                >
                  <span>Return to RS/IS Masterlist</span>
                </button>
              </div>
            </div>
          )}

        </div>
      )}

      {/* JAE Universal Data Import Modal for Admin and QC Hold */}
      {isImportModalOpen && (
        <DataImportModal
          isOpen={isImportModalOpen}
          onClose={() => setIsImportModalOpen(false)}
          onImportComplete={() => {
            setRecords(storageService.getRSISRecords());
            onRefreshData();
            setFeedbackMsg({
              type: 'success',
              text: 'RS/IS Masterlist records imported and synchronized successfully!'
            });
          }}
          initialCategory="RSIS_RECORD"
        />
      )}

      {/* RS / IS Request Integration Import Modal */}
      {isRequestImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#0f1712] border-2 border-emerald-500/80 rounded-2xl max-w-3xl w-full max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] border-b border-emerald-600/70 text-white flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <UploadCloud className="w-5 h-5 text-teal-300" />
                <div>
                  <h3 className="font-bold text-sm font-['Chakra_Petch'] uppercase tracking-wide">
                    Import from RS / IS Sample Request Module
                  </h3>
                  <p className="text-[11px] text-emerald-200">
                    Select a submitted request to automatically populate this entry form
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsRequestImportModalOpen(false)}
                className="p-1 text-emerald-200 hover:text-white rounded-lg hover:bg-emerald-700/50 transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 overflow-y-auto space-y-3 flex-1 text-xs">
              {(() => {
                const requests = (storageService as any).getRSISRequests ? (storageService as any).getRSISRequests() : storageService.getRSISRecords();
                // Also fallback to any KeepSampleRequests marked as RS Sample or general requests
                const ksRequests = storageService.getKeepSampleRequests
                  ? storageService.getKeepSampleRequests().filter(r => r.typeOfBorrowedSample === 'RS Sample')
                  : [];
                
                const allImportable = [...requests, ...ksRequests];

                if (allImportable.length === 0) {
                  return (
                    <div className="p-8 text-center bg-[#141e17] rounded-xl border border-emerald-800/60 text-slate-400 space-y-2">
                      <FileSpreadsheet className="w-8 h-8 text-emerald-500 mx-auto opacity-50" />
                      <p className="font-semibold text-emerald-200">No Pending RS / IS Requests Found</p>
                      <p className="text-[11px] text-slate-400">
                        Create a request in the RS / IS Sample Request module first, or enter details manually.
                      </p>
                    </div>
                  );
                }

                return (
                  <div className="space-y-2.5">
                    {allImportable.map((req: any) => {
                      const firstItem = req.items && req.items[0];
                      const itemTitle = firstItem?.itemName || req.itemName || req.item || 'N/A';
                      const poVal = firstItem?.poNumber || req.poNumber || req.po || 'N/A';
                      const lotVal = firstItem?.lotNumber || req.lotNumber || req.lot || 'N/A';
                      const drawingVal = firstItem?.drawingNumber || req.drawingNumber || 'N/A';
                      const qtyVal = firstItem?.quantity || req.quantity || 1;
                      const defectVal = firstItem?.defectType || req.reason || req.typeOfDefect || 'RS/IS Investigation';

                      return (
                        <div
                          key={req.id || req.controlNo}
                          className="p-3.5 bg-[#121c16] hover:bg-[#16251c] border border-emerald-700/60 hover:border-teal-500 rounded-xl transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-pink-400 text-xs">
                                {req.controlNo}
                              </span>
                              <span className="px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-700/70 rounded-md text-[10px] font-bold">
                                {req.sampleType || 'RS Sample'}
                              </span>
                              <span className="text-[10px] text-slate-400">
                                {req.date || req.dateRequested || 'Recent'}
                              </span>
                            </div>
                            <div className="text-white font-semibold flex items-center gap-2">
                              <span>Part: <strong className="text-emerald-300">{itemTitle}</strong></span>
                              <span className="text-slate-500">|</span>
                              <span>P.O: <span className="font-mono text-pink-300">{poVal}</span></span>
                              <span className="text-slate-500">|</span>
                              <span>Lot: <span className="font-mono text-amber-300">{lotVal}</span></span>
                            </div>
                            <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-x-3">
                              <span>Requestor: <strong className="text-slate-200">{req.requestorName || req.issuedBy || 'Staff'}</strong></span>
                              <span>Section: <span className="text-slate-300">{req.section || 'MX CONNECTOR'}</span></span>
                              <span>Qty: <strong className="text-emerald-400">{qtyVal} pcs</strong></span>
                            </div>
                            {defectVal && (
                              <p className="text-[11px] text-amber-300/90 italic">
                                Reason/Defect: {defectVal}
                              </p>
                            )}
                          </div>

                          <button
                            type="button"
                            onClick={() => handleImportFromRequest(req)}
                            className="px-4 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow-sm transition-all cursor-pointer whitespace-nowrap"
                          >
                            <Zap className="w-3.5 h-3.5 text-yellow-300" />
                            <span>Import to Entry</span>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                );
              })()}
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-[#0d1611] border-t border-emerald-800/60 flex justify-end">
              <button
                type="button"
                onClick={() => setIsRequestImportModalOpen(false)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
