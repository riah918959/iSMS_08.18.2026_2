import React, { useState } from 'react';
import {
  QrCode,
  ScanLine,
  X,
  Camera,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  PackageCheck
} from 'lucide-react';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanned: (result: string) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScanned
}) => {
  const [manualCode, setManualCode] = useState('');

  if (!isOpen) return null;

  const samplePresets = [
    {
      label: 'RS Sample: MX57A02HQA (Pin Insertion High)',
      payload: 'RS-2026-0150|MX57A02HQA|DWG-MX57-H24|PO-2026-HN-9982|L-260214-M1|5|Pin Insertion Force Exceeds Spec'
    },
    {
      label: 'RS Sample: MX34 Terminal 16P (Crimp Flare)',
      payload: 'RS-2026-0151|MX34 Terminal Header 16P|DWG-MX34-16P-01|PO-2026-TY-4421|L-260214-T3|3|Terminal Crimp Flare'
    },
    {
      label: 'Keep Sample Box: 24-08-001-1F (Mezzanine M04)',
      payload: '24-08-001-1F'
    },
    {
      label: 'Keep Sample Box: 24-08-002-1F (Mezzanine M02)',
      payload: '24-08-002-1F'
    },
    {
      label: 'Keep Sample Box: 25-01-001-2F (F2B B01)',
      payload: '25-01-001-2F'
    }
  ];

  const handleApplyPayload = (val: string) => {
    onScanned(val);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-[#044e3b] to-emerald-800 text-white p-4 flex items-center justify-between font-['Chakra_Petch']">
          <div className="flex items-center space-x-2">
            <ScanLine className="w-5 h-5 text-emerald-400" />
            <span className="font-bold tracking-wide text-sm uppercase">
              Optical Barcode &amp; QR Scanner Engine
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:text-pink-300 p-1 rounded transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scanner Simulation Viewfinder */}
        <div className="p-6 space-y-5 text-xs">
          
          <div className="relative bg-slate-950 rounded-xl p-6 flex flex-col items-center justify-center text-center overflow-hidden border border-slate-800 shadow-inner">
            {/* Viewfinder corner lines */}
            <div className="w-48 h-32 border-2 border-dashed border-emerald-400/70 rounded-lg relative flex items-center justify-center">
              {/* Laser scanning beam animation */}
              <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 animate-pulse top-1/2 shadow-[0_0_8px_rgba(236,72,153,0.8)]" />
              <QrCode className="w-16 h-16 text-slate-600" />
            </div>
            <p className="text-slate-400 text-[11px] mt-3 font-mono">
              Align 2D DataMatrix or Code-128 Barcode inside target
            </p>
          </div>

          {/* Quick Click Sample Presets for Testing */}
          <div className="space-y-2">
            <span className="font-bold text-slate-700 uppercase tracking-wider block font-['Chakra_Petch']">
              Quick Scan Presets (Live Simulation):
            </span>
            <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
              {samplePresets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleApplyPayload(preset.payload)}
                  className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-pink-50 hover:border-pink-300 border border-slate-200 transition-all flex items-center justify-between group"
                >
                  <div className="truncate mr-2">
                    <div className="font-semibold text-slate-800 text-[11px] group-hover:text-pink-700">
                      {preset.label}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono truncate">
                      {preset.payload}
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-pink-600 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Manual Input Fallback */}
          <div className="pt-2 border-t border-slate-200 space-y-2">
            <label className="font-bold text-slate-700 uppercase block">
              Or Type / Paste Barcode Value:
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="Scan or type barcode string..."
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-pink-500 focus:outline-none"
              />
              <button
                onClick={() => {
                  if (manualCode.trim()) handleApplyPayload(manualCode.trim());
                }}
                disabled={!manualCode.trim()}
                className="px-4 py-2 bg-[#044e3b] hover:bg-emerald-800 text-white font-bold rounded-lg text-xs disabled:opacity-40 transition-colors"
              >
                Submit
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
