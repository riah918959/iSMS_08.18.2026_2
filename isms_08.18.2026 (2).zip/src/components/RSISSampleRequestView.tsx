import React, { useState } from 'react';
import {
  Send,
  Plus,
  Trash2,
  Save,
  Search,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText,
  UserCheck,
  ArrowLeft,
  Calendar,
  Layers,
  FileSpreadsheet,
  ShieldCheck,
  History,
  MailCheck,
  Mail,
  CheckCircle,
  Info,
  PackageCheck,
  QrCode,
  AlertTriangle,
  X,
  ChevronDown,
  Printer
} from 'lucide-react';
import {
  RSISSampleRecord,
  UserProfile,
  DepartmentType,
  SectionType,
  SampleCategory
} from '../types';
import { storageService } from '../services/storageService';
import { JAELogo } from './BrandingLogos';

interface RSISSampleRequestViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
  onNavigateToEntry?: (recordId?: string, filterQuery?: string) => void;
}

type RSISReqTab = 
  | 'REQUESTOR_REQUISITION'
  | 'QM_APPROVAL'
  | 'QC_DISPATCH'
  | 'QA_RETURN_DISPOSITION'
  | 'NOTIFICATIONS_AUDIT';

export const RSISSampleRequestView: React.FC<RSISSampleRequestViewProps> = ({
  currentUser,
  onRefreshData,
  onNavigateToEntry
}) => {
  const [records, setRecords] = useState<RSISSampleRecord[]>(storageService.getRSISRecords());
  const [isMultitabOpen, setIsMultitabOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<RSISReqTab>('REQUESTOR_REQUISITION');
  const [selectedReqId, setSelectedReqId] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [sampleSearchQuery, setSampleSearchQuery] = useState('');
  const [selectedBoxId, setSelectedBoxId] = useState('');
  const [filterType, setFilterType] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [printModalRecord, setPrintModalRecord] = useState<RSISSampleRecord | null>(null);

  const handlePrintRSISReport = (rec: RSISSampleRecord) => {
    setPrintModalRecord(rec);
  };

  const handleTriggerBrowserPrint = () => {
    window.print();
  };

  // 1. REQUESTOR STATE
  const [controlNo, setControlNo] = useState<string>(storageService.generateNextRSISControlNo());
  const [dateRequested, setDateRequested] = useState<string>(new Date().toISOString().split('T')[0]);
  const [requestorName, setRequestorName] = useState<string>(`${currentUser.firstName} ${currentUser.lastName}`);
  const [department, setDepartment] = useState<DepartmentType>(currentUser.department);
  const [section, setSection] = useState<SectionType>(currentUser.section);
  const [sampleType, setSampleType] = useState<'RS Sample' | 'IS Sample'>('RS Sample');
  const [rsIsNumber, setRsIsNumber] = useState<string>('RS-2026-0201');
  const [itemName, setItemName] = useState<string>('MX34 Automotive Terminal Header 16P');
  const [drawingNumber, setDrawingNumber] = useState<string>('DWG-MX34-16P-01');
  const [poNumber, setPoNumber] = useState<string>('PO-2026-TY-4421');
  const [lotNumber, setLotNumber] = useState<string>('L-260214-T3');
  const [quantity, setQuantity] = useState<number>(3);
  const [dateNeeded, setDateNeeded] = useState<string>(new Date().toISOString().split('T')[0]);
  const [returnedDueDate, setReturnedDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [reason, setReason] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  // 2. QM DEPARTMENT STATE
  const [qmStaffEngineer, setQmStaffEngineer] = useState<string>('');
  const [qmEndorsedToQC, setQmEndorsedToQC] = useState<string>('');
  const [qmDate, setQmDate] = useState<string>('');
  const [qmStatus, setQmStatus] = useState<'Approved' | 'Not Yet Approved'>('Approved');

  // 3. QC HOLD STATE
  const [qcForwardedBy, setQcForwardedBy] = useState<string>('');
  const [qcForwardedTo, setQcForwardedTo] = useState<string>('');
  const [qcForwardedDate, setQcForwardedDate] = useState<string>('');
  const [qcRemarks, setQcRemarks] = useState<string>('');
  const [qcStatus, setQcStatus] = useState<'Forwarded' | 'Not Yet Forwarded' | 'For Filling' | 'No Received Sample' | 'For Disposition'>('For Disposition');
  const [qcReturnedBy, setQcReturnedBy] = useState<string>('');
  const [qcDateReturned, setQcDateReturned] = useState<string>('');

  // 4. QA STATE
  const [qaStatus, setQaStatus] = useState<'Open' | 'Closed' | 'Returned'>('Open');
  const [qaReturnedTo, setQaReturnedTo] = useState<string>('');
  const [qaDateReturned, setQaDateReturned] = useState<string>('');
  const [qaFindings, setQaFindings] = useState<string>('');

  const isSysadmin = currentUser.role === 'Sysadmin';
  const isAdmin = currentUser.role === 'Admin';
  const isQM = currentUser.role === 'QM';

  const handleOpenNewRequest = () => {
    setSelectedReqId(null);
    const nextCtrl = storageService.generateNextRSISControlNo();
    setControlNo(nextCtrl);
    setDateRequested(new Date().toISOString().split('T')[0]);
    setRequestorName(`${currentUser.firstName} ${currentUser.lastName}`);
    setDepartment(currentUser.department);
    setSection(currentUser.section);
    setSampleType('RS Sample');
    setRsIsNumber(`RS-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);
    setItemName('');
    setDrawingNumber('');
    setPoNumber('');
    setLotNumber('');
    setQuantity(1);
    setDateNeeded(new Date().toISOString().split('T')[0]);
    const d = new Date();
    d.setDate(d.getDate() + 7);
    setReturnedDueDate(d.toISOString().split('T')[0]);
    setReason('');
    setRemarks('');
    setQmStaffEngineer('');
    setQmEndorsedToQC('');
    setQmDate('');
    setQmStatus('Approved');
    setQcForwardedBy('');
    setQcForwardedTo('');
    setQcForwardedDate('');
    setQcRemarks('');
    setQcReturnedBy('');
    setQcDateReturned('');
    setQcStatus('For Disposition');
    setQaReturnedTo('');
    setQaDateReturned('');
    setQaFindings('');
    setQaStatus('Open');
    setActiveTab('REQUESTOR_REQUISITION');
    setIsMultitabOpen(true);
    setFeedbackMsg({
      type: 'info',
      text: `Created new RS/IS Request: ${nextCtrl}. Fill in borrow requisitions across role tabs.`
    });
  };

  const handleSelectRecordFromMasterlist = (rec: RSISSampleRecord) => {
    setSelectedReqId(rec.id);
    setControlNo(rec.controlNo);
    setDateRequested(rec.dateRequested || rec.date || new Date().toISOString().split('T')[0]);
    setRequestorName(rec.requestorName || rec.issuedBy);
    setDepartment(rec.department);
    setSection(rec.section);
    setSampleType(rec.sampleType);
    setRsIsNumber(rec.rsIsNumber);
    setItemName(rec.itemName);
    setDrawingNumber(rec.drawingNumber);
    setPoNumber(rec.poNumber);
    setLotNumber(rec.lotNumber);
    setQuantity(rec.quantity);
    setDateNeeded(rec.dateNeeded || rec.dateForwarded || new Date().toISOString().split('T')[0]);
    setReturnedDueDate(rec.returnedDueDate || new Date().toISOString().split('T')[0]);
    setReason(rec.reason || rec.typeOfDefect || '');
    setRemarks(rec.remarks || rec.qcRemarks || '');

    setQmStaffEngineer(rec.qmStaffEngineer || 'Maria Cristina Reyes');
    setQmEndorsedToQC(rec.qmEndorsedToQA || 'Rodel Bautista');
    setQmDate(rec.qmDate || new Date().toISOString().split('T')[0]);
    setQmStatus(rec.qmStatus === 'Approved' ? 'Approved' : 'Approved');

    setQcForwardedBy(rec.receivedBy || 'Rodel Bautista');
    setQcForwardedTo(rec.qcForwardedTo || 'QA Department');
    setQcForwardedDate(rec.qcDateForwarded || new Date().toISOString().split('T')[0]);
    setQcRemarks(rec.qcRemarks || 'Forwarded');
    setQcStatus(rec.qcHoldStatus);
    setQcReturnedBy(rec.qcReturnedBy || '');
    setQcDateReturned(rec.qcDateReturned || '');

    setQaStatus(rec.qaStatus || 'Open');
    setQaReturnedTo(rec.qaReturnedTo || 'QC Hold');
    setQaDateReturned(rec.qaDateReturned || '');
    setQaFindings(rec.qaFindings || '');

    setActiveTab('REQUESTOR_REQUISITION');
    setIsMultitabOpen(true);
  };

  const handleSaveRequest = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    try {
      const saved = storageService.saveRSISRecord({
        id: selectedReqId || undefined,
        controlNo,
        dateRequested,
        requestorName,
        issuedBy: requestorName,
        department,
        section,
        sampleType,
        rsIsNumber,
        itemName,
        drawingNumber,
        poNumber,
        lotNumber,
        typeOfDefect: reason,
        quantity,
        dateNeeded,
        returnedDueDate,
        reason,
        remarks,
        qmStaffEngineer,
        qmEndorsedToQA: qmEndorsedToQC,
        qmDate,
        qmStatus: qmStatus === 'Approved' ? 'Forwarded' : 'Not Yet Forwarded',
        receivedBy: qcForwardedBy,
        qcForwardedTo,
        qcDateForwarded: qcForwardedDate,
        qcRemarks,
        qcHoldStatus: qcStatus,
        qcReturnedBy,
        qcDateReturned,
        qaEngineer: currentUser.firstName + ' ' + currentUser.lastName,
        qaStatus,
        qaReturnedTo,
        qaDateReturned,
        qaFindings
      });

      const updated = storageService.getRSISRecords();
      setRecords(updated);
      onRefreshData();
      setSelectedReqId(saved.id);

      setFeedbackMsg({
        type: 'success',
        text: `RS/IS Request ${saved.controlNo} saved! Automated notification dispatched to ${requestorName} & QA/QC teams.`
      });
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed to save request: ${err.message}`
      });
    }
  };

  const handleDeleteRequest = (rec: RSISSampleRecord) => {
    if (!isSysadmin && !isAdmin && !isQM) {
      alert('Access Denied: Only Admin, Sysadmin, or QM can delete RS/IS requests.');
      return;
    }

    if (window.confirm(`Delete request ${rec.controlNo}?`)) {
      try {
        storageService.deleteRSISRecord(rec.id);
        setRecords(storageService.getRSISRecords());
        onRefreshData();
        if (selectedReqId === rec.id) {
          setIsMultitabOpen(false);
        }
        setFeedbackMsg({
          type: 'success',
          text: `Request ${rec.controlNo} deleted.`
        });
      } catch (err: any) {
        alert(`Error deleting request: ${err.message}`);
      }
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'Control No',
      'RS/IS Number',
      'Sample Type',
      'Item Name',
      'Drawing No',
      'PO Number',
      'Lot Number',
      'Quantity',
      'Requestor',
      'Section',
      'Department',
      'QC Status',
      'QA Status'
    ];

    const rows = records.map((r) => [
      `"${r.controlNo}"`,
      `"${r.rsIsNumber}"`,
      `"${r.sampleType}"`,
      `"${r.itemName}"`,
      `"${r.drawingNumber}"`,
      `"${r.poNumber}"`,
      `"${r.lotNumber}"`,
      `"${r.quantity}"`,
      `"${r.requestorName || r.issuedBy}"`,
      `"${r.section}"`,
      `"${r.department}"`,
      `"${r.qcHoldStatus}"`,
      `"${r.qaStatus || 'Open'}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `JAE_RSIS_Sample_Requests_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredRecords = records.filter((r) => {
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      r.controlNo.toLowerCase().includes(q) ||
      r.rsIsNumber.toLowerCase().includes(q) ||
      r.itemName.toLowerCase().includes(q) ||
      (r.requestorName && r.requestorName.toLowerCase().includes(q)) ||
      r.issuedBy.toLowerCase().includes(q);

    const matchesType = filterType === 'All' || r.sampleType === filterType;
    const matchesStatus = filterStatus === 'All' || r.qcHoldStatus === filterStatus || r.qaStatus === filterStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div id="rsis-sample-request-view" className="w-full p-4 md:p-6 space-y-6 font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <Mail className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                RS / IS Sample Request
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                NOTIFICATION DISPATCH
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center flex-wrap gap-2 w-full md:w-auto justify-start md:justify-end">
          {isMultitabOpen ? (
            <button
              onClick={() => setIsMultitabOpen(false)}
              className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold flex items-center space-x-1.5 shadow-sm transition-all border border-slate-700"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Masterlist</span>
            </button>
          ) : (
            <>
              <button
                onClick={handleExportCSV}
                className="px-3 py-1.5 bg-slate-900/80 hover:bg-slate-800 text-emerald-300 rounded-lg text-xs font-bold border border-emerald-700/50 flex items-center space-x-1.5 shadow-xs transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export CSV</span>
              </button>

              <button
                onClick={handleOpenNewRequest}
                className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-sm flex items-center space-x-1.5 transition-all transform active:scale-98"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ New RS/IS Borrow Request</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-xs ${
          feedbackMsg.type === 'success'
            ? 'bg-[#0a2820] border-emerald-500/70 text-emerald-200'
            : feedbackMsg.type === 'error'
            ? 'bg-rose-950/80 border-rose-600/70 text-rose-200'
            : 'bg-blue-950/80 border-blue-600/70 text-blue-200'
        }`}>
          <div className="flex items-center space-x-2">
            {feedbackMsg.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
            {feedbackMsg.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />}
            {feedbackMsg.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-[11px] underline ml-2 opacity-80 hover:opacity-100 text-pink-300"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. MASTERLIST VIEW */}
      {/* ========================================================================= */}
      {!isMultitabOpen ? (
        <div className="space-y-4 animate-in fade-in duration-200 w-full">
          
          {/* Top KPIs / Metric Cubes with Vibrant Colored Top Strips */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Cube 1: Total Request */}
            <div className="bg-[#141a16] rounded-xl border border-emerald-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-emerald-600 to-green-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">TOTAL REQUEST</span>
                <Send className="w-3.5 h-3.5 text-emerald-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-white">{records.length}</div>
                <div className="p-2 bg-[#0a2820] text-emerald-400 rounded-lg border border-emerald-600/60">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 2: QC Hold Area */}
            <div className="bg-[#141a16] rounded-xl border border-amber-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-amber-600 to-orange-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">QC HOLD AREA</span>
                <Clock className="w-3.5 h-3.5 text-amber-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-amber-400">
                  {records.filter(r => r.qcHoldStatus === 'For Disposition' || r.qcHoldStatus === 'For Filling').length}
                </div>
                <div className="p-2 bg-[#2d1f0e] text-amber-400 rounded-lg border border-amber-600/60">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 3: Dispatched to QA */}
            <div className="bg-[#141a16] rounded-xl border border-blue-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">DISPATCHED TO QA</span>
                <ShieldCheck className="w-3.5 h-3.5 text-blue-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-blue-400">
                  {records.filter(r => r.qcHoldStatus === 'Forwarded' || r.qaStatus === 'Open').length}
                </div>
                <div className="p-2 bg-[#0c1e30] text-blue-400 rounded-lg border border-blue-600/60">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Cube 4: Auto-Notified */}
            <div className="bg-[#141a16] rounded-xl border border-pink-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-pink-600 to-rose-600 px-3 py-1.5 flex items-center justify-between">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">AUTO-NOTIFIED</span>
                <MailCheck className="w-3.5 h-3.5 text-pink-100" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-pink-400">
                  {records.length}
                </div>
                <div className="p-2 bg-[#2d0e1e] text-pink-400 rounded-lg border border-pink-600/60">
                  <MailCheck className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

          {/* Masterlist Table Container with High-Contrast Dark-Green Header */}
          <div className="bg-[#121815] rounded-xl shadow-lg border border-emerald-700/60 overflow-hidden">
            <div className="px-4 py-2.5 border-b border-emerald-700/60 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-gradient-to-r from-[#064e3b] via-[#095742] to-[#043d2e]">
              <div>
                <h2 className="text-sm md:text-base font-bold text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                  <Send className="w-4 h-4 text-pink-300" />
                  <span className="text-white">REGISTERED RS / IS BORROW REQUISITIONS</span>
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-[200px]">
                  <Search className="w-3.5 h-3.5 text-emerald-300 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search control no, part, requestor..."
                    className="w-full bg-[#0a2820] border border-emerald-500/70 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-emerald-200/60 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Types</option>
                  <option value="RS Sample">RS Sample</option>
                  <option value="IS Sample">IS Sample</option>
                </select>

                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Statuses</option>
                  <option value="For Disposition">For Disposition</option>
                  <option value="Forwarded">Forwarded</option>
                  <option value="Open">QA Open</option>
                  <option value="Closed">QA Closed</option>
                </select>
              </div>
            </div>

            {/* Space-Maximized Table */}
            <div className="overflow-x-auto">
              <table className="isms-table w-full text-xs">
                <thead>
                  <tr className="bg-[#062c21] text-emerald-200 uppercase text-[10px] tracking-wider border-b border-emerald-700/60">
                    <th className="p-2.5 font-bold text-emerald-100">Control No</th>
                    <th className="p-2.5 font-bold text-emerald-100">Type</th>
                    <th className="p-2.5 font-bold text-emerald-100">Item Description</th>
                    <th className="p-2.5 font-bold text-emerald-100">Requestor</th>
                    <th className="p-2.5 font-bold text-emerald-100">Section</th>
                    <th className="p-2.5 font-bold text-emerald-100">QC Status</th>
                    <th className="p-2.5 font-bold text-emerald-100">QA Status</th>
                    <th className="p-2.5 font-bold text-emerald-100">Notification</th>
                    <th className="p-2.5 text-right font-bold text-emerald-100">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-900/40">
                  {filteredRecords.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-6 text-center text-emerald-200/70">
                        No RS/IS sample requisitions found. Click "+ New RS/IS Borrow Request" to start.
                      </td>
                    </tr>
                  ) : (
                    filteredRecords.map((rec) => {
                      const isSelected = selectedReqId === rec.id;
                      return (
                        <tr
                          key={rec.id}
                          onClick={() => setSelectedReqId(rec.id)}
                          onDoubleClick={() => handleSelectRecordFromMasterlist(rec)}
                          className={`cursor-pointer transition-colors duration-150 group hover:bg-[#18392d]/80 ${
                            isSelected ? 'bg-pink-950/50' : 'bg-[#101e18]'
                          }`}
                          title="Double-click to open multi-tab workspace"
                        >
                          <td className="p-2.5 font-mono font-bold text-pink-300 group-hover:text-pink-200 whitespace-nowrap">
                            {rec.controlNo}
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              rec.sampleType === 'RS Sample' ? 'bg-amber-900/80 text-amber-200 border border-amber-600' : 'bg-purple-900/80 text-purple-200 border border-purple-600'
                            }`}>
                              {rec.sampleType}
                            </span>
                          </td>
                          <td className="p-2.5 font-semibold text-slate-100 max-w-xs truncate" title={rec.itemName}>
                            {rec.itemName}
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            <div className="font-semibold text-white">{rec.requestorName || rec.issuedBy}</div>
                            <div className="text-[10px] text-emerald-300 font-mono">{rec.dateRequested || rec.date}</div>
                          </td>
                          <td className="p-2.5 whitespace-nowrap font-medium text-emerald-100">
                            {rec.section}
                          </td>
                          <td className="p-2.5 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                const nextStatus = rec.qcHoldStatus === 'Forwarded' ? 'For Disposition' : 'Forwarded';
                                storageService.updateRSISRecord(rec.id, { qcHoldStatus: nextStatus as any });
                                setRecords(storageService.getRSISRecords());
                                onRefreshData();
                              }}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-transform active:scale-95 ${
                                rec.qcHoldStatus === 'For Disposition' ? 'bg-rose-900/80 text-rose-200 border-rose-600' :
                                rec.qcHoldStatus === 'Forwarded' ? 'bg-emerald-900/80 text-emerald-200 border-emerald-600' :
                                'bg-blue-900/80 text-blue-200 border-blue-600'
                              }`}
                              title="Click to toggle QC status"
                            >
                              {rec.qcHoldStatus}
                            </button>
                          </td>
                          <td className="p-2.5 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                const nextQA = rec.qaStatus === 'Closed' ? 'Open' : 'Closed';
                                storageService.updateRSISRecord(rec.id, { qaStatus: nextQA });
                                setRecords(storageService.getRSISRecords());
                                onRefreshData();
                              }}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-transform active:scale-95 ${
                                rec.qaStatus === 'Closed' ? 'bg-teal-900/80 text-teal-200 border-teal-600' : 'bg-blue-900/80 text-blue-200 border-blue-600'
                              }`}
                              title="Click to toggle QA status"
                            >
                              {rec.qaStatus || 'Open'}
                            </button>
                          </td>
                          <td className="p-2.5 whitespace-nowrap">
                            <span className="flex items-center gap-1 text-[11px] text-emerald-300 font-semibold">
                              <MailCheck className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Auto-Sent</span>
                            </span>
                          </td>
                          <td className="p-2.5 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end space-x-1.5">
                              <button
                                onClick={() => handlePrintRSISReport(rec)}
                                className="p-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded border border-emerald-700/60 shadow-xs transition-colors cursor-pointer"
                                title="Generate PDF Report / Print Routing Sign-off Slip"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleSelectRecordFromMasterlist(rec)}
                                className="p-1 bg-pink-900/60 hover:bg-pink-800 text-pink-200 rounded border border-pink-600/60 shadow-xs transition-colors cursor-pointer"
                                title="Open Multitab per Roles"
                              >
                                <Layers className="w-3.5 h-3.5" />
                              </button>
                              {(isSysadmin || isAdmin || isQM) && (
                                <button
                                  onClick={() => handleDeleteRequest(rec)}
                                  className="p-1 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded border border-rose-600/60 shadow-xs transition-colors cursor-pointer"
                                  title="Delete"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-[#0d1612] border-t border-emerald-800/60 text-xs text-emerald-300/80 flex justify-between items-center">
              <span>Showing {filteredRecords.length} of {records.length} requisitions</span>
              <span className="font-mono text-[11px] text-pink-300/80">JAE Automated Alert & Escalation Matrix</span>
            </div>
          </div>

        </div>
      ) : (
        /* ========================================================================= */
        /* 2. MULTI-TAB WORKSPACE PER ROLES */
        /* ========================================================================= */
        <div className="space-y-6 animate-in fade-in duration-300 w-full">
          
          {/* Multitab Bar */}
          <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-2 flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab('REQUESTOR_REQUISITION')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'REQUESTOR_REQUISITION'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>1. Requestor Form</span>
            </button>

            <button
              onClick={() => setActiveTab('QM_APPROVAL')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'QM_APPROVAL'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>2. QM Approval</span>
            </button>

            <button
              onClick={() => setActiveTab('QC_DISPATCH')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'QC_DISPATCH'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <PackageCheck className="w-4 h-4" />
              <span>3. QC Hold Dispatch</span>
            </button>

            <button
              onClick={() => setActiveTab('QA_RETURN_DISPOSITION')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'QA_RETURN_DISPOSITION'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>4. QA Disposition</span>
            </button>

            <button
              onClick={() => setActiveTab('NOTIFICATIONS_AUDIT')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all ${
                activeTab === 'NOTIFICATIONS_AUDIT'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#1b241f] hover:bg-[#233029] text-emerald-200 hover:text-white border border-emerald-800/60 font-semibold'
              }`}
            >
              <MailCheck className="w-4 h-4" />
              <span>5. Auto-Notifications</span>
            </button>
          </div>

          {/* Tab 1: Requestor Requisition */}
          {activeTab === 'REQUESTOR_REQUISITION' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    Requestor Borrow Requisition & Specifications
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-pink-300 bg-pink-950/80 px-3 py-1 rounded-lg border border-pink-700/60 shadow-xs">
                  {controlNo}
                </span>
              </div>

              {/* Searchable Auto-Select from Registered Keep Sample Entry */}
              <div className="p-3 bg-[#0a2820] border border-emerald-600/70 rounded-xl space-y-2 shadow-xs">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center space-x-2">
                    <div className="p-1.5 bg-emerald-700 text-white rounded-lg">
                      <Layers className="w-4 h-4 text-emerald-200" />
                    </div>
                    <div className="text-xs font-bold text-emerald-200 font-['Chakra_Petch'] uppercase tracking-wider">
                      🔗 REGISTERED KEEP SAMPLE SELECTION
                    </div>
                  </div>

                  {selectedBoxId && (
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedBoxId('');
                        setSampleSearchQuery('');
                      }}
                      className="text-[11px] text-pink-300 hover:text-pink-200 flex items-center gap-1 font-semibold self-end sm:self-center"
                    >
                      <X className="w-3 h-3" /> Clear Selection
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-center">
                  <div className="md:col-span-5 relative">
                    <Search className="w-3.5 h-3.5 text-emerald-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      placeholder="Search keep sample by Box #, item, DWG, PO, lot..."
                      value={sampleSearchQuery}
                      onChange={(e) => setSampleSearchQuery(e.target.value)}
                      className="w-full bg-[#101e18] border border-emerald-500/80 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                    {sampleSearchQuery && (
                      <button
                        type="button"
                        onClick={() => setSampleSearchQuery('')}
                        className="absolute right-2.5 top-2 text-slate-400 hover:text-white"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="md:col-span-7">
                    <select
                      value={selectedBoxId}
                      onChange={(e) => {
                        const selId = e.target.value;
                        setSelectedBoxId(selId);
                        if (!selId) return;
                        const allBoxes = storageService.getKeepSampleBoxes();
                        const foundBox = allBoxes.find(b => b.id === selId || b.boxNumber === selId);
                        if (foundBox) {
                          if (foundBox.item) setItemName(foundBox.item);
                          setDrawingNumber('DWG-' + foundBox.boxNumber);
                          setPoNumber('PO-' + new Date().getFullYear());
                          setLotNumber('LOT-' + foundBox.boxNumber);
                          if (foundBox.samples && foundBox.samples.length > 0) {
                            const first = foundBox.samples[0];
                            setItemName(first.itemName);
                            setDrawingNumber(first.drawingNumber);
                            if (first.poNumber) setPoNumber(first.poNumber);
                            setLotNumber(first.lotNumber);
                            setQuantity(first.quantity || 1);
                          }
                          if (foundBox.section) setSection(foundBox.section);
                          setFeedbackMsg({
                            type: 'success',
                            text: `Auto-populated part details from Box ${foundBox.boxNumber}`
                          });
                        }
                      }}
                      className="w-full bg-[#101e18] border-2 border-emerald-500 rounded-lg px-3 py-1.5 text-xs font-bold text-white shadow-xs focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    >
                      <option value="">
                        {storageService.getKeepSampleBoxes().filter(b => {
                          if (!sampleSearchQuery) return true;
                          const q = sampleSearchQuery.toLowerCase();
                          return (
                            (b.boxNumber || '').toLowerCase().includes(q) ||
                            (b.item || '').toLowerCase().includes(q) ||
                            (b.section || '').toLowerCase().includes(q) ||
                            (b.remarks || '').toLowerCase().includes(q) ||
                            (b.samples || []).some(s => 
                              (s.itemName || '').toLowerCase().includes(q) ||
                              (s.drawingNumber || '').toLowerCase().includes(q) ||
                              (s.lotNumber || '').toLowerCase().includes(q) ||
                              (s.poNumber || '').toLowerCase().includes(q)
                            )
                          );
                        }).length === 0
                          ? 'No matching registered samples found'
                          : '🔍 Select Registered Sample from matches...'}
                      </option>
                      {storageService.getKeepSampleBoxes()
                        .filter(box => {
                          if (!sampleSearchQuery) return true;
                          const q = sampleSearchQuery.toLowerCase();
                          return (
                            (box.boxNumber || '').toLowerCase().includes(q) ||
                            (box.item || '').toLowerCase().includes(q) ||
                            (box.section || '').toLowerCase().includes(q) ||
                            (box.remarks || '').toLowerCase().includes(q) ||
                            (box.samples || []).some(s => 
                              (s.itemName || '').toLowerCase().includes(q) ||
                              (s.drawingNumber || '').toLowerCase().includes(q) ||
                              (s.lotNumber || '').toLowerCase().includes(q) ||
                              (s.poNumber || '').toLowerCase().includes(q)
                            )
                          );
                        })
                        .map((box) => (
                          <option key={box.id} value={box.id}>
                            📦 {box.boxNumber} — {box.item || 'Sample'} ({box.section}) {box.samples?.length ? `[${box.samples.length} items]` : ''}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">CONTROL NUMBER: <span className="text-pink-400">*</span></label>
                  <input
                    type="text"
                    value={controlNo}
                    onChange={(e) => setControlNo(e.target.value)}
                    required
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5 flex items-center">
                    <Calendar className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    DATE REQUESTED:
                  </label>
                  <input
                    type="date"
                    value={dateRequested}
                    onChange={(e) => setDateRequested(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">REQUESTOR NAME:</label>
                  <input
                    type="text"
                    value={requestorName}
                    onChange={(e) => setRequestorName(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">ITEM NAME:</label>
                  <input
                    type="text"
                    value={itemName}
                    onChange={(e) => setItemName(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">DRAWING NUMBER:</label>
                  <input
                    type="text"
                    value={drawingNumber}
                    onChange={(e) => setDrawingNumber(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">LOT NUMBER:</label>
                  <input
                    type="text"
                    value={lotNumber}
                    onChange={(e) => setLotNumber(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">QUANTITY:</label>
                  <input
                    type="number"
                    min={1}
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5 flex items-center">
                    <Calendar className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    DATE NEEDED:
                  </label>
                  <input
                    type="date"
                    value={dateNeeded}
                    onChange={(e) => setDateNeeded(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5 flex items-center">
                    <Calendar className="w-3.5 h-3.5 text-emerald-400 mr-1.5" />
                    DUE DATE:
                  </label>
                  <input
                    type="date"
                    value={returnedDueDate}
                    onChange={(e) => setReturnedDueDate(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-white uppercase tracking-wider mb-1.5">REASON FOR REQUISITION:</label>
                <textarea
                  rows={2}
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="State borrow purpose or verification testing reason..."
                  className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl p-2.5 text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                />
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setIsMultitabOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to Masterlist</span>
                </button>
                <div className="flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => handleSaveRequest()}
                    className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Request</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleSaveRequest();
                      setActiveTab('QM_APPROVAL');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all"
                  >
                    <span>Proceed to QM Approval →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: QM Approval */}
          {activeTab === 'QM_APPROVAL' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    Quality Management (QM) Approval
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">QM ENGINEER:</label>
                  <input
                    type="text"
                    value={qmStaffEngineer}
                    onChange={(e) => setQmStaffEngineer(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">APPROVAL DATE:</label>
                  <input
                    type="date"
                    value={qmDate}
                    onChange={(e) => setQmDate(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-emerald-100 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">QM STATUS:</label>
                  <select
                    value={qmStatus}
                    onChange={(e) => setQmStatus(e.target.value as any)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-bold text-emerald-300 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="Approved">Approved</option>
                    <option value="Not Yet Approved">Not Yet Approved</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('REQUESTOR_REQUISITION')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: Requestor Form</span>
                </button>
                <div className="flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => handleSaveRequest()}
                    className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleSaveRequest();
                      setActiveTab('QC_DISPATCH');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all"
                  >
                    <span>Proceed to QC Hold Dispatch →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: QC Dispatch */}
          {activeTab === 'QC_DISPATCH' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    QC Hold Physical Dispatch & Status
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">FORWARDED BY:</label>
                  <input
                    type="text"
                    value={qcForwardedBy}
                    onChange={(e) => setQcForwardedBy(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">FORWARDED TO:</label>
                  <input
                    type="text"
                    value={qcForwardedTo}
                    onChange={(e) => setQcForwardedTo(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">QC STATUS:</label>
                  <select
                    value={qcStatus}
                    onChange={(e) => setQcStatus(e.target.value as any)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="For Disposition">For Disposition</option>
                    <option value="Forwarded">Forwarded</option>
                    <option value="For Filling">For Filling</option>
                    <option value="No Received Sample">No Received Sample</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('QM_APPROVAL')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: QM Approval</span>
                </button>
                <div className="flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => handleSaveRequest()}
                    className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleSaveRequest();
                      setActiveTab('QA_RETURN_DISPOSITION');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all"
                  >
                    <span>Proceed to QA Disposition →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab 4: QA Disposition */}
          {activeTab === 'QA_RETURN_DISPOSITION' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide">
                    QA Investigation & Disposition Result
                  </h3>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">QA STATUS:</label>
                  <select
                    value={qaStatus}
                    onChange={(e) => setQaStatus(e.target.value as any)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  >
                    <option value="Open">Open</option>
                    <option value="Closed">Closed</option>
                    <option value="Returned">Returned</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-white uppercase tracking-wider mb-1.5">RETURNED TO:</label>
                  <input
                    type="text"
                    value={qaReturnedTo}
                    onChange={(e) => setQaReturnedTo(e.target.value)}
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('QC_DISPATCH')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: QC Hold Dispatch</span>
                </button>
                <div className="flex items-center space-x-3">
                  <button
                    type="button"
                    onClick={() => handleSaveRequest()}
                    className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleSaveRequest();
                      setActiveTab('NOTIFICATIONS_AUDIT');
                    }}
                    className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all"
                  >
                    <span>Proceed to Notifications & Audit →</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Tab 5: Automated Notifications */}
          {activeTab === 'NOTIFICATIONS_AUDIT' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-6 space-y-4 text-xs">
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-4 rounded-xl border border-emerald-600/70 shadow-xs flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-sm text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                    <MailCheck className="w-4 h-4 text-pink-400" />
                    <span>Personnel Automatic Email Dispatch Matrix</span>
                  </h3>
                </div>
              </div>

              <div className="space-y-3">
                <div className="p-4 bg-[#0d1f18] rounded-xl border border-emerald-700/60 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-emerald-200 flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                      <span>Notification Dispatched to Requestor</span>
                    </span>
                    <span className="font-mono text-[10px] text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-700">STATUS: {qcStatus}</span>
                  </div>
                  <p className="text-[11px] text-emerald-300/80">
                    Recipient: <strong className="font-mono text-white">{requestorName}</strong> ({department} / {section})
                  </p>
                </div>

                <div className="p-4 bg-[#0c1e30] rounded-xl border border-blue-700/60 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-blue-200 flex items-center gap-1.5">
                      <MailCheck className="w-4 h-4 text-blue-400" />
                      <span>QC Hold Area Custody Alert</span>
                    </span>
                    <span className="font-mono text-[10px] text-blue-400 bg-blue-950/80 px-2 py-0.5 rounded border border-blue-700">DISPATCHED</span>
                  </div>
                  <p className="text-[11px] text-blue-300/80">
                    Recipient: <strong className="font-mono text-white">{qcForwardedBy}</strong> (QC Hold Section)
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setActiveTab('QA_RETURN_DISPOSITION')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>← Previous: QA Disposition</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsMultitabOpen(false)}
                  className="px-5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all border border-slate-700"
                >
                  <span>Return to Masterlist</span>
                </button>
              </div>
            </div>
          )}

        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. FORMAL PRINTABLE SIGN-OFF SLIP & PDF REPORT MODAL (Request #4) */}
      {/* ========================================================================= */}
      {printModalRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 bg-black/85 backdrop-blur-sm overflow-y-auto animate-in fade-in">
          <div className="relative w-full max-w-4xl bg-white text-slate-900 rounded-xl shadow-2xl overflow-hidden my-auto border border-slate-300">
            
            {/* Top Toolbar (Hidden during browser print) */}
            <div className="print:hidden bg-slate-900 text-white px-5 py-3 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Printer className="w-5 h-5 text-pink-400" />
                <h3 className="text-sm font-bold uppercase tracking-wider font-['Chakra_Petch']">
                  Official RS/IS Sample Routing & Sign-off Report
                </h3>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={handleTriggerBrowserPrint}
                  className="px-4 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs rounded-lg shadow flex items-center space-x-1.5 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Document / Save as PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPrintModalRecord(null)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Document Body (A4/Letter Paper Format) */}
            <div className="p-8 sm:p-10 space-y-6 bg-white text-slate-900 text-xs font-sans print:p-0 print:m-0">
              
              {/* Official Header */}
              <div className="border-b-2 border-slate-900 pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <JAELogo />
                    <div>
                      <h1 className="text-base font-black tracking-tight text-slate-900 uppercase">
                        JAE Philippines, Inc.
                      </h1>
                      <p className="text-[11px] font-semibold text-slate-700 tracking-wide">
                        Quality Management Division • Integrated Sample Management System (iSMS)
                      </p>
                      <p className="text-[10px] text-slate-500 font-mono">
                        Standard Quality Procedure Document • Form Ref: JAE-QMD-RSIS-04
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="px-3 py-1 bg-slate-100 border border-slate-400 rounded text-center">
                      <div className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">REQUISITION CONTROL NO.</div>
                      <div className="text-base font-black font-mono text-slate-900">{printModalRecord.controlNo}</div>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1 font-mono">
                      Generated: {new Date().toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="mt-3 text-center py-1.5 bg-slate-900 text-white font-bold uppercase tracking-wider text-xs rounded">
                  RS / IS SAMPLE REQUISITION & MULTI-STAGE SIGN-OFF ROUTING SLIP
                </div>
              </div>

              {/* 1. Request Details Matrix */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-900 uppercase tracking-wide border-b border-slate-300 pb-0.5">
                  1. Requisition Header & Item Identification
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 border border-slate-300 p-3 rounded bg-slate-50/50">
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Date Requested:</div>
                    <div className="font-mono font-bold text-slate-900">{printModalRecord.dateRequested}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Requestor Name:</div>
                    <div className="font-bold text-slate-900">{printModalRecord.requestorName}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Department:</div>
                    <div className="font-semibold text-slate-900">{printModalRecord.department}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Section:</div>
                    <div className="font-semibold text-slate-900">{printModalRecord.section}</div>
                  </div>

                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Sample Category:</div>
                    <div className="font-bold text-pink-700">{printModalRecord.sampleType}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">RS / IS Reference #:</div>
                    <div className="font-mono font-bold text-slate-900">{printModalRecord.rsIsNumber || '-'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Drawing / Part No:</div>
                    <div className="font-mono font-bold text-slate-900">{printModalRecord.drawingNumber || '-'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">P.O. / Lot No:</div>
                    <div className="font-mono font-bold text-slate-900">{printModalRecord.poNumber || printModalRecord.lotNumber || '-'}</div>
                  </div>

                  <div className="col-span-2">
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Item / Component Description:</div>
                    <div className="font-bold text-slate-900">{printModalRecord.itemName}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Quantity Requisitioned:</div>
                    <div className="font-mono font-extrabold text-slate-900 text-sm">{printModalRecord.quantity} pcs</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Target Due / Return Date:</div>
                    <div className="font-mono font-bold text-slate-900">{printModalRecord.returnedDueDate || printModalRecord.dateNeeded}</div>
                  </div>

                  <div className="col-span-4 pt-1 border-t border-slate-200">
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Reason for Request / Verification Purpose:</div>
                    <div className="text-slate-800 italic">{printModalRecord.reason || 'Verification & Analysis'}</div>
                  </div>
                </div>
              </div>

              {/* 2. Official Multi-Department Sign-off Grid */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-slate-900 uppercase tracking-wide border-b border-slate-300 pb-0.5">
                  2. Sequential Departmental Endorsements & Physical Sign-Off Matrix
                </div>
                
                <table className="w-full border-collapse border border-slate-400 text-[11px]">
                  <thead>
                    <tr className="bg-slate-200 text-slate-900 font-bold border-b border-slate-400">
                      <th className="border border-slate-400 p-2 text-left w-1/4">Workflow Stage</th>
                      <th className="border border-slate-400 p-2 text-left w-1/4">Designated Personnel</th>
                      <th className="border border-slate-400 p-2 text-left w-1/4">Action / Disposition Status</th>
                      <th className="border border-slate-400 p-2 text-center w-1/4">Signature & Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Stage 1: Requestor */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        1. Requestor Requisition
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRecord.requestorName}</div>
                        <div className="text-[9px] text-slate-500">{printModalRecord.section}</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold text-emerald-800">
                        Requisition Submitted ({printModalRecord.dateRequested})
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 2: QM Review */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        2. QM Section Endorsement
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRecord.qmStaffEngineer || 'Maria Cristina Reyes'}</div>
                        <div className="text-[9px] text-slate-500">QM Engineer / In-Charge</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Status: <span className="text-emerald-800 font-bold">{printModalRecord.qmStatus || 'Approved'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 3: QC Dispatch */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        3. QC Hold Dispatch & Handoff
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRecord.qcForwardedBy || 'Rodel Bautista'}</div>
                        <div className="text-[9px] text-slate-500">QC Hold Custodian</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Status: <span className="text-amber-800 font-bold">{printModalRecord.qcHoldStatus || 'Forwarded'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 4: QA Inspection */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        4. QA Inspection & Return Disposition
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRecord.qaReturnedTo || 'QA Section Inspector'}</div>
                        <div className="text-[9px] text-slate-500">QA Department</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Status: <span className="text-blue-800 font-bold">{printModalRecord.qaStatus || 'Open'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* 3. Formal Quality Notice Footer */}
              <div className="border-t border-slate-300 pt-3 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                <div>
                  ISO 9001 / IATF 16949 Compliant Quality Record • JAE Philippines, Inc.
                </div>
                <div>
                  Page 1 of 1 • System Generated via iSMS Cloud
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};

export default RSISSampleRequestView;
