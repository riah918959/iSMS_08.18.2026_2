import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertCircle,
  Play,
  Pause,
  Plus,
  Filter,
  Search,
  Save,
  BarChart2,
  TrendingUp,
  Cpu,
  Bell,
  Send,
  CheckCircle,
  UserCheck,
  AlertTriangle,
  XCircle,
  RotateCcw,
  Mail,
  ShieldCheck,
  History
} from 'lucide-react';
import {
  ProductionScheduleItem,
  ProductionStage,
  UserProfile,
  FactoryType,
  PICNotificationStatus
} from '../types';
import { storageService } from '../services/storageService';

interface ProductionScheduleViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
}

export const ProductionScheduleView: React.FC<ProductionScheduleViewProps> = ({
  currentUser,
  onRefreshData
}) => {
  const [schedules, setSchedules] = useState<ProductionScheduleItem[]>(storageService.getProductionSchedules());
  const [selectedScheduleId, setSelectedScheduleId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('All');
  const [factoryFilter, setFactoryFilter] = useState<string>('All');
  const [notificationFilter, setNotificationFilter] = useState<string>('All');

  // Form state
  const [jobOrderNo, setJobOrderNo] = useState(`JO-2026-${Math.floor(Math.random() * 900) + 100}`);
  const [partNumber, setPartNumber] = useState('MX57-24P-M-CONN');
  const [partDescription, setPartDescription] = useState('24-Pin Sealed Automotive Header Assembly');
  const [lineName, setLineName] = useState('Line 1 - Automated Assembly');
  const [factory, setFactory] = useState<FactoryType>(currentUser.factory);
  const [stage, setStage] = useState<ProductionStage>('Pre-Assembly');
  const [targetQuantity, setTargetQuantity] = useState(25000);
  const [completedQuantity, setCompletedQuantity] = useState(14200);
  const [defectQuantity, setDefectQuantity] = useState(18);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [targetEndDate, setTargetEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().split('T')[0];
  });
  const [status, setStatus] = useState<'Scheduled' | 'In Progress' | 'Quality Gate Hold' | 'Completed' | 'Delayed'>('In Progress');
  const [picName, setPicName] = useState(`${currentUser.firstName} ${currentUser.lastName}`);
  const [picDepartment, setPicDepartment] = useState('Production Engineering');
  const [picNotificationStatus, setPicNotificationStatus] = useState<PICNotificationStatus>('Not Sent');
  const [picNotificationDate, setPicNotificationDate] = useState<string>('');
  const [picNotificationMethod, setPicNotificationMethod] = useState<'In-App Alert' | 'Email' | 'SMS / Pager' | 'Radio Dispatch' | 'Direct Handover'>('In-App Alert');
  const [picNotificationSentBy, setPicNotificationSentBy] = useState<string>('');
  const [picNotificationAcknowledgedAt, setPicNotificationAcknowledgedAt] = useState<string>('');
  const [picNotificationRemarks, setPicNotificationRemarks] = useState<string>('');
  const [notes, setNotes] = useState('High precision connector tooling installed.');

  const stagesList: ProductionStage[] = [
    'Stamping',
    'Molding',
    'Pin Insertion',
    'Pre-Assembly',
    'Final Harness Assembly',
    'Automated Optical Inspection',
    'Quality Gate'
  ];

  const notificationStatusOptions: { value: PICNotificationStatus; label: string; description: string }[] = [
    { value: 'Not Sent', label: '🔔 Not Sent', description: 'Schedule created or updated, PIC notification not yet dispatched' },
    { value: 'Pending', label: '⏳ Pending', description: 'Notification queued in system pipeline' },
    { value: 'Notified', label: '📨 Notified', description: 'PIC received dispatch broadcast (Awaiting PIC sign-off)' },
    { value: 'Acknowledged', label: '✅ Acknowledged', description: 'Assigned PIC confirmed receipt & workcenter readiness' },
    { value: 'Rescheduled', label: '🔄 Rescheduled', description: 'Line timing modified, re-notification needed' },
    { value: 'Cancelled', label: '❌ Cancelled', description: 'Job order cancelled or transferred' },
    { value: 'Failed', label: '⚠️ Failed', description: 'Transmission failure; fallback manual contact required' }
  ];

  const handleSelectSchedule = (item: ProductionScheduleItem) => {
    setSelectedScheduleId(item.id);
    setJobOrderNo(item.jobOrderNo);
    setPartNumber(item.partNumber);
    setPartDescription(item.partDescription);
    setLineName(item.lineName);
    setFactory(item.factory);
    setStage(item.stage);
    setTargetQuantity(item.targetQuantity);
    setCompletedQuantity(item.completedQuantity);
    setDefectQuantity(item.defectQuantity);
    setStartDate(item.startDate);
    setTargetEndDate(item.targetEndDate);
    setStatus(item.status);
    setPicName(item.picName || `${currentUser.firstName} ${currentUser.lastName}`);
    setPicDepartment(item.picDepartment || 'Production Assembly');
    setPicNotificationStatus(item.picNotificationStatus || 'Not Sent');
    setPicNotificationDate(item.picNotificationDate || '');
    setPicNotificationMethod(item.picNotificationMethod || 'In-App Alert');
    setPicNotificationSentBy(item.picNotificationSentBy || '');
    setPicNotificationAcknowledgedAt(item.picNotificationAcknowledgedAt || '');
    setPicNotificationRemarks(item.picNotificationRemarks || '');
    setNotes(item.notes || '');
  };

  const handleResetForm = () => {
    setSelectedScheduleId(null);
    setJobOrderNo(`JO-2026-${Math.floor(Math.random() * 900) + 100}`);
    setPartNumber('');
    setPartDescription('');
    setLineName('Line 1 - Automated Assembly');
    setFactory(currentUser.factory);
    setStage('Pre-Assembly');
    setTargetQuantity(10000);
    setCompletedQuantity(0);
    setDefectQuantity(0);
    setStatus('Scheduled');
    setPicName(`${currentUser.firstName} ${currentUser.lastName}`);
    setPicDepartment('Production Assembly');
    setPicNotificationStatus('Not Sent');
    setPicNotificationDate('');
    setPicNotificationMethod('In-App Alert');
    setPicNotificationSentBy('');
    setPicNotificationAcknowledgedAt('');
    setPicNotificationRemarks('');
    setNotes('');
  };

  const handleNotifyPIC = () => {
    const now = new Date().toLocaleString();
    const sender = `${currentUser.firstName} ${currentUser.lastName} (${currentUser.role})`;
    setPicNotificationStatus('Notified');
    setPicNotificationDate(now);
    setPicNotificationSentBy(sender);
    
    // Auto-save if editing an existing schedule
    if (selectedScheduleId) {
      storageService.saveProductionSchedule({
        id: selectedScheduleId,
        jobOrderNo,
        partNumber,
        partDescription,
        lineName,
        factory,
        stage,
        targetQuantity,
        completedQuantity,
        defectQuantity,
        startDate,
        targetEndDate,
        status,
        picName,
        picDepartment,
        picNotificationStatus: 'Notified',
        picNotificationDate: now,
        picNotificationMethod,
        picNotificationSentBy: sender,
        picNotificationAcknowledgedAt,
        picNotificationRemarks: picNotificationRemarks || `Notification dispatched by ${sender} via ${picNotificationMethod}`,
        notes
      });
      setSchedules(storageService.getProductionSchedules());
      onRefreshData();
    }
  };

  const handleAcknowledgePIC = () => {
    const now = new Date().toLocaleString();
    setPicNotificationStatus('Acknowledged');
    setPicNotificationAcknowledgedAt(now);

    if (selectedScheduleId) {
      storageService.saveProductionSchedule({
        id: selectedScheduleId,
        jobOrderNo,
        partNumber,
        partDescription,
        lineName,
        factory,
        stage,
        targetQuantity,
        completedQuantity,
        defectQuantity,
        startDate,
        targetEndDate,
        status,
        picName,
        picDepartment,
        picNotificationStatus: 'Acknowledged',
        picNotificationDate: picNotificationDate || now,
        picNotificationMethod,
        picNotificationSentBy: picNotificationSentBy || `${currentUser.firstName} ${currentUser.lastName}`,
        picNotificationAcknowledgedAt: now,
        picNotificationRemarks: picNotificationRemarks || `Acknowledged by assigned P.I.C. ${picName}`,
        notes
      });
      setSchedules(storageService.getProductionSchedules());
      onRefreshData();
    }
  };

  const handleSaveSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const saved = storageService.saveProductionSchedule({
        id: selectedScheduleId || undefined,
        jobOrderNo,
        partNumber,
        partDescription,
        lineName,
        factory,
        stage,
        targetQuantity,
        completedQuantity,
        defectQuantity,
        startDate,
        targetEndDate,
        status,
        picName,
        picDepartment,
        picNotificationStatus,
        picNotificationDate: picNotificationDate || (picNotificationStatus === 'Notified' ? new Date().toLocaleString() : undefined),
        picNotificationMethod,
        picNotificationSentBy: picNotificationSentBy || (picNotificationStatus === 'Notified' ? `${currentUser.firstName} ${currentUser.lastName}` : undefined),
        picNotificationAcknowledgedAt: picNotificationAcknowledgedAt || (picNotificationStatus === 'Acknowledged' ? new Date().toLocaleString() : undefined),
        picNotificationRemarks,
        notes
      });

      setSchedules(storageService.getProductionSchedules());
      onRefreshData();
      alert(`Job Order ${saved.jobOrderNo} saved successfully!`);
      handleResetForm();
    } catch (err: any) {
      alert(`Error saving schedule: ${err.message}`);
    }
  };

  const getNotificationBadge = (st?: PICNotificationStatus) => {
    switch (st) {
      case 'Acknowledged':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-600/70 inline-flex items-center gap-1 font-mono shadow-xs">
            <CheckCircle className="w-3 h-3 text-emerald-400" />
            ACKNOWLEDGED
          </span>
        );
      case 'Notified':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-950/80 text-blue-300 border border-blue-600/70 inline-flex items-center gap-1 font-mono shadow-xs">
            <Send className="w-3 h-3 text-blue-400" />
            NOTIFIED
          </span>
        );
      case 'Pending':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-600/70 inline-flex items-center gap-1 font-mono shadow-xs">
            <Clock className="w-3 h-3 text-amber-400" />
            PENDING
          </span>
        );
      case 'Rescheduled':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-950/80 text-purple-300 border border-purple-600/70 inline-flex items-center gap-1 font-mono shadow-xs">
            <RotateCcw className="w-3 h-3 text-purple-400" />
            RESCHEDULED
          </span>
        );
      case 'Cancelled':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-900 text-slate-400 border border-slate-700 inline-flex items-center gap-1 font-mono shadow-xs">
            <XCircle className="w-3 h-3 text-slate-400" />
            CANCELLED
          </span>
        );
      case 'Failed':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-950/80 text-rose-300 border border-rose-600/70 inline-flex items-center gap-1 font-mono shadow-xs">
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            FAILED
          </span>
        );
      case 'Not Sent':
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#1e1e1e] text-slate-300 border border-slate-700 inline-flex items-center gap-1 font-mono shadow-xs">
            <Bell className="w-3 h-3 text-slate-400" />
            NOT SENT
          </span>
        );
    }
  };

  const filteredSchedules = schedules.filter((s) => {
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (s.jobOrderNo || '').toLowerCase().includes(q) ||
      (s.partNumber || '').toLowerCase().includes(q) ||
      (s.partDescription || '').toLowerCase().includes(q) ||
      (s.picName || '').toLowerCase().includes(q) ||
      (s.lineName || '').toLowerCase().includes(q);

    const matchesStage = stageFilter === 'All' || s.stage === stageFilter;
    const matchesFactory = factoryFilter === 'All' || s.factory === factoryFilter;
    const matchesNotification = notificationFilter === 'All' || (s.picNotificationStatus || 'Not Sent') === notificationFilter;

    return matchesSearch && matchesStage && matchesFactory && matchesNotification;
  });

  return (
    <div id="production-schedule-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette, compact layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <Cpu className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                Production Scheduling & Stage Tracking
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                LINE STAGE DISPATCH
              </span>
            </div>
          </div>
        </div>

        <button
          onClick={handleResetForm}
          className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-sm flex items-center space-x-1.5 transition-all cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Job Order</span>
        </button>
      </div>

      {/* STAGE PIPELINE MONITOR */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {stagesList.map((stg) => {
          const count = schedules.filter((s) => s.stage === stg).length;
          const holds = schedules.filter((s) => s.stage === stg && s.status === 'Quality Gate Hold').length;
          return (
            <div
              key={stg}
              onClick={() => setStageFilter(stageFilter === stg ? 'All' : stg)}
              className={`p-3 rounded-xl border transition-all cursor-pointer ${
                stageFilter === stg
                  ? 'bg-pink-950/80 border-pink-500 ring-1 ring-pink-500 text-pink-200'
                  : 'bg-[#1A1A1A] border-emerald-800/40 hover:border-pink-500/50 text-slate-300'
              }`}
            >
              <div className="text-[11px] font-bold uppercase tracking-tight truncate font-['Chakra_Petch']">
                {stg}
              </div>
              <div className="flex items-baseline justify-between mt-1">
                <span className="text-xl font-extrabold font-mono text-white">{count}</span>
                {holds > 0 && (
                  <span className="text-[10px] font-bold bg-rose-950 text-rose-300 border border-rose-700 px-1.5 py-0.5 rounded">
                    {holds} Hold
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* FORM & REAL-TIME PROGRESS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Job Order Form */}
        <form onSubmit={handleSaveSchedule} className="lg:col-span-8 bg-[#1A1A1A] rounded-xl shadow-md border border-emerald-800/40 overflow-hidden">
          <div className="bg-gradient-to-r from-pink-600 to-rose-600 text-white py-2.5 px-4 font-bold text-xs tracking-wide font-['Chakra_Petch'] flex items-center justify-between uppercase">
            <span>Job Order Execution & P.I.C. Notification</span>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-mono bg-black/40 text-pink-200 px-2.5 py-0.5 rounded font-bold border border-white/20">
                {jobOrderNo}
              </span>
            </div>
          </div>

          <div className="p-4 md:p-5 space-y-4 text-xs bg-[#161616]">
            
            {/* Core Job Details */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Job Order No:</label>
                <input
                  type="text"
                  value={jobOrderNo}
                  onChange={(e) => setJobOrderNo(e.target.value)}
                  required
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-mono font-bold text-pink-400 focus:border-pink-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Part Number:</label>
                <input
                  type="text"
                  value={partNumber}
                  onChange={(e) => setPartNumber(e.target.value)}
                  required
                  placeholder="e.g. MX57-24P-M-CONN"
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-mono font-bold text-white focus:border-pink-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Line / Workcenter:</label>
                <input
                  type="text"
                  value={lineName}
                  onChange={(e) => setLineName(e.target.value)}
                  required
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs text-white focus:border-pink-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Factory:</label>
                <select
                  value={factory}
                  onChange={(e) => setFactory(e.target.value as FactoryType)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-semibold text-white focus:border-pink-500 focus:outline-none"
                >
                  <option value="First Factory">First Factory (1F)</option>
                  <option value="Second Factory">Second Factory (2F)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Production Stage:</label>
                <select
                  value={stage}
                  onChange={(e) => setStage(e.target.value as ProductionStage)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-semibold text-white focus:border-pink-500 focus:outline-none"
                >
                  {stagesList.map((stg) => (
                    <option key={stg} value={stg}>{stg}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Schedule Status:</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-bold text-white focus:border-pink-500 focus:outline-none"
                >
                  <option value="Scheduled">Scheduled</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Quality Gate Hold">Quality Gate Hold</option>
                  <option value="Completed">Completed</option>
                  <option value="Delayed">Delayed</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-300 uppercase mb-1">Part Description:</label>
              <input
                type="text"
                value={partDescription}
                onChange={(e) => setPartDescription(e.target.value)}
                required
                className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-1.5 text-xs text-white focus:border-pink-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Target Quantity (pcs):</label>
                <input
                  type="number"
                  min="1"
                  value={targetQuantity}
                  onChange={(e) => setTargetQuantity(parseInt(e.target.value) || 1)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-mono font-bold text-white focus:border-pink-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Completed Quantity (pcs):</label>
                <input
                  type="number"
                  min="0"
                  value={completedQuantity}
                  onChange={(e) => setCompletedQuantity(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-mono font-bold text-emerald-400 focus:border-pink-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Defects (pcs):</label>
                <input
                  type="number"
                  min="0"
                  value={defectQuantity}
                  onChange={(e) => setDefectQuantity(parseInt(e.target.value) || 0)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-mono font-bold text-rose-400 focus:border-pink-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Start Date:</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-mono text-white focus:border-pink-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-300 uppercase mb-1">Target End Date:</label>
                <input
                  type="date"
                  value={targetEndDate}
                  onChange={(e) => setTargetEndDate(e.target.value)}
                  className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-2 text-xs font-mono font-bold text-white focus:border-pink-500 focus:outline-none"
                />
              </div>
            </div>

            {/* P.I.C. Notification Workflow Panel (Controlled Status & Audit Engine) */}
            <div className="p-4 bg-[#10241b] rounded-xl border border-emerald-700/70 space-y-3.5 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-800/80 pb-2">
                <div className="flex items-center space-x-2">
                  <div className="p-1.5 bg-emerald-900 text-emerald-200 rounded-lg border border-emerald-600/50">
                    <UserCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-white text-xs uppercase tracking-wider font-['Chakra_Petch']">
                      Person-in-Charge (P.I.C.) Notification Workflow
                    </span>
                    <span className="ml-2">{getNotificationBadge(picNotificationStatus)}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={handleNotifyPIC}
                    className="px-3 py-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-lg text-xs font-bold shadow-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                    title="Dispatch immediate schedule notification to assigned P.I.C."
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Notify PIC</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleAcknowledgePIC}
                    className="px-3 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-lg text-xs font-bold shadow-xs flex items-center space-x-1.5 transition-all cursor-pointer"
                    title="Record PIC acknowledgment of schedule"
                  >
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Acknowledge</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-emerald-300 uppercase mb-1">
                    Assigned P.I.C. Name:
                  </label>
                  <input
                    type="text"
                    value={picName}
                    onChange={(e) => setPicName(e.target.value)}
                    required
                    placeholder="Engineer / Line Leader name"
                    className="w-full bg-[#091b14] border border-emerald-600/70 rounded px-3 py-2 text-xs font-semibold text-white focus:border-pink-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-emerald-300 uppercase mb-1">
                    PIC Department / Section:
                  </label>
                  <input
                    type="text"
                    value={picDepartment}
                    onChange={(e) => setPicDepartment(e.target.value)}
                    placeholder="e.g. Stamping, Molding, Assembly"
                    className="w-full bg-[#091b14] border border-emerald-600/70 rounded px-3 py-2 text-xs text-white focus:border-pink-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-emerald-300 uppercase mb-1">
                    Notification Status (Controlled):
                  </label>
                  <select
                    value={picNotificationStatus}
                    onChange={(e) => setPicNotificationStatus(e.target.value as PICNotificationStatus)}
                    className="w-full bg-[#091b14] border border-emerald-600/70 rounded px-3 py-2 text-xs font-bold text-white focus:border-pink-500 focus:outline-none"
                  >
                    {notificationStatusOptions.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-emerald-300 uppercase mb-1">
                    Dispatch Method:
                  </label>
                  <select
                    value={picNotificationMethod}
                    onChange={(e) => setPicNotificationMethod(e.target.value as any)}
                    className="w-full bg-[#091b14] border border-emerald-600/70 rounded px-3 py-2 text-xs text-white focus:border-pink-500 focus:outline-none"
                  >
                    <option value="In-App Alert">In-App Alert</option>
                    <option value="Email">Email Broadcast</option>
                    <option value="SMS / Pager">SMS / Pager</option>
                    <option value="Radio Dispatch">Radio Dispatch</option>
                    <option value="Direct Handover">Direct Handover</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-emerald-300 uppercase mb-1">
                    Notification Date & Time:
                  </label>
                  <input
                    type="text"
                    value={picNotificationDate}
                    onChange={(e) => setPicNotificationDate(e.target.value)}
                    placeholder="Auto-generated upon dispatch"
                    className="w-full bg-[#091b14] border border-emerald-600/70 rounded px-3 py-2 text-xs font-mono text-emerald-200 focus:border-pink-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-emerald-300 uppercase mb-1">
                    Acknowledged At:
                  </label>
                  <input
                    type="text"
                    value={picNotificationAcknowledgedAt}
                    onChange={(e) => setPicNotificationAcknowledgedAt(e.target.value)}
                    placeholder="Auto-recorded on PIC confirm"
                    className="w-full bg-[#091b14] border border-emerald-600/70 rounded px-3 py-2 text-xs font-mono text-emerald-200 focus:border-pink-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-emerald-300 uppercase mb-1">
                  Notification Audit Remarks / Response:
                </label>
                <input
                  type="text"
                  value={picNotificationRemarks}
                  onChange={(e) => setPicNotificationRemarks(e.target.value)}
                  placeholder="e.g. PIC acknowledged line setup on Line 1 at 08:30"
                  className="w-full bg-[#091b14] border border-emerald-600/70 rounded px-3 py-1.5 text-xs text-white focus:border-pink-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-300 uppercase mb-1">Production Notes:</label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Tooling setup, lot change notes..."
                className="w-full bg-[#141414] border border-slate-700 rounded px-3 py-1.5 text-xs text-white focus:border-pink-500 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                type="button"
                onClick={handleResetForm}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-bold transition-colors cursor-pointer"
              >
                Clear
              </button>
              <button
                type="submit"
                id="btn-save-production-schedule"
                className="px-6 py-2 bg-gradient-to-r from-[#044e3b] to-emerald-700 hover:from-[#033b2c] hover:to-emerald-800 text-white rounded-lg text-xs font-bold shadow flex items-center space-x-1.5 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Production Schedule</span>
              </button>
            </div>
          </div>
        </form>

        {/* Real-Time Line Yield Gauge */}
        <div className="lg:col-span-4 bg-[#1A1A1A] p-4 md:p-5 rounded-xl shadow-md border border-emerald-800/40 space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider flex items-center space-x-1.5 font-['Chakra_Petch']">
                <Cpu className="w-4 h-4 text-pink-400" />
                <span>Live Production Output</span>
              </span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950 border border-emerald-700/60 px-2 py-0.5 rounded">
                REAL-TIME
              </span>
            </div>

            <div className="py-4 space-y-4">
              <div>
                <div className="flex justify-between text-xs font-bold text-slate-300 mb-1">
                  <span>Batch Completion Progress</span>
                  <span className="font-mono text-pink-400">{Math.round((completedQuantity / Math.max(targetQuantity, 1)) * 100)}%</span>
                </div>
                <div className="w-full bg-slate-900 h-3 rounded-full overflow-hidden border border-slate-700">
                  <div
                    className="bg-gradient-to-r from-emerald-500 to-emerald-400 h-full transition-all duration-500"
                    style={{ width: `${Math.min(100, Math.round((completedQuantity / Math.max(targetQuantity, 1)) * 100))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 mt-1 font-mono">
                  <span>{completedQuantity.toLocaleString()} pcs</span>
                  <span>{targetQuantity.toLocaleString()} pcs target</span>
                </div>
              </div>

              <div className="bg-[#141414] p-3 rounded-lg border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Calculated Yield Rate:</span>
                  <span className="font-bold font-mono text-emerald-400">
                    {completedQuantity > 0 ? ((1 - defectQuantity / completedQuantity) * 100).toFixed(2) : 100}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Scrap / Reject:</span>
                  <span className="font-bold font-mono text-rose-400">{defectQuantity} pcs</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Target Completion:</span>
                  <span className="font-mono text-slate-300 font-semibold">{targetEndDate}</span>
                </div>
                <div className="flex justify-between border-t border-slate-800 pt-1.5">
                  <span className="text-slate-400">Assigned P.I.C.:</span>
                  <span className="font-bold text-pink-300">{picName || 'Unassigned'}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-emerald-950/60 border border-emerald-800/60 rounded-lg text-emerald-300 text-xs">
            <span className="font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Automated Quality Gate Status:
            </span>
            <p className="text-[11px] mt-0.5 text-emerald-400">
              Inspection parameters synchronized with QM database standards.
            </p>
          </div>
        </div>

      </div>

      {/* Production Schedule Table */}
      <div className="bg-[#1A1A1A] rounded-xl shadow-md border border-emerald-800/40 overflow-hidden">
        <div className="bg-[#141414] text-white py-2.5 px-4 font-bold text-xs tracking-wider uppercase font-['Chakra_Petch'] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <span className="text-emerald-400">ACTIVE PRODUCTION JOB ORDERS</span>
            <span className="text-[10px] text-slate-400 font-mono">({filteredSchedules.length} Items)</span>
          </div>

          <div className="flex items-center flex-wrap gap-2 w-full sm:w-auto">
            <div className="relative w-full sm:w-44">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
              <input
                type="text"
                placeholder="Search JO / PIC..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#1a1a1a] text-white pl-8 pr-2 py-1 rounded text-xs border border-slate-700 focus:outline-none focus:border-pink-500"
              />
            </div>

            <select
              value={factoryFilter}
              onChange={(e) => setFactoryFilter(e.target.value)}
              className="bg-[#1a1a1a] text-white px-2 py-1 rounded text-xs border border-slate-700 focus:outline-none"
            >
              <option value="All">All Factories</option>
              <option value="First Factory">1F Only</option>
              <option value="Second Factory">2F Only</option>
            </select>

            <select
              value={notificationFilter}
              onChange={(e) => setNotificationFilter(e.target.value)}
              className="bg-[#1a1a1a] text-white px-2 py-1 rounded text-xs border border-slate-700 focus:outline-none"
            >
              <option value="All">All Notification Statuses</option>
              <option value="Not Sent">🔔 Not Sent</option>
              <option value="Pending">⏳ Pending</option>
              <option value="Notified">📨 Notified</option>
              <option value="Acknowledged">✅ Acknowledged</option>
              <option value="Rescheduled">🔄 Rescheduled</option>
              <option value="Cancelled">❌ Cancelled</option>
              <option value="Failed">⚠️ Failed</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#121212] text-emerald-400 border-b border-slate-800 font-bold uppercase text-[10px] tracking-wider font-mono">
                <th className="p-2.5 border-r border-slate-800">JOB ORDER</th>
                <th className="p-2.5 border-r border-slate-800">PART NUMBER</th>
                <th className="p-2.5 border-r border-slate-800">LINE / FACTORY</th>
                <th className="p-2.5 border-r border-slate-800">STAGE</th>
                <th className="p-2.5 border-r border-slate-800">PROGRESS (PCS)</th>
                <th className="p-2.5 border-r border-slate-800">P.I.C. NOTIFICATION</th>
                <th className="p-2.5 border-r border-slate-800">DUE DATE</th>
                <th className="p-2.5 border-r border-slate-800">STATUS</th>
                <th className="p-2.5 text-center">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 bg-[#161616]">
              {filteredSchedules.map((item) => (
                <tr
                  key={item.id}
                  onClick={() => handleSelectSchedule(item)}
                  className={`hover:bg-white/5 cursor-pointer transition-colors ${selectedScheduleId === item.id ? 'bg-pink-950/40 font-semibold' : ''}`}
                >
                  <td className="p-2.5 border-r border-slate-800 font-mono font-bold text-pink-400 whitespace-nowrap">
                    {item.jobOrderNo}
                  </td>
                  <td className="p-2.5 border-r border-slate-800 font-mono font-semibold text-slate-200 whitespace-nowrap">
                    {item.partNumber}
                  </td>
                  <td className="p-2.5 border-r border-slate-800 text-slate-300 whitespace-nowrap">
                    {item.lineName} ({item.factory === 'First Factory' ? '1F' : '2F'})
                  </td>
                  <td className="p-2.5 border-r border-slate-800 font-semibold text-slate-300 whitespace-nowrap">
                    {item.stage}
                  </td>
                  <td className="p-2.5 border-r border-slate-800 font-mono whitespace-nowrap">
                    <span className="font-bold text-emerald-400">{item.completedQuantity.toLocaleString()}</span> / {item.targetQuantity.toLocaleString()}
                  </td>
                  <td className="p-2.5 border-r border-slate-800 whitespace-nowrap">
                    <div className="flex flex-col gap-0.5">
                      <div>{getNotificationBadge(item.picNotificationStatus)}</div>
                      <div className="text-[10px] text-slate-400 font-medium">
                        PIC: <span className="text-pink-300 font-semibold">{item.picName || 'N/A'}</span>
                      </div>
                    </div>
                  </td>
                  <td className="p-2.5 border-r border-slate-800 font-mono text-slate-400 whitespace-nowrap">
                    {item.targetEndDate}
                  </td>
                  <td className="p-2.5 border-r border-slate-800 whitespace-nowrap">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                      item.status === 'Completed'
                        ? 'bg-emerald-950 text-emerald-300 border-emerald-700/60'
                        : item.status === 'Quality Gate Hold'
                        ? 'bg-rose-950 text-rose-300 border-rose-700/60'
                        : 'bg-blue-950 text-blue-300 border-blue-700/60'
                    }`}>
                      {item.status}
                    </span>
                  </td>
                  <td className="p-2.5 text-center whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-center space-x-1.5">
                      <button
                        type="button"
                        onClick={() => handleSelectSchedule(item)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-pink-300 rounded text-[11px] font-bold border border-slate-700 transition-colors cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const now = new Date().toLocaleString();
                          const sender = `${currentUser.firstName} ${currentUser.lastName} (${currentUser.role})`;
                          storageService.saveProductionSchedule({
                            ...item,
                            picNotificationStatus: 'Notified',
                            picNotificationDate: now,
                            picNotificationSentBy: sender
                          });
                          setSchedules(storageService.getProductionSchedules());
                          onRefreshData();
                        }}
                        className="p-1 bg-blue-950 hover:bg-blue-900 text-blue-300 rounded border border-blue-700/60 transition-colors cursor-pointer"
                        title="Quick Notify PIC"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};

