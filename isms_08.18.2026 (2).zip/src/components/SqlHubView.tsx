import React, { useState, useEffect } from 'react';
import {
  Database,
  Server,
  RefreshCw,
  Copy,
  Download,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  Layers,
  Save,
  Wifi,
  WifiOff,
  CloudUpload,
  ArrowRight,
  ShieldCheck,
  Code2,
  FileText,
  HardDrive,
  Terminal,
  Clock,
  ExternalLink
} from 'lucide-react';
import { SQLConfig, UserProfile } from '../types';
import { storageService } from '../services/storageService';
import { apiClient, ApiHealthStatus } from '../services/apiClient';

interface SqlHubViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
}

export const SqlHubView: React.FC<SqlHubViewProps> = ({ currentUser, onRefreshData }) => {
  const [sqlConfig, setSqlConfig] = useState<SQLConfig>(storageService.getSQLConfig());
  const [activeTab, setActiveTab] = useState<'status' | 'scripts' | 'api' | 'backup' | 'guide'>('status');
  const [apiHealth, setApiHealth] = useState<ApiHealthStatus | null>(null);
  const [testingConnection, setTestingConnection] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [selectedScriptId, setSelectedScriptId] = useState<string>('001');
  const [customApiUrl, setCustomApiUrl] = useState<string>(apiClient.getBaseUrl());

  const isSysadmin = currentUser.role === 'Sysadmin';
  const isAdmin = currentUser.role === 'Admin';
  const hasDbaAccess = isSysadmin || isAdmin;

  // Available SQL Server Migration Scripts
  const sqlScripts = [
    {
      id: '001',
      title: '001_CreateDatabase.sql',
      desc: 'Database creation, UTF-8 collation & Snapshot Isolation for high-concurrency QMS transactions',
      code: `-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 001: Database Creation & High-Performance Configuration
-- Target Database: Microsoft SQL Server 2019 / 2022 / SQL Express
-- IATF 16949 / ISO 9001 Compliance Tier
-- ==============================================================================

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'ISMS_QM_DB')
BEGIN
    CREATE DATABASE [ISMS_QM_DB]
    COLLATE Latin1_General_100_CI_AS_SC_UTF8;
    PRINT 'Database [ISMS_QM_DB] created successfully with UTF-8 collation.';
END
ELSE
BEGIN
    PRINT 'Database [ISMS_QM_DB] already exists.';
END
GO

USE [ISMS_QM_DB];
GO

-- Enable Snapshot Isolation for high-concurrency multi-user transactions without lock contention
ALTER DATABASE [ISMS_QM_DB] SET READ_COMMITTED_SNAPSHOT ON WITH ROLLBACK IMMEDIATE;
ALTER DATABASE [ISMS_QM_DB] SET ALLOW_SNAPSHOT_ISOLATION ON;
ALTER DATABASE [ISMS_QM_DB] SET AUTO_UPDATE_STATISTICS ON;
ALTER DATABASE [ISMS_QM_DB] SET RECOVERY FULL;
GO

-- Create Dedicated Schema for QMS
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'qms')
    EXEC('CREATE SCHEMA [qms] AUTHORIZATION [dbo]');
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'audit')
    EXEC('CREATE SCHEMA [audit] AUTHORIZATION [dbo]');
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'sec')
    EXEC('CREATE SCHEMA [sec] AUTHORIZATION [dbo]');
GO

PRINT 'Script 001 executed: Database, Schemas, and Snapshot Isolation configured.';`
    },
    {
      id: '002',
      title: '002_Security_RBAC.sql',
      desc: 'User accounts, salted password hashes (PBKDF2/BCrypt), roles and granular permission matrix',
      code: `-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 002: Security, Users, Roles & Granular Permission Matrix (RBAC)
-- ==============================================================================

USE [ISMS_QM_DB];
GO

IF OBJECT_ID(N'[sec].[Roles]', N'U') IS NULL
BEGIN
    CREATE TABLE [sec].[Roles] (
        [RoleId] NVARCHAR(50) NOT NULL PRIMARY KEY,
        [RoleName] NVARCHAR(100) NOT NULL,
        [Description] NVARCHAR(255) NULL,
        [HierarchyLevel] INT NOT NULL DEFAULT 1,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [IsActive] BIT NOT NULL DEFAULT 1
    );
END
GO

IF OBJECT_ID(N'[sec].[Users]', N'U') IS NULL
BEGIN
    CREATE TABLE [sec].[Users] (
        [UserId] NVARCHAR(64) NOT NULL PRIMARY KEY,
        [EmployeeId] NVARCHAR(50) NOT NULL UNIQUE,
        [Username] NVARCHAR(50) NOT NULL UNIQUE,
        [PasswordHash] NVARCHAR(255) NOT NULL,
        [PasswordSalt] NVARCHAR(128) NOT NULL,
        [FirstName] NVARCHAR(100) NOT NULL,
        [LastName] NVARCHAR(100) NOT NULL,
        [Email] NVARCHAR(150) NOT NULL,
        [Department] NVARCHAR(50) NOT NULL,
        [Section] NVARCHAR(50) NOT NULL,
        [Factory] NVARCHAR(20) NOT NULL,
        [Shift] NVARCHAR(20) NOT NULL DEFAULT 'Shift A',
        [RoleId] NVARCHAR(50) NOT NULL FOREIGN KEY REFERENCES [sec].[Roles]([RoleId]),
        [IsActive] BIT NOT NULL DEFAULT 1,
        [FailedLoginAttempts] INT NOT NULL DEFAULT 0,
        [LockoutEnd] DATETIMEOFFSET NULL,
        [LastLoginAt] DATETIMEOFFSET NULL,
        [CreatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [RowVersion] ROWVERSION NOT NULL
    );
END
GO`
    },
    {
      id: '007',
      title: '007_Audit_Immutable.sql',
      desc: 'Server-side cryptographic SHA-256 block hash chain & atomic sequence number generators',
      code: `-- ==============================================================================
-- JAE Philippines, Inc. - iSMS (Integrated Sample Management System)
-- SCRIPT 007: Immutable Cryptographic Audit Trail, SHA-256 Hash Chain & Sequence Engine
-- Compliance: IATF 16949 §7.5.3.2.1 (Record Retention & Tamper Resistance)
-- ==============================================================================

USE [ISMS_QM_DB];
GO

-- Concurrency-Safe Sequence Engine
IF OBJECT_ID(N'[qms].[DocumentSequences]', N'U') IS NULL
BEGIN
    CREATE TABLE [qms].[DocumentSequences] (
        [SequencePrefix] NVARCHAR(20) NOT NULL,
        [YearMonth] NVARCHAR(6) NOT NULL,
        [CurrentValue] INT NOT NULL DEFAULT 0,
        [UpdatedAt] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        CONSTRAINT PK_DocumentSequences PRIMARY KEY ([SequencePrefix], [YearMonth])
    );
END
GO

-- Server-Side Immutable Audit Trail with Cryptographic Verification
IF OBJECT_ID(N'[audit].[AuditLogs]', N'U') IS NULL
BEGIN
    CREATE TABLE [audit].[AuditLogs] (
        [AuditId] BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        [CorrelationId] NVARCHAR(64) NOT NULL,
        [Timestamp] DATETIMEOFFSET NOT NULL DEFAULT SYSDATETIMEOFFSET(),
        [ActorUserId] NVARCHAR(64) NULL,
        [ActorEmployeeId] NVARCHAR(50) NOT NULL,
        [ActorName] NVARCHAR(100) NOT NULL,
        [ActorRole] NVARCHAR(50) NOT NULL,
        [Module] NVARCHAR(100) NOT NULL,
        [Action] NVARCHAR(100) NOT NULL,
        [RecordId] NVARCHAR(100) NOT NULL,
        [Details] NVARCHAR(MAX) NOT NULL,
        [PreviousValues] NVARCHAR(MAX) NULL,
        [NewValues] NVARCHAR(MAX) NULL,
        [IpAddress] NVARCHAR(45) NOT NULL,
        [UserAgent] NVARCHAR(255) NULL,
        [PreviousBlockHash] NVARCHAR(64) NULL,
        [CurrentBlockHash] NVARCHAR(64) NOT NULL
    );
END
GO`
    }
  ];

  // Test real HTTP connection to ASP.NET Core API backend
  const checkLiveConnection = async () => {
    setTestingConnection(true);
    const result = await apiClient.checkHealth();
    setApiHealth(result);
    setTestingConnection(false);
  };

  useEffect(() => {
    checkLiveConnection();
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleDownloadScript = (fileName: string, content: string) => {
    const blob = new Blob([content], { type: 'text/sql;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportFullBackup = () => {
    const backupJson = storageService.exportFullBackupJSON();
    const blob = new Blob([backupJson], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `iSMS_Local_Storage_Snapshot_${Date.now()}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const selectedScript = sqlScripts.find(s => s.id === selectedScriptId) || sqlScripts[0];

  return (
    <div id="sql-hub-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Module Header */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <Database className="w-5 h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                Microsoft SQL Server & ASP.NET Core 8 Web API Foundation
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-emerald-950/90 text-emerald-300 rounded-md font-mono font-bold border border-emerald-700/60">
                IATF 16949 COMPLIANT
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium">
              Enterprise Instance: <span className="font-mono font-bold text-pink-300">{sqlConfig.serverName}</span> • Target DB: <span className="font-mono font-bold text-emerald-300">{sqlConfig.databaseName}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className={`text-xs px-2.5 py-1 rounded-lg font-bold border flex items-center gap-1.5 ${
            isSysadmin
              ? 'bg-purple-950/80 text-purple-200 border-purple-600/70'
              : isAdmin
              ? 'bg-blue-950/80 text-blue-200 border-blue-600/70'
              : 'bg-emerald-950/80 text-emerald-200 border-emerald-600/70'
          }`}>
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Role: {currentUser.role} {isSysadmin ? '(Full DBA Access)' : isAdmin ? '(Admin View)' : '(Operator View)'}</span>
          </span>
          <button
            onClick={checkLiveConnection}
            disabled={testingConnection}
            className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 disabled:opacity-50 text-white rounded-lg text-xs font-bold border border-emerald-500/50 flex items-center space-x-1.5 transition-colors shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testingConnection ? 'animate-spin' : ''}`} />
            <span>Test Live Connection</span>
          </button>
        </div>
      </div>

      {/* Connection State Banner (Transparent, Honest Reporting) */}
      <div className={`p-4 rounded-xl border flex flex-col md:flex-row items-start md:items-center justify-between gap-3 ${
        apiHealth?.online 
          ? 'bg-emerald-950/40 border-emerald-600/60 text-emerald-200' 
          : 'bg-amber-950/30 border-amber-600/50 text-amber-200'
      }`}>
        <div className="flex items-start space-x-3">
          {apiHealth?.online ? (
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/40 shrink-0">
              <Wifi className="w-5 h-5 text-emerald-400" />
            </div>
          ) : (
            <div className="p-2 bg-amber-500/20 text-amber-400 rounded-lg border border-amber-500/40 shrink-0">
              <WifiOff className="w-5 h-5 text-amber-400" />
            </div>
          )}
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm font-['Chakra_Petch'] uppercase">
                {apiHealth?.online ? 'Connected to ASP.NET Core 8 Web API' : 'Local Offline Draft Mode Active'}
              </span>
              <span className={`text-[10px] px-2 py-0.2 rounded-full font-mono font-bold ${
                apiHealth?.online ? 'bg-emerald-500/30 text-emerald-300' : 'bg-amber-500/30 text-amber-300'
              }`}>
                {apiHealth?.online ? `Latency: ${apiHealth.latencyMs}ms` : 'API Server Not Running'}
              </span>
            </div>
            <p className="text-xs mt-1 text-slate-300">
              {apiHealth?.online 
                ? `Successfully communicating with backend on ${apiClient.getBaseUrl()}. SQL Server connection verified.`
                : `Currently using browser storage cache. To connect to live Microsoft SQL Server, launch the ASP.NET Core API server located in /backend/ISMS.Api/ on http://localhost:5000.`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <input
            type="text"
            value={customApiUrl}
            onChange={(e) => setCustomApiUrl(e.target.value)}
            disabled={!isSysadmin}
            className={`px-2.5 py-1 bg-slate-900 border rounded text-xs font-mono w-56 focus:outline-none ${
              isSysadmin
                ? 'border-slate-700 text-slate-200 focus:border-emerald-500'
                : 'border-slate-800 text-slate-400 cursor-not-allowed'
            }`}
            placeholder="http://localhost:5000/api"
            title={isSysadmin ? 'Configure API Endpoint' : 'Only Sysadmin can change API endpoint binding'}
          />
          {isSysadmin && (
            <button
              onClick={() => {
                apiClient.setBaseUrl(customApiUrl);
                checkLiveConnection();
              }}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded border border-slate-600 transition-colors"
            >
              Apply
            </button>
          )}
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('status')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-colors ${
            activeTab === 'status' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>System Topology & Endpoints</span>
        </button>

        <button
          onClick={() => setActiveTab('scripts')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-colors ${
            activeTab === 'scripts' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <FileCode className="w-3.5 h-3.5" />
          <span>8-Part SQL Server Scripts</span>
        </button>

        <button
          onClick={() => setActiveTab('api')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-colors ${
            activeTab === 'api' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>ASP.NET Core 8 Web API</span>
        </button>

        <button
          onClick={() => setActiveTab('backup')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-colors ${
            activeTab === 'backup' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <HardDrive className="w-3.5 h-3.5" />
          <span>SQL .BAK Backup & DR</span>
        </button>

        <button
          onClick={() => setActiveTab('guide')}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-colors ${
            activeTab === 'guide' ? 'bg-emerald-700 text-white shadow-xs' : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>IIS & Server Guide</span>
        </button>
      </div>

      {/* TAB 1: SYSTEM TOPOLOGY & ENDPOINTS */}
      {activeTab === 'status' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: SQL Server Database */}
          <div className="bg-[#18181b] border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-emerald-600/20 text-emerald-400 rounded-lg border border-emerald-500/30">
                <Database className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">SQL Server Database</h3>
                <p className="text-[11px] text-slate-400">Microsoft SQL Server 2022 / Express</p>
              </div>
            </div>

            <div className="space-y-2 text-xs font-mono bg-slate-950/80 p-3 rounded-lg border border-slate-800/80">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Instance:</span>
                <span className="text-pink-300 font-bold">{sqlConfig.serverName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Database:</span>
                <span className="text-emerald-300 font-bold">{sqlConfig.databaseName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Collation:</span>
                <span className="text-slate-200">Latin1_General_100_CI_AS_SC_UTF8</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Isolation:</span>
                <span className="text-emerald-400">READ_COMMITTED_SNAPSHOT</span>
              </div>
            </div>
          </div>

          {/* Card 2: ASP.NET Core 8 Web API */}
          <div className="bg-[#18181b] border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-600/20 text-blue-400 rounded-lg border border-blue-500/30">
                <Server className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">ASP.NET Core 8 Web API</h3>
                <p className="text-[11px] text-slate-400">C# 12 / .NET 8 / EF Core</p>
              </div>
            </div>

            <div className="space-y-2 text-xs font-mono bg-slate-950/80 p-3 rounded-lg border border-slate-800/80">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Base URL:</span>
                <span className="text-blue-300">{apiClient.getBaseUrl()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Auth Engine:</span>
                <span className="text-slate-200">JWT Bearer + PBKDF2/BCrypt</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Audit Chain:</span>
                <span className="text-emerald-400">SHA-256 Block Hashing</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Sequences:</span>
                <span className="text-slate-200">Atomic SQL Procedure</span>
              </div>
            </div>
          </div>

          {/* Card 3: Storage & Safety State */}
          <div className="bg-[#18181b] border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-600/20 text-purple-400 rounded-lg border border-purple-500/30">
                <ShieldCheck className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">Security & IATF 16949</h3>
                <p className="text-[11px] text-slate-400">Strict Server-Enforced RBAC</p>
              </div>
            </div>

            <div className="space-y-2 text-xs font-mono bg-slate-950/80 p-3 rounded-lg border border-slate-800/80">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Identity Guard:</span>
                <span className="text-emerald-300">Server Token Claims</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Password Policy:</span>
                <span className="text-slate-200">Salted Hashes Only</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Audit Trail:</span>
                <span className="text-purple-300">Immutable & Append-Only</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">DR Status:</span>
                <span className="text-slate-200">Full .BAK Script Ready</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: 8-PART MODULAR SQL SCRIPTS */}
      {activeTab === 'scripts' && (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {sqlScripts.map((script) => (
              <button
                key={script.id}
                onClick={() => setSelectedScriptId(script.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono transition-colors ${
                  selectedScriptId === script.id
                    ? 'bg-pink-600 text-white shadow-xs'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {script.title}
              </button>
            ))}
          </div>

          <div className="bg-[#141414] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
            <div className="bg-slate-900/90 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-emerald-400 font-mono">{selectedScript.title}</span>
                <p className="text-[11px] text-slate-400">{selectedScript.desc}</p>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleCopy(selectedScript.code, selectedScript.id)}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-bold flex items-center space-x-1 border border-slate-700 transition-colors"
                >
                  {copied === selectedScript.id ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied === selectedScript.id ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={() => handleDownloadScript(selectedScript.title, selectedScript.code)}
                  className="px-2.5 py-1 bg-emerald-700 hover:bg-emerald-600 text-white rounded text-xs font-bold flex items-center space-x-1 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .sql</span>
                </button>
              </div>
            </div>

            <pre className="p-4 text-xs font-mono text-emerald-300/90 bg-slate-950 overflow-x-auto max-h-96 leading-relaxed select-all">
              {selectedScript.code}
            </pre>
          </div>
        </div>
      )}

      {/* TAB 3: ASP.NET CORE 8 WEB API PROJECT */}
      {activeTab === 'api' && (
        <div className="bg-[#18181b] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Code2 className="w-4 h-4 text-blue-400" />
                ASP.NET Core 8 Web API Project Structure
              </h3>
              <p className="text-xs text-slate-400">Located in <code className="text-emerald-300 font-mono">/backend/ISMS.Api/</code> in this workspace</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono space-y-2">
              <div className="text-slate-400 font-bold uppercase text-[10px] pb-1 border-b border-slate-800">Controllers & Endpoints</div>
              <div className="text-emerald-400">POST /api/auth/login <span className="text-slate-400">- JWT PBKDF2</span></div>
              <div className="text-blue-400">GET /api/keepsample/boxes <span className="text-slate-400">- Box Master</span></div>
              <div className="text-blue-400">POST /api/keepsample/requests <span className="text-slate-400">- BKS Requisition</span></div>
              <div className="text-purple-400">GET /api/rsis <span className="text-slate-400">- Defect Sample Records</span></div>
              <div className="text-pink-400">GET /api/audit <span className="text-slate-400">- SHA-256 Immutable Audit</span></div>
              <div className="text-amber-400">GET /api/health <span className="text-slate-400">- SQL Server Diagnostic</span></div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs font-mono space-y-2">
              <div className="text-slate-400 font-bold uppercase text-[10px] pb-1 border-b border-slate-800">C# Services & Infrastructure</div>
              <div className="text-slate-200">ISMSDbContext.cs <span className="text-slate-400">(EF Core SQL Server)</span></div>
              <div className="text-slate-200">AuditLogService.cs <span className="text-slate-400">(SHA-256 Block Chain)</span></div>
              <div className="text-slate-200">DocumentSequenceService.cs <span className="text-slate-400">(Atomic T-SQL)</span></div>
              <div className="text-slate-200">Program.cs <span className="text-slate-400">(.NET 8 Kestrel + CORS)</span></div>
              <div className="text-slate-200">appsettings.json <span className="text-slate-400">(Connection Strings)</span></div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: SQL .BAK BACKUP & DISASTER RECOVERY */}
      {activeTab === 'backup' && (
        <div className="bg-[#18181b] border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-emerald-400" />
                Physical SQL Server Database Backup (.BAK) Generator
              </h3>
              <p className="text-xs text-slate-400">IATF 16949 / ISO 9001 Production Backup Strategy</p>
            </div>

            <button
              onClick={handleExportFullBackup}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-700 flex items-center space-x-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-pink-400" />
              <span>Export Local JSON Snapshot</span>
            </button>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-300 font-mono">T-SQL Automated Backup Script for SQL Server Agent</span>
              <button
                onClick={() => handleCopy(`USE master;\nGO\nBACKUP DATABASE [ISMS_QM_DB]\nTO DISK = N'D:\\SQL_Backups\\ISMS_QM_DB_FULL.bak'\nWITH FORMAT, MEDIANAME = N'ISMS_DB_Backups', NAME = N'Full Backup of ISMS_QM_DB', COMPRESSION, CHECKSUM, STATS = 10;\nGO`, 'bak_script')}
                className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-mono"
              >
                <Copy className="w-3 h-3" />
                <span>{copied === 'bak_script' ? 'Copied!' : 'Copy Script'}</span>
              </button>
            </div>
            <pre className="text-xs font-mono text-slate-300 overflow-x-auto p-3 bg-slate-900 rounded border border-slate-800">
{`USE master;
GO

-- Daily Compressed Full Database Backup with SHA Verification
DECLARE @BackupFile NVARCHAR(500);
SET @BackupFile = N'D:\\SQL_Backups\\ISMS_QM_DB_FULL_' + REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), ':', '-') + N'.bak';

BACKUP DATABASE [ISMS_QM_DB]
TO DISK = @BackupFile
WITH FORMAT,
     MEDIANAME = N'ISMS_DB_Backups',
     NAME = N'Full Backup of ISMS_QM_DB',
     COMPRESSION,
     CHECKSUM,
     STATS = 10;
GO`}
            </pre>
          </div>
        </div>
      )}

      {/* TAB 5: IIS & SERVER DEPLOYMENT GUIDE */}
      {activeTab === 'guide' && (
        <div className="bg-[#18181b] border border-slate-800 rounded-xl p-5 space-y-4 text-xs text-slate-300 leading-relaxed">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-purple-400" />
            Windows Server 2022 + IIS 10 Deployment Procedure
          </h3>

          <ol className="list-decimal pl-5 space-y-2">
            <li><strong>Install Prerequisites:</strong> Install .NET 8.0 Hosting Bundle and IIS URL Rewrite 2.1 on the Windows Server.</li>
            <li><strong>Execute SQL Database Scripts:</strong> Run scripts <code className="text-emerald-300 font-mono">001_CreateDatabase.sql</code> through <code className="text-emerald-300 font-mono">008_SeedData.sql</code> in SQL Server Management Studio (SSMS).</li>
            <li><strong>Publish API:</strong> Run <code className="text-blue-300 font-mono">dotnet publish -c Release</code> in <code className="text-slate-200">/backend/ISMS.Api/</code> and bind the site in IIS to port 5000.</li>
            <li><strong>Deploy React Frontend:</strong> Run <code className="text-pink-300 font-mono">npm run build</code> and copy the <code className="text-slate-200">dist/</code> directory to IIS document root.</li>
          </ol>
        </div>
      )}

    </div>
  );
};
