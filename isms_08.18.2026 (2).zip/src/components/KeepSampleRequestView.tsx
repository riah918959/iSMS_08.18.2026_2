import React, { useState, useMemo } from 'react';
import {
  FileText,
  Plus,
  Trash2,
  Save,
  CheckCircle2,
  Clock,
  Printer,
  Search,
  AlertCircle,
  ArrowRight,
  Filter,
  UserCheck,
  PackageCheck,
  ArrowLeft,
  Calendar,
  ShieldCheck,
  History,
  FileSpreadsheet,
  CheckCircle,
  Package,
  Layers,
  Send,
  AlertTriangle,
  Info,
  Lock,
  Unlock,
  X,
  ChevronDown,
  Check,
  Mail,
  Bell,
  RefreshCw,
  Eye,
  EyeOff,
  CornerDownRight
} from 'lucide-react';
import {
  KeepSampleRequest,
  SampleItemRow,
  UserProfile,
  FactoryType,
  DepartmentType,
  SampleCategory,
  KeepSampleRequestStatus
} from '../types';
import { storageService } from '../services/storageService';
import { JAELogo } from './BrandingLogos';

interface KeepSampleRequestViewProps {
  currentUser: UserProfile;
  onRefreshData: () => void;
}

export type KeepSampleReqTab = 
  | 'REQUESTOR_BORROW'
  | 'QM_APPROVAL'
  | 'QC_DELIVERY'
  | 'QC_RETURN_FILING'
  | 'AUDIT_TRAIL';

interface NotificationLog {
  id: string;
  timestamp: string;
  recipients: string[];
  subject: string;
  body: string;
  triggerAction: string;
  type: 'email' | 'system';
}

export const KeepSampleRequestView: React.FC<KeepSampleRequestViewProps> = ({
  currentUser,
  onRefreshData
}) => {
  const [requests, setRequests] = useState<KeepSampleRequest[]>(storageService.getKeepSampleRequests());
  const [isMultitabOpen, setIsMultitabOpen] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<KeepSampleReqTab>('REQUESTOR_BORROW');
  const [selectedReqId, setSelectedReqId] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error' | 'info' | 'warning'; text: string } | null>(null);
  const [printModalRequest, setPrintModalRequest] = useState<KeepSampleRequest | null>(null);

  const handlePrintSignOffSlip = (req: KeepSampleRequest) => {
    setPrintModalRequest(req);
  };

  const handleTriggerBrowserPrint = () => {
    window.print();
  };

  // Notification / Email Audit Log state
  const [notificationLogs, setNotificationLogs] = useState<NotificationLog[]>([]);
  const [showNotificationModal, setShowNotificationModal] = useState<boolean>(false);

  // 1. Requestor / Staff Member Form State
  const [controlNo, setControlNo] = useState<string>(storageService.generateNextControlNo());
  const [idNumber, setIdNumber] = useState<string>(currentUser.idNumber || currentUser.employeeId || 'JAE-57784');
  const [firstName, setFirstName] = useState<string>(currentUser.firstName || 'Maria Cristina');
  const [middleName, setMiddleName] = useState<string>(currentUser.middleName || 'Santos');
  const [lastName, setLastName] = useState<string>(currentUser.lastName || 'Reyes');
  const [dateRequested, setDateRequested] = useState<string>(new Date().toISOString().split('T')[0]);
  const [requestorName, setRequestorName] = useState<string>(`${currentUser.firstName} ${currentUser.lastName}`);
  const [department, setDepartment] = useState<DepartmentType>(currentUser.department);
  const [factory, setFactory] = useState<FactoryType>(currentUser.factory);
  const [employmentStatus, setEmploymentStatus] = useState<string>(currentUser.employmentStatus || 'JAE-Reg.');
  const [position, setPosition] = useState<string>(currentUser.position || 'Staff_E');
  const [section, setSection] = useState<string>(currentUser.section || 'Mfg. Connector');
  const [typeOfBorrowedSample, setTypeOfBorrowedSample] = useState<'KS' | 'FILES' | 'Die con' | 'RS Sample'>('KS');
  
  // Sample Request Details Items
  const [items, setItems] = useState<SampleItemRow[]>([]);

  const [dateNeeded, setDateNeeded] = useState<string>(new Date().toISOString().split('T')[0]);
  const [boxNumber, setBoxNumber] = useState<string>('');
  const [rackLocation, setRackLocation] = useState<string>('');
  const [area, setArea] = useState<string>('');
  const [returnedDueDate, setReturnedDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [reason, setReason] = useState<string>('');
  const [remarks, setRemarks] = useState<string>('');

  // 2. Requestor Filter & Search Grid for Samples (NO AUTOFILL - MANUAL ADD ONLY)
  const [filterPartName, setFilterPartName] = useState<string>('');
  const [filterDrawingNo, setFilterDrawingNo] = useState<string>('');
  const [filterPoNo, setFilterPoNo] = useState<string>('');
  const [filterLotNo, setFilterLotNo] = useState<string>('');
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState<boolean>(true);
  const [showSampleList, setShowSampleList] = useState<boolean>(false);

  // 3. QM Department Authorization State
  const [qmStaffEngineer, setQmStaffEngineer] = useState<string>('');
  const [categoryOfSample, setCategoryOfSample] = useState<SampleCategory>('Connector');
  const [approvedBy, setApprovedBy] = useState<string>('');
  const [endorsedBy, setEndorsedBy] = useState<string>('');
  const [qmDate, setQmDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [qmStatus, setQmStatus] = useState<'Approved' | 'Not Yet Approved' | 'Rejected' | 'Pending QM Review'>('Pending QM Review');

  // 4. QC Hold Delivery & Return State
  const [deliveredBy, setDeliveredBy] = useState<string>('');
  const [dateDelivered, setDateDelivered] = useState<string>('');
  const [returnedBy, setReturnedBy] = useState<string>('');
  const [dateReturned, setDateReturned] = useState<string>('');
  const [fillingInBox, setFillingInBox] = useState<string>('');
  const [dateFiled, setDateFiled] = useState<string>('');
  const [status, setStatus] = useState<KeepSampleRequestStatus>('Pending QM Approval');
  
  // Received Lock state: Once Requestor clicks "For Received", form is locked
  const [isReceivedByRequestor, setIsReceivedByRequestor] = useState<boolean>(false);

  // RBAC Permission Checks
  const isSysadmin = currentUser.role === 'Sysadmin' || currentUser.role === 'Admin';
  const isQMAdmin = currentUser.role === 'QM Admin' || isSysadmin;
  const isQMHold = currentUser.role === 'QM Hold' || currentUser.role === 'QM';
  const isQCHold = currentUser.role === 'QC Hold';
  const isQCInspector = currentUser.role === 'QC Inspector';
  const isRequestorRole = currentUser.role === 'Requestor' || (!isQMAdmin && !isQMHold && !isQCHold);

  // Verification if active user is the original requestor
  const isOriginalRequestor = useMemo(() => {
    if (!selectedReqId) return true; // Brand new draft
    const currentFullName = `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim().toLowerCase();
    const currentUsername = (currentUser.username || '').toLowerCase();
    const currentEmployeeId = (currentUser.employeeId || currentUser.idNumber || '').toLowerCase();
    const currentStaff = (currentUser.staff || '').toLowerCase();
    
    const reqName = (requestorName || '').toLowerCase();
    const reqIdNum = (idNumber || '').toLowerCase();

    return (
      currentFullName === reqName ||
      currentUsername === reqName ||
      (currentStaff && currentStaff === reqName) ||
      (currentEmployeeId && currentEmployeeId === reqIdNum) ||
      isSysadmin
    );
  }, [selectedReqId, currentUser, requestorName, idNumber, isSysadmin]);

  // Request Lifecycle Status Checks
  const isPendingApproval = status === 'For QM Approval' || status === 'Pending QM Approval';
  const isApprovedOrCompleted = status === 'For Delivery' || status === 'For QC Delivery' || status === 'For Received' || status === 'Received' || status === 'For Return' || status === 'Returned';
  const isDesignatedPIC = isOriginalRequestor || isQMAdmin || isQMHold || isQCHold;

  // Edit Access Restrictions:
  // If active user is NOT the original requestor, prevent editing submitted details while pending approval from QM Hold / QM Admin
  // If request is already received, approved, or completed, automatically lock to read-only mode
  const canEditRequestorDetails = !isReceivedByRequestor && !isApprovedOrCompleted && (
    !selectedReqId || (isOriginalRequestor && (!isPendingApproval || isOriginalRequestor))
  ) && isDesignatedPIC;

  const canEditQMApproval = isQMAdmin || isQMHold || isSysadmin;
  const canUpdateReturnFiling = isQMHold || isQMAdmin || isSysadmin;
  const canActionQCDelivery = isQCHold || isQMAdmin || isQMHold || isSysadmin;

  // Helper to send in-system email/notification and record log
  const dispatchNotification = (recipients: string[], subject: string, body: string, triggerAction: string) => {
    const newLog: NotificationLog = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: new Date().toLocaleString(),
      recipients,
      subject,
      body,
      triggerAction,
      type: 'email'
    };
    setNotificationLogs((prev) => [newLog, ...prev]);
    return newLog;
  };

  // Extract all registered samples across all Keep Sample Boxes
  const allAvailableSamples = useMemo(() => {
    const boxes = storageService.getKeepSampleBoxes();
    const list: Array<{
      boxId: string;
      boxNumber: string;
      storageArea: string;
      rackLocation: string;
      section: string;
      productFamily?: string;
      sample: SampleItemRow;
    }> = [];

    boxes.forEach((b) => {
      if (b.samples && b.samples.length > 0) {
        b.samples.forEach((s) => {
          list.push({
            boxId: b.id,
            boxNumber: b.boxNumber,
            storageArea: b.storageArea,
            rackLocation: b.rackLocation || 'RACK-1F-M01',
            section: b.section,
            productFamily: b.productFamily,
            sample: s
          });
        });
      } else if (b.item) {
        list.push({
          boxId: b.id,
          boxNumber: b.boxNumber,
          storageArea: b.storageArea,
          rackLocation: b.rackLocation || 'RACK-1F-M01',
          section: b.section,
          productFamily: b.productFamily,
          sample: {
            id: `smp-auto-${b.id}`,
            itemName: b.item,
            drawingNumber: `DWG-${b.boxNumber}`,
            poNumber: `PO-JAE-${new Date().getFullYear()}`,
            lotNumber: `LOT-${b.boxNumber}`,
            quantity: b.maxCapacity || 1,
            remarks: b.remarks || 'Keep Sample'
          }
        });
      }
    });
    return list;
  }, [requests, isMultitabOpen]);

  // Filtered available samples list based on user filter inputs
  const filteredAvailableSamples = useMemo(() => {
    const filterPartLower = (filterPartName || '').toLowerCase();
    const filterDwgLower = (filterDrawingNo || '').toLowerCase();
    const filterPoLower = (filterPoNo || '').toLowerCase();
    const filterLotLower = (filterLotNo || '').toLowerCase();

    return allAvailableSamples.filter((entry) => {
      const sampleItemName = (entry.sample?.itemName || '').toLowerCase();
      const sampleDwg = (entry.sample?.drawingNumber || '').toLowerCase();
      const samplePo = (entry.sample?.poNumber || '').toLowerCase();
      const sampleLot = (entry.sample?.lotNumber || '').toLowerCase();

      const matchPart = !filterPartLower || sampleItemName.includes(filterPartLower);
      const matchDwg = !filterDwgLower || sampleDwg.includes(filterDwgLower);
      const matchPo = !filterPoLower || samplePo.includes(filterPoLower);
      const matchLot = !filterLotLower || sampleLot.includes(filterLotLower);
      return matchPart && matchDwg && matchPo && matchLot;
    });
  }, [allAvailableSamples, filterPartName, filterDrawingNo, filterPoNo, filterLotNo]);

  // Handle adding sample strictly when "Add" button is clicked
  const handleAddSampleToRequestDetails = (entry: typeof allAvailableSamples[0]) => {
    const s = entry.sample;

    // Check if this lot + drawing already added
    const alreadyAdded = items.some((it) => it.lotNumber === s.lotNumber && it.drawingNumber === s.drawingNumber);
    if (alreadyAdded) {
      setFeedbackMsg({
        type: 'warning',
        text: `Item with Lot ${s.lotNumber} (${s.itemName}) is already added to SAMPLE REQUEST DETAILS.`
      });
      return;
    }

    const newItem: SampleItemRow = {
      id: `itm-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      itemName: s.itemName,
      drawingNumber: s.drawingNumber || '',
      poNumber: s.poNumber || '',
      lotNumber: s.lotNumber || '',
      quantity: 1,
      defectType: s.defectType || 'Keep Sample Specimen',
      boxNo: entry.boxNumber,
      unitQty: s.unitQty,
      cavity: s.cavity,
      cavityNo: s.cavityNo,
      time: s.time,
      remarks: `Box: ${entry.boxNumber} | Rack: ${entry.rackLocation} (${entry.storageArea})`
    };

    setItems((prev) => [...prev, newItem]);
    
    // Set Target Box and Location reference
    setBoxNumber(entry.boxNumber);
    setRackLocation(entry.rackLocation);
    setArea(entry.storageArea);

    setFeedbackMsg({
      type: 'success',
      text: `✅ Added "${s.itemName}" (Lot: ${s.lotNumber}) to SAMPLE REQUEST DETAILS.`
    });
  };

  const handleOpenNewRequest = () => {
    setSelectedReqId(null);
    const nextCtrl = storageService.generateNextControlNo();
    setControlNo(nextCtrl);
    setIdNumber(currentUser.idNumber || currentUser.employeeId || 'JAE-57784');
    setFirstName(currentUser.firstName || 'Maria Cristina');
    setMiddleName(currentUser.middleName || 'Santos');
    setLastName(currentUser.lastName || 'Reyes');
    setDateRequested(new Date().toISOString().split('T')[0]);
    setRequestorName(`${currentUser.firstName} ${currentUser.lastName}`);
    setDepartment(currentUser.department);
    setFactory(currentUser.factory);
    setEmploymentStatus(currentUser.employmentStatus || 'JAE-Reg.');
    setPosition(currentUser.position || 'Staff_E');
    setSection(currentUser.section || 'Mfg. Connector');
    setTypeOfBorrowedSample('KS');
    setItems([]);
    setDateNeeded(new Date().toISOString().split('T')[0]);
    setBoxNumber('');
    setRackLocation('');
    setArea('');
    const d = new Date();
    d.setDate(d.getDate() + 7);
    setReturnedDueDate(d.toISOString().split('T')[0]);
    setReason('');
    setRemarks('');
    setQmStaffEngineer('');
    setApprovedBy('');
    setEndorsedBy('');
    setDeliveredBy('');
    setDateDelivered('');
    setStatus('Pending QM Approval');
    setQmStatus('Pending QM Review');
    setIsReceivedByRequestor(false);
    setReturnedBy('');
    setDateReturned('');
    setFillingInBox('');
    setDateFiled('');
    setActiveTab('REQUESTOR_BORROW');
    setIsMultitabOpen(true);
    setFeedbackMsg({
      type: 'info',
      text: `Created new borrow requisition: ${nextCtrl}. Filter and click "Add" to include keep samples.`
    });
  };

  const handleSelectRequestFromMasterlist = (req: KeepSampleRequest) => {
    setSelectedReqId(req.id);
    setControlNo(req.controlNo);
    setDateRequested(req.date || new Date().toISOString().split('T')[0]);
    setRequestorName(req.requestorName);
    
    const nameParts = req.requestorName.split(' ');
    if (nameParts.length >= 2) {
      setFirstName(nameParts[0]);
      setLastName(nameParts.slice(1).join(' '));
    } else {
      setFirstName(req.requestorName);
      setLastName('');
    }
    
    setDepartment(req.department);
    setFactory(req.factory);
    setTypeOfBorrowedSample(req.typeOfBorrowedSample);
    setItems(req.items && req.items.length > 0 ? req.items : []);
    setDateNeeded(req.dateNeeded);
    setBoxNumber(req.boxNumber);
    setRackLocation(req.rackLocation);
    setArea(req.area);
    setReturnedDueDate(req.returnedDueDate);
    setReason(req.reason);
    setRemarks(req.remarks || '');

    setQmStaffEngineer(req.qmStaffEngineer || 'Maria Cristina Reyes');
    setCategoryOfSample(req.categoryOfSample || 'Connector');
    setApprovedBy(req.approvedBy || 'Maria Cristina Reyes');
    setEndorsedBy(req.endorsedBy || 'QM Supervisor');
    setQmDate(req.qmDate || '');
    setQmStatus(req.qmStatus || 'Pending QM Review');

    setDeliveredBy(req.deliveredBy || 'Rodel Bautista (QC Hold)');
    setDateDelivered(req.dateDelivered || '');
    setReturnedBy(req.returnedBy || '');
    setDateReturned(req.dateReturned || '');
    setFillingInBox(req.fillingInBox || 'QM Hold Officer');
    setDateFiled(req.dateFiled || '');
    setStatus(req.status);

    // If already received by requestor, mark locked
    const isLocked = req.status === 'Received' || req.status === 'For Return' || req.status === 'Returned';
    setIsReceivedByRequestor(isLocked);

    // Provide clear feedback regarding permissions and read-only locks
    if (isLocked) {
      setFeedbackMsg({
        type: 'info',
        text: `🔒 Read-Only Lock: Borrow request ${req.controlNo} is ${req.status}. All modification controls are disabled.`
      });
    } else if (req.status === 'For QM Approval' || req.status === 'Pending QM Approval') {
      const currentFullName = `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim().toLowerCase();
      const currentUsername = (currentUser.username || '').toLowerCase();
      const currentEmployeeId = (currentUser.employeeId || currentUser.idNumber || '').toLowerCase();
      const isReq = (
        currentFullName === req.requestorName.toLowerCase() ||
        currentUsername === req.requestorName.toLowerCase() ||
        (currentEmployeeId && currentEmployeeId === ((req as any).idNumber || '').toLowerCase()) ||
        isSysadmin
      );
      if (!isReq) {
        setFeedbackMsg({
          type: 'info',
          text: `🔒 Read-Only Mode: You are viewing ${req.controlNo} submitted by ${req.requestorName}. Non-requestors cannot edit details while pending approval.`
        });
      }
    }

    // Set tab according to status
    if (req.status === 'Pending QM Approval' || req.status === 'For QM Approval') {
      setActiveTab('QM_APPROVAL');
    } else if (req.status === 'For Delivery' || req.status === 'For QC Delivery') {
      setActiveTab('QC_DELIVERY');
    } else if (req.status === 'For Return' || req.status === 'Returned') {
      setActiveTab('QC_RETURN_FILING');
    } else {
      setActiveTab('REQUESTOR_BORROW');
    }

    setIsMultitabOpen(true);
  };

  const handleSaveRequest = (forcedStatus?: KeepSampleRequestStatus) => {
    try {
      const computedName = `${firstName} ${middleName ? middleName + ' ' : ''}${lastName}`.trim() || requestorName;
      const targetStatus = forcedStatus || status;

      const saved = storageService.saveKeepSampleRequest({
        id: selectedReqId || undefined,
        controlNo,
        date: dateRequested,
        requestorName: computedName,
        department,
        factory,
        typeOfBorrowedSample,
        items,
        dateNeeded,
        boxNumber,
        rackLocation,
        area,
        returnedDueDate,
        reason,
        remarks,
        qmStaffEngineer,
        categoryOfSample,
        approvedBy,
        endorsedBy,
        qmDate,
        qmStatus,
        deliveredBy,
        dateDelivered,
        returnedBy,
        dateReturned,
        fillingInBox,
        dateFiled,
        status: targetStatus
      });

      const updated = storageService.getKeepSampleRequests();
      setRequests(updated);
      onRefreshData();
      setSelectedReqId(saved.id);
      setStatus(targetStatus);

      return saved;
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: `Failed to save request: ${err.message}`
      });
      return null;
    }
  };

  // =========================================================================
  // WORKFLOW ACTION 1: PROCEED TO QM APPROVAL (Requestor -> QM Hold & QM Admin)
  // =========================================================================
  const handleProceedToQMApproval = () => {
    if (items.length === 0) {
      setFeedbackMsg({
        type: 'warning',
        text: 'Please add at least 1 keep sample item in "SAMPLE REQUEST DETAILS" before submitting for approval.'
      });
      return;
    }

    const saved = handleSaveRequest('For QM Approval');
    if (!saved) return;

    // Send Notification to QM Hold and QM Admin
    const recipients = ['QM Hold', 'QM Admin'];
    dispatchNotification(
      recipients,
      `[iSMS Approval Requisition] New Keep Sample Borrow Request #${controlNo}`,
      `Requestor ${requestorName} (${department} - ${section}) has submitted borrow request #${controlNo} containing ${items.length} sample item(s). Please evaluate and authorize.`,
      'PROCEED_TO_QM_APPROVAL'
    );

    setFeedbackMsg({
      type: 'success',
      text: `📧 Notification & Email dispatched to QM Hold and QM Admin for Request #${controlNo}. Status updated to "For QM Approval".`
    });

    setActiveTab('QM_APPROVAL');
  };

  // =========================================================================
  // WORKFLOW ACTION 2: QM APPROVAL -> CLICK "QC DELIVERY" (QM Hold/Admin -> QC Hold)
  // =========================================================================
  const handleQMApproveAndQCDelivery = () => {
    if (!canEditQMApproval) {
      setFeedbackMsg({
        type: 'error',
        text: 'Access Denied: Only QM Hold and QM Admin can approve keep sample requests and initiate QC Delivery.'
      });
      return;
    }

    setQmStatus('Approved');
    const saved = handleSaveRequest('For Delivery');
    if (!saved) return;

    // Send Notification to QC Hold
    const recipients = ['QC Hold'];
    dispatchNotification(
      recipients,
      `[iSMS Dispatch Notice] Keep Sample Request #${controlNo} Approved for QC Delivery`,
      `QM Authority (${currentUser.firstName} ${currentUser.lastName}) has approved Request #${controlNo}. Please retrieve the physical samples from Box ${boxNumber} (${rackLocation}) and dispatch to Requestor ${requestorName}.`,
      'QM_QC_DELIVERY_CLICK'
    );

    setFeedbackMsg({
      type: 'success',
      text: `📧 Notification & Email sent to QC Hold: Samples for Request #${controlNo} are approved and queued for physical delivery.`
    });

    setActiveTab('QC_DELIVERY');
  };

  // =========================================================================
  // WORKFLOW ACTION 3: QC DELIVERY -> CLICK "FOR RECEIVED" (QC Hold -> Requestor)
  // =========================================================================
  const handleQCDeliveryForReceived = () => {
    if (!canActionQCDelivery) {
      setFeedbackMsg({
        type: 'error',
        text: 'Access Denied: Only QC Hold (or QM Authority) can mark delivery handoff.'
      });
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    setDateDelivered(today);
    setDeliveredBy(`${currentUser.firstName} ${currentUser.lastName} (QC Hold)`);

    const saved = handleSaveRequest('For Received');
    if (!saved) return;

    // Send Notification to Requestor
    const recipients = [requestorName, 'Requestor'];
    dispatchNotification(
      recipients,
      `[iSMS Physical Handoff Ready] Samples Delivered for Request #${controlNo}`,
      `QC Hold (${currentUser.firstName} ${currentUser.lastName}) has delivered the physical keep samples for Request #${controlNo}. Please click "For Received" in your request form to confirm physical acceptance.`,
      'QC_HOLD_FOR_RECEIVED_CLICK'
    );

    setFeedbackMsg({
      type: 'success',
      text: `📧 Notification & Email sent to Requestor (${requestorName}): Keep samples for Request #${controlNo} have been delivered and are waiting for receipt confirmation.`
    });

    setActiveTab('REQUESTOR_BORROW');
  };

  // =========================================================================
  // WORKFLOW ACTION 4A: REQUESTOR CLICKS "FOR RECEIVED" (Locks Editing)
  // =========================================================================
  const handleRequestorConfirmReceived = () => {
    setIsReceivedByRequestor(true);
    const saved = handleSaveRequest('Received');
    if (!saved) return;

    setFeedbackMsg({
      type: 'success',
      text: `🔒 Request #${controlNo} confirmed as RECEIVED by ${requestorName}. The request details are now locked against further edits.`
    });
  };

  // =========================================================================
  // WORKFLOW ACTION 4B: REQUESTOR CLICKS "FOR RETURN" (Notifies Requestor, QC Hold, QM Hold, QM Admin)
  // =========================================================================
  const handleRequestorForReturn = () => {
    const saved = handleSaveRequest('For Return');
    if (!saved) return;

    // Send Notification to Requestor, QC Hold, QM Hold, and QM Admin
    const recipients = [requestorName, 'QC Hold', 'QM Hold', 'QM Admin'];
    dispatchNotification(
      recipients,
      `[iSMS Return Notice] Keep Sample Requisition #${controlNo} Queued For Return`,
      `Requestor ${requestorName} has initiated return of keep samples for Request #${controlNo} (Box ${boxNumber}, ${rackLocation}). QM Hold and QC Hold: Please verify physical intactness and complete box re-filing intake.`,
      'REQUESTOR_FOR_RETURN_CLICK'
    );

    setFeedbackMsg({
      type: 'success',
      text: `📧 Return Notification & Email sent to Requestor, QC Hold, QM Hold, and QM Admin for Request #${controlNo}. Status set to "For Return".`
    });

    setActiveTab('QC_RETURN_FILING');
  };

  // =========================================================================
  // WORKFLOW ACTION 5: QM HOLD UPDATES "QC RETURN INTAKE & BOX RE-FILING" & REMARKS
  // =========================================================================
  const handleQMHoldCompleteReturnFiling = () => {
    if (!canUpdateReturnFiling) {
      setFeedbackMsg({
        type: 'error',
        text: 'Access Denied: Only QM Hold and QM Admin can update and finalize "QC RETURN INTAKE & BOX RE-FILING".'
      });
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    setDateReturned(dateReturned || today);
    setDateFiled(today);
    setReturnedBy(returnedBy || requestorName);
    setFillingInBox(`${currentUser.firstName} ${currentUser.lastName} (QM Hold)`);

    const saved = handleSaveRequest('Returned');
    if (!saved) return;

    dispatchNotification(
      [requestorName, 'QM Admin', 'QC Hold'],
      `[iSMS Return Completed] Keep Samples for Request #${controlNo} Re-filed into Box ${boxNumber}`,
      `QM Hold authority (${currentUser.firstName} ${currentUser.lastName}) has verified and re-filed all returned samples for Request #${controlNo} into Box ${boxNumber} (${rackLocation}). Loan record is officially CLOSED.`,
      'QM_HOLD_RETURN_FILING_COMPLETE'
    );

    setFeedbackMsg({
      type: 'success',
      text: `✅ QM Hold successfully updated QC Return Intake & Box Re-filing for Request #${controlNo}. Loan is officially finalized and returned!`
    });
  };

  const handleAddItemRow = () => {
    if (isReceivedByRequestor) {
      setFeedbackMsg({
        type: 'warning',
        text: 'Cannot add items: Request is locked after receipt confirmation.'
      });
      return;
    }
    setItems((prev) => [
      ...prev,
      {
        id: `itm-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        itemName: '',
        drawingNumber: '',
        poNumber: '',
        lotNumber: '',
        quantity: 1,
        remarks: ''
      }
    ]);
  };

  const handleRemoveItemRow = (id: string) => {
    if (isReceivedByRequestor) {
      alert('Cannot remove items: Request is locked after receipt confirmation.');
      return;
    }
    setItems((prev) => prev.filter((it) => it.id !== id));
  };

  const handleItemChange = (id: string, field: keyof SampleItemRow, val: any) => {
    if (isReceivedByRequestor) return;
    setItems((prev) => prev.map((it) => (it.id === id ? { ...it, [field]: val } : it)));
  };

  const handleDeleteRequest = (req: KeepSampleRequest) => {
    if (!isSysadmin && !isQMAdmin) {
      alert('Access Denied: Only Sysadmin or QM Admin can delete Keep Sample requests.');
      return;
    }
    if (window.confirm(`Delete borrow request #${req.controlNo}?`)) {
      storageService.deleteKeepSampleRequest(req.id);
      setRequests(storageService.getKeepSampleRequests());
      onRefreshData();
      if (selectedReqId === req.id) {
        setIsMultitabOpen(false);
      }
      setFeedbackMsg({
        type: 'info',
        text: `Request #${req.controlNo} deleted.`
      });
    }
  };

  const filteredRequests = requests.filter((r) => {
    const q = (searchQuery || '').toLowerCase();
    const matchesSearch =
      !q ||
      (r.controlNo || '').toLowerCase().includes(q) ||
      (r.requestorName || '').toLowerCase().includes(q) ||
      (r.boxNumber || '').toLowerCase().includes(q) ||
      (r.rackLocation || '').toLowerCase().includes(q) ||
      (r.items && r.items.some((it) => 
        (it.itemName || '').toLowerCase().includes(q) ||
        (it.drawingNumber || '').toLowerCase().includes(q) ||
        (it.lotNumber || '').toLowerCase().includes(q)
      ));

    const matchesStatus = statusFilter === 'All' || r.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (st: KeepSampleRequestStatus | string) => {
    switch (st) {
      case 'Returned':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-950/80 text-emerald-300 border border-emerald-600/70 inline-flex items-center gap-1 font-mono">
            <CheckCircle className="w-3 h-3 text-emerald-400" />
            RETURNED
          </span>
        );
      case 'For Return':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-amber-950/80 text-amber-300 border border-amber-600/70 inline-flex items-center gap-1 font-mono">
            <Clock className="w-3 h-3 text-amber-400" />
            FOR RETURN
          </span>
        );
      case 'Received':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-blue-950/80 text-blue-300 border border-blue-600/70 inline-flex items-center gap-1 font-mono">
            <Lock className="w-3 h-3 text-blue-400" />
            RECEIVED (LOCKED)
          </span>
        );
      case 'For Received':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-purple-950/80 text-purple-300 border border-purple-600/70 inline-flex items-center gap-1 font-mono">
            <PackageCheck className="w-3 h-3 text-purple-400" />
            FOR RECEIVED
          </span>
        );
      case 'For Delivery':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-teal-950/80 text-teal-300 border border-teal-600/70 inline-flex items-center gap-1 font-mono">
            <Package className="w-3 h-3 text-teal-400" />
            FOR QC DELIVERY
          </span>
        );
      case 'For QM Approval':
      case 'Pending QM Approval':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-pink-950/80 text-pink-300 border border-pink-600/70 inline-flex items-center gap-1 font-mono">
            <ShieldCheck className="w-3 h-3 text-pink-400" />
            FOR QM APPROVAL
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-slate-900 text-slate-300 border border-slate-700 inline-flex items-center gap-1 font-mono">
            {st.toUpperCase()}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 font-['Plus_Jakarta_Sans']">
      
      {/* Header & Role Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-emerald-800/60">
        <div>
          <h1 className="text-xl md:text-2xl font-black text-white tracking-tight font-['Chakra_Petch'] uppercase flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-pink-400" />
            <span>KEEP SAMPLE BORROW REQUEST & APPROVAL WORKFLOW</span>
          </h1>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setShowNotificationModal(true)}
            className="relative px-3 py-1.5 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-700/60 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer"
            title="View email / system notification dispatch logs"
          >
            <Mail className="w-3.5 h-3.5 text-pink-400" />
            <span>Notification Logs</span>
            {notificationLogs.length > 0 && (
              <span className="ml-1 px-1.5 py-0.2 rounded-full bg-pink-600 text-white text-[10px] font-mono">
                {notificationLogs.length}
              </span>
            )}
          </button>

          {!isMultitabOpen && (
            <button
              type="button"
              onClick={handleOpenNewRequest}
              className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-all shadow-md active:scale-98 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ New Borrow Request</span>
            </button>
          )}
        </div>
      </div>

      {/* Feedback Banner */}
      {feedbackMsg && (
        <div className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-between shadow-xs ${
          feedbackMsg.type === 'success'
            ? 'bg-emerald-950/90 border-emerald-500 text-emerald-200'
            : feedbackMsg.type === 'error'
            ? 'bg-rose-950/90 border-rose-500 text-rose-200'
            : feedbackMsg.type === 'warning'
            ? 'bg-amber-950/90 border-amber-500 text-amber-200'
            : 'bg-blue-950/90 border-blue-500 text-blue-200'
        }`}>
          <div className="flex items-center space-x-2.5">
            {feedbackMsg.type === 'success' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
            {feedbackMsg.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />}
            {feedbackMsg.type === 'warning' && <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />}
            {feedbackMsg.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{feedbackMsg.text}</span>
          </div>
          <button
            onClick={() => setFeedbackMsg(null)}
            className="text-[11px] underline ml-2 opacity-80 hover:opacity-100 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. MASTERLIST VIEW */}
      {/* ========================================================================= */}
      {!isMultitabOpen ? (
        <div className="space-y-4 animate-in fade-in duration-200">
          
          {/* Summary Metric Cubes */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-[#121815] rounded-xl border border-emerald-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-emerald-800 to-green-700 px-3 py-1.5 flex items-center justify-between border-b border-emerald-600/50">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">TOTAL REQUISITIONS</span>
                <FileText className="w-3.5 h-3.5 text-emerald-200" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-white">{requests.length}</div>
                <div className="p-2 bg-emerald-950 text-emerald-400 rounded-lg border border-emerald-700/60">
                  <FileSpreadsheet className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div className="bg-[#121815] rounded-xl border border-pink-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-pink-800 to-rose-700 px-3 py-1.5 flex items-center justify-between border-b border-pink-600/50">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">PENDING QM APPROVAL</span>
                <ShieldCheck className="w-3.5 h-3.5 text-pink-200" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-pink-300">
                  {requests.filter(r => r.status === 'For QM Approval' || r.status === 'Pending QM Approval').length}
                </div>
                <div className="p-2 bg-pink-950 text-pink-400 rounded-lg border border-pink-700/60">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div className="bg-[#121815] rounded-xl border border-teal-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-teal-800 to-emerald-700 px-3 py-1.5 flex items-center justify-between border-b border-teal-600/50">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">FOR DELIVERY / RECEIVED</span>
                <PackageCheck className="w-3.5 h-3.5 text-teal-200" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-teal-300">
                  {requests.filter(r => r.status === 'For Delivery' || r.status === 'For Received' || r.status === 'Received').length}
                </div>
                <div className="p-2 bg-teal-950 text-teal-400 rounded-lg border border-teal-700/60">
                  <PackageCheck className="w-4 h-4" />
                </div>
              </div>
            </div>

            <div className="bg-[#121815] rounded-xl border border-amber-700/60 shadow-sm overflow-hidden flex flex-col justify-between">
              <div className="bg-gradient-to-r from-amber-800 to-orange-700 px-3 py-1.5 flex items-center justify-between border-b border-amber-600/50">
                <span className="text-[11px] font-black text-white uppercase tracking-wider font-['Chakra_Petch']">FOR RETURN / CLOSED</span>
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-200" />
              </div>
              <div className="p-3 flex items-center justify-between">
                <div className="text-2xl font-black font-mono text-amber-300">
                  {requests.filter(r => r.status === 'For Return' || r.status === 'Returned').length}
                </div>
                <div className="p-2 bg-amber-950 text-amber-400 rounded-lg border border-amber-700/60">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

          {/* Masterlist Container */}
          <div className="bg-[#121815] rounded-xl shadow-lg border border-emerald-700/60 overflow-hidden">
            
            <div className="px-4 py-2.5 border-b border-emerald-700/60 flex flex-col md:flex-row md:items-center md:justify-between gap-3 bg-gradient-to-r from-[#064e3b] via-[#095742] to-[#043d2e]">
              <div>
                <h2 className="text-sm md:text-base font-bold text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                  <FileText className="w-4 h-4 text-pink-300" />
                  <span>KEEP SAMPLE BORROW REQUESTS MASTERLIST</span>
                </h2>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="relative min-w-[220px]">
                  <Search className="w-3.5 h-3.5 text-emerald-300 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search control #, requestor, box, part..."
                    className="w-full bg-[#0a2820] border border-emerald-500/70 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-emerald-300/60 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-[#0a2820] border border-emerald-500/70 rounded-lg px-2.5 py-1.5 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                >
                  <option value="All">All Statuses</option>
                  <option value="For QM Approval">For QM Approval</option>
                  <option value="For Delivery">For QC Delivery</option>
                  <option value="For Received">For Received</option>
                  <option value="Received">Received (Locked)</option>
                  <option value="For Return">For Return</option>
                  <option value="Returned">Returned (Closed)</option>
                </select>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="isms-table w-full text-xs">
                <thead>
                  <tr className="bg-[#062c21] text-emerald-200 uppercase text-[10px] tracking-wider border-b border-emerald-700/60 font-mono">
                    <th className="p-2.5 font-bold text-emerald-100">Control No</th>
                    <th className="p-2.5 font-bold text-emerald-100">Date Req</th>
                    <th className="p-2.5 font-bold text-emerald-100">Requestor & Dept</th>
                    <th className="p-2.5 font-bold text-emerald-100">Target Box & Rack</th>
                    <th className="p-2.5 font-bold text-emerald-100">Sample Items</th>
                    <th className="p-2.5 font-bold text-emerald-100">Expected Due</th>
                    <th className="p-2.5 font-bold text-emerald-100">Workflow Status</th>
                    <th className="p-2.5 text-right font-bold text-emerald-100">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-emerald-900/40">
                  {filteredRequests.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-emerald-300/70">
                        No Keep Sample borrow requests found.
                      </td>
                    </tr>
                  ) : (
                    filteredRequests.map((req) => (
                      <tr
                        key={req.id}
                        onClick={() => handleSelectRequestFromMasterlist(req)}
                        onDoubleClick={() => handleSelectRequestFromMasterlist(req)}
                        className="cursor-pointer transition-colors duration-150 hover:bg-[#18392d]/80 bg-[#101e18] group"
                        title="Double-click to open request custody chain (read-only locks apply based on P.I.C. & status)"
                      >
                        <td className="p-2.5 font-mono font-bold text-pink-300 group-hover:text-pink-200 whitespace-nowrap">
                          {req.controlNo}
                        </td>
                        <td className="p-2.5 font-mono text-slate-300 whitespace-nowrap">
                          {req.dateRequested || req.date}
                        </td>
                        <td className="p-2.5 whitespace-nowrap">
                          <span className="font-semibold text-white block">{req.requestorName}</span>
                          <span className="text-[10px] text-emerald-400 font-mono">{req.department} • {req.factory}</span>
                        </td>
                        <td className="p-2.5 whitespace-nowrap">
                          <span className="font-mono font-bold text-pink-400 block">{req.boxNumber}</span>
                          <span className="text-[10px] text-emerald-300 font-mono">{req.rackLocation}</span>
                        </td>
                        <td className="p-2.5 max-w-xs truncate">
                          <span className="font-bold text-white block">
                            {req.items?.[0]?.itemName || req.item || 'Keep Sample'}
                          </span>
                          <span className="text-[10px] text-emerald-400 font-mono">
                            {req.items?.length || 1} part(s) requested
                          </span>
                        </td>
                        <td className="p-2.5 font-mono text-rose-300 font-bold whitespace-nowrap">
                          {req.returnedDueDate || '-'}
                        </td>
                        <td className="p-2.5 whitespace-nowrap">
                          {getStatusBadge(req.status)}
                        </td>
                        <td className="p-2.5 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end space-x-1.5">
                            <button
                              onClick={() => handlePrintSignOffSlip(req)}
                              className="p-1 bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded border border-emerald-700/60 shadow-xs transition-colors cursor-pointer"
                              title="Generate PDF Report / Print Borrow Sign-Off Slip"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleSelectRequestFromMasterlist(req)}
                              className="p-1 bg-pink-900/60 hover:bg-pink-800 text-pink-200 rounded border border-pink-600/60 shadow-xs cursor-pointer"
                              title="Open Multi-tab Requisition"
                            >
                              <Layers className="w-3.5 h-3.5" />
                            </button>
                            {(isSysadmin || isQMAdmin) && (
                              <button
                                onClick={() => handleDeleteRequest(req)}
                                className="p-1 bg-rose-900/60 hover:bg-rose-800 text-rose-200 rounded border border-rose-600/60 shadow-xs cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-[#0a1a14] border-t border-emerald-800/60 text-xs text-emerald-300/80 flex justify-between items-center font-mono">
              <span>Showing {filteredRequests.length} of {requests.length} borrow requests</span>
              <span>JAE Sample Custody Chain Standard</span>
            </div>
          </div>

        </div>
      ) : (
        /* ========================================================================= */
        /* 2. MULTI-TAB WORKSPACE */
        /* ========================================================================= */
        <div className="space-y-4 animate-in fade-in duration-300">
          
          {/* Header Bar for Active Request */}
          <div className="bg-[#101e18] rounded-xl p-3.5 border border-emerald-700/60 flex flex-col md:flex-row md:items-center md:justify-between gap-3 shadow-md">
            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={() => setIsMultitabOpen(false)}
                className="px-3 py-1.5 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-700/60 font-bold rounded-lg text-xs flex items-center space-x-1 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Masterlist</span>
              </button>
              <div>
                <span className="text-[11px] text-emerald-400 font-mono block">ACTIVE BORROW WORKSPACE</span>
                <h2 className="text-base font-black text-white font-mono tracking-wider flex items-center gap-2">
                  <span className="text-pink-400">{controlNo}</span>
                  <span className="text-xs text-slate-300 font-sans font-normal">({requestorName} • {department})</span>
                  {getStatusBadge(status)}
                </h2>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={() => setShowNotificationModal(true)}
                className="px-3 py-1.5 bg-[#0c241c] hover:bg-[#143d30] text-emerald-200 border border-emerald-700/60 rounded-lg text-xs font-bold flex items-center space-x-1.5 transition-all shadow-xs"
              >
                <Mail className="w-3.5 h-3.5 text-pink-400" />
                <span>View Email Audit Trail</span>
              </button>
            </div>
          </div>

          {/* Multitab Navigation Bar */}
          <div className="bg-[#181818] rounded-2xl shadow-lg border border-emerald-800/60 p-2 flex flex-wrap gap-1.5">
            <button
              onClick={() => setActiveTab('REQUESTOR_BORROW')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'REQUESTOR_BORROW'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>1. Requestor Form</span>
              {isReceivedByRequestor && <Lock className="w-3 h-3 text-pink-300 ml-1" />}
            </button>

            <button
              onClick={() => setActiveTab('QM_APPROVAL')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'QM_APPROVAL'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>2. QM Approval</span>
            </button>

            <button
              onClick={() => setActiveTab('QC_DELIVERY')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'QC_DELIVERY'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <PackageCheck className="w-4 h-4" />
              <span>3. QC Delivery</span>
            </button>

            <button
              onClick={() => setActiveTab('QC_RETURN_FILING')}
              className={`flex-1 min-w-[170px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'QC_RETURN_FILING'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>4. Return & Re-filing</span>
            </button>

            <button
              onClick={() => setActiveTab('AUDIT_TRAIL')}
              className={`flex-1 min-w-[150px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                activeTab === 'AUDIT_TRAIL'
                  ? 'bg-gradient-to-r from-pink-600 to-rose-600 text-white font-bold shadow-md border border-pink-500/60'
                  : 'bg-[#222] hover:bg-[#2c2c2c] text-slate-300 hover:text-white border border-slate-700/60 font-semibold'
              }`}
            >
              <History className="w-4 h-4" />
              <span>5. Audit & Emails ({notificationLogs.length})</span>
            </button>
          </div>

          {/* ========================================================================= */}
          {/* TAB 1: REQUESTOR FORM (Filtered Samples Grid -> Click ADD to include) */}
          {/* ========================================================================= */}
          {activeTab === 'REQUESTOR_BORROW' && (
            <div className="space-y-6 text-xs animate-in fade-in duration-200">
              
              {/* Receipt Status Banner if Locked */}
              {isReceivedByRequestor && (
                <div className="p-3 bg-blue-950/80 border border-blue-500/80 rounded-xl text-xs text-blue-200 flex items-center justify-between shadow-xs">
                  <div className="flex items-center space-x-2">
                    <Lock className="w-4 h-4 text-blue-400" />
                    <span><strong>REQUEST IS LOCKED</strong>: Physical keep samples have been marked as received. Modifications are disabled.</span>
                  </div>
                  {status === 'Received' && (
                    <button
                      type="button"
                      onClick={handleRequestorForReturn}
                      className="px-4 py-1.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold rounded-lg text-xs shadow-md flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>Click "For Return" (Notify All) →</span>
                    </button>
                  )}
                </div>
              )}

              {/* Edit Restriction Banner: If active user is not original requestor while pending QM approval */}
              {!isOriginalRequestor && isPendingApproval && (
                <div className="p-3 bg-amber-950/90 border border-amber-500/80 rounded-xl text-xs text-amber-200 flex items-center gap-2.5 shadow-xs">
                  <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                  <div>
                    <strong>READ-ONLY ACCESS RESTRICTION</strong>: You are not the original requestor (<strong>{requestorName || 'Assigned Requestor'}</strong>). Requisition details cannot be edited or updated while pending approval from QM Hold / QM Admin.
                  </div>
                </div>
              )}

              {/* Read-Only Status Banner if already approved, delivered, or returned */}
              {!isReceivedByRequestor && isApprovedOrCompleted && (
                <div className="p-3 bg-purple-950/80 border border-purple-500/80 rounded-xl text-xs text-purple-200 flex items-center gap-2.5 shadow-xs">
                  <Lock className="w-4 h-4 text-purple-400 shrink-0" />
                  <div>
                    <strong>READ-ONLY LOCKED</strong>: This borrow request is currently at status <strong>{status}</strong>. Details are locked to preserve audit integrity.
                  </div>
                </div>
              )}

              {/* SECTION A: SEARCH & FILTER AVAILABLE KEEP SAMPLES (DO NOT AUTOFILL, ADD ONLY ON CLICK) */}
              {canEditRequestorDetails && (
                <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 overflow-hidden">
                  <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-3.5 px-4 md:px-5 border-b border-emerald-600/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center space-x-2.5">
                      <Search className="w-5 h-5 text-pink-400" />
                      <div>
                        <h3 className="font-bold text-sm md:text-base text-white font-['Chakra_Petch'] uppercase tracking-wider flex items-center gap-2">
                          <span>SEARCH & FILTER KEEP SAMPLES IN STORAGE</span>
                        </h3>
                      </div>
                    </div>

                    {/* Show/Hide Toggle Button + Clear Filters Button */}
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={() => setShowSampleList(!showSampleList)}
                        className="px-3 py-1 bg-[#0c241c] hover:bg-[#143d30] text-emerald-300 border border-emerald-700/60 rounded-lg text-[11px] font-bold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                        title={showSampleList ? 'Hide available sample list to prevent screen clutter' : 'Show available sample list'}
                      >
                        {showSampleList ? <EyeOff className="w-3.5 h-3.5 text-pink-400" /> : <Eye className="w-3.5 h-3.5 text-emerald-400" />}
                        <span>{showSampleList ? 'Hide Samples' : 'Show Samples'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setFilterPartName('');
                          setFilterDrawingNo('');
                          setFilterPoNo('');
                          setFilterLotNo('');
                        }}
                        className="px-3 py-1 bg-[#0c241c] hover:bg-[#143d30] text-emerald-300 border border-emerald-700/60 rounded-lg text-[11px] font-bold self-start sm:self-auto cursor-pointer shadow-xs transition-colors"
                      >
                        Clear Filters
                      </button>
                    </div>
                  </div>

                  <div className="p-4 md:p-6 space-y-4">
                    {/* Filter Inputs Bar */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-[#0d2820] p-3.5 rounded-xl border border-emerald-700/70">
                      <div>
                        <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                          ITEM / PART NAME:
                        </label>
                        <input
                          type="text"
                          value={filterPartName}
                          onChange={(e) => {
                            setFilterPartName(e.target.value);
                            if (e.target.value) setShowSampleList(true);
                          }}
                          placeholder="Filter by part description..."
                          className="w-full bg-[#071e17] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                          DRAWING NUMBER:
                        </label>
                        <input
                          type="text"
                          value={filterDrawingNo}
                          onChange={(e) => {
                            setFilterDrawingNo(e.target.value);
                            if (e.target.value) setShowSampleList(true);
                          }}
                          placeholder="Filter by drawing number..."
                          className="w-full bg-[#071e17] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                          PO NUMBER:
                        </label>
                        <input
                          type="text"
                          value={filterPoNo}
                          onChange={(e) => {
                            setFilterPoNo(e.target.value);
                            if (e.target.value) setShowSampleList(true);
                          }}
                          placeholder="Filter by PO number..."
                          className="w-full bg-[#071e17] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1">
                          LOT NUMBER:
                        </label>
                        <input
                          type="text"
                          value={filterLotNo}
                          onChange={(e) => {
                            setFilterLotNo(e.target.value);
                            if (e.target.value) setShowSampleList(true);
                          }}
                          placeholder="Filter by lot number..."
                          className="w-full bg-[#071e17] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none"
                        />
                      </div>
                    </div>

                    {/* Show/Hide Conditional Sample List (Prevents clutter) */}
                    {showSampleList ? (
                      <div className="border border-emerald-700/60 rounded-xl overflow-x-auto shadow-xs bg-[#121815] animate-in fade-in duration-200">
                        <table className="w-full text-left text-xs border-collapse">
                          <thead className="bg-[#062c21] text-emerald-200 font-bold uppercase text-[10px] tracking-wider border-b border-emerald-700/60 font-mono">
                            <tr>
                              <th className="p-2.5">Item / Part Name</th>
                              <th className="p-2.5">Drawing Number</th>
                              <th className="p-2.5">PO Number</th>
                              <th className="p-2.5">Lot Number</th>
                              <th className="p-2.5">Qty Avail</th>
                              <th className="p-2.5">Box / Rack Location</th>
                              <th className="p-2.5 text-right">Action</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-emerald-900/40">
                            {filteredAvailableSamples.length === 0 ? (
                              <tr>
                                <td colSpan={7} className="p-6 text-center text-emerald-300/70">
                                  No Keep Samples found matching your filter criteria.
                                </td>
                              </tr>
                            ) : (
                              filteredAvailableSamples.slice(0, 10).map((entry, idx) => {
                                const s = entry.sample;
                                const isAdded = items.some((it) => it.lotNumber === s.lotNumber && it.drawingNumber === s.drawingNumber);
                                return (
                                  <tr key={idx} className="hover:bg-[#18392d]/80 text-white">
                                    <td className="p-2.5 font-bold text-white">{s.itemName}</td>
                                    <td className="p-2.5 font-mono text-emerald-300">{s.drawingNumber || '-'}</td>
                                    <td className="p-2.5 font-mono text-emerald-300">{s.poNumber || '-'}</td>
                                    <td className="p-2.5 font-mono font-bold text-pink-400">{s.lotNumber || '-'}</td>
                                    <td className="p-2.5 font-mono text-white font-bold">{s.quantity || 1} pcs</td>
                                    <td className="p-2.5 whitespace-nowrap">
                                      <span className="font-mono text-pink-300 font-bold block">{entry.boxNumber}</span>
                                      <span className="text-[10px] text-emerald-400 font-mono">{entry.rackLocation} ({entry.storageArea})</span>
                                    </td>
                                    <td className="p-2.5 text-right">
                                      <button
                                        type="button"
                                        onClick={() => handleAddSampleToRequestDetails(entry)}
                                        disabled={isAdded || !canEditRequestorDetails}
                                        className={`px-3 py-1 rounded-lg text-xs font-bold flex items-center space-x-1 ml-auto transition-all cursor-pointer ${
                                          isAdded
                                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-700/60 opacity-60 cursor-not-allowed'
                                            : 'bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white shadow-xs'
                                        }`}
                                      >
                                        {isAdded ? (
                                          <>
                                            <Check className="w-3 h-3 text-emerald-400" />
                                            <span>Added</span>
                                          </>
                                        ) : (
                                          <>
                                            <Plus className="w-3 h-3" />
                                            <span>Add</span>
                                          </>
                                        )}
                                      </button>
                                    </td>
                                  </tr>
                                );
                              })
                            )}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="p-3 bg-[#0a2019] rounded-xl border border-emerald-700/50 text-emerald-300 flex items-center justify-between">
                        <div className="flex items-center gap-2 text-xs">
                          <Info className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Sample list is hidden to prevent screen clutter. Click "Show Samples" to view matching storage items ({filteredAvailableSamples.length} found).</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setShowSampleList(true)}
                          className="px-3 py-1 bg-emerald-900/90 hover:bg-emerald-800 text-emerald-200 border border-emerald-600/60 rounded-lg text-[11px] font-bold flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Show Samples</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* SECTION B: RENAMED "SAMPLE REQUEST DETAILS" (Items strictly added via Add button) */}
              <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 overflow-hidden">
                <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-3.5 px-4 md:px-5 border-b border-emerald-600/70 flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <Layers className="w-5 h-5 text-pink-400" />
                    <div>
                      <h3 className="font-bold text-sm md:text-base text-white font-['Chakra_Petch'] uppercase tracking-wider">
                        SAMPLE REQUEST DETAILS
                      </h3>
                      <p className="text-[11px] text-emerald-300 font-mono">
                        List of keep samples included in this loan requisition. Added via filter "Add" button or manual line.
                      </p>
                    </div>
                  </div>

                  {!isReceivedByRequestor && canEditRequestorDetails && (
                    <div className="flex items-center space-x-2">
                      <button
                        type="button"
                        onClick={handleAddItemRow}
                        className="px-3 py-1 bg-pink-600 hover:bg-pink-700 text-white rounded-lg text-xs font-bold border border-pink-400 shadow-xs flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+ Add Manual Row</span>
                      </button>
                      <span className="text-xs font-mono font-bold text-emerald-200 bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-700/60 shadow-xs">
                        {items.length} ITEM(S)
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-4 md:p-6 space-y-4">
                  <div className="border border-emerald-700/60 rounded-xl overflow-x-auto shadow-xs">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-[#062c21] text-emerald-200 font-bold uppercase text-[10px] tracking-wider border-b border-emerald-700/60 font-mono">
                        <tr>
                          <th className="p-3">Item / Part Name *</th>
                          <th className="p-3">Drawing Number *</th>
                          <th className="p-3">PO Number</th>
                          <th className="p-3">Lot Number *</th>
                          <th className="p-3 w-24">Qty *</th>
                          <th className="p-3">Remarks / Box Reference</th>
                          <th className="p-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-emerald-900/40 bg-[#0a2820]">
                        {items.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-emerald-300/70">
                              <Package className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                              <p className="font-semibold text-emerald-200">No sample items added yet.</p>
                              <p className="text-[11px] text-emerald-400/80 mt-1">
                                Use the search filter above and click "Add" to include keep samples into this request.
                              </p>
                            </td>
                          </tr>
                        ) : (
                          items.map((it) => (
                            <tr key={it.id} className="hover:bg-[#13382c]/80 transition-colors">
                              <td className="p-2.5">
                                <input
                                  type="text"
                                  value={it.itemName}
                                  onChange={(e) => handleItemChange(it.id, 'itemName', e.target.value)}
                                  disabled={!canEditRequestorDetails}
                                  placeholder="Part description..."
                                  className="w-full bg-[#061e18] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs text-white font-medium focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                                />
                              </td>
                              <td className="p-2.5">
                                <input
                                  type="text"
                                  value={it.drawingNumber}
                                  onChange={(e) => handleItemChange(it.id, 'drawingNumber', e.target.value)}
                                  disabled={!canEditRequestorDetails}
                                  placeholder="DWG number..."
                                  className="w-full bg-[#061e18] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                                />
                              </td>
                              <td className="p-2.5">
                                <input
                                  type="text"
                                  value={it.poNumber || ''}
                                  onChange={(e) => handleItemChange(it.id, 'poNumber', e.target.value)}
                                  disabled={!canEditRequestorDetails}
                                  placeholder="PO number..."
                                  className="w-full bg-[#061e18] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs font-mono text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                                />
                              </td>
                              <td className="p-2.5">
                                <input
                                  type="text"
                                  value={it.lotNumber}
                                  onChange={(e) => handleItemChange(it.id, 'lotNumber', e.target.value)}
                                  disabled={!canEditRequestorDetails}
                                  placeholder="Lot identification..."
                                  className="w-full bg-[#061e18] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                                />
                              </td>
                              <td className="p-2.5 w-24">
                                <input
                                  type="number"
                                  min={1}
                                  value={it.quantity}
                                  onChange={(e) => handleItemChange(it.id, 'quantity', Number(e.target.value))}
                                  disabled={!canEditRequestorDetails}
                                  className="w-full bg-[#061e18] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs font-mono font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                                />
                              </td>
                              <td className="p-2.5">
                                <input
                                  type="text"
                                  value={it.remarks || ''}
                                  onChange={(e) => handleItemChange(it.id, 'remarks', e.target.value)}
                                  disabled={!canEditRequestorDetails}
                                  placeholder="Traceability remarks..."
                                  className="w-full bg-[#061e18] border border-emerald-600/70 rounded-lg px-2.5 py-1.5 text-xs text-emerald-200 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                                />
                              </td>
                              <td className="p-2.5 text-right">
                                {!isReceivedByRequestor && canEditRequestorDetails && (
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveItemRow(it.id)}
                                    className="text-rose-400 hover:text-rose-300 p-1.5 hover:bg-rose-950/80 rounded-lg transition-colors cursor-pointer"
                                    title="Remove item"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* SECTION C: REQUISITION DATES & PURPOSE */}
              <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 p-4 md:p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-white uppercase tracking-wider mb-1.5">
                      CONTROL NUMBER:
                    </label>
                    <input
                      type="text"
                      value={controlNo}
                      readOnly
                      className="w-full bg-[#061e18] border border-emerald-700/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-pink-400 cursor-not-allowed select-none shadow-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-white uppercase tracking-wider mb-1.5">
                      DATE REQUESTED:
                    </label>
                    <input
                      type="date"
                      value={dateRequested}
                      readOnly
                      className="w-full bg-[#061e18] border border-emerald-700/60 rounded-xl px-3 py-2 text-xs font-mono font-bold text-emerald-200 cursor-not-allowed select-none shadow-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-white uppercase tracking-wider mb-1.5">
                      DATE NEEDED: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="date"
                      value={dateNeeded}
                      onChange={(e) => setDateNeeded(e.target.value)}
                      disabled={!canEditRequestorDetails}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-white uppercase tracking-wider mb-1.5">
                      EXPECTED RETURN DUE DATE: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="date"
                      value={returnedDueDate}
                      onChange={(e) => setReturnedDueDate(e.target.value)}
                      disabled={!canEditRequestorDetails}
                      className="w-full bg-[#1e0f14] border border-rose-600/70 rounded-xl px-3 py-2 text-xs font-mono font-bold text-rose-300 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-white uppercase tracking-wider mb-1.5">
                    REASON FOR BORROWING: <span className="text-pink-400 font-bold">*</span>
                  </label>
                  <textarea
                    rows={2}
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                    disabled={!canEditRequestorDetails}
                    placeholder="Purpose of sample requisition (e.g. Tooling inspection, Golden reference comparison, Crimp cross-section validation)..."
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl p-3 text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                  />
                </div>
              </div>

              {/* ACTION BUTTONS ROW */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => setIsMultitabOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back to Masterlist</span>
                </button>

                <div className="flex flex-wrap items-center gap-3">
                  {/* If Request is at 'For Received' stage, Requestor sees "For Received" button */}
                  {status === 'For Received' && (
                    <button
                      type="button"
                      onClick={handleRequestorConfirmReceived}
                      className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Click "For Received" (Confirm Physical Receipt & Lock)</span>
                    </button>
                  )}

                  {/* If Request is already received, Requestor sees "For Return" button */}
                  {status === 'Received' && (
                    <button
                      type="button"
                      onClick={handleRequestorForReturn}
                      className="px-5 py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-black rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                    >
                      <Clock className="w-4 h-4" />
                      <span>Click "For Return" (Notify Requestor, QC Hold, QM Hold & Admin)</span>
                    </button>
                  )}

                  {!isReceivedByRequestor && canEditRequestorDetails && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleSaveRequest()}
                        className="px-4 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 cursor-pointer"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save Draft</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleProceedToQMApproval}
                        className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                      >
                        <Send className="w-4 h-4" />
                        <span>Proceed to QM Approval (Notify QM Hold & Admin) →</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 2: QM APPROVAL (Only QM Hold and QM Admin can update/edit and click "QC Delivery") */}
          {/* ========================================================================= */}
          {activeTab === 'QM_APPROVAL' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 overflow-hidden text-xs animate-in fade-in duration-200">
              
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-3.5 px-4 md:px-5 border-b border-emerald-600/70 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <ShieldCheck className="w-5 h-5 text-pink-400" />
                  <div>
                    <h3 className="font-bold text-sm md:text-base text-white font-['Chakra_Petch'] uppercase tracking-wider">
                      QM APPROVAL & AUTHORIZATION
                    </h3>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-pink-300 bg-pink-950/80 px-3 py-1 rounded-lg border border-pink-700/60 shadow-xs">
                  {qmStatus.toUpperCase()}
                </span>
              </div>

              {!canEditQMApproval && (
                <div className="p-3 bg-amber-950/70 border-b border-amber-600/70 text-amber-200 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    Read-only mode: Only <strong>QM Hold</strong> and <strong>QM Admin</strong> can update and approve keep sample requests.
                  </span>
                </div>
              )}

              <div className="p-4 md:p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      QM ENGINEER / EVALUATOR: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="text"
                      value={qmStaffEngineer}
                      onChange={(e) => setQmStaffEngineer(e.target.value)}
                      disabled={!canEditQMApproval}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      SAMPLE CATEGORY: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <select
                      value={categoryOfSample}
                      onChange={(e) => setCategoryOfSample(e.target.value as SampleCategory)}
                      disabled={!canEditQMApproval}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-bold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    >
                      <option value="Connector">Connector</option>
                      <option value="Harness Item">Harness Item</option>
                      <option value="Molding">Molding</option>
                      <option value="Stamping">Stamping</option>
                      <option value="Pre-assembly">Pre-assembly</option>
                      <option value="Insulator">Insulator</option>
                      <option value="Die con">Die con</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      EVALUATION DATE: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="date"
                      value={qmDate || new Date().toISOString().split('T')[0]}
                      onChange={(e) => setQmDate(e.target.value)}
                      disabled={!canEditQMApproval}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      QM APPROVAL STATUS: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <select
                      value={qmStatus}
                      onChange={(e) => setQmStatus(e.target.value as any)}
                      disabled={!canEditQMApproval}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-bold text-pink-300 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    >
                      <option value="Pending QM Review">Pending QM Review</option>
                      <option value="Approved">Approved</option>
                      <option value="Not Yet Approved">Not Yet Approved</option>
                      <option value="Rejected">Rejected</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      ENDORSED BY (SUPERVISOR):
                    </label>
                    <input
                      type="text"
                      value={endorsedBy}
                      onChange={(e) => setEndorsedBy(e.target.value)}
                      disabled={!canEditQMApproval}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      APPROVED BY (QM SECTION HEAD):
                    </label>
                    <input
                      type="text"
                      value={approvedBy}
                      onChange={(e) => setApprovedBy(e.target.value)}
                      disabled={!canEditQMApproval}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('REQUESTOR_BORROW')}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>← Previous: Requestor Form</span>
                  </button>

                  <div className="flex items-center space-x-3">
                    {canEditQMApproval && (
                      <button
                        type="button"
                        onClick={() => handleSaveRequest()}
                        className="px-4 py-2 bg-[#0a2820] hover:bg-[#143d30] text-emerald-200 border border-emerald-600/70 font-bold rounded-xl text-xs cursor-pointer"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save Evaluation</span>
                      </button>
                    )}

                    {/* QM Hold and QM Admin "QC Delivery" Button */}
                    <button
                      type="button"
                      onClick={handleQMApproveAndQCDelivery}
                      disabled={!canEditQMApproval}
                      className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-black rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                    >
                      <PackageCheck className="w-4 h-4" />
                      <span>Approve & Click "QC Delivery" (Notify QC Hold) →</span>
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 3: QC DELIVERY (QC Hold clicks "For Received" -> notifies Requestor) */}
          {/* ========================================================================= */}
          {activeTab === 'QC_DELIVERY' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 overflow-hidden text-xs animate-in fade-in duration-200">
              
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-3.5 px-4 md:px-5 border-b border-emerald-600/70 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <PackageCheck className="w-5 h-5 text-pink-400" />
                  <div>
                    <h3 className="font-bold text-sm md:text-base text-white font-['Chakra_Petch'] uppercase tracking-wider">
                      QC HOLD CUSTODY & PHYSICAL SAMPLE DELIVERY
                    </h3>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-200 bg-emerald-950/80 px-3 py-1 rounded-lg border border-emerald-700/60 shadow-xs">
                  QC DISPATCH
                </span>
              </div>

              <div className="p-4 md:p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      DELIVERED BY (QC HOLD PIC): <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="text"
                      value={deliveredBy}
                      onChange={(e) => setDeliveredBy(e.target.value)}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      DATE DELIVERED: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="date"
                      value={dateDelivered}
                      onChange={(e) => setDateDelivered(e.target.value)}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-pink-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      DISPATCH STATUS:
                    </label>
                    <div className="p-2 bg-[#0d2820] rounded-xl border border-emerald-700/60 text-emerald-300 font-bold text-xs flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                      <span>Physical specimen handled by QC Hold</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('QM_APPROVAL')}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>← Previous: QM Approval</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleQCDeliveryForReceived}
                    className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-black rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Click "For Received" (Notify Requestor {requestorName}) →</span>
                  </button>
                </div>

              </div>

            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 4: QC RETURN INTAKE & BOX RE-FILING (QM Hold is the one to update) */}
          {/* ========================================================================= */}
          {activeTab === 'QC_RETURN_FILING' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 overflow-hidden text-xs animate-in fade-in duration-200">
              
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-3.5 px-4 md:px-5 border-b border-emerald-600/70 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <CheckCircle2 className="w-5 h-5 text-pink-400" />
                  <div>
                    <h3 className="font-bold text-sm md:text-base text-white font-['Chakra_Petch'] uppercase tracking-wider">
                      QC RETURN INTAKE & BOX RE-FILING (QM HOLD SECTION)
                    </h3>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-pink-300 bg-pink-950/80 px-3 py-1 rounded-lg border border-pink-700/60 shadow-xs">
                  {status === 'Returned' ? 'RETURNED & RE-FILED' : 'RETURN IN PROGRESS'}
                </span>
              </div>

              {!canUpdateReturnFiling && (
                <div className="p-3 bg-amber-950/70 border-b border-amber-600/70 text-amber-200 text-xs flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>
                    Notice: <strong>QM Hold</strong> is responsible for updating and signing off QC Return Intake & Box Re-filing.
                  </span>
                </div>
              )}

              <div className="p-4 md:p-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      RETURNED BY (BORROWER): <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="text"
                      value={returnedBy || requestorName}
                      onChange={(e) => setReturnedBy(e.target.value)}
                      disabled={!canUpdateReturnFiling}
                      placeholder="Requestor name on return..."
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      DATE RETURNED: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="date"
                      value={dateReturned || new Date().toISOString().split('T')[0]}
                      onChange={(e) => setDateReturned(e.target.value)}
                      disabled={!canUpdateReturnFiling}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-mono text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      FILED BACK BY (QM HOLD): <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <input
                      type="text"
                      value={fillingInBox}
                      onChange={(e) => setFillingInBox(e.target.value)}
                      disabled={!canUpdateReturnFiling}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-semibold text-white focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                      FINAL STATUS: <span className="text-pink-400 font-bold">*</span>
                    </label>
                    <select
                      value={status}
                      onChange={(e) => setStatus(e.target.value as KeepSampleRequestStatus)}
                      disabled={!canUpdateReturnFiling}
                      className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl px-3 py-2 text-xs font-bold text-pink-400 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                    >
                      <option value="For Return">For Return (Pending Verification)</option>
                      <option value="Returned">Returned (Re-filed & Closed)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-emerald-300 uppercase tracking-wider mb-1.5">
                    QM HOLD RETURN INTAKE REMARKS & NOTES:
                  </label>
                  <textarea
                    rows={3}
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    disabled={!canUpdateReturnFiling}
                    placeholder="Verification remarks on physical specimen condition upon return and rack re-filing slot verification..."
                    className="w-full bg-[#0a2820] border border-emerald-600/70 rounded-xl p-3 text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-pink-500 focus:outline-none disabled:opacity-60"
                  />
                </div>

                <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('QC_DELIVERY')}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>← Previous: QC Delivery</span>
                  </button>

                  <div className="flex items-center space-x-3">
                    <button
                      type="button"
                      onClick={handleQMHoldCompleteReturnFiling}
                      disabled={!canUpdateReturnFiling}
                      className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-50 text-white font-black rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>QM Hold: Finalize Return Intake & Box Re-filing</span>
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ========================================================================= */}
          {/* TAB 5: AUDIT TRAIL & EMAIL NOTIFICATION LOGS */}
          {/* ========================================================================= */}
          {activeTab === 'AUDIT_TRAIL' && (
            <div className="bg-[#141a16] rounded-2xl shadow-lg border border-emerald-800/60 overflow-hidden text-xs animate-in fade-in duration-200">
              
              <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white p-3.5 px-4 md:px-5 border-b border-emerald-600/70 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <History className="w-5 h-5 text-pink-400" />
                  <div>
                    <h3 className="font-bold text-sm md:text-base text-white font-['Chakra_Petch'] uppercase tracking-wide flex items-center gap-2">
                      <span>CUSTODY AUDIT TRAIL & NOTIFICATION DISPATCHES</span>
                    </h3>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-pink-300 bg-pink-950/80 px-3 py-1 rounded-lg border border-pink-700/60 shadow-xs">
                  IATF 16949 COMPLIANT
                </span>
              </div>

              <div className="p-4 md:p-6 space-y-4">
                <div className="space-y-3">
                  <div className="p-3 bg-[#0d2820] rounded-xl border border-emerald-700/60 flex items-start space-x-3">
                    <Clock className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                    <div>
                      <div className="font-bold text-white">Requisition Initiated</div>
                      <div className="text-[11px] text-emerald-300/80 font-mono">
                        Date: {dateRequested} • Requestor: {requestorName} • Department: {department}
                      </div>
                    </div>
                  </div>

                  {notificationLogs.map((log) => (
                    <div key={log.id} className="p-3 bg-[#0d2820] rounded-xl border border-pink-700/60 flex items-start space-x-3">
                      <Mail className="w-4 h-4 text-pink-400 mt-0.5 shrink-0" />
                      <div className="space-y-1 w-full">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-pink-300">{log.subject}</span>
                          <span className="text-[10px] text-emerald-400 font-mono">{log.timestamp}</span>
                        </div>
                        <div className="text-[11px] text-emerald-200">
                          <strong>Recipients:</strong> {log.recipients.join(', ')}
                        </div>
                        <p className="text-[11px] text-slate-300 bg-[#071e17] p-2 rounded-lg border border-emerald-800/80 font-mono">
                          {log.body}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-emerald-800/60 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('QC_RETURN_FILING')}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl text-xs flex items-center space-x-1.5 border border-slate-700 cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>← Previous: Return & Re-filing</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsMultitabOpen(false)}
                    className="px-5 py-2 bg-pink-600 hover:bg-pink-700 text-white font-bold rounded-xl text-xs shadow-md flex items-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <span>Return to Request Masterlist</span>
                  </button>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. EMAIL & NOTIFICATION DISPATCH LOGS MODAL */}
      {/* ========================================================================= */}
      {showNotificationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200 font-['Plus_Jakarta_Sans']">
          <div className="bg-[#141a16] rounded-2xl shadow-2xl border border-emerald-800/80 w-full max-w-2xl max-h-[85vh] overflow-y-auto text-white">
            <div className="bg-gradient-to-r from-[#044e3b] via-[#065f46] to-[#044e3b] text-white px-6 py-4 flex items-center justify-between border-b border-emerald-700/60 sticky top-0 z-10">
              <div className="flex items-center space-x-2.5">
                <Mail className="w-5 h-5 text-pink-400" />
                <h3 className="text-sm font-bold tracking-tight font-['Chakra_Petch'] uppercase">
                  iSMS Notification & Email Audit Logs
                </h3>
              </div>
              <button
                onClick={() => setShowNotificationModal(false)}
                className="text-emerald-300 hover:text-white font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              {notificationLogs.length === 0 ? (
                <div className="p-8 text-center text-emerald-300/70">
                  <Mail className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                  <p className="font-semibold text-emerald-200">No notifications dispatched in current session yet.</p>
                  <p className="text-[11px] text-emerald-400/80 mt-1">
                    Notifications are automatically generated when advancing through the approval & return custody chain.
                  </p>
                </div>
              ) : (
                notificationLogs.map((log) => (
                  <div key={log.id} className="p-4 bg-[#0d2820] rounded-xl border border-emerald-700/70 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white">{log.subject}</span>
                      <span className="font-mono text-[10px] text-emerald-400">{log.timestamp}</span>
                    </div>
                    <div className="text-[11px] text-pink-300">
                      <strong>To:</strong> {log.recipients.join(', ')}
                    </div>
                    <div className="p-2.5 bg-[#071e17] rounded-lg border border-emerald-900/60 font-mono text-[11px] text-slate-200">
                      {log.body}
                    </div>
                  </div>
                ))
              )}

              <div className="pt-3 flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowNotificationModal(false)}
                  className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. FORMAL PRINTABLE SIGN-OFF SLIP & PDF REPORT MODAL (Request #4) */}
      {/* ========================================================================= */}
      {printModalRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-6 bg-black/85 backdrop-blur-sm overflow-y-auto animate-in fade-in">
          <div className="relative w-full max-w-4xl bg-white text-slate-900 rounded-xl shadow-2xl overflow-hidden my-auto border border-slate-300">
            
            {/* Top Toolbar (Hidden during browser print) */}
            <div className="print:hidden bg-slate-900 text-white px-5 py-3 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <Printer className="w-5 h-5 text-pink-400" />
                <h3 className="text-sm font-bold uppercase tracking-wider font-['Chakra_Petch']">
                  Official Keep Sample Borrow Routing & Custody Sign-Off Report
                </h3>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={handleTriggerBrowserPrint}
                  className="px-4 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs rounded-lg shadow flex items-center space-x-1.5 transition-all cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Document / Save as PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPrintModalRequest(null)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Printable Document Body (A4/Letter Paper Format) */}
            <div className="p-8 sm:p-10 space-y-6 bg-white text-slate-900 text-xs font-sans print:p-0 print:m-0">
              
              {/* Official Header */}
              <div className="border-b-2 border-slate-900 pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <JAELogo />
                    <div>
                      <h1 className="text-base font-black tracking-tight text-slate-900 uppercase">
                        JAE Philippines, Inc.
                      </h1>
                      <p className="text-[11px] font-semibold text-slate-700 tracking-wide">
                        Quality Management Division • Integrated Sample Management System (iSMS)
                      </p>
                      <p className="text-[10px] text-slate-500 font-mono">
                        Standard Quality Custody Document • Form Ref: JAE-QMD-KS-REQ-01
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="px-3 py-1 bg-slate-100 border border-slate-400 rounded text-center">
                      <div className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">BORROW CONTROL NO.</div>
                      <div className="text-base font-black font-mono text-slate-900">{printModalRequest.controlNo}</div>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-1 font-mono">
                      Issued: {new Date().toLocaleString()}
                    </div>
                  </div>
                </div>

                <div className="mt-3 text-center py-1.5 bg-slate-900 text-white font-bold uppercase tracking-wider text-xs rounded">
                  KEEP SAMPLE BORROW REQUISITION & CUSTODY CHAIN ROUTING SLIP
                </div>
              </div>

              {/* 1. Request Details Matrix */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-900 uppercase tracking-wide border-b border-slate-300 pb-0.5">
                  1. Requestor Header & Storage Location Details
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 border border-slate-300 p-3 rounded bg-slate-50/50">
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Date Requested:</div>
                    <div className="font-mono font-bold text-slate-900">{printModalRequest.dateRequested || printModalRequest.date}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Requestor Name:</div>
                    <div className="font-bold text-slate-900">{printModalRequest.requestorName}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Department / Section:</div>
                    <div className="font-semibold text-slate-900">{printModalRequest.department} / {printModalRequest.section}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Factory / Facility:</div>
                    <div className="font-semibold text-slate-900">{printModalRequest.factory}</div>
                  </div>

                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Target Box Number:</div>
                    <div className="font-mono font-black text-pink-700 text-sm">{printModalRequest.boxNumber}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Storage Area:</div>
                    <div className="font-semibold text-slate-900">{printModalRequest.area || '1F Mezzanine'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Rack Location:</div>
                    <div className="font-mono font-bold text-slate-900">{printModalRequest.rackLocation}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Current Status:</div>
                    <div className="font-bold text-emerald-800 uppercase">{printModalRequest.status}</div>
                  </div>

                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Sample Category:</div>
                    <div className="font-bold text-slate-900">{printModalRequest.typeOfBorrowedSample || 'Keep Sample'}</div>
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Date Needed:</div>
                    <div className="font-mono text-slate-900">{printModalRequest.dateNeeded}</div>
                  </div>
                  <div className="col-span-2">
                    <div className="text-[10px] font-bold text-rose-700 uppercase">Mandatory Return Due Date:</div>
                    <div className="font-mono font-black text-rose-700 text-sm">{printModalRequest.returnedDueDate}</div>
                  </div>

                  <div className="col-span-4 pt-1 border-t border-slate-200">
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Borrow Purpose / Reason:</div>
                    <div className="text-slate-800 italic">{printModalRequest.reason || 'Verification & Analysis'}</div>
                  </div>
                </div>
              </div>

              {/* 2. Requisitioned Items Table */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-900 uppercase tracking-wide border-b border-slate-300 pb-0.5">
                  2. Requisitioned Sample Items Checklist
                </div>
                <table className="w-full border-collapse border border-slate-400 text-[11px]">
                  <thead>
                    <tr className="bg-slate-200 text-slate-900 font-bold border-b border-slate-400">
                      <th className="border border-slate-400 p-1.5 text-center w-10">#</th>
                      <th className="border border-slate-400 p-1.5 text-left">Sample Code / Serial</th>
                      <th className="border border-slate-400 p-1.5 text-left">Part Name / Item Description</th>
                      <th className="border border-slate-400 p-1.5 text-center w-20">Cavity #</th>
                      <th className="border border-slate-400 p-1.5 text-center w-24">Lot / Batch #</th>
                      <th className="border border-slate-400 p-1.5 text-center w-20">Qty (pcs)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(printModalRequest.items && printModalRequest.items.length > 0) ? (
                      printModalRequest.items.map((item, idx) => (
                        <tr key={item.id || idx}>
                          <td className="border border-slate-400 p-1.5 text-center font-mono">{idx + 1}</td>
                          <td className="border border-slate-400 p-1.5 font-mono font-bold text-slate-900">{item.sampleCode || `KS-${idx + 1}`}</td>
                          <td className="border border-slate-400 p-1.5 font-semibold text-slate-900">{item.itemName || printModalRequest.item || 'Keep Sample Item'}</td>
                          <td className="border border-slate-400 p-1.5 text-center font-mono">{item.cavityNo || '-'}</td>
                          <td className="border border-slate-400 p-1.5 text-center font-mono">{item.lotNo || '-'}</td>
                          <td className="border border-slate-400 p-1.5 text-center font-mono font-bold">{item.quantity || 1}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td className="border border-slate-400 p-1.5 text-center font-mono">1</td>
                        <td className="border border-slate-400 p-1.5 font-mono font-bold text-slate-900">KS-MAIN</td>
                        <td className="border border-slate-400 p-1.5 font-semibold text-slate-900">{printModalRequest.item || 'Keep Sample Component'}</td>
                        <td className="border border-slate-400 p-1.5 text-center font-mono">1</td>
                        <td className="border border-slate-400 p-1.5 text-center font-mono">-</td>
                        <td className="border border-slate-400 p-1.5 text-center font-mono font-bold">1</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 3. Official 6-Stage Custody Sign-off Matrix */}
              <div className="space-y-2">
                <div className="text-[11px] font-bold text-slate-900 uppercase tracking-wide border-b border-slate-300 pb-0.5">
                  3. Official Chain of Custody & Physical Sign-off Verification Matrix
                </div>
                
                <table className="w-full border-collapse border border-slate-400 text-[11px]">
                  <thead>
                    <tr className="bg-slate-200 text-slate-900 font-bold border-b border-slate-400">
                      <th className="border border-slate-400 p-2 text-left w-1/4">Custody Stage</th>
                      <th className="border border-slate-400 p-2 text-left w-1/4">Assigned Personnel</th>
                      <th className="border border-slate-400 p-2 text-left w-1/4">Status / Endorsement</th>
                      <th className="border border-slate-400 p-2 text-center w-1/4">Signature & Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {/* Stage 1: Requestor */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        1. Requestor Requisition
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRequest.requestorName}</div>
                        <div className="text-[9px] text-slate-500">{printModalRequest.section}</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold text-emerald-800">
                        Submitted ({printModalRequest.dateRequested || printModalRequest.date})
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 2: Section Head */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        2. Section Head Endorsement
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRequest.sectionHeadApprovedBy || 'Section Supervisor'}</div>
                        <div className="text-[9px] text-slate-500">{printModalRequest.section}</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Status: <span className="text-emerald-800 font-bold">{printModalRequest.sectionHeadApproved ? 'Approved' : 'Pending'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 3: QM Approval */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        3. Quality Management Approval
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRequest.approvedByQM || 'QM Head / In-Charge'}</div>
                        <div className="text-[9px] text-slate-500">Quality Management Section</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Status: <span className="text-emerald-800 font-bold">{printModalRequest.qmApproved ? 'Approved' : 'Pending'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 4: QC Delivery */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        4. QC Delivery / Vault Handoff
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRequest.deliveredBy || 'QC Hold Vault Custodian'}</div>
                        <div className="text-[9px] text-slate-500">QC Hold Section</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Delivered: <span className="text-blue-800 font-bold">{printModalRequest.dateDelivered || 'Pending'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 5: Requestor Received Confirmation */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        5. Requestor Receipt Confirmation
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRequest.requestorName}</div>
                        <div className="text-[9px] text-slate-500">{printModalRequest.section}</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Physical Receipt: <span className="text-emerald-800 font-bold">{printModalRequest.isReceivedByRequestor ? 'Confirmed' : 'Pending'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>

                    {/* Stage 6: QC Hold Return Verification */}
                    <tr>
                      <td className="border border-slate-400 p-2 font-bold bg-slate-50">
                        6. QC Hold Return & Vault Re-filing
                      </td>
                      <td className="border border-slate-400 p-2">
                        <div className="font-semibold text-slate-900">{printModalRequest.returnedToQCBy || 'QC Hold Receiver'}</div>
                        <div className="text-[9px] text-slate-500">QC Hold Section</div>
                      </td>
                      <td className="border border-slate-400 p-2 font-semibold">
                        Box Re-filed: <span className="text-purple-800 font-bold">{printModalRequest.isFilingClosed ? 'Completed' : 'Pending'}</span>
                      </td>
                      <td className="border border-slate-400 p-2 text-center align-bottom h-14">
                        <div className="border-b border-slate-500 w-3/4 mx-auto mb-1"></div>
                        <span className="text-[9px] text-slate-500 uppercase font-mono">Sign & Date</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* 4. Formal Notice Footer */}
              <div className="border-t border-slate-300 pt-3 flex items-center justify-between text-[10px] text-slate-500 font-mono">
                <div>
                  ISO 9001:2015 Quality Record • Strict Custody Chain Compliance • JAE Philippines, Inc.
                </div>
                <div>
                  Page 1 of 1 • System Generated via iSMS Cloud
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
};
