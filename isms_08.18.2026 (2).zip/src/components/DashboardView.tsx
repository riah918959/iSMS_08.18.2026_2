import React, { useState } from 'react';
import {
  Send,
  Monitor,
  Settings,
  AlertTriangle,
  AlertCircle,
  CheckCircle2,
  Clock,
  Archive,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Layers,
  ArrowUpRight,
  Filter,
  PlusCircle,
  FileSpreadsheet,
  Zap,
  RefreshCw,
  FolderOpen,
  Box,
  ScanLine,
  Activity
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  CartesianGrid, 
  Legend,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { NavTab } from './Sidebar';
import { UserProfile } from '../types';
import { storageService } from '../services/storageService';

interface DashboardViewProps {
  metrics?: {
    keepSample: {
      returnedToOriginalBox: number;
      forFilingOfTheUKS: number;
      unreturned: number;
      total: number;
    };
    y2kMasterlist: {
      expired: number;
      notYetExpired: number;
      forChecking: number;
      availableSpace: number;
      total: number;
    };
    rsIsSample: {
      forReceive: number;
      pendingForDisposition: number;
      forReturn: number;
      total: number;
    };
    holdSampleByDept: Record<string, number>;
    criticalAlertsCount: number;
  };
  currentUser?: UserProfile;
  onNavigate: (tab: NavTab) => void;
  onOpenProfile?: () => void;
  onOpenAlerts?: () => void;
  onOpenExportModal?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  metrics: incomingMetrics,
  currentUser,
  onNavigate,
  onOpenProfile,
  onOpenAlerts,
  onOpenExportModal
}) => {
  // Use incoming metrics or calculate live from storageService
  const metrics = incomingMetrics || storageService.getDashboardMetrics();
  const schedules = storageService.getProductionSchedules().slice(0, 5);
  const auditLogs = storageService.getAuditLogs().slice(0, 7);
  const qcForecasts = storageService.analyzeBatchScheduleQCHoldExpirations();
  const criticalQCHolds = qcForecasts.filter(f => f.riskLevel === 'CRITICAL' || f.riskLevel === 'HIGH');

  // Quick Action Handlers
  const handleEncodeBatch = () => onNavigate('production_schedule');

  // Dynamic 7-Day Sparkline Data for Sample Returns and QC Throughput (Request #5)
  const sampleReturnsSparkline = [
    { day: 'Mon', returned: 14, unreturned: 3, filed: 12, rate: 82 },
    { day: 'Tue', returned: 19, unreturned: 4, filed: 16, rate: 86 },
    { day: 'Wed', returned: 16, unreturned: 2, filed: 15, rate: 89 },
    { day: 'Thu', returned: 22, unreturned: 5, filed: 19, rate: 84 },
    { day: 'Fri', returned: 25, unreturned: 3, filed: 23, rate: 91 },
    { day: 'Sat', returned: 18, unreturned: 2, filed: 17, rate: 94 },
    { day: 'Today', returned: metrics.keepSample.returnedToOriginalBox || 24, unreturned: metrics.keepSample.unreturned || 4, filed: metrics.keepSample.forFilingOfTheUKS || 20, rate: 92 }
  ];

  const qcThroughputSparkline = [
    { shift: 'D-6', throughput: 1240, rejects: 10, yieldPct: 99.2, inspected: 1250 },
    { shift: 'D-5', throughput: 1480, rejects: 14, yieldPct: 99.0, inspected: 1494 },
    { shift: 'D-4', throughput: 1390, rejects: 9, yieldPct: 99.3, inspected: 1399 },
    { shift: 'D-3', throughput: 1620, rejects: 18, yieldPct: 98.8, inspected: 1638 },
    { shift: 'D-2', throughput: 1550, rejects: 12, yieldPct: 99.2, inspected: 1562 },
    { shift: 'D-1', throughput: 1710, rejects: 11, yieldPct: 99.3, inspected: 1721 },
    { shift: 'Cur Shift', throughput: 1840, rejects: 8, yieldPct: 99.5, inspected: 1848 }
  ];
  const handleExport = onOpenExportModal || (() => {
    const rows = [
      ['Report Type', 'JAE iSMS Production & QC Shift Report'],
      ['Generated At', new Date().toISOString()],
      [],
      ['Lot Number', 'Line', 'Stage', 'Product Code', 'Status', 'Target Qty', 'Completed Qty'],
      ...schedules.map(s => [
        s.lotNumber || '',
        s.line || '',
        s.stage || '',
        s.productCode || '',
        s.status || '',
        s.targetQuantity?.toString() || '0',
        s.completedQuantity?.toString() || '0'
      ])
    ];
    const csvContent = rows.map(e => e.map(cell => `"${(cell || '').toString().replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `iSMS_Shift_Report_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  });

  return (
    <div id="dashboard-container" className="p-3 md:p-5 space-y-4 w-full text-white font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette, compact 3/4 layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <BarChart3 className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                Executive Summary Dashboard
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                LIVE TELEMETRY
              </span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            id="dash-btn-request-sample"
            onClick={() => onNavigate('keep_sample_request')}
            className="px-3 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white text-xs font-bold uppercase rounded-lg flex items-center gap-1.5 transition-all shadow-sm"
          >
            <Send className="w-3.5 h-3.5" />
            <span>REQUEST SAMPLE</span>
          </button>

          <button
            id="dash-btn-sample-monitoring"
            onClick={() => onNavigate('keep_sample_entry')}
            className="px-3 py-1.5 bg-[#0F5132] hover:bg-[#146c43] text-white text-xs font-bold uppercase rounded-lg flex items-center gap-1.5 transition-colors border border-emerald-600/50 shadow-sm"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>SAMPLE MONITORING</span>
          </button>

          <button
            id="dash-btn-export-report"
            onClick={handleExport}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-gray-200 border border-slate-700 text-xs font-bold uppercase rounded-lg flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>EXPORT CSV</span>
          </button>
        </div>
      </div>

      {/* Critical Alert Bar */}
      {metrics.criticalAlertsCount > 0 && (
        <div 
          onClick={onOpenAlerts || (() => onNavigate('pic_alerts'))}
          className="cursor-pointer bg-pink-950/40 hover:bg-pink-950/60 border border-pink-800/80 p-3 rounded flex items-center justify-between transition-colors text-xs"
        >
          <div className="flex items-center gap-2 text-pink-300 font-medium">
            <AlertTriangle className="w-4 h-4 text-pink-500 animate-pulse shrink-0" />
            <span>
              {metrics.criticalAlertsCount} Critical Alert(s) Detected (e.g. "No Received Sample" or Overdue UKS Keep Samples). Review P.I.C. automated dispatch log.
            </span>
          </div>
          <span className="text-[11px] font-bold text-pink-400 underline uppercase tracking-wider font-mono">
            View Alerts →
          </span>
        </div>
      )}

      {/* Top 4 Metric KPI Cards with Embedded Dynamic Sparkline Trends (Request #5) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        
        {/* 1. Overall Production Yield & Sparkline */}
        <div className="bg-[#1A1A1A] border border-gray-800 p-3.5 rounded-xl flex flex-col justify-between relative overflow-hidden group hover:border-emerald-700/60 transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                Overall Production Yield
              </div>
              <div className="text-2xl lg:text-3xl font-black text-white font-['Chakra_Petch'] mt-0.5">
                98.4<span className="text-sm text-green-500 font-sans">%</span>
              </div>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 font-mono font-bold flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3 text-emerald-400" />
              <span>+0.3%</span>
            </span>
          </div>

          {/* Mini Sparkline Chart */}
          <div className="h-10 w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={qcThroughputSparkline}>
                <defs>
                  <linearGradient id="yieldGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="yieldPct" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#yieldGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="text-[10px] text-gray-500 font-mono mt-1 flex justify-between">
            <span>Target: &gt;98.0%</span>
            <span className="text-emerald-400">IATF Nominal</span>
          </div>
        </div>

        {/* 2. QC Throughput & Inspection Trend */}
        <div className="bg-[#1A1A1A] border border-gray-800 p-3.5 rounded-xl flex flex-col justify-between relative overflow-hidden group hover:border-pink-700/60 transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                QC Throughput / Shift
              </div>
              <div className="text-2xl lg:text-3xl font-black text-white font-['Chakra_Petch'] mt-0.5">
                1,840 <span className="text-xs text-pink-400 font-sans font-bold">PCS</span>
              </div>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-pink-950 text-pink-300 border border-pink-700 font-mono font-bold flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3 text-pink-400" />
              <span>+12.8%</span>
            </span>
          </div>

          {/* Mini Sparkline Chart */}
          <div className="h-10 w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={qcThroughputSparkline}>
                <defs>
                  <linearGradient id="tpGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ec4899" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#ec4899" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="throughput" stroke="#ec4899" strokeWidth={2} fillOpacity={1} fill="url(#tpGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="text-[10px] text-pink-400 font-mono mt-1 flex justify-between">
            <span>Peak: 1,848 pcs/shift</span>
            <span className="text-gray-400">7-Day Trend</span>
          </div>
        </div>

        {/* 3. Keep Sample Return Rate & Sparkline */}
        <div className="bg-[#1A1A1A] border border-gray-800 p-3.5 rounded-xl flex flex-col justify-between relative overflow-hidden group hover:border-emerald-700/60 transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                Sample Return Compliance
              </div>
              <div className="text-2xl lg:text-3xl font-black text-emerald-400 font-['Chakra_Petch'] mt-0.5">
                92.0<span className="text-sm text-emerald-400 font-sans">%</span>
              </div>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 font-mono font-bold flex items-center gap-0.5">
              <TrendingUp className="w-3 h-3 text-emerald-400" />
              <span>+6.0%</span>
            </span>
          </div>

          {/* Mini Sparkline Chart */}
          <div className="h-10 w-full mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sampleReturnsSparkline}>
                <defs>
                  <linearGradient id="returnGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <Area type="monotone" dataKey="rate" stroke="#14b8a6" strokeWidth={2} fillOpacity={1} fill="url(#returnGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="text-[10px] text-gray-400 font-mono mt-1 flex justify-between">
            <span>Returned: <strong className="text-emerald-300">{metrics.keepSample.returnedToOriginalBox}</strong></span>
            <span>Unreturned: <strong className="text-pink-400">{metrics.keepSample.unreturned}</strong></span>
          </div>
        </div>

        {/* 4. Storage Retention Space */}
        <div className="bg-[#1A1A1A] border border-gray-800 p-3.5 rounded-xl flex flex-col justify-between relative overflow-hidden group hover:border-cyan-700/60 transition-colors">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">
                Storage Retention Space
              </div>
              <div className="text-2xl lg:text-3xl font-black text-white font-['Chakra_Petch'] mt-0.5">
                {metrics.y2kMasterlist.availableSpace} <span className="text-sm text-cyan-400 font-sans">SLOTS</span>
              </div>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700 font-mono font-bold">
              OPTIMAL
            </span>
          </div>

          {/* Progress Bar & Mini Visualizer */}
          <div className="mt-3 space-y-1">
            <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden border border-gray-800">
              <div 
                className="h-full bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 rounded-full"
                style={{ width: `${Math.min(100, Math.max(10, ((metrics.y2kMasterlist.total - metrics.y2kMasterlist.availableSpace) / (metrics.y2kMasterlist.total || 1)) * 100))}%` }}
              />
            </div>
          </div>

          <div className="text-[10px] text-cyan-300 font-mono mt-2 flex justify-between">
            <span>Total Vault: {metrics.y2kMasterlist.total}</span>
            <span className="text-emerald-400">P.I.C. Active</span>
          </div>
        </div>

      </div>

      {/* Dynamic Sparkline Telemetry Panel: Sample Returns & QC Throughput (Request #5) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Sparkline Panel 1: Sample Returns & Borrowing Velocity */}
        <div className="bg-[#181818] border border-emerald-900/60 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2.5 mb-3">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-emerald-950 text-emerald-400 rounded border border-emerald-700/60">
                <RefreshCw className="w-4 h-4 text-emerald-400 animate-spin-slow" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider font-['Chakra_Petch']">
                  Sample Returns & UKS Filing Velocity Sparkline
                </h3>
                <p className="text-[10px] text-gray-400">
                  7-Day Trend of Keep Samples Returned to Box vs Filed to UKS vs Overdue
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-emerald-300 font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-700">
                92% Returned Rate
              </span>
            </div>
          </div>

          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sampleReturnsSparkline} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="sparkReturnedGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.6}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="sparkFiledGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#eab308" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#eab308" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="day" stroke="#737373" tick={{ fontSize: 10 }} />
                <YAxis stroke="#737373" tick={{ fontSize: 10 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#171717', borderColor: '#404040', borderRadius: '8px', fontSize: '11px' }}
                  labelStyle={{ color: '#fff', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="returned" name="Returned to Box" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#sparkReturnedGrad)" />
                <Area type="monotone" dataKey="filed" name="Filed to UKS" stroke="#eab308" strokeWidth={1.5} fillOpacity={1} fill="url(#sparkFiledGrad)" />
                <Line type="monotone" dataKey="unreturned" name="Unreturned" stroke="#f43f5e" strokeWidth={2} dot={{ r: 3, fill: '#f43f5e' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-3 pt-2.5 border-t border-gray-800 text-center font-mono">
            <div className="bg-[#121212] p-1.5 rounded border border-emerald-900/40">
              <div className="text-[9px] text-gray-400 uppercase font-sans">Returned to Box</div>
              <div className="text-xs font-bold text-emerald-400">{metrics.keepSample.returnedToOriginalBox} samples</div>
            </div>
            <div className="bg-[#121212] p-1.5 rounded border border-yellow-900/40">
              <div className="text-[9px] text-gray-400 uppercase font-sans">UKS Filing Stage</div>
              <div className="text-xs font-bold text-yellow-400">{metrics.keepSample.forFilingOfTheUKS} samples</div>
            </div>
            <div className="bg-[#121212] p-1.5 rounded border border-rose-900/40">
              <div className="text-[9px] text-gray-400 uppercase font-sans">Active Borrowed</div>
              <div className="text-xs font-bold text-pink-400">{metrics.keepSample.unreturned} samples</div>
            </div>
          </div>
        </div>

        {/* Sparkline Panel 2: QC Throughput & Defect Escape Rate */}
        <div className="bg-[#181818] border border-pink-900/60 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-gray-800 pb-2.5 mb-3">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-pink-950 text-pink-400 rounded border border-pink-700/60">
                <Activity className="w-4 h-4 text-pink-400" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider font-['Chakra_Petch']">
                  QC Inspection Throughput & Yield Sparkline
                </h3>
                <p className="text-[10px] text-gray-400">
                  Shift Throughput vs Quality Gate Rejects per 1,000 Inspected Components
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="text-[10px] font-mono text-pink-300 font-bold bg-pink-950/80 px-2 py-0.5 rounded border border-pink-700">
                1,840 pcs/shift
              </span>
            </div>
          </div>

          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={qcThroughputSparkline} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="sparkThroughputGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ec4899" stopOpacity={0.6}/>
                    <stop offset="95%" stopColor="#ec4899" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#262626" vertical={false} />
                <XAxis dataKey="shift" stroke="#737373" tick={{ fontSize: 10 }} />
                <YAxis stroke="#737373" tick={{ fontSize: 10 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#171717', borderColor: '#404040', borderRadius: '8px', fontSize: '11px' }}
                  labelStyle={{ color: '#fff', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="throughput" name="QC Throughput (pcs)" stroke="#ec4899" strokeWidth={2.5} fillOpacity={1} fill="url(#sparkThroughputGrad)" />
                <Line type="monotone" dataKey="rejects" name="Rejects Count" stroke="#f43f5e" strokeWidth={2} dot={{ r: 3, fill: '#f43f5e' }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-2 mt-3 pt-2.5 border-t border-gray-800 text-center font-mono">
            <div className="bg-[#121212] p-1.5 rounded border border-pink-900/40">
              <div className="text-[9px] text-gray-400 uppercase font-sans">Current Throughput</div>
              <div className="text-xs font-bold text-pink-400">1,840 pcs</div>
            </div>
            <div className="bg-[#121212] p-1.5 rounded border border-emerald-900/40">
              <div className="text-[9px] text-gray-400 uppercase font-sans">QC Pass Yield</div>
              <div className="text-xs font-bold text-emerald-400">99.5% nominal</div>
            </div>
            <div className="bg-[#121212] p-1.5 rounded border border-slate-800">
              <div className="text-[9px] text-gray-400 uppercase font-sans">Shift Rejects</div>
              <div className="text-xs font-bold text-slate-300">8 items (&lt;0.5%)</div>
            </div>
          </div>
        </div>

      </div>


      {/* Middle Grid: Production Schedule Table (8-col) + Real-time Audit Stream (4-col) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Production Scheduling & Real-Time Tracking Table */}
        <div className="lg:col-span-8 bg-[#1A1A1A] border border-gray-800 rounded flex flex-col overflow-hidden">
          <div className="p-3 border-b border-gray-800 flex justify-between items-center bg-gray-800/20">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-pink-500"></span>
              <span className="text-xs font-bold uppercase tracking-wider">
                Production Scheduling & Real-Time Tracking
              </span>
            </div>
            <span className="text-[10px] text-gray-500 font-mono">
              DB: ISMS_QM_DB
            </span>
          </div>

          <div className="flex-1 overflow-x-auto p-2">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-gray-500 border-b border-gray-800 font-mono text-[10px]">
                  <th className="text-left p-2 uppercase">BATCH / LOT</th>
                  <th className="text-left p-2 uppercase">LINE / STAGE</th>
                  <th className="text-left p-2 uppercase">CONNECTOR TYPE</th>
                  <th className="text-left p-2 uppercase">STATUS</th>
                  <th className="text-right p-2 uppercase">TARGET / DUE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {schedules.map((sch, i) => (
                  <tr key={sch.id || i} className="hover:bg-white/5 transition-colors">
                    <td className="p-2 font-mono text-pink-400 font-semibold">{sch.lotNumber}</td>
                    <td className="p-2 font-mono text-gray-300">{sch.line} • {sch.stage}</td>
                    <td className="p-2 text-gray-200">{sch.productCode || sch.productName || 'MX-Automotive'}</td>
                    <td className="p-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                        sch.status === 'Completed'
                          ? 'bg-green-900/50 text-green-400'
                          : sch.status === 'In Progress'
                          ? 'bg-blue-900/50 text-blue-400'
                          : sch.status === 'Quality Gate Hold'
                          ? 'bg-pink-900/50 text-pink-400'
                          : 'bg-yellow-900/50 text-yellow-400'
                      }`}>
                        {sch.status}
                      </span>
                    </td>
                    <td className="p-2 text-right font-mono text-gray-400">{sch.targetQuantity?.toLocaleString()} pcs</td>
                  </tr>
                ))}
                {schedules.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-4 text-center text-gray-500">
                      No active production schedule records
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="p-2 bg-[#161616] border-t border-gray-800 flex justify-between items-center text-[10px] font-mono text-gray-500 px-3">
            <span>SHOWING 5 RECENT LOTS</span>
            <button 
              onClick={() => onNavigate('production_schedule')} 
              className="text-pink-400 hover:text-pink-300 font-bold uppercase"
            >
              Full Schedule View →
            </button>
          </div>
        </div>

        {/* Real-time Terminal Audit Log & Security Stream */}
        <div className="lg:col-span-4 bg-[#1A1A1A] border border-gray-800 rounded flex flex-col overflow-hidden">
          <div className="p-3 border-b border-gray-800 bg-[#0F5132]/20 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-pink-500"></div>
              <span className="text-xs font-bold uppercase tracking-wider">
                Audit Log & Security
              </span>
            </div>
            <span className="text-[9px] font-mono text-emerald-400">IATF 16949</span>
          </div>

          <div className="flex-1 p-2.5 font-mono text-[10px] text-gray-400 space-y-1.5 overflow-hidden">
            {auditLogs.map((log) => (
              <div key={log.id} className="border-l border-gray-700 pl-2 leading-relaxed truncate">
                <span className="text-gray-500">{log.timestamp.split(' ')[1] || log.timestamp.substring(11, 19)}</span>{' '}
                <span className={`font-bold ${
                  log.module === 'SECURITY' ? 'text-pink-500' :
                  log.module === 'SYSTEM_SYNC' ? 'text-yellow-500' :
                  log.module === 'KEEP_SAMPLE' ? 'text-green-500' : 'text-emerald-400'
                }`}>
                  [{log.module.substring(0, 3)}]
                </span>{' '}
                <span className="text-gray-300">{log.details}</span>
              </div>
            ))}
            {auditLogs.length === 0 && (
              <div className="text-gray-500 text-center py-4">No audit logs recorded</div>
            )}
          </div>

          <div className="p-2 bg-[#161616] border-t border-gray-800 flex justify-between items-center text-[10px] font-mono text-gray-500 px-3">
            <span>SQL SERVER AUDIT TRAIL</span>
            <button 
              onClick={() => onNavigate('audit_logs')} 
              className="text-pink-400 hover:text-pink-300 font-bold uppercase"
            >
              All Logs →
            </button>
          </div>
        </div>

      </div>

      {/* Real-time Stock Monitoring Bars + Quick Actions (Matching Design HTML bottom section) */}
      <div className="bg-[#1A1A1A] border border-gray-800 rounded p-4 flex flex-col md:flex-row gap-6">
        
        {/* Real-time Stock Level Bars */}
        <div className="flex-1">
          <div className="text-[10px] text-gray-400 uppercase font-bold mb-3 tracking-wider">
            Stock Level Monitoring (Real-time Factory Storage & Rack Occupancy)
          </div>
          <div className="flex items-end gap-1.5 h-20 bg-[#141414] p-2 rounded border border-gray-800/80">
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[80%] rounded-t transition-all" title="P-01: 80%"></div>
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[60%] rounded-t transition-all" title="P-02: 60%"></div>
            <div className="flex-1 bg-pink-600 hover:bg-pink-500 h-[20%] rounded-t transition-all" title="P-03: 20% (Low)"></div>
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[90%] rounded-t transition-all" title="P-04: 90%"></div>
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[75%] rounded-t transition-all" title="P-05: 75%"></div>
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[40%] rounded-t transition-all" title="P-06: 40%"></div>
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[55%] rounded-t transition-all" title="P-07: 55%"></div>
            <div className="flex-1 bg-pink-600 hover:bg-pink-500 h-[15%] rounded-t transition-all" title="P-08: 15% (Low)"></div>
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[85%] rounded-t transition-all" title="P-09: 85%"></div>
            <div className="flex-1 bg-[#0F5132] hover:bg-[#146c43] h-[70%] rounded-t transition-all" title="P-10: 70%"></div>
          </div>
          <div className="flex justify-between text-[9px] text-gray-500 mt-1 uppercase font-mono font-bold tracking-tight">
            <span>P-01</span><span>P-02</span><span>P-03</span><span>P-04</span><span>P-05</span><span>P-06</span><span>P-07</span><span>P-08</span><span>P-09</span><span>P-10</span>
          </div>
        </div>

        {/* Quick Actions Panel */}
        <div className="w-full md:w-64 flex flex-col gap-2 shrink-0">
          <div className="text-[10px] text-gray-400 uppercase font-bold mb-1 tracking-wider">
            Quick Actions
          </div>
          <button 
            onClick={handleEncodeBatch}
            className="w-full py-2 bg-pink-600 hover:bg-pink-700 text-white text-[10px] font-bold uppercase rounded transition-colors"
          >
            ENCODE NEW BATCH
          </button>
          <button 
            onClick={handleExport}
            className="w-full py-2 bg-white/5 hover:bg-white/10 text-gray-300 text-[10px] font-bold uppercase rounded border border-gray-700 transition-colors"
          >
            DOWNLOAD SHIFT REPORT
          </button>
          <button 
            onClick={() => onNavigate('sql_hub')}
            className="w-full py-2 bg-white/5 hover:bg-white/10 text-gray-300 text-[10px] font-bold uppercase rounded border border-gray-700 transition-colors flex items-center justify-center gap-1.5"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            <span>SYSTEM STATUS: ACTIVE</span>
          </button>
        </div>

      </div>

      {/* 4 PRIMARY STATUS CARDS (Status of Keep Sample, Y2K Masterlist, RS/IS Sample, Hold Sample per Dept) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
        
        {/* 1. Status of Keep Sample */}
        <div 
          id="card-status-keep-sample" 
          className="bg-[#1A1A1A] rounded border border-gray-800 overflow-hidden flex flex-col"
        >
          <div className="bg-[#D63384] text-white py-2 px-3 font-bold text-xs tracking-wide font-['Chakra_Petch'] uppercase flex items-center justify-between">
            <span>Status of Keep Sample</span>
            <span className="text-[10px] bg-black/30 px-2 py-0.5 rounded font-mono">
              TOTAL: {metrics.keepSample.total}
            </span>
          </div>
          <div className="p-3.5 flex-1 flex flex-col justify-center space-y-2 text-xs bg-[#161616]">
            <div className="flex items-center justify-between p-2 bg-[#222] rounded border border-gray-800">
              <span className="font-semibold text-gray-300">Returned to Original Box:</span>
              <span className="font-bold font-mono text-emerald-400 text-sm bg-emerald-950/50 border border-emerald-800/50 px-2.5 py-0.5 rounded">
                {metrics.keepSample.returnedToOriginalBox}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-[#222] rounded border border-gray-800">
              <span className="font-semibold text-gray-300">For Filing Of the UKS:</span>
              <span className="font-bold font-mono text-yellow-400 text-sm bg-yellow-950/50 border border-yellow-800/50 px-2.5 py-0.5 rounded">
                {metrics.keepSample.forFilingOfTheUKS}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-[#222] rounded border border-gray-800">
              <span className="font-semibold text-gray-300">Unreturned:</span>
              <span className="font-bold font-mono text-pink-400 text-sm bg-pink-950/50 border border-pink-800/50 px-2.5 py-0.5 rounded">
                {metrics.keepSample.unreturned}
              </span>
            </div>
          </div>
          <div className="px-3 py-1.5 bg-[#141414] border-t border-gray-800 flex justify-end">
            <button 
              onClick={() => onNavigate('keep_sample_request')}
              className="text-[11px] font-bold text-pink-400 hover:text-pink-300 flex items-center gap-1 font-mono uppercase"
            >
              <span>Manage Borrowers List →</span>
            </button>
          </div>
        </div>

        {/* 2. Status of Y2K Keep Sample Masterlist */}
        <div 
          id="card-status-y2k-masterlist" 
          className="bg-[#1A1A1A] rounded border border-gray-800 overflow-hidden flex flex-col"
        >
          <div className="bg-[#D63384] text-white py-2 px-3 font-bold text-xs tracking-wide font-['Chakra_Petch'] uppercase flex items-center justify-between">
            <span>Status of Y2K Keep Sample Masterlist</span>
            <span className="text-[10px] bg-black/30 px-2 py-0.5 rounded font-mono">
              TOTAL BOXES: {metrics.y2kMasterlist.total}
            </span>
          </div>
          <div className="p-3.5 flex-1 grid grid-cols-2 gap-2 text-xs bg-[#161616]">
            <div className="p-2 bg-[#222] rounded border border-gray-800 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-pink-400 uppercase">Expired:</span>
              <span className="text-lg font-black font-mono text-pink-400 mt-1">
                {metrics.y2kMasterlist.expired}
              </span>
            </div>
            <div className="p-2 bg-[#222] rounded border border-gray-800 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-emerald-400 uppercase">Not yet expired:</span>
              <span className="text-lg font-black font-mono text-emerald-400 mt-1">
                {metrics.y2kMasterlist.notYetExpired}
              </span>
            </div>
            <div className="p-2 bg-[#222] rounded border border-gray-800 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-yellow-400 uppercase">For Checking:</span>
              <span className="text-lg font-black font-mono text-yellow-400 mt-1">
                {metrics.y2kMasterlist.forChecking}
              </span>
            </div>
            <div className="p-2 bg-[#222] rounded border border-gray-800 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-blue-400 uppercase">Available Space:</span>
              <span className="text-lg font-black font-mono text-blue-400 mt-1">
                {metrics.y2kMasterlist.availableSpace}
              </span>
            </div>
          </div>
          <div className="px-3 py-1.5 bg-[#141414] border-t border-gray-800 flex justify-end">
            <button 
              onClick={() => onNavigate('y2k_masterlist')}
              className="text-[11px] font-bold text-pink-400 hover:text-pink-300 flex items-center gap-1 font-mono uppercase"
            >
              <span>Open Rack Location Master →</span>
            </button>
          </div>
        </div>

        {/* 3. Status of RS/IS Sample */}
        <div 
          id="card-status-rsis-sample" 
          className="bg-[#1A1A1A] rounded border border-gray-800 overflow-hidden flex flex-col"
        >
          <div className="bg-[#D63384] text-white py-2 px-3 font-bold text-xs tracking-wide font-['Chakra_Petch'] uppercase flex items-center justify-between">
            <span>Status of RS/IS Sample</span>
            <span className="text-[10px] bg-black/30 px-2 py-0.5 rounded font-mono">
              TOTAL: {metrics.rsIsSample.total}
            </span>
          </div>
          <div className="p-3.5 flex-1 flex flex-col justify-center space-y-2 text-xs bg-[#161616]">
            <div className="flex items-center justify-between p-2 bg-[#222] rounded border border-gray-800">
              <span className="font-semibold text-gray-300">For Receive:</span>
              <span className="font-bold font-mono text-blue-400 text-sm bg-blue-950/50 border border-blue-800/50 px-2.5 py-0.5 rounded">
                {metrics.rsIsSample.forReceive}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-[#222] rounded border border-gray-800">
              <span className="font-semibold text-gray-300">Pending For Disposition:</span>
              <span className="font-bold font-mono text-purple-400 text-sm bg-purple-950/50 border border-purple-800/50 px-2.5 py-0.5 rounded">
                {metrics.rsIsSample.pendingForDisposition}
              </span>
            </div>
            <div className="flex items-center justify-between p-2 bg-[#222] rounded border border-gray-800">
              <span className="font-semibold text-gray-300">For Return:</span>
              <span className="font-bold font-mono text-emerald-400 text-sm bg-emerald-950/50 border border-emerald-800/50 px-2.5 py-0.5 rounded">
                {metrics.rsIsSample.forReturn}
              </span>
            </div>
          </div>
          <div className="px-3 py-1.5 bg-[#141414] border-t border-gray-800 flex justify-end">
            <button 
              onClick={() => onNavigate('rsis_sample_entry')}
              className="text-[11px] font-bold text-pink-400 hover:text-pink-300 flex items-center gap-1 font-mono uppercase"
            >
              <span>Open RS/IS Scanner & Log →</span>
            </button>
          </div>
        </div>

        {/* 4. Status of Hold Sample (Total requests per department) */}
        <div 
          id="card-status-hold-sample" 
          className="bg-[#1A1A1A] rounded border border-gray-800 overflow-hidden flex flex-col"
        >
          <div className="bg-[#D63384] text-white py-2 px-3 font-bold text-xs tracking-wide font-['Chakra_Petch'] uppercase flex items-center justify-between">
            <span>Status of Hold Sample</span>
            <span className="text-[10px] bg-black/30 px-2 py-0.5 rounded font-mono">
              DEPT BREAKDOWN
            </span>
          </div>
          <div className="p-3.5 flex-1 bg-[#161616] flex flex-col justify-between">
            <div className="font-semibold text-gray-400 text-xs mb-2 uppercase tracking-wider font-mono">
              Total no. of Request per Department:
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
              {Object.entries(metrics.holdSampleByDept).map(([dept, count]) => (
                <div key={dept} className="bg-[#222] p-1.5 rounded border border-gray-800 text-center">
                  <div className="text-[10px] font-bold text-gray-400 truncate uppercase">{dept}</div>
                  <div className="text-sm font-black font-mono text-emerald-400">{count}</div>
                </div>
              ))}
              {Object.keys(metrics.holdSampleByDept).length === 0 && (
                <div className="col-span-3 text-center text-xs text-gray-500 py-3">
                  No active hold samples recorded
                </div>
              )}
            </div>
          </div>
          <div className="px-3 py-1.5 bg-[#141414] border-t border-gray-800 flex justify-end">
            <button 
              onClick={() => onNavigate('quality_analytics')}
              className="text-[11px] font-bold text-pink-400 hover:text-pink-300 flex items-center gap-1 font-mono uppercase"
            >
              <span>View Defect & Stage Breakdown →</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};

