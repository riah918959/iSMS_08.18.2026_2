import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  TrendingUp,
  Download,
  FileSpreadsheet,
  Printer,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Settings,
  Calendar,
  Sparkles
} from 'lucide-react';
import { UserProfile } from '../types';
import { storageService } from '../services/storageService';

interface QualityAnalyticsViewProps {
  currentUser: UserProfile;
}

export const QualityAnalyticsView: React.FC<QualityAnalyticsViewProps> = ({ currentUser }) => {
  const [timeRange, setTimeRange] = useState<'Daily' | 'Weekly' | 'Monthly' | 'Yearly'>('Monthly');
  const [selectedStage, setSelectedStage] = useState<string>('All');
  const [showYieldWidget, setShowYieldWidget] = useState(true);
  const [showDefectWidget, setShowDefectWidget] = useState(true);
  const [showStageScrapWidget, setShowStageScrapWidget] = useState(true);
  const [showComplianceWidget, setShowComplianceWidget] = useState(true);

  // Defect Pareto Data
  const defectParetoData = [
    { defect: 'Pin Insertion High Force', count: 48, cumulativePercent: 38 },
    { defect: 'Crimp Terminal Flare', count: 32, cumulativePercent: 63 },
    { defect: 'Insulator Flash/Burr', count: 21, cumulativePercent: 80 },
    { defect: 'Contact Plating Scratch', count: 14, cumulativePercent: 91 },
    { defect: 'Missing Waterproof Seal', count: 8, cumulativePercent: 97 },
    { defect: 'Others / Dimensional', count: 4, cumulativePercent: 100 }
  ];

  // Stage Yield Data
  const stageYieldData = [
    { stage: 'Stamping', target: 99.8, actual: 99.91, scrapCost: 120 },
    { stage: 'Molding', target: 99.5, actual: 99.64, scrapCost: 340 },
    { stage: 'Pin Insertion', target: 99.7, actual: 99.45, scrapCost: 510 },
    { stage: 'Pre-Assembly', target: 99.6, actual: 99.80, scrapCost: 220 },
    { stage: 'Harness Assy', target: 99.4, actual: 99.52, scrapCost: 680 },
    { stage: 'AOI Inspection', target: 99.9, actual: 99.88, scrapCost: 150 }
  ];

  // 12-Month Quality Trend
  const monthlyTrendData = [
    { month: 'Jan', fpy: 99.4, holdLots: 3, rsisDefects: 12 },
    { month: 'Feb', fpy: 99.6, holdLots: 1, rsisDefects: 9 },
    { month: 'Mar', fpy: 99.5, holdLots: 2, rsisDefects: 14 },
    { month: 'Apr', fpy: 99.7, holdLots: 0, rsisDefects: 7 },
    { month: 'May', fpy: 99.3, holdLots: 4, rsisDefects: 18 },
    { month: 'Jun', fpy: 99.8, holdLots: 1, rsisDefects: 6 },
    { month: 'Jul', fpy: 99.6, holdLots: 2, rsisDefects: 11 },
    { month: 'Aug', fpy: 99.9, holdLots: 0, rsisDefects: 4 }
  ];

  const COLORS = ['#10b981', '#ec4899', '#38bdf8', '#f59e0b', '#a855f7', '#f43f5e'];

  const handleExportQualityReport = () => {
    const csvContent = [
      ['JAE Quality Analytics Summary Report', `Generated: ${new Date().toISOString()}`],
      ['Time Range:', timeRange],
      ['Exported By:', `${currentUser.firstName} ${currentUser.lastName}`],
      [''],
      ['Defect Category', 'Defect Count', 'Pareto Cumulative %'],
      ...defectParetoData.map(d => [d.defect, d.count, `${d.cumulativePercent}%`]),
      [''],
      ['Manufacturing Stage', 'Target FPY %', 'Actual FPY %', 'Scrap Cost (USD)'],
      ...stageYieldData.map(s => [s.stage, `${s.target}%`, `${s.actual}%`, `$${s.scrapCost}`])
    ].map(e => e.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `JAE_Quality_Analytics_Report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="quality-analytics-view" className="p-4 md:p-6 space-y-6 w-full font-['Plus_Jakarta_Sans']">
      
      {/* Standardized Colorful Module Header (Green + Pink Palette, compact 3/4 layout) */}
      <div className="bg-gradient-to-r from-[#064e3b] via-[#0f5132] to-[#141414] border border-emerald-700/60 rounded-xl px-4 py-2.5 md:py-3 shadow-md flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-pink-600/20 text-pink-400 rounded-lg border border-pink-500/40 shadow-inner">
            <TrendingUp className="w-5 h-5 md:w-5 md:h-5 text-pink-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg md:text-xl font-extrabold text-white tracking-wide font-['Chakra_Petch'] uppercase">
                Sample Analytics Report
              </h1>
              <span className="text-[9px] px-2 py-0.5 bg-pink-950/80 text-pink-300 rounded-md font-mono font-bold border border-pink-700/60">
                FPY & YIELD ENGINE
              </span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex bg-[#141414] p-1 rounded-lg border border-slate-700 text-xs">
            {(['Daily', 'Weekly', 'Monthly', 'Yearly'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setTimeRange(r)}
                className={`px-3 py-1 rounded-md font-bold transition-all ${
                  timeRange === r
                    ? 'bg-gradient-to-r from-emerald-600 to-emerald-700 text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportQualityReport}
            className="px-3.5 py-1.5 bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-700 hover:to-rose-700 text-white rounded-lg text-xs font-bold shadow-xs flex items-center space-x-1.5 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* CUSTOMIZABLE WIDGET TOGGLES */}
      <div className="bg-[#1A1A1A] p-3 rounded-xl shadow-xs border border-emerald-800/40 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 font-bold text-slate-200">
          <Settings className="w-4 h-4 text-pink-400" />
          <span>Active Reporting Widgets:</span>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showYieldWidget}
              onChange={(e) => setShowYieldWidget(e.target.checked)}
              className="accent-pink-600 rounded"
            />
            <span className="font-semibold text-slate-300">First Pass Yield (FPY)</span>
          </label>
          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showDefectWidget}
              onChange={(e) => setShowDefectWidget(e.target.checked)}
              className="accent-pink-600 rounded"
            />
            <span className="font-semibold text-slate-300">Defect Pareto</span>
          </label>
          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showStageScrapWidget}
              onChange={(e) => setShowStageScrapWidget(e.target.checked)}
              className="accent-pink-600 rounded"
            />
            <span className="font-semibold text-slate-300">Stage Performance</span>
          </label>
          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={showComplianceWidget}
              onChange={(e) => setShowComplianceWidget(e.target.checked)}
              className="accent-pink-600 rounded"
            />
            <span className="font-semibold text-slate-300">Audit Compliance</span>
          </label>
        </div>
      </div>

      {/* KPI METRIC CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-sm">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Plantwide First Pass Yield</div>
          <div className="text-2xl font-black font-mono text-emerald-400 mt-1">99.78%</div>
          <div className="text-[11px] text-emerald-500 font-semibold mt-1">▲ +0.12% vs Target (99.50%)</div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-sm">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Total Logged RS/IS Defects</div>
          <div className="text-2xl font-black font-mono text-pink-400 mt-1">127 pcs</div>
          <div className="text-[11px] text-slate-400 font-semibold mt-1">Automotive line containment active</div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-sm">
          <div className="text-[11px] font-bold text-slate-400 uppercase">Average Disposition Pending</div>
          <div className="text-2xl font-black font-mono text-emerald-400 mt-1">1.8 Days</div>
          <div className="text-[11px] text-emerald-500 font-semibold mt-1">Target &lt; 3.0 Days met</div>
        </div>

        <div className="bg-[#1A1A1A] p-4 rounded-xl border border-emerald-800/40 shadow-sm">
          <div className="text-[11px] font-bold text-slate-400 uppercase">IATF 16949 Audit Compliance</div>
          <div className="text-2xl font-black font-mono text-emerald-400 mt-1">100.0%</div>
          <div className="text-[11px] text-emerald-500 font-semibold mt-1">0 Overdue Golden Samples</div>
        </div>
      </div>

      {/* CHARTS GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Widget 1: First Pass Yield Trend */}
        {showYieldWidget && (
          <div className="bg-[#1A1A1A] p-4 md:p-5 rounded-xl shadow-md border border-emerald-800/40 space-y-3">
             <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider font-['Chakra_Petch']">
                Monthly First Pass Yield (FPY %) Trend
              </span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950 border border-emerald-700/60 px-2 py-0.5 rounded">
                Target: &gt;99.5%
              </span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={monthlyTrendData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#262626" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} stroke="#404040" />
                  <YAxis domain={[99.0, 100.0]} tick={{ fontSize: 11, fill: '#94a3b8' }} stroke="#404040" tickFormatter={(v) => `${v}%`} />
                  <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#334155', color: '#fff', borderRadius: '8px' }} formatter={(val: any) => [`${val}%`, 'FPY']} />
                  <Legend wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
                  <Line type="monotone" dataKey="fpy" stroke="#10b981" strokeWidth={3} dot={{ r: 4, fill: '#10b981' }} name="FPY %" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Widget 2: Defect Pareto Distribution */}
        {showDefectWidget && (
          <div className="bg-[#1A1A1A] p-4 md:p-5 rounded-xl shadow-md border border-emerald-800/40 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider font-['Chakra_Petch']">
                Top Defect Pareto Distribution (80/20 Rule)
              </span>
              <span className="text-[10px] text-pink-300 font-bold bg-pink-950 border border-pink-700/60 px-2 py-0.5 rounded">
                Root Cause Priority
              </span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={defectParetoData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#262626" />
                  <XAxis type="number" tick={{ fontSize: 11, fill: '#94a3b8' }} stroke="#404040" />
                  <YAxis type="category" dataKey="defect" width={140} tick={{ fontSize: 10, fill: '#94a3b8' }} stroke="#404040" />
                  <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#334155', color: '#fff', borderRadius: '8px' }} />
                  <Bar dataKey="count" fill="#ec4899" radius={[0, 4, 4, 0]} name="Defect Quantity" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Widget 3: Stage Yield Comparison */}
        {showStageScrapWidget && (
          <div className="bg-[#1A1A1A] p-4 md:p-5 rounded-xl shadow-md border border-emerald-800/40 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider font-['Chakra_Petch']">
                Stage Target vs. Actual Yield
              </span>
              <span className="text-[10px] text-slate-400 font-mono">Stamping to Inspection</span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stageYieldData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#262626" />
                  <XAxis dataKey="stage" tick={{ fontSize: 10, fill: '#94a3b8' }} stroke="#404040" />
                  <YAxis domain={[99.0, 100.0]} tick={{ fontSize: 11, fill: '#94a3b8' }} stroke="#404040" tickFormatter={(v) => `${v}%`} />
                  <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#334155', color: '#fff', borderRadius: '8px' }} />
                  <Legend wrapperStyle={{ fontSize: 11, color: '#94a3b8' }} />
                  <Bar dataKey="actual" fill="#10b981" name="Actual Yield %" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="target" fill="#64748b" name="Target Yield %" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Widget 4: Defect Breakdown by Category */}
        {showComplianceWidget && (
          <div className="bg-[#1A1A1A] p-4 md:p-5 rounded-xl shadow-md border border-emerald-800/40 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="font-bold text-white text-xs uppercase tracking-wider font-['Chakra_Petch']">
                Defect Allocation Breakdown
              </span>
              <span className="text-[10px] text-slate-400 font-mono">By Failure Mechanism</span>
            </div>
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={defectParetoData}
                    dataKey="count"
                    nameKey="defect"
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    label={(entry) => `${entry.count} pcs`}
                  >
                    {defectParetoData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: '#141414', borderColor: '#334155', color: '#fff', borderRadius: '8px' }} />
                  <Legend wrapperStyle={{ fontSize: 10, color: '#94a3b8' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
