/**
 * iSMS - Integrated Sample Management System
 * JAE Philippines, Inc. Quality Management Department
 * Type Definitions & System Constants
 */

export type UserRole = 
  | 'User' 
  | 'QC Hold' 
  | 'QC Inspector' 
  | 'QM Hold' 
  | 'QM Admin' 
  | 'QM' 
  | 'QA' 
  | 'Admin' 
  | 'Sysadmin';

export type FactoryType = 'First Factory' | 'Second Factory';
export type FactoryCode = '1F' | '2F';

export type EmploymentStatus = 
  | 'JAE-Reg.' 
  | 'MDHII-Reg' 
  | 'FAMSI-Reg.' 
  | 'PKIMT-Reg.';

export type DepartmentType = 
  | 'Assembly' 
  | 'Molding' 
  | 'Stamping' 
  | 'QA' 
  | 'QM' 
  | 'PC' 
  | 'Warehouse';

export type SectionType =
  | 'Mfg. Connector'
  | 'Mfg. Molding (Inspection)'
  | 'Mfg. Molding (Operation)'
  | 'Mfg. Stamping'
  | 'Mfg. Harness (Process)'
  | 'Mfg. Harness (Taping)'
  | 'Mfg. PreAssy'
  | 'Mfg. Pre-Assy'
  | 'Assembly Tech 1F'
  | 'Assembly Tech 2F'
  | 'Mfg. Training'
  | 'Mfg. 8D Team'
  | 'Mfg. IQT'
  | "Eng'g Ass'y (Connector)"
  | "Eng'g Molding"
  | "Eng'g Stamping"
  | "Eng'g Harness (Process)"
  | "Eng'g Harness (Taping)"
  | "Eng'g Ass'y (Pre-Assy)"
  | 'QA 1F'
  | 'QA 2F'
  | 'QM 1F'
  | 'QM 2F'
  | 'PC 1F'
  | 'PC 2F'
  | 'Warehouse 1F'
  | 'Warehouse 2F'
  | 'MX CONNECTOR'
  | 'MX HARNESS'
  | 'MX PRE ASSY'
  | 'MX57 MANUAL'
  | 'MX57 AUTO'
  | 'VARIOUS'
  | 'MX HONDA'
  | 'QM/IQC'
  | 'OQC'
  | 'QA/QC'
  | 'STAMPING'
  | 'MOLDING'
  | 'WAREHOUSE';

export type PositionType =
  | 'Engineer_E'
  | 'Engineer_N'
  | 'Foreman_E'
  | 'Foreman_N'
  | 'Safety Officer_E'
  | 'Safety Officer_N'
  | 'Sr. Staff_E'
  | 'Sr. Staff_N'
  | 'Sr. Supervisor'
  | 'Sr. Trainer_E'
  | 'Sr. Trainer_N'
  | 'Staff_E'
  | 'Staff_N'
  | 'Supervisor'
  | 'Technical Foreman'
  | 'Trainer_E'
  | 'Trainer_N';

export type StorageAreaType = 
  | '1F MEZZANINE' 
  | 'F2B STORAGE' 
  | 'Y2K BUILDING';

export type ArchiveType = 
  | 'KS' 
  | 'FILES' 
  | 'DIECON' 
  | 'RS Sample' 
  | 'IQC KS';

export type SampleCategory = 
  | 'Insulator' 
  | 'Stamping' 
  | 'Connector' 
  | 'IQC' 
  | 'Harness Item' 
  | 'Die con' 
  | 'Pre-assembly';

export type KeepSampleBoxStatus = 
  | 'FOR CHECKING' 
  | 'AVAILABLE SPACE' 
  | 'EXPIRED' 
  | 'NOT YET EXPIRED';

export type KeepSampleRequestStatus = 
  | 'Pending QM Approval'
  | 'For QM Approval'
  | 'Approved by QM'
  | 'For Delivery'
  | 'For QC Delivery'
  | 'For Received'
  | 'Received'
  | 'For Return'
  | 'Returned'
  | 'Returned To Original Box' 
  | 'For Filling the UKS' 
  | 'For Filing the UKS'
  | 'Unreturned'
  | 'Pending Approval'
  | 'Approved'
  | 'Cancelled';

export type RSISStatus = 
  | 'For Filling' 
  | 'No Received Sample' 
  | 'For Disposition' 
  | 'Forwarded' 
  | 'Not Yet Forwarded' 
  | 'Open' 
  | 'Closed' 
  | 'Returned';

export type ProductionStage = 
  | 'Stamping' 
  | 'Molding' 
  | 'Pin Insertion' 
  | 'Pre-Assembly' 
  | 'Final Harness Assembly' 
  | 'Automated Optical Inspection' 
  | 'Quality Gate'
  | 'Taping'
  | 'Final Assembly'
  | 'IQC'
  | 'OQC';

export type UserActionPermission =
  | 'view'
  | 'edit'
  | 'update'
  | 'entry'
  | 'request'
  | 'lock'
  | 'display'
  | 'delete'
  | 'export';

export interface UserSectionAccess {
  section: SectionType;
  actions: UserActionPermission[];
}

export interface UserProfile {
  id: string;
  idNumber: string;
  employeeId?: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  factory: FactoryType;
  employmentStatus?: EmploymentStatus;
  department: DepartmentType;
  section: SectionType;
  position?: PositionType;
  username?: string;
  role: UserRole;
  email: string;
  avatarUrl?: string;
  isActive?: boolean;
  mustChangePassword?: boolean;
  permissions?: string[];
  allowedSections?: SectionType[];
  allowedActions?: UserActionPermission[];
  sectionAccess?: Record<string, UserActionPermission[]>;
  passwordNumeric?: string;
  status?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface KeepSampleBox {
  id: string;
  boxNumber: string; // Format: YY-MM-***-*F e.g., 24-08-001-2F
  factory: FactoryType;
  requestedBy: string;
  storageArea: StorageAreaType;
  section: SectionType;
  item: string;
  productFamily?: string;
  archiveType: ArchiveType;
  dateGenerated: string; // YYYY-MM-DD
  dateExpiration?: string; // YYYY-MM-DD
  expirationDate?: string;
  status: KeepSampleBoxStatus;
  boxState?: 'open' | 'closed'; // 'open' = Draft/Editable, 'closed' = Locked/Finalized (only QM Hold can edit)
  remarks: string;
  rackLocation?: string;
  occupiedSlots?: number;
  maxCapacity?: number;
  samples?: SampleItemRow[];
  createdAt?: string;
  updatedAt?: string;
}

export interface SampleItemRow {
  id: string;
  itemName: string;
  drawingNumber: string;
  poNumber: string;
  lotNumber: string;
  quantity: number;
  remarks?: string;
  defectType?: string;
  boxNo?: string;
  cavity?: string;
  cavityNo?: string;
  time?: string;
  unitQty?: string;
  process?: string;
}

export interface KeepSampleRequest {
  id: string;
  controlNo: string; // Format: BKS-YYMM-**** e.g. BKS-2601-0001
  date: string;
  requestorName: string;
  department: DepartmentType;
  section?: SectionType;
  factory: FactoryType;
  typeOfBorrowedSample: 'KS' | 'FILES' | 'Die con' | 'RS Sample';
  items: SampleItemRow[];
  dateNeeded: string;
  boxNumber: string;
  rackLocation: string;
  area: string; // Y2K Building, Mezzanine, F2B
  returnedDueDate: string;
  reason: string;
  remarks: string;
  
  // QM Department Authorization (Admin role)
  qmStaffEngineer: string;
  categoryOfSample: SampleCategory;
  approvedBy: string;
  endorsedBy: string;
  qmDate: string;
  qmStatus: 'Approved' | 'Not Yet Approved' | 'Rejected';

  // QC Hold Section
  deliveredBy: string;
  dateDelivered: string;
  returnedBy: string;
  dateReturned: string;
  fillingInBox: string;
  dateFiled: string;
  status: KeepSampleRequestStatus;
  
  // Lifecycle tracking
  receivedBy?: string;
  dateReceived?: string;
  qcDeliveryNotifiedAt?: string;
  requestorNotifiedAt?: string;
  returnNotifiedAt?: string;
  qmRemarks?: string;
  qcRemarks?: string;
  returnRemarks?: string;
  
  createdAt?: string;
  updatedAt?: string;
}

export interface RSISSampleRecord {
  id: string;
  controlNo: string; // RISR-YYMM-****
  rsIsNumber: string;
  date?: string;
  dateRequested?: string;
  sampleType: 'RS Sample' | 'IS Sample';
  
  // Requestor / Issued By
  issuedBy: string;
  requestorName?: string;
  department: DepartmentType;
  section: SectionType;
  dateForwarded?: string;
  items?: SampleItemRow[];
  dateNeeded?: string;
  returnedDueDate?: string;
  reason?: string;
  remarks?: string;
  typeOfDefect?: string;
  quantity: number;
  drawingNumber: string;
  poNumber: string;
  itemName: string;
  lotNumber: string;

  // QC Hold section
  receivedBy?: string;
  dateReceived?: string;
  qcHoldStatus: 'For Filling' | 'No Received Sample' | 'For Disposition' | 'Forwarded' | 'Not Yet Forwarded';
  qcDateForwarded?: string;
  qcReturnedBy?: string;
  qcDateReturned?: string;
  qcForwardedTo?: string;
  qcRemarks?: string;

  // QM Department section
  qmStaffEngineer?: string;
  qmCategoryOfSample?: SampleCategory;
  qmEndorsedToQA?: string;
  qmDate?: string;
  qmStatus?: 'Forwarded' | 'Not Yet Forwarded' | 'Approved' | 'Not Yet Approved';

  // QA Department section
  qaEngineer?: string;
  qaDateReceived?: string;
  qaReturnedTo?: string;
  qaDateReturned?: string;
  qaStatus?: 'Open' | 'Closed' | 'Returned';
  qaFindings?: string;

  createdAt?: string;
  updatedAt?: string;
}

export interface Y2KSampleLocation {
  id: string;
  no?: number;
  rackLocation: string; // e.g. RACK-A-01, RACK-B-04
  boxNumber: string;
  storageArea: StorageAreaType;
  year: number;
  section: SectionType;
  item: string;
  archiveType: ArchiveType;
  dateGenerated: string;
  expirationDate: string;
  status: KeepSampleBoxStatus;
  remarks: string;
  lastAuditedDate?: string;
}

export type PICNotificationStatus =
  | 'Not Sent'
  | 'Pending'
  | 'Notified'
  | 'Acknowledged'
  | 'Action Required'
  | 'Escalated'
  | 'Rescheduled'
  | 'Cancelled'
  | 'Failed';

export interface ProductionScheduleItem {
  id: string;
  jobOrderNo?: string;
  lotNumber?: string;
  partNumber?: string;
  productCode?: string; // e.g. MX57-24P-HDR, MX-CONN-04F
  partDescription?: string;
  productName?: string; // e.g. 24-Pin Sealed Automotive Header
  customer?: string; // Honda, Toyota, Nissan, Denso
  line?: string; // e.g. Line 1 Connector, Line 3 Harness
  lineName?: string;
  factory: FactoryType;
  targetQuantity: number;
  completedQuantity: number;
  defectQuantity: number;
  shift?: 'Day Shift (A)' | 'Night Shift (B)';
  stage: ProductionStage;
  status: 'In Progress' | 'Completed' | 'On Hold' | 'Scheduled' | 'Quality Gate Hold' | 'Delayed';
  scheduledDate?: string;
  startDate?: string;
  targetEndDate?: string;
  picStaff?: string;
  picName?: string;
  picDepartment?: DepartmentType | string;
  picNotificationStatus?: PICNotificationStatus;
  picNotificationDate?: string;
  picNotificationMethod?: 'Email' | 'System Alert' | 'SMS' | 'Push Notification' | 'Direct Dispatch';
  picNotificationSentBy?: string;
  picNotificationAcknowledgedAt?: string;
  picNotificationRemarks?: string;
  crimpHeightSpecMm?: string;
  pullForceSpecN?: string;
  notes?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  staffId?: string;
  actorEmployeeId?: string;
  staffName?: string;
  actorName?: string;
  role?: UserRole;
  actorRole?: UserRole;
  module: string;
  action: string;
  recordId?: string;
  targetId?: string;
  details: string;
  ipAddress?: string;
}

export type AuditLogEntry = AuditLog;

export interface EmailAlert {
  id: string;
  timestamp?: string;
  sentAt?: string;
  toEmail?: string;
  recipientEmail?: string;
  picName?: string;
  recipientName?: string;
  subject: string;
  triggerReason?: 'NO_RECEIVED_SAMPLE' | 'EXPIRED_SAMPLE' | 'OVERDUE_UNRETURNED' | 'QC_HOLD_DISPOSITION' | 'CRITICAL_DEFECT_DETECTED' | 'NO_RECEIVED_SAMPLE' | 'OVERDUE_SAMPLE' | 'EXPIRATION_WARNING' | 'QUALITY_GATE_HOLD';
  alertType?: 'NO_RECEIVED_SAMPLE' | 'OVERDUE_SAMPLE' | 'EXPIRATION_WARNING' | 'QUALITY_GATE_HOLD' | string;
  urgency?: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  status: 'SENT' | 'QUEUED' | 'Delivered' | string;
  body: string;
  relatedControlNo?: string;
  referenceControlNo?: string;
}

export type EmailAlertNotification = EmailAlert;

export interface SQLServerConfig {
  connectionString?: string;
  serverInstance?: string;
  serverName?: string; // DESKTOP-RLHCI2C\SQLEXPRESS (DESKTOP-RLHCI2C\Intel)
  databaseName: string; // ISMS_QM_DB
  authMode?: 'Windows Authentication' | 'SQL Server Authentication';
  username?: string;
  user?: string;
  port?: number;
  status: 'CONNECTED_LOCAL' | 'OFFLINE_READY' | 'SYNCHRONIZED' | 'Connected' | 'Offline' | string;
  lastSyncTimestamp: string;
  totalSyncedRecords?: number;
}

export type SQLConfig = SQLServerConfig;

export interface BatchJobDefinition {
  id: string;
  code: string;
  name: string;
  description: string;
  frequency: string;
  cronExpression?: string;
  category: 'RETENTION_SWEEP' | 'QC_ESCALATION' | 'OVERDUE_ALERT' | 'SQL_SYNC' | 'AUDIT_CHECKSUM';
  lastRunTimestamp?: string;
  nextScheduledRun: string;
  status: 'IDLE' | 'RUNNING' | 'SUCCESS' | 'WARNING' | 'FAILED';
  recordsAffectedLastRun: number;
  autoEnabled: boolean;
}

export interface BatchJobRunLog {
  id: string;
  batchJobId: string;
  batchName: string;
  timestamp: string;
  triggerType: 'MANUAL' | 'CRON_AUTOMATED' | 'EVENT_TRIGGERED';
  durationMs: number;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
  recordsProcessed: number;
  details: string;
  executedBy: string;
}

export interface QCHoldExpirationAnalysis {
  id: string;
  sourceType: 'RSIS_HOLD' | 'BORROW_RETURN_HOLD' | 'BOX_RETENTION_EXPIRY' | 'PRODUCTION_GATE_HOLD';
  referenceControlNo: string;
  lotNumber?: string;
  jobOrderNo?: string;
  partNumber?: string;
  partDescription: string;
  lineName?: string;
  factory: FactoryType;
  department: DepartmentType;
  section: SectionType;
  picName: string;
  picEmail: string;
  qcHoldStatus: string;
  expirationDate: string;
  daysRemaining: number;
  riskLevel: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  impactAnalysis: string;
  recommendedAction: string;
  batchScheduleImpact?: {
    jobOrderNo: string;
    stage: ProductionStage;
    scheduledDate: string;
    customer?: string;
    targetQuantity?: number;
  };
}
