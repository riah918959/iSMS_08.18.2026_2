// ==============================================================================
// JAE Philippines, Inc. - iSMS Enterprise Client API Service
// Connects to ASP.NET Core 8 Web API & SQL Server with Offline Fallback
// ==============================================================================

import { KeepSampleBox, KeepSampleRequest, RSISSampleRecord, AuditLog, UserProfile } from '../types';

export interface ApiHealthStatus {
  online: boolean;
  status: 'HEALTHY' | 'DEGRADED' | 'OFFLINE';
  system?: string;
  version?: string;
  environment?: string;
  latencyMs?: number;
  database?: {
    provider: string;
    connected: boolean;
    latencyMs?: number;
    error?: string | null;
  };
  errorMessage?: string;
}

export interface LoginResult {
  success: boolean;
  token?: string;
  refreshToken?: string;
  mustChangePassword?: boolean;
  user?: UserProfile;
  permissions?: string[];
  message: string;
}

class ApiClient {
  private baseUrl: string;
  private token: string | null = null;
  private refreshTokenVal: string | null = null;

  constructor() {
    this.baseUrl = (import.meta as any).env?.VITE_API_BASE_URL || '/api';
    this.token = sessionStorage.getItem('isms_jwt_token') || localStorage.getItem('isms_jwt_token');
    this.refreshTokenVal = sessionStorage.getItem('isms_refresh_token') || localStorage.getItem('isms_refresh_token');
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  public setBaseUrl(url: string) {
    this.baseUrl = url.replace(/\/+$/, '');
  }

  public setTokens(token: string | null, refreshToken?: string | null) {
    this.token = token;
    if (token) {
      sessionStorage.setItem('isms_jwt_token', token);
      localStorage.setItem('isms_jwt_token', token);
    } else {
      sessionStorage.removeItem('isms_jwt_token');
      localStorage.removeItem('isms_jwt_token');
    }

    if (refreshToken !== undefined) {
      this.refreshTokenVal = refreshToken;
      if (refreshToken) {
        sessionStorage.setItem('isms_refresh_token', refreshToken);
        localStorage.setItem('isms_refresh_token', refreshToken);
      } else {
        sessionStorage.removeItem('isms_refresh_token');
        localStorage.removeItem('isms_refresh_token');
      }
    }
  }

  public getToken(): string | null {
    return this.token || sessionStorage.getItem('isms_jwt_token') || localStorage.getItem('isms_jwt_token');
  }

  public getRefreshToken(): string | null {
    return this.refreshTokenVal || sessionStorage.getItem('isms_refresh_token') || localStorage.getItem('isms_refresh_token');
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<{ ok: boolean; status: number; data?: T; error?: string }> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {})
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      let res = await fetch(`${this.baseUrl}${endpoint}`, {
        ...options,
        credentials: 'include',
        headers
      });

      // Handle token expiration & automatic refresh
      if (res.status === 401 && this.getRefreshToken()) {
        const refreshSuccess = await this.refreshToken();
        if (refreshSuccess) {
          headers['Authorization'] = `Bearer ${this.getToken()}`;
          res = await fetch(`${this.baseUrl}${endpoint}`, {
            ...options,
            credentials: 'include',
            headers
          });
        }
      }

      if (res.ok) {
        const data = await res.json();
        return { ok: true, status: res.status, data };
      } else {
        let errorMsg = `HTTP ${res.status}: ${res.statusText}`;
        try {
          const errData = await res.json();
          if (errData.message) errorMsg = errData.message;
        } catch {
          // ignore non-json error
        }
        return { ok: false, status: res.status, error: errorMsg };
      }
    } catch (err: any) {
      return { ok: false, status: 0, error: err.message || 'Network connection failed' };
    }
  }

  // Real HTTP Health Probe to ASP.NET Core Backend
  public async checkHealth(): Promise<ApiHealthStatus> {
    const startTime = performance.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const res = await fetch(`${this.baseUrl}/health`, {
        method: 'GET',
        signal: controller.signal,
        headers: { 'Accept': 'application/json' }
      });
      clearTimeout(timeoutId);
      const elapsed = Math.round(performance.now() - startTime);

      if (res.ok) {
        const data = await res.json();
        return {
          online: true,
          status: data.status || 'HEALTHY',
          system: data.system,
          version: data.version,
          environment: data.environment,
          latencyMs: elapsed,
          database: data.database
        };
      } else {
        return {
          online: false,
          status: 'DEGRADED',
          latencyMs: elapsed,
          errorMessage: `HTTP ${res.status}: ${res.statusText}`
        };
      }
    } catch (err: any) {
      const elapsed = Math.round(performance.now() - startTime);
      return {
        online: false,
        status: 'OFFLINE',
        latencyMs: elapsed,
        errorMessage: err.name === 'AbortError' ? 'Connection timeout (4000ms)' : (err.message || 'Cannot reach ASP.NET Core API server at ' + this.baseUrl)
      };
    }
  }

  // Authentication Endpoints
  public async login(identifier: string, password: string): Promise<LoginResult> {
    try {
      const res = await fetch(`${this.baseUrl}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier, password })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        this.setTokens(data.token, data.refreshToken);
        const mappedUser: UserProfile = {
          id: data.user.userId || data.user.id,
          idNumber: data.user.employeeId || data.user.idNumber,
          employeeId: data.user.employeeId,
          firstName: data.user.firstName,
          lastName: data.user.lastName,
          username: data.user.username,
          email: data.user.email,
          department: data.user.department,
          section: data.user.section,
          factory: data.user.factory === '2F' ? 'Second Factory' : 'First Factory',
          role: data.user.roleId || data.user.role,
          mustChangePassword: data.mustChangePassword,
          permissions: data.permissions,
          isActive: true
        };
        return {
          success: true,
          token: data.token,
          refreshToken: data.refreshToken,
          mustChangePassword: data.mustChangePassword,
          user: mappedUser,
          permissions: data.permissions,
          message: data.message
        };
      } else {
        return {
          success: false,
          message: data.message || 'Authentication failed. Please verify your credentials.'
        };
      }
    } catch (err: any) {
      return { success: false, message: `API Connection Failed: ${err.message}` };
    }
  }

  public async refreshToken(): Promise<boolean> {
    const currentRefresh = this.getRefreshToken();
    if (!currentRefresh) return false;

    try {
      const res = await fetch(`${this.baseUrl}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: currentRefresh })
      });

      if (res.ok) {
        const data = await res.json();
        this.setTokens(data.token, data.refreshToken);
        return true;
      } else {
        this.setTokens(null, null);
        return false;
      }
    } catch {
      return false;
    }
  }

  public async logout(): Promise<void> {
    const refresh = this.getRefreshToken();
    try {
      await this.request('/auth/logout', {
        method: 'POST',
        body: JSON.stringify({ refreshToken: refresh })
      });
    } catch {
      // ignore network errors on logout
    } finally {
      this.setTokens(null, null);
    }
  }

  public async changePassword(currentPassword: string, newPassword: string): Promise<{ success: boolean; message: string }> {
    const res = await this.request<{ success: boolean; message: string }>('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword })
    });
    if (res.ok && res.data) {
      return { success: true, message: res.data.message || 'Password changed successfully.' };
    }
    return { success: false, message: res.error || 'Failed to update password.' };
  }

  // Keep Sample Endpoints
  public async getKeepSampleBoxes(): Promise<{ ok: boolean; data?: KeepSampleBox[]; error?: string }> {
    const res = await this.request<KeepSampleBox[]>('/KeepSample/boxes');
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async createKeepSampleBox(box: Partial<KeepSampleBox>): Promise<{ ok: boolean; data?: KeepSampleBox; error?: string }> {
    const res = await this.request<KeepSampleBox>('/KeepSample/boxes', {
      method: 'POST',
      body: JSON.stringify(box)
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async getKeepSampleRequests(): Promise<{ ok: boolean; data?: KeepSampleRequest[]; error?: string }> {
    const res = await this.request<KeepSampleRequest[]>('/KeepSample/requests');
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async createKeepSampleRequest(req: Partial<KeepSampleRequest>): Promise<{ ok: boolean; data?: KeepSampleRequest; error?: string }> {
    const res = await this.request<KeepSampleRequest>('/KeepSample/requests', {
      method: 'POST',
      body: JSON.stringify(req)
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async approveKeepSampleRequest(id: string): Promise<{ ok: boolean; data?: KeepSampleRequest; error?: string }> {
    const res = await this.request<KeepSampleRequest>(`/KeepSample/requests/${encodeURIComponent(id)}/approve`, {
      method: 'PUT'
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  // RS / IS Defect Endpoints
  public async getRSISRecords(): Promise<{ ok: boolean; data?: RSISSampleRecord[]; error?: string }> {
    const res = await this.request<RSISSampleRecord[]>('/RSIS');
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async createRSISRecord(record: Partial<RSISSampleRecord>): Promise<{ ok: boolean; data?: RSISSampleRecord; error?: string }> {
    const res = await this.request<RSISSampleRecord>('/RSIS', {
      method: 'POST',
      body: JSON.stringify(record)
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async qcIntakeRSIS(id: string): Promise<{ ok: boolean; data?: RSISSampleRecord; error?: string }> {
    const res = await this.request<RSISSampleRecord>(`/RSIS/${encodeURIComponent(id)}/qc-intake`, {
      method: 'PUT'
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async qmEndorseRSIS(id: string, endorsedQAEngineer: string): Promise<{ ok: boolean; data?: RSISSampleRecord; error?: string }> {
    const res = await this.request<RSISSampleRecord>(`/RSIS/${encodeURIComponent(id)}/qm-endorse`, {
      method: 'PUT',
      body: JSON.stringify({ endorsedQAEngineer })
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async qaDispositionRSIS(id: string, rootCause: string, finalDisposition: string, status: string = 'Closed'): Promise<{ ok: boolean; data?: RSISSampleRecord; error?: string }> {
    const res = await this.request<RSISSampleRecord>(`/RSIS/${encodeURIComponent(id)}/qa-disposition`, {
      method: 'PUT',
      body: JSON.stringify({ rootCause, finalDisposition, status })
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  // Audit Logs & Cryptographic Integrity Endpoints
  public async getAuditLogs(): Promise<{ ok: boolean; data?: AuditLog[]; error?: string }> {
    const res = await this.request<AuditLog[]>('/Audit');
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async verifyAuditIntegrity(): Promise<{ ok: boolean; data?: any; error?: string }> {
    const res = await this.request<any>('/Audit/verify-integrity');
    return { ok: res.ok, data: res.data, error: res.error };
  }

  // User Management Endpoints
  public async getUsers(): Promise<{ ok: boolean; data?: any[]; error?: string }> {
    const res = await this.request<any[]>('/Users');
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async createUser(userReq: any): Promise<{ ok: boolean; data?: any; error?: string }> {
    const res = await this.request<any>('/Users', {
      method: 'POST',
      body: JSON.stringify(userReq)
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async resetUserPassword(userId: string, newPassword: string): Promise<{ ok: boolean; data?: any; error?: string }> {
    const res = await this.request<any>(`/Users/${encodeURIComponent(userId)}/reset-password`, {
      method: 'POST',
      body: JSON.stringify({ newPassword })
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }

  public async toggleUserActive(userId: string): Promise<{ ok: boolean; data?: any; error?: string }> {
    const res = await this.request<any>(`/Users/${encodeURIComponent(userId)}/toggle-active`, {
      method: 'POST'
    });
    return { ok: res.ok, data: res.data, error: res.error };
  }
}

export const apiClient = new ApiClient();
