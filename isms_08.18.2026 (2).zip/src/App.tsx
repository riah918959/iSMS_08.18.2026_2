import React, { useState, useEffect } from 'react';
import { User, LogOut, Shield, ChevronDown, Check, Sparkles } from 'lucide-react';
import { Sidebar, NavTab, SidebarBadgeCounts } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { KeepSampleEntryView } from './components/KeepSampleEntryView';
import { KeepSampleRequestView } from './components/KeepSampleRequestView';
import { RSISSampleEntryView } from './components/RSISSampleEntryView';
import { RSISSampleRequestView } from './components/RSISSampleRequestView';
import { Y2KMasterlistView } from './components/Y2KMasterlistView';
import { BatchSchedulingView } from './components/BatchSchedulingView';
import { ProductionScheduleView } from './components/ProductionScheduleView';
import { QualityAnalyticsView } from './components/QualityAnalyticsView';
import { UserRegistryView } from './components/UserRegistryView';
import { PicAlertsView } from './components/PicAlertsView';
import { SqlHubView } from './components/SqlHubView';
import { AuditLogsView } from './components/AuditLogsView';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { DataImportModal, ImportCategory } from './components/DataImportModal';
import { LoginView } from './components/LoginView';
import { UserProfile, SQLConfig } from './types';
import { storageService } from './services/storageService';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [currentUser, setCurrentUser] = useState<UserProfile>(() => storageService.getCurrentUser());
  const [availableUsers, setAvailableUsers] = useState<UserProfile[]>(() => storageService.getUsers());
  const [sqlConfig, setSqlConfig] = useState<SQLConfig>(() => storageService.getSQLConfig());
  const [dataVersion, setDataVersion] = useState<number>(0);

  // Barcode Scanner Modal State
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannerCallback, setScannerCallback] = useState<((val: string) => void) | null>(null);

  // Bulk Data Import Modal State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importCategory, setImportCategory] = useState<ImportCategory>('KEEP_SAMPLE_BOX');

  // Connected RS/IS Request & Sample Entry Synchronization State
  const [rsisFilterQuery, setRsisFilterQuery] = useState<string>('');
  const [rsisTargetRequestId, setRsisTargetRequestId] = useState<string>('');

  // Badge Counts for Sidebar
  const [badgeCounts, setBadgeCounts] = useState<SidebarBadgeCounts>({
    keepSampleBoxes: 0,
    keepSampleRequests: 0,
    rsisRecords: 0,
    rsisRequests: 0,
    productionAlerts: 0,
    emailAlerts: 0
  });

  const refreshBadges = () => {
    const boxes = storageService.getKeepSampleBoxes();
    const ksReqs = storageService.getKeepSampleRequests();
    const rsis = storageService.getRSISRecords();
    const emails = storageService.getEmailAlerts();
    const sched = storageService.getProductionSchedules();
    const users = storageService.getUsers();

    setBadgeCounts({
      keepSampleBoxes: boxes.filter(b => b.status === 'EXPIRED' || b.status === 'FOR CHECKING').length,
      keepSampleRequests: ksReqs.filter(r => r.status === 'Unreturned').length,
      rsisRecords: rsis.filter(r => r.qcHoldStatus === 'No Received Sample' || r.qaStatus === 'Open').length,
      rsisRequests: rsis.filter(r => r.qmStatus === 'Not Yet Approved').length,
      productionAlerts: sched.filter(s => s.status === 'Quality Gate Hold').length,
      emailAlerts: emails.length,
      unreturnedCount: ksReqs.filter(r => r.status === 'Unreturned').length,
      pendingDispositionCount: rsis.filter(r => r.qcHoldStatus === 'No Received Sample').length,
      expiredCount: boxes.filter(b => b.status === 'EXPIRED').length,
      criticalAlertsCount: emails.filter(e => e.urgency === 'CRITICAL' || e.triggerReason === 'NO_RECEIVED_SAMPLE').length
    });
    
    setAvailableUsers(users);
    setSqlConfig(storageService.getSQLConfig());
    setDataVersion(v => v + 1);
  };

  useEffect(() => {
    refreshBadges();
  }, []);

  const handleSwitchUser = (u: UserProfile) => {
    storageService.setCurrentUser(u);
    setCurrentUser(u);
    refreshBadges();
  };

  const handleLoginSuccess = (u: UserProfile) => {
    setCurrentUser(u);
    setIsLoggedIn(true);
    refreshBadges();
  };

  const handleLockStation = () => {
    setIsLoggedIn(false);
  };

  const handleOpenScanner = (onScanned: (val: string) => void) => {
    setScannerCallback(() => onScanned);
    setScannerOpen(true);
  };

  const handleScannedResult = (val: string) => {
    if (scannerCallback) {
      scannerCallback(val);
    }
  };

  const handleOpenImportModal = (cat?: ImportCategory) => {
    if (cat) setImportCategory(cat);
    setIsImportModalOpen(true);
  };

  const handleGlobalSearch = (query: string) => {
    if (!query.trim()) return;
    const q = query.trim().toUpperCase();

    if (q.startsWith('BKS-')) {
      setCurrentTab('keep_sample_request');
    } else if (q.startsWith('RISR-')) {
      setCurrentTab('rsis_sample_request');
    } else if (q.includes('BOX') || q.includes('-1F') || q.includes('-2F')) {
      setCurrentTab('keep_sample_entry');
    } else if (q.includes('RACK') || q.includes('Y2K')) {
      setCurrentTab('y2k_masterlist');
    } else if (q.includes('LINE') || q.includes('BATCH')) {
      setCurrentTab('batch_scheduling');
    }
  };

  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const getTabInfo = (tab: NavTab) => {
    switch (tab) {
      case 'dashboard':
        return { title: 'Executive Summary Dashboard', category: 'Summary Notification' };
      case 'batch_scheduling':
        return { title: 'Batch Scheduling & Maintenance', category: 'Summary Notification' };
      case 'production_schedule':
        return { title: 'Production Schedules & Lot Tracking', category: 'Summary Notification' };
      case 'quality_analytics':
        return { title: 'Quality & Crimp Analytics', category: 'Summary Notification' };
      case 'keep_sample_entry':
        return { title: 'Keep Sample & Box Masterlist', category: 'Keep Sample' };
      case 'rsis_sample_entry':
        return { title: 'RS / IS Sample & Investigation Masterlist', category: 'RS / IS Sample' };
      case 'y2k_masterlist':
        return { title: 'Y2K Physical Location Masterlist', category: 'Location' };
      case 'keep_sample_request':
        return { title: 'Keep Sample Borrow Request', category: 'Request' };
      case 'rsis_sample_request':
        return { title: 'RS / IS Sample Borrow Request', category: 'Request' };
      case 'user_registry':
        return { title: 'User & Shift Registry', category: 'Administration & System' };
      case 'pic_alerts':
        return { title: 'P.I.C. Notification Center', category: 'Administration & System' };
      case 'sql_hub':
        return { title: 'MS SQL Server Database Hub', category: 'Administration & System' };
      case 'audit_logs':
        return { title: 'System Audit Trail & Telemetry', category: 'Administration & System' };
      default:
        return { title: 'Quality Sample Management System', category: 'JAE QM' };
    }
  };

  const currentTabInfo = getTabInfo(currentTab);

  // If not logged in, display the full Login View with JAE 2nd Plant facility background
  if (!isLoggedIn) {
    return (
      <LoginView
        onLoginSuccess={handleLoginSuccess}
        availableUsers={availableUsers}
      />
    );
  }

  return (
    <div className="h-screen w-full bg-[#121212] flex flex-col text-white font-['Plus_Jakarta_Sans'] antialiased overflow-hidden">
      
      {/* Main Container with Sidebar + Content View */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Navigation Sidebar with Corporate Header and Separated Categories */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          badgeCounts={badgeCounts}
          userRole={currentUser.role}
          onLockStation={handleLockStation}
          onOpenImportModal={() => handleOpenImportModal()}
        />

        {/* Dynamic Main Column with Top Header and Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden bg-[#121212]">
          
          {/* Top Bar with Clean Header Title, User Profile Name, Icon, Role, Switcher, and Logout Button */}
          <header className="h-14 bg-gradient-to-r from-[#141414] via-[#161f1a] to-[#141414] border-b border-emerald-900/40 px-4 md:px-6 flex items-center justify-between shrink-0 select-none z-20">
            
            {/* Left: Active Module Title */}
            <div className="flex items-center space-x-2 text-xs">
              <span className="text-white font-extrabold tracking-wide font-['Chakra_Petch'] text-sm md:text-base">
                {currentTabInfo.title}
              </span>
            </div>

            {/* Right: Restored User Profile Name, Icon, Role, Switcher, and Logout Button */}
            <div className="flex items-center space-x-3">
              
              {/* User Identity Info Card & Switcher Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2.5 px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-emerald-700/40 transition-all shadow-xs"
                  title="Switch Active Operator / Profile"
                >
                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-pink-600 to-rose-500 flex items-center justify-center text-white font-bold text-xs border border-pink-400/80 shadow-xs shrink-0">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  
                  <div className="flex flex-col text-left hidden sm:flex">
                    <div className="flex items-center space-x-1.5">
                      <span className="text-xs font-bold text-white leading-tight">
                        {currentUser.firstName} {currentUser.lastName}
                      </span>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-pink-500/20 text-pink-300 border border-pink-500/30">
                        {currentUser.role}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 leading-tight">
                      {currentUser.idNumber || currentUser.username} • {currentUser.department}
                    </span>
                  </div>

                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                </button>

                {/* Operator Switcher Dropdown Menu */}
                {isUserMenuOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-30"
                      onClick={() => setIsUserMenuOpen(false)}
                    />
                    <div className="absolute right-0 mt-2 w-64 bg-[#1a1a1a] border border-emerald-800/60 rounded-xl shadow-2xl z-40 overflow-hidden py-1.5 animate-in fade-in zoom-in-95 duration-150">
                      <div className="px-3 py-2 border-b border-slate-700/60 text-[10px] uppercase font-bold text-slate-400 flex items-center justify-between">
                        <span>Switch Active Operator</span>
                        <span className="text-emerald-400 font-mono">IATF RBAC</span>
                      </div>
                      <div className="max-h-56 overflow-y-auto py-1">
                        {availableUsers.map((u) => {
                          const isCurrent = u.id === currentUser.id;
                          return (
                            <button
                              key={u.id}
                              onClick={() => {
                                handleSwitchUser(u);
                                setIsUserMenuOpen(false);
                              }}
                              className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-800 transition-colors ${
                                isCurrent ? 'bg-pink-950/40 text-pink-300 font-bold' : 'text-slate-200'
                              }`}
                            >
                              <div className="flex flex-col">
                                <span className="font-semibold">{u.firstName} {u.lastName}</span>
                                <span className="text-[10px] font-mono text-slate-400">
                                  {u.idNumber} • {u.role} ({u.department})
                                </span>
                              </div>
                              {isCurrent && <Check className="w-3.5 h-3.5 text-pink-400 shrink-0" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Logout / Lock Station Button with Icon */}
              <button
                onClick={handleLockStation}
                title="Log Out / Lock Workstation"
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 text-rose-200 border border-rose-700/60 rounded-xl text-xs font-bold transition-all shadow-xs hover:shadow-rose-950/50"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-400" />
                <span className="hidden md:inline">Logout</span>
              </button>

            </div>
          </header>

          {/* Dynamic Main Content Area */}
          <main className="flex-1 overflow-y-auto bg-[#121212] p-2 md:p-4 w-full">
          
          {/* PRODUCTION CONTROL */}
          {currentTab === 'dashboard' && (
            <DashboardView
              onNavigate={(tab) => setCurrentTab(tab as NavTab)}
              currentUser={currentUser}
            />
          )}

          {currentTab === 'batch_scheduling' && (
            <BatchSchedulingView
              key={`batch-${dataVersion}`}
              currentUser={currentUser}
            />
          )}

          {currentTab === 'production_schedule' && (
            <ProductionScheduleView
              key={`prod-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
            />
          )}

          {currentTab === 'quality_analytics' && (
            <QualityAnalyticsView
              currentUser={currentUser}
            />
          )}

          {/* SAMPLE ENTRY */}
          {currentTab === 'keep_sample_entry' && (
            <KeepSampleEntryView
              key={`ks-entry-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
              onOpenScanner={handleOpenScanner}
            />
          )}

          {currentTab === 'rsis_sample_entry' && (
            <RSISSampleEntryView
              key={`rsis-entry-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
              onOpenScanner={handleOpenScanner}
              initialFilterQuery={rsisFilterQuery}
              initialLinkedRequestId={rsisTargetRequestId}
              onNavigateToRequest={(requestId) => {
                if (requestId) setRsisTargetRequestId(requestId);
                setCurrentTab('rsis_sample_request');
              }}
            />
          )}

          {currentTab === 'y2k_masterlist' && (
            <Y2KMasterlistView
              key={`y2k-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
            />
          )}

          {/* REQUEST SAMPLE */}
          {currentTab === 'keep_sample_request' && (
            <KeepSampleRequestView
              key={`ks-req-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
            />
          )}

          {currentTab === 'rsis_sample_request' && (
            <RSISSampleRequestView
              key={`rsis-req-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
              onNavigateToEntry={(recordId, filterQuery) => {
                if (recordId) setRsisTargetRequestId(recordId);
                if (filterQuery !== undefined) setRsisFilterQuery(filterQuery);
                setCurrentTab('rsis_sample_entry');
              }}
            />
          )}

          {/* ADMINISTRATION & SYSTEM */}
          {currentTab === 'user_registry' && (
            <UserRegistryView
              key={`users-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
              onSwitchUser={handleSwitchUser}
            />
          )}

          {currentTab === 'pic_alerts' && (
            <PicAlertsView
              key={`alerts-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
            />
          )}

          {currentTab === 'sql_hub' && (
            <SqlHubView
              key={`sql-${dataVersion}`}
              currentUser={currentUser}
              onRefreshData={refreshBadges}
            />
          )}

          {currentTab === 'audit_logs' && (
            <AuditLogsView
              key={`audit-${dataVersion}`}
              currentUser={currentUser}
            />
          )}

        </main>
        </div>
      </div>

      {/* High Density Status Bar Footer */}
      <footer className="h-8 bg-[#0F5132] flex items-center px-4 md:px-6 justify-between text-[10px] font-mono text-white/90 border-t border-emerald-800 shrink-0 select-none">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-green-400"></span>
            <span className="font-bold">STATUS: OPERATIONAL</span>
          </div>
          <span className="hidden sm:inline opacity-70">•</span>
          <span className="hidden sm:inline">LATENCY: 12ms</span>
          <span className="hidden sm:inline opacity-70">•</span>
          <span className="hidden sm:inline text-emerald-200">ON-PREMISES SECURE (ZERO AI CALLS)</span>
        </div>
        <div className="flex items-center gap-4">
          <span>SEC LEVEL: 4 (IATF 16949)</span>
          <span className="opacity-70">•</span>
          <span className="font-bold text-pink-300">USER: {currentUser.idNumber || currentUser.username} ({currentUser.role})</span>
        </div>
      </footer>

      {/* Global Barcode & QR Scanner Modal */}
      <BarcodeScannerModal
        isOpen={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScanned={handleScannedResult}
      />

      {/* Bulk Data Import Modal */}
      <DataImportModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onImportComplete={refreshBadges}
        initialCategory={importCategory}
      />

    </div>
  );
}
